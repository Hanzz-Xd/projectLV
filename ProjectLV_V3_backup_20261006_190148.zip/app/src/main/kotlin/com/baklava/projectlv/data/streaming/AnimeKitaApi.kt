package com.baklava.projectlv.data.streaming

import com.baklava.projectlv.data.network.HttpClientProvider
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.RequestBody
import okhttp3.ResponseBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface AnimeKitaApi {
    @GET("home/ongoing.php")
    suspend fun getOngoing(
        @Query("page") page: Int,
        @Query("type") type: String = "all"
    ): List<AnimeListItem>

    @GET("baruupload.php")
    suspend fun getLatest(@Query("page") page: Int): List<AnimeListItem>

    @GET("home/all.php")
    suspend fun getAllAnime(@Query("page") page: Int): List<AnimeListItem>

    @POST("series.php")
    suspend fun getSeries(
        @Query("url") url: String,
        @Body request: RequestBody
    ): ResponseBody

    @GET("search.php")
    suspend fun search(
        @Query("keyword") keyword: String,
        @Query("page") page: Int,
        @Query("per_page") perPage: Int = 20
    ): AnimeSearchResponse

    @GET("movie.php")
    suspend fun getMovies(): List<AnimeListItem>

    @POST("series/episode/data.php")
    suspend fun getEpisodeStreams(
        @Query("url") url: String,
        @Body request: RequestBody
    ): EpisodeStreamResponse
}

/**
 * The API wrapper intentionally keeps the transport separate from the existing
 * tools repository so Streaming Mode can evolve without affecting the toolkit.
 */
object AnimeKitaApiProvider {
    private const val BASE_URL = "https://apps.animekita.org/api/v1.2.5/"

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val requestMediaType = "text/plain; charset=utf-8".toMediaType()
    private val seriesRequestAdapter = moshi.adapter(SeriesRequest::class.java)
    private val episodeRequestAdapter = moshi.adapter(EpisodeRequest::class.java)

    fun seriesBody(request: SeriesRequest): RequestBody =
        seriesRequestAdapter.toJson(request).toRequestBody(requestMediaType)

    fun episodeBody(request: EpisodeRequest): RequestBody =
        episodeRequestAdapter.toJson(request).toRequestBody(requestMediaType)

    fun unwrapJsonString(raw: String): String {
        return runCatching {
            moshi.adapter(String::class.java).fromJson(raw)
        }.getOrNull()?.trim().orEmpty().ifBlank { raw }
    }

    val api: AnimeKitaApi by lazy {
        val client = HttpClientProvider.okHttpClient.newBuilder()
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header("User-Agent", "Dart/3.9 (dart:io)")
                    .header("Accept", "application/json")
                    .build()
                chain.proceed(request)
            }
            .build()
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi).asLenient())
            .build()
            .create(AnimeKitaApi::class.java)
    }
}
