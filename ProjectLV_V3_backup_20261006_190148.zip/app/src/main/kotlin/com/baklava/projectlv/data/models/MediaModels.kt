package com.baklava.projectlv.data.models

/**
 * Jenis file yang didukung oleh endpoint upload (api/tools/upload).
 * Dipakai untuk validasi ekstensi & filter file picker di UI, serta
 * fallback mimetype kalau ContentResolver tidak bisa menebaknya.
 */
enum class MediaFileType(val extensions: List<String>, val defaultMime: String, val label: String) {
    IMAGE(listOf("png", "jpg", "jpeg", "gif", "webp"), "image/png", "Gambar"),
    PDF(listOf("pdf"), "application/pdf", "PDF"),
    DOC(listOf("doc", "docx"), "application/msword", "Dokumen Word"),
    XLS(listOf("xls", "xlsx"), "application/vnd.ms-excel", "Spreadsheet Excel"),
    PPT(listOf("ppt", "pptx"), "application/vnd.ms-powerpoint", "Presentasi PowerPoint");

    companion object {
        /** Deteksi MediaFileType dari ekstensi nama file. Null kalau ekstensi tidak didukung. */
        fun fromExtension(extension: String): MediaFileType? {
            val ext = extension.lowercase()
            return values().firstOrNull { ext in it.extensions }
        }

        /** MIME string gabungan seluruh tipe yang didukung, dipakai sebagai filter file picker (ACTION_GET_CONTENT). */
        val ALL_SUPPORTED_MIME_TYPES = arrayOf(
            "image/png", "image/jpeg", "image/gif", "image/webp",
            "application/pdf",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-powerpoint",
            "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        )
    }
}

/** Hasil upload file publik dari endpoint api/tools/upload. */
data class MediaUploadResult(
    val directUrl: String,
    val originalName: String,
    val size: Long,
    val mimetype: String
)

/** Hasil proses upscale gambar: file lokal (cache) hasil PNG dari endpoint api/tools/upscale. */
data class UpscaleResult(
    val localFilePath: String,
    val scale: Int
)
