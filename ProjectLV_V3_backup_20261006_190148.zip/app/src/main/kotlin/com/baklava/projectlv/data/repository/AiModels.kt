package com.baklava.projectlv.data.repository

enum class StromAiModel(
    val displayName: String,
    val shortName: String,
    val supportsFileUpload: Boolean
) {
    STROM(
        displayName = "STROM AI",
        shortName = "STROM",
        supportsFileUpload = true
    ),
    CLAUDE(
        displayName = "Claude Opus 4.8",
        shortName = "CLAUDE",
        supportsFileUpload = false
    ),
    CHATGPT(
        displayName = "GPT-OSS 20B",
        shortName = "CHATGPT",
        supportsFileUpload = false
    ),
    DEEPSEEK_FLASH(
        displayName = "DeepSeek V4 Flash",
        shortName = "DEEPSEEK FLASH",
        supportsFileUpload = false
    ),
    DEEPSEEK_PRO(
        displayName = "DeepSeek V4 Pro",
        shortName = "DEEPSEEK PRO",
        supportsFileUpload = false
    )
}
