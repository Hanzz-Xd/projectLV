package com.baklava.projectlv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.baklava.projectlv.data.admin.AdminControlManager
import com.baklava.projectlv.data.admin.GlobalControlState
import com.baklava.projectlv.data.admin.GlobalToolPolicy
import com.baklava.projectlv.data.network.NetworkMonitor
import com.baklava.projectlv.data.network.NetworkStatus
import com.baklava.projectlv.data.repository.ErrorReportManager
import com.baklava.projectlv.data.security.FirebaseSecurityManager
import com.baklava.projectlv.data.security.FirebaseUserAuthManager
import com.baklava.projectlv.ui.security.DeviceBlockedScreen
import com.baklava.projectlv.ui.maintenance.MaintenanceScreen
import com.baklava.projectlv.ui.auth.AuthScreen
import com.baklava.projectlv.data.repository.LeviathanRepository
import com.baklava.projectlv.data.storage.LocalWorkspaceManager
import com.baklava.projectlv.data.storage.ChatHistoryManager
import com.baklava.projectlv.ui.components.AppCreditDialog
import com.baklava.projectlv.ui.components.ErrorReportDialog
import com.baklava.projectlv.ui.components.LeviathanDestination
import com.baklava.projectlv.ui.components.LeviathanScaffold
import com.baklava.projectlv.ui.components.LocalAppWindowSize
import com.baklava.projectlv.ui.components.rememberAppWindowSize
import com.baklava.projectlv.ui.admin.AdminEntryScreen
import com.baklava.projectlv.ui.admin.AdminSystemGate
import com.baklava.projectlv.ui.admin.AnnouncementBanner
import com.baklava.projectlv.data.admin.AnnouncementSeenStore
import com.baklava.projectlv.ui.dashboard.DashboardScreen
import com.baklava.projectlv.ui.modules.base64.Base64LabScreen
import com.baklava.projectlv.ui.modules.downloader.DownloaderScreen
import com.baklava.projectlv.ui.modules.magiclink.MagicLinkScreen
import com.baklava.projectlv.ui.modules.media.MediaScreen
import com.baklava.projectlv.ui.modules.pyobfuscator.PyObfuscatorScreen
import com.baklava.projectlv.ui.modules.pterodactyl.PterodactylWhatsAppScreen
import com.baklava.projectlv.ui.modules.alightfinder.AlightMotionFinderScreen
import com.baklava.projectlv.ui.modules.sflbypass.SflBypassScreen
import com.baklava.projectlv.ui.modules.stromai.StromAiScreen
import com.baklava.projectlv.ui.modules.webtools.WebToolsScreen
import com.baklava.projectlv.ui.modules.tiktokquality.TikTokQualityScreen
import com.baklava.projectlv.ui.settings.SettingsScreen
import com.baklava.projectlv.ui.streaming.StreamingScreen
import com.baklava.projectlv.data.streaming.StreamingLocalStore
import com.baklava.projectlv.data.streaming.StreamingCloudSyncManager
import com.baklava.projectlv.ui.splash.BootDiagnosticsManager
import com.baklava.projectlv.ui.splash.SplashScreen
import com.baklava.projectlv.ui.theme.LeviathanTheme
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch

enum class AppNavState {
    AUTH_REQUIRED,
    SPLASH,
    MAIN_APP,
    DEVICE_BLOCKED
}

class MainActivity : ComponentActivity() {

    private lateinit var networkMonitor: NetworkMonitor
    private lateinit var adminControlManager: AdminControlManager
    private lateinit var errorReportManager: ErrorReportManager
    private lateinit var workspaceManager: LocalWorkspaceManager
    private lateinit var repository: LeviathanRepository
    private lateinit var chatHistoryManager: ChatHistoryManager
    private lateinit var bootDiagnosticsManager: BootDiagnosticsManager
    private lateinit var firebaseSecurityManager: FirebaseSecurityManager
    private lateinit var firebaseUserAuthManager: FirebaseUserAuthManager
    private lateinit var streamingLocalStore: StreamingLocalStore
    private lateinit var streamingCloudSyncManager: StreamingCloudSyncManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Core System Services
        networkMonitor = NetworkMonitor(applicationContext)
        adminControlManager = AdminControlManager(applicationContext)
        errorReportManager = ErrorReportManager(applicationContext, networkMonitor, adminControlManager)
        workspaceManager = LocalWorkspaceManager(applicationContext)
        chatHistoryManager = ChatHistoryManager(applicationContext)
        repository = LeviathanRepository(applicationContext, errorReportManager, workspaceManager)
        firebaseSecurityManager = FirebaseSecurityManager(applicationContext)
        firebaseUserAuthManager = FirebaseUserAuthManager(applicationContext)
        streamingLocalStore = StreamingLocalStore(applicationContext)
        val initialFirebaseUser = firebaseUserAuthManager.currentUser
        streamingLocalStore.activateUser(initialFirebaseUser?.takeIf { it.isEmailVerified }?.uid)
        streamingCloudSyncManager = StreamingCloudSyncManager(streamingLocalStore, firebaseUserAuthManager)
        streamingCloudSyncManager.start()

        bootDiagnosticsManager = BootDiagnosticsManager(
            applicationContext,
            networkMonitor,
            repository,
            errorReportManager,
            firebaseSecurityManager
        )

        setContent {
            val windowSize = rememberAppWindowSize()
            val snackbarHostState = remember { SnackbarHostState() }
            val scope = rememberCoroutineScope()
            val announcementSeenStore = remember { AnnouncementSeenStore(applicationContext) }

            val networkStatus by networkMonitor.status.collectAsState()
            val isOnline = networkStatus is NetworkStatus.Connected

            val firebaseUser by firebaseUserAuthManager.observeAuthState().collectAsStateWithLifecycle(initialValue = firebaseUserAuthManager.currentUser)
            val globalControlFlow = remember(adminControlManager, firebaseUser?.uid) {
                if (firebaseUser != null) adminControlManager.observeGlobalControl() else flowOf(GlobalControlState())
            }
            val announcementsFlow = remember(adminControlManager, firebaseUser?.uid) {
                if (firebaseUser != null) adminControlManager.observeAnnouncements() else flowOf(emptyList())
            }
            val globalControl by globalControlFlow.collectAsStateWithLifecycle(initialValue = null)
            val announcements by announcementsFlow.collectAsStateWithLifecycle(initialValue = emptyList())
            val isAdmin by remember(adminControlManager, firebaseUser?.uid) {
                if (firebaseUser != null) adminControlManager.observeAdminRecord() else flowOf(false)
            }.collectAsStateWithLifecycle(initialValue = false)

            var navState by remember {
                mutableStateOf(if (firebaseUserAuthManager.currentUser == null) AppNavState.AUTH_REQUIRED else AppNavState.SPLASH)
            }
            var currentDestination by remember { mutableStateOf(LeviathanDestination.DASHBOARD) }
            var showCreditDialog by remember { mutableStateOf(false) }
            var showAdminPanel by remember { mutableStateOf(false) }
            // true saat player Streaming Anime aktif (landscape + fullscreen). Dipakai untuk
            // menyembunyikan nav global / padding status bar supaya video benar-benar penuh.
            var streamingImmersive by remember { mutableStateOf(false) }
            val immersiveActive = streamingImmersive &&
                currentDestination == LeviathanDestination.STREAMING_ANIME

            // Real-time device access. Collected for the lifetime of the app so an
            // admin ban (or unban) is reflected immediately no matter which screen
            // is currently showing, without waiting for the next boot check.
            val realtimeAccessFlow = remember(bootDiagnosticsManager) { bootDiagnosticsManager.observeSecurityAccess() }
            val realtimeAccess by realtimeAccessFlow.collectAsStateWithLifecycle(initialValue = null)
            val isRealtimeBanned = realtimeAccess?.banned == true

            // Maintenance global (control/global.enabled == false): layar penuh untuk user
            // biasa, di atas semua tab/tool. Admin yang terikat di admins/{uid} tetap bypass.
            val showMaintenance = navState == AppNavState.MAIN_APP &&
                globalControl?.isMaintenanceActive() == true &&
                !isAdmin

            LaunchedEffect(firebaseUser?.uid, firebaseUser?.isEmailVerified) {
                val currentUser = firebaseUser
                streamingLocalStore.activateUser(currentUser?.takeIf { it.isEmailVerified }?.uid)
                navState = when {
                    currentUser == null || currentUser.isEmailVerified != true -> AppNavState.AUTH_REQUIRED
                    navState == AppNavState.AUTH_REQUIRED -> AppNavState.SPLASH
                    else -> navState
                }
            }

            LaunchedEffect(Unit) {
                adminControlManager.recordPresence()
            }

            fun showSnackbar(message: String) {
                scope.launch {
                    snackbarHostState.showSnackbar(
                        message = message,
                        duration = SnackbarDuration.Short
                    )
                }
            }

            CompositionLocalProvider(LocalAppWindowSize provides windowSize) {
                LeviathanTheme {

                    // Perbaikan: mencegah UI masuk ke area status bar
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .then(if (immersiveActive) Modifier else Modifier.statusBarsPadding())
                    ) {
                        if (isRealtimeBanned) {
                            // A ban detected in real time (e.g. an admin bans the device
                            // while the app is already open) overrides whatever screen is
                            // currently showing — full-screen, regardless of navState.
                            DeviceBlockedScreen(
                                message = realtimeAccess?.message.orEmpty(),
                                banExpiresAt = realtimeAccess?.banExpiresAt,
                                onOk = { finish() }
                            )
                        } else if (showMaintenance) {
                            MaintenanceScreen(
                                message = globalControl?.message.orEmpty(),
                                onOk = { finish() }
                            )
                        } else {
                        AnimatedContent(
                            targetState = navState,
                            modifier = Modifier.fillMaxSize(),
                            transitionSpec = {
                                (fadeIn(tween(450, delayMillis = 60, easing = FastOutSlowInEasing)) +
                                    scaleIn(initialScale = 0.94f, animationSpec = tween(450, easing = FastOutSlowInEasing))) togetherWith
                                    (fadeOut(tween(260)) +
                                        scaleOut(targetScale = 1.05f, animationSpec = tween(260)))
                            },
                            label = "ScreenTransition"
                        ) { state ->
                            when (state) {
                                AppNavState.AUTH_REQUIRED -> {
                                    AuthScreen(authManager = firebaseUserAuthManager)
                                }

                                AppNavState.SPLASH -> {
                                    SplashScreen(
                                        diagnosticsManager = bootDiagnosticsManager,
                                        onReady = {
                                            navState = if (bootDiagnosticsManager.state.value.isSecurityBlocked) {
                                                AppNavState.DEVICE_BLOCKED
                                            } else {
                                                showCreditDialog = true
                                                AppNavState.MAIN_APP
                                            }
                                        }
                                    )
                                }

                                AppNavState.DEVICE_BLOCKED -> {
                                    val securityState = bootDiagnosticsManager.state.value
                                    DeviceBlockedScreen(
                                        message = securityState.securityBlockMessage,
                                        banExpiresAt = securityState.securityBanExpiresAt,
                                        onOk = { finish() }
                                    )
                                }

                                AppNavState.MAIN_APP -> {
                                    val policy = globalControl
                                    val currentToolId = GlobalToolPolicy.forDestination(currentDestination.name)
                                    // Global maintenance may be bypassed by admins, but an
                                    // explicitly disabled feature always shows its own overlay.
                                    val featureMaintenance = currentToolId != null &&
                                        policy != null &&
                                        (
                                            policy.isToolEnabled(currentToolId) == false ||
                                            (!isAdmin && policy.enabled == false)
                                        )

                                    BackHandler(
                                        enabled = currentDestination != LeviathanDestination.DASHBOARD
                                    ) {
                                        currentDestination = LeviathanDestination.DASHBOARD
                                    }

                                    LeviathanScaffold(
                                        currentDestination = currentDestination,
                                        onNavigateTo = { currentDestination = it },
                                        snackbarHostState = snackbarHostState,
                                        windowSize = windowSize,
                                        isOnline = isOnline,
                                        immersive = immersiveActive,
                                        onOfflineModuleBlocked = { moduleName ->
                                            showSnackbar(
                                                "Tidak ada koneksi internet. Modul $moduleName memerlukan koneksi."
                                            )
                                        }
                                    ) {
                                        Box(modifier = Modifier.fillMaxSize()) {
                                            if (featureMaintenance) {
                                                AdminSystemGate(
                                                    message = policy?.message.orEmpty().ifBlank {
                                                        "Fitur ini sedang dinonaktifkan sementara oleh admin."
                                                    },
                                                    toolName = currentDestination.title
                                                )
                                            } else {
                                                AnimatedContent(
                                                    targetState = currentDestination,
                                                    modifier = Modifier.fillMaxSize(),
                                                    transitionSpec = {
                                                        val direction = if (targetState.ordinal >= initialState.ordinal) 1 else -1
                                                        (fadeIn(tween(380, delayMillis = 40, easing = FastOutSlowInEasing)) +
                                                            slideInHorizontally(tween(380, easing = FastOutSlowInEasing)) { fullWidth -> direction * fullWidth / 7 } +
                                                            scaleIn(initialScale = 0.97f, animationSpec = tween(380, easing = FastOutSlowInEasing))) togetherWith
                                                            (fadeOut(tween(220)) +
                                                                slideOutHorizontally(tween(300, easing = FastOutSlowInEasing)) { fullWidth -> -direction * fullWidth / 10 })
                                                    },
                                                    label = "ModuleTransition"
                                                ) { destination ->
                                            LaunchedEffect(destination) {
                                                GlobalToolPolicy.forDestination(destination.name)?.let { adminControlManager.recordPresence(it) }
                                            }
                                            when (destination) {
                                                LeviathanDestination.DASHBOARD -> {
                                                    DashboardScreen(
                                                        windowSize = windowSize,
                                                        isOnline = isOnline,
                                                        onNavigateTo = {
                                                            currentDestination = it
                                                        },
                                                        onOfflineModuleBlocked = { moduleName ->
                                                            showSnackbar(
                                                                "Tidak ada koneksi internet. Modul $moduleName memerlukan koneksi."
                                                            )
                                                        },
                                                        onSecretAdminGesture = { showAdminPanel = true },
                                                        isToolEnabled = { id ->
                                                            val currentPolicy = globalControl
                                                            currentPolicy == null ||
                                                                (
                                                                    (isAdmin || currentPolicy.enabled) &&
                                                                        currentPolicy.isToolEnabled(id)
                                                                )
                                                        },
                                                    )
                                                }

                                                LeviathanDestination.BASE64_LAB -> {
                                                    Base64LabScreen(
                                                        repository = repository,
                                                        windowSize = windowSize,
                                                        onShowSnackbar = {
                                                            showSnackbar(it)
                                                        }
                                                    )
                                                }

                                                LeviathanDestination.MAGIC_LINK -> {
                                                    MagicLinkScreen(
                                                        repository = repository,
                                                        windowSize = windowSize,
                                                        onShowSnackbar = {
                                                            showSnackbar(it)
                                                        }
                                                    )
                                                }

                                                LeviathanDestination.WEB_TOOLS -> {
                                                    WebToolsScreen(
                                                        repository = repository,
                                                        windowSize = windowSize,
                                                        onShowSnackbar = {
                                                            showSnackbar(it)
                                                        }
                                                    )
                                                }

                                                LeviathanDestination.STROM_AI -> {
                                                    StromAiScreen(
                                                        repository = repository,
                                                        chatHistoryManager = chatHistoryManager,
                                                        windowSize = windowSize,
                                                        onShowSnackbar = {
                                                            showSnackbar(it)
                                                        }
                                                    )
                                                }

                                                LeviathanDestination.DOWNLOADER -> {
                                                    DownloaderScreen(
                                                        repository = repository,
                                                        windowSize = windowSize,
                                                        onShowSnackbar = {
                                                            showSnackbar(it)
                                                        }
                                                    )
                                                }

                                                LeviathanDestination.MEDIA -> {
                                                    MediaScreen(
                                                        repository = repository,
                                                        windowSize = windowSize,
                                                        onShowSnackbar = {
                                                            showSnackbar(it)
                                                        }
                                                    )
                                                }

                                                LeviathanDestination.TIKTOK_QUALITY -> {
                                                    TikTokQualityScreen(
                                                        windowSize = windowSize,
                                                        onShowSnackbar = {
                                                            showSnackbar(it)
                                                        }
                                                    )
                                                }

                                                LeviathanDestination.PY_OBFUSCATOR -> {
                                                    PyObfuscatorScreen(
                                                        repository = repository,
                                                        windowSize = windowSize,
                                                        onShowSnackbar = {
                                                            showSnackbar(it)
                                                        }
                                                    )
                                                }

                                                LeviathanDestination.PTERODACTYL_WHATSAPP -> {
                                                    PterodactylWhatsAppScreen(
                                                        windowSize = windowSize,
                                                        onShowSnackbar = {
                                                            showSnackbar(it)
                                                        }
                                                    )
                                                }

                                                LeviathanDestination.ALIGHT_MOTION_FINDER -> {
                                                    AlightMotionFinderScreen(
                                                        windowSize = windowSize,
                                                        onShowSnackbar = {
                                                            showSnackbar(it)
                                                        },
                                                        onBack = {
                                                            currentDestination = LeviathanDestination.DASHBOARD
                                                        }
                                                    )
                                                }

                                                LeviathanDestination.SFL_BYPASS -> {
                                                    SflBypassScreen(
                                                        windowSize = windowSize,
                                                        onShowSnackbar = {
                                                            showSnackbar(it)
                                                        },
                                                        onBack = {
                                                            currentDestination = LeviathanDestination.DASHBOARD
                                                        }
                                                    )
                                                }

                                                LeviathanDestination.STREAMING_ANIME -> {
                                                    StreamingScreen(
                                                        localStore = streamingLocalStore,
                                                        windowCompact = windowSize.isCompact,
                                                        onShowSnackbar = ::showSnackbar,
                                                        onOpenTools = {
                                                            currentDestination = LeviathanDestination.DASHBOARD
                                                        },
                                                        onImmersiveChange = { streamingImmersive = it }
                                                    )
                                                }

                                                LeviathanDestination.SETTINGS -> {
                                                    SettingsScreen(
                                                        errorReportManager = errorReportManager,
                                                        authManager = firebaseUserAuthManager,
                                                        networkMonitor = networkMonitor,
                                                        windowSize = windowSize,
                                                        onShowSnackbar = {
                                                            showSnackbar(it)
                                                        }
                                                    )
                                                }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        }
                    }

                    // Popup Kredit Aplikasi (muncul sekali saat pertama masuk ke aplikasi)
                    if (showCreditDialog) {
                        AppCreditDialog(
                            onDismiss = { showCreditDialog = false }
                        )
                    }


                    val currentAnnouncementUser = firebaseUser
                    if (!isRealtimeBanned && !immersiveActive && navState == AppNavState.MAIN_APP && globalControl?.enabled != false && currentAnnouncementUser != null) {
                        AnnouncementBanner(
                            announcements = announcements,
                            seenStore = announcementSeenStore,
                            uid = currentAnnouncementUser.uid,
                            onDismiss = {}
                        )
                    }

                    if (showAdminPanel) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            AdminEntryScreen(
                                manager = adminControlManager,
                                onClose = { showAdminPanel = false }
                            )
                        }
                    }

                }
            }
        }
    }

    }

    override fun onDestroy() {
        if (::streamingCloudSyncManager.isInitialized) {
            streamingCloudSyncManager.close()
        }
        bootDiagnosticsManager.dispose()
        super.onDestroy()
    }

}
