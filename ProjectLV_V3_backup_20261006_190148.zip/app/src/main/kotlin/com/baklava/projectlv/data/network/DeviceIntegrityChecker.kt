package com.baklava.projectlv.data.network

import android.content.Context
import android.os.Build
import android.os.Debug
import android.provider.Settings
import java.io.File

/**
 * Pemeriksaan lingkungan perangkat saat boot: indikator root, status debugger,
 * heuristik emulator, dan status VPN aktif (didelegasikan ke [VpnDetector]).
 *
 * Ini adalah pengecekan informasional untuk panel diagnostics — tidak memblokir
 * penggunaan aplikasi kecuali VPN aktif (ditangani terpisah oleh [VpnDetector] +
 * VpnBlockedDialog di level MainActivity).
 */
data class EnvironmentCheckResult(
    val vpnActive: Boolean,
    val rootIndicatorsFound: Int,
    val debuggerAttached: Boolean,
    val isProbableEmulator: Boolean,
    val isDeviceSecure: Boolean
)

class DeviceIntegrityChecker(context: Context) {

    private val appContext = context.applicationContext
    private val vpnDetector = VpnDetector(appContext)

    fun runFullCheck(): EnvironmentCheckResult {
        val vpn = try {
            vpnDetector.isVpnActive()
        } catch (_: Exception) {
            false
        }

        val rootHits = countRootIndicators()
        val debuggerOn = Debug.isDebuggerConnected()
        val emulatorLike = looksLikeEmulator()
        val deviceSecure = isDeviceLockSecure()

        return EnvironmentCheckResult(
            vpnActive = vpn,
            rootIndicatorsFound = rootHits,
            debuggerAttached = debuggerOn,
            isProbableEmulator = emulatorLike,
            isDeviceSecure = deviceSecure
        )
    }

    /** Menghitung berapa banyak indikator root umum yang ditemukan (bukan bukti mutlak). */
    private fun countRootIndicators(): Int {
        var hits = 0

        val rootPaths = listOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su",
            "/su/bin/su"
        )
        if (rootPaths.any { File(it).exists() }) hits++

        val buildTags = Build.TAGS
        if (buildTags != null && buildTags.contains("test-keys")) hits++

        val rootPackageHints = listOf(
            "com.topjohnwu.magisk",
            "eu.chainfire.supersu",
            "com.noshufou.android.su",
            "com.koushikdutta.superuser"
        )
        try {
            val pm = appContext.packageManager
            for (pkg in rootPackageHints) {
                try {
                    pm.getPackageInfo(pkg, 0)
                    hits++
                } catch (_: Exception) {
                    // Not installed — expected on clean devices.
                }
            }
        } catch (_: Exception) {
            // Ignore package manager access issues.
        }

        return hits
    }

    /** Heuristik ringan berbasis Build fingerprint untuk deteksi kemungkinan emulator. */
    private fun looksLikeEmulator(): Boolean {
        return (Build.FINGERPRINT.startsWith("generic")
            || Build.FINGERPRINT.startsWith("unknown")
            || Build.MODEL.contains("google_sdk")
            || Build.MODEL.contains("Emulator")
            || Build.MODEL.contains("Android SDK built for x86")
            || Build.MANUFACTURER.contains("Genymotion")
            || (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic"))
            || "google_sdk" == Build.PRODUCT)
    }

    private fun isDeviceLockSecure(): Boolean {
        return try {
            val km = appContext.getSystemService(Context.KEYGUARD_SERVICE) as? android.app.KeyguardManager
            km?.isDeviceSecure == true
        } catch (_: Exception) {
            false
        }
    }
}
