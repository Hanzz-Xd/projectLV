package com.baklava.projectlv.ui.modules.webtools

import android.content.Intent
import android.net.Uri
import androidx.compose.material.icons.filled.Link
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import com.baklava.projectlv.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import com.baklava.projectlv.ui.components.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import com.baklava.projectlv.ui.components.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import com.baklava.projectlv.ui.components.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.data.models.PageSourceResult
import com.baklava.projectlv.data.models.Web2ApkBuildRequest
import com.baklava.projectlv.data.models.Web2ApkBuildResult
import com.baklava.projectlv.data.models.WebToZipResult
import com.baklava.projectlv.data.repository.LeviathanRepository
import com.baklava.projectlv.data.repository.ResultState
import com.baklava.projectlv.ui.components.AppWindowSize
import com.baklava.projectlv.ui.components.ModuleHeaderCard
import com.baklava.projectlv.ui.theme.BrightAmber
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.BrightMagenta
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.launch

// ----------------------------------------------------------------
// Client-side validation (fails fast before wasting a request on
// the Web2Apk server, mirroring the reference CLI's input checks)
// ----------------------------------------------------------------
private fun isValidHttpUrl(value: String): Boolean {
    val v = value.trim()
    if (!v.startsWith("http://", ignoreCase = true) && !v.startsWith("https://", ignoreCase = true)) return false
    return try {
        !Uri.parse(v).host.isNullOrBlank()
    } catch (_: Exception) {
        false
    }
}

private val PACKAGE_NAME_REGEX = Regex("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$")
private fun isValidPackageName(value: String): Boolean = PACKAGE_NAME_REGEX.matches(value.trim())
private fun isValidHexColor(value: String): Boolean = Regex("^#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?$").matches(value.trim())

@Composable
fun WebToolsScreen(
    repository: LeviathanRepository,
    windowSize: AppWindowSize,
    onShowSnackbar: (String) -> Unit
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("Web to APK", "Page Source", "Web to ZIP", "Short URL", "Enc HTML")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
    ) {
        ModuleHeaderCard(
            icon = Icons.Default.Language,
            title = "WEB TOOLS",
            subtitle = "Web Automation, Code Inspector & Packaging Center",
            modifier = Modifier.padding(16.dp)
        )

        ScrollableTabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = CyberDarkNavy,
            contentColor = BrightCyan,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = BrightCyan
                )
            },
            divider = { Box(modifier = Modifier.height(1.dp).background(CyberCardBorder)) }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) BrightCyan else MutedGrey
                            )
                        )
                    },
                    modifier = Modifier.testTag("tab_webtool_$index")
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            when (selectedTabIndex) {
                0 -> Web2ApkTab(repository, onShowSnackbar)
                1 -> PageSourceTab(repository, onShowSnackbar)
                2 -> WebToZipTab(repository, onShowSnackbar)
                3 -> ShortUrlTab(repository, onShowSnackbar)
                4 -> HtmlObfuscatorTab(onShowSnackbar)
            }
        }
    }
}

// ----------------------------------------------------------------
// 1. WEB TO APK TAB
// ----------------------------------------------------------------

private val WEB2APK_PERMISSION_OPTIONS = listOf(
    "android.permission.CAMERA" to "Kamera",
    "android.permission.RECORD_AUDIO" to "Mikrofon",
    "android.permission.ACCESS_FINE_LOCATION" to "Lokasi presisi",
    "android.permission.ACCESS_COARSE_LOCATION" to "Lokasi perkiraan",
    "android.permission.READ_MEDIA_IMAGES" to "Galeri / gambar",
    "android.permission.READ_EXTERNAL_STORAGE" to "Penyimpanan lama",
    "android.permission.WRITE_EXTERNAL_STORAGE" to "Tulis penyimpanan lama",
    "android.permission.POST_NOTIFICATIONS" to "Notifikasi",
    "android.permission.VIBRATE" to "Vibrate",
    "android.permission.CALL_PHONE" to "Telepon"
)

private val WEB2APK_SPLASH_TYPES = listOf(
    "default" to "Default",
    "fade" to "Fade in",
    "zoom" to "Zoom in",
    "slide" to "Slide up",
    "bounce" to "Bounce",
    "pulse" to "Pulse",
    "rotate" to "Sway",
    "typewriter" to "Typewriter",
    "spinner" to "Spinner"
)

private fun localApkUri(context: android.content.Context, filePath: String): Uri? {
    val file = java.io.File(filePath)
    if (!file.exists()) return null
    return androidx.core.content.FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        file
    )
}

private fun openLocalApk(context: android.content.Context, filePath: String) {
    val uri = localApkUri(context, filePath) ?: return
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "application/vnd.android.package-archive")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(intent)
}

private fun shareLocalApk(context: android.content.Context, filePath: String) {
    val uri = localApkUri(context, filePath) ?: return
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/vnd.android.package-archive"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        clipData = android.content.ClipData.newRawUri("APK", uri)
    }
    context.startActivity(Intent.createChooser(intent, "Bagikan APK"))
}

@Composable
private fun Web2ApkConfigRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, fontWeight = FontWeight.SemiBold)
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey, fontSize = 11.sp)
            )
        }
        androidx.compose.material3.Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun Web2ApkTab(
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var appName by remember { mutableStateOf("") }
    var websiteUrl by remember { mutableStateOf("https://") }
    var packageName by remember { mutableStateOf("com.mycompany.app") }
    var versionName by remember { mutableStateOf("1.0.0") }
    var versionCode by remember { mutableStateOf("1") }
    var appIconUrl by remember { mutableStateOf("") }
    var iconPng by remember { mutableStateOf<ByteArray?>(null) }
    var iconDisplayName by remember { mutableStateOf("Ikon template") }

    var splashEnabled by remember { mutableStateOf(true) }
    var splashType by remember { mutableStateOf("fade") }
    var splashMs by remember { mutableStateOf("2000") }
    var splashSubtitle by remember { mutableStateOf("Menyiapkan aplikasi…") }
    var splashBg by remember { mutableStateOf("#0C0D10") }
    var splashFg by remember { mutableStateOf("#FFFFFF") }
    var headerEnabled by remember { mutableStateOf(true) }
    var headerText by remember { mutableStateOf("") }
    var headerBg by remember { mutableStateOf("#14161A") }
    var headerFg by remember { mutableStateOf("#FFFFFF") }
    var jsEnabled by remember { mutableStateOf(true) }
    var zoomEnabled by remember { mutableStateOf(false) }
    var desktopEnabled by remember { mutableStateOf(false) }
    var externalBrowser by remember { mutableStateOf(false) }
    var sameHost by remember { mutableStateOf(false) }
    var orientation by remember { mutableStateOf("portrait") }
    var showAdvanced by remember { mutableStateOf(false) }

    val selectedPermissions = remember { mutableStateOf(setOf<String>()) }
    var isBuilding by remember { mutableStateOf(false) }
    var buildProgress by remember { mutableIntStateOf(0) }
    var statusMessage by remember { mutableStateOf("") }
    var buildResult by remember { mutableStateOf<Web2ApkBuildResult?>(null) }

    val iconPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("File icon tidak dapat dibaca")
            require(bytes.size <= 4 * 1024 * 1024) { "Ukuran icon terlalu besar (maks. 4 MB)" }
            require(bytes.size >= 8 && bytes.copyOfRange(0, 8).contentEquals(byteArrayOf(
                0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A
            ))) { "Icon harus berupa PNG" }
            iconPng = bytes
            iconDisplayName = uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "Ikon PNG" } ?: "Ikon PNG"
        }.onFailure { onShowSnackbar(it.message ?: "Gagal membaca icon") }
    }

    val saveLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { uri ->
        val result = buildResult
        if (uri != null && result != null) {
            scope.launch(kotlinx.coroutines.Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { output ->
                        java.io.File(result.filePath).inputStream().use { input -> input.copyTo(output) }
                    } ?: error("Tidak bisa membuka lokasi penyimpanan")
                }.onSuccess {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        onShowSnackbar("APK disimpan ke penyimpanan perangkat.")
                    }
                }.onFailure {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        onShowSnackbar("Gagal menyimpan APK: ${it.message}")
                    }
                }
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
    containerColor = CyberDarkNavy
),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Default.Android, contentDescription = null, tint = BrightCyan, modifier = Modifier.size(24.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("WEB TO APK", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                        Text(
                            "Forge APK langsung di perangkat • template SDKForge API",
                            style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey, fontSize = 11.sp)
                        )
                    }
                    if (buildResult != null) {
                        Text(
                            "SIAP",
                            style = MaterialTheme.typography.labelSmall.copy(color = BrightGreen, fontWeight = FontWeight.Bold)
                        )
                    }
                }

                OutlinedTextField(
                    value = appName,
                    onValueChange = { value ->
                        val previousName = appName
                        appName = value
                        if (packageName.startsWith("com.mycompany.")) {
                            packageName = "com.app." + value.lowercase().replace("[^a-z0-9]".toRegex(), "").ifBlank { "app" }
                        }
                        if (headerText.isBlank() || headerText == previousName) headerText = value
                    },
                    label = { Text("Nama Aplikasi") },
                    placeholder = { Text("Contoh: Toko Online") },
                    modifier = Modifier.fillMaxWidth().testTag("input_apk_app_name"),
                    colors = defaultFieldColors(),
                    shape = RoundedCornerShape(8.dp)
                )

                OutlinedTextField(
                    value = websiteUrl,
                    onValueChange = { websiteUrl = it },
                    label = { Text("URL Website") },
                    placeholder = { Text("https://contoh.com") },
                    modifier = Modifier.fillMaxWidth().testTag("input_apk_website_url"),
                    colors = defaultFieldColors(),
                    shape = RoundedCornerShape(8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = packageName,
                        onValueChange = { packageName = it },
                        label = { Text("Package Name") },
                        modifier = Modifier.weight(1.5f).testTag("input_apk_package_name"),
                        colors = defaultFieldColors(),
                        shape = RoundedCornerShape(8.dp)
                    )
                    OutlinedTextField(
                        value = versionName,
                        onValueChange = { versionName = it },
                        label = { Text("Version") },
                        modifier = Modifier.weight(1f).testTag("input_apk_version_name"),
                        colors = defaultFieldColors(),
                        shape = RoundedCornerShape(8.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = versionCode,
                        onValueChange = { versionCode = it.filter(Char::isDigit) },
                        label = { Text("Version Code") },
                        modifier = Modifier.weight(1f),
                        colors = defaultFieldColors(),
                        shape = RoundedCornerShape(8.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Ikon Launcher", style = MaterialTheme.typography.labelMedium.copy(color = MutedGrey))
                        Text(iconDisplayName, style = MaterialTheme.typography.bodySmall.copy(color = Color.White), maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = { iconPicker.launch(arrayOf("image/png")) },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = BrightCyan)
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Pilih PNG")
                    }
                }

                OutlinedTextField(
                    value = appIconUrl,
                    onValueChange = {
                        appIconUrl = it
                        if (it.isNotBlank()) {
                            iconPng = null
                            iconDisplayName = "Icon dari URL"
                        }
                    },
                    label = { Text("URL Icon PNG (opsional)") },
                    placeholder = { Text("https://.../icon.png") },
                    modifier = Modifier.fillMaxWidth().testTag("input_apk_icon_url"),
                    colors = defaultFieldColors(),
                    shape = RoundedCornerShape(8.dp)
                )

                Card(
                    colors = CardDefaults.cardColors(
                    containerColor = CyberDarkNavy
                ),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.Build, contentDescription = null, tint = BrightCyan, modifier = Modifier.size(20.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Pengaturan Build", fontWeight = FontWeight.Bold, color = Color.White)
                                Text("Splash, header, WebView, orientasi & permission", color = MutedGrey, fontSize = 11.sp)
                            }
                            TextButton(onClick = { showAdvanced = !showAdvanced }) {
                                Text(if (showAdvanced) "Tutup" else "Atur", color = BrightCyan)
                            }
                        }

                        AnimatedVisibility(visible = showAdvanced) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Spacer(Modifier.height(4.dp))
                                Web2ApkConfigRow("Splash screen", "Animasi pembuka sebelum WebView siap", splashEnabled) { splashEnabled = it }
                                if (splashEnabled) {
                                    Text("Jenis splash", style = MaterialTheme.typography.labelSmall.copy(color = MutedGrey, fontWeight = FontWeight.Bold))
                                    Row(
                                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        WEB2APK_SPLASH_TYPES.forEach { (value, label) ->
                                            OutlinedButton(
                                                onClick = { splashType = value },
                                                shape = RoundedCornerShape(8.dp),
                                                colors = ButtonDefaults.outlinedButtonColors(
                                                    containerColor = if (splashType == value) CyberSurfaceVariant else Color.Transparent,
                                                    contentColor = if (splashType == value) Color.White else MutedGrey
                                                )
                                            ) { Text(label, fontSize = 11.sp) }
                                        }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(
                                            value = splashMs,
                                            onValueChange = { splashMs = it.filter(Char::isDigit).take(5) },
                                            label = { Text("Durasi ms") },
                                            modifier = Modifier.weight(1f),
                                            colors = defaultFieldColors(),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = splashSubtitle,
                                            onValueChange = { splashSubtitle = it },
                                            label = { Text("Subtitle") },
                                            modifier = Modifier.weight(2f),
                                            colors = defaultFieldColors(),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(
                                            value = splashBg,
                                            onValueChange = { splashBg = it },
                                            label = { Text("Splash BG") },
                                            modifier = Modifier.weight(1f),
                                            colors = defaultFieldColors(),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = splashFg,
                                            onValueChange = { splashFg = it },
                                            label = { Text("Splash FG") },
                                            modifier = Modifier.weight(1f),
                                            colors = defaultFieldColors(),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }

                                Web2ApkConfigRow("Header bar", "Tampilkan header native di atas WebView", headerEnabled) { headerEnabled = it }
                                if (headerEnabled) {
                                    OutlinedTextField(
                                        value = headerText,
                                        onValueChange = { headerText = it },
                                        label = { Text("Teks Header") },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = defaultFieldColors(),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(
                                            value = headerBg,
                                            onValueChange = { headerBg = it },
                                            label = { Text("Header BG") },
                                            modifier = Modifier.weight(1f),
                                            colors = defaultFieldColors(),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = headerFg,
                                            onValueChange = { headerFg = it },
                                            label = { Text("Header FG") },
                                            modifier = Modifier.weight(1f),
                                            colors = defaultFieldColors(),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }

                                Text("WEBVIEW", style = MaterialTheme.typography.labelSmall.copy(color = MutedGrey, fontWeight = FontWeight.Bold))
                                Web2ApkConfigRow("JavaScript", "Izinkan script di halaman", jsEnabled) { jsEnabled = it }
                                Web2ApkConfigRow("Pinch-Zoom", "Izinkan zoom gestur", zoomEnabled) { zoomEnabled = it }
                                Web2ApkConfigRow("Desktop mode", "Gunakan user-agent desktop", desktopEnabled) { desktopEnabled = it }
                                Web2ApkConfigRow("External browser", "Link tertentu dibuka di browser luar", externalBrowser) { externalBrowser = it }
                                Web2ApkConfigRow("Same-host navigation", "Batasi navigasi utama ke host website", sameHost) { sameHost = it }

                                Text("ORIENTASI", style = MaterialTheme.typography.labelSmall.copy(color = MutedGrey, fontWeight = FontWeight.Bold))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("portrait" to "PORTRAIT", "landscape" to "LANDSCAPE").forEach { (value, label) ->
                                        OutlinedButton(
                                            onClick = { orientation = value },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(
                                                containerColor = if (orientation == value) CyberSurfaceVariant else Color.Transparent,
                                                contentColor = if (orientation == value) Color.White else MutedGrey
                                            )
                                        ) { Text(label, fontSize = 11.sp) }
                                    }
                                }

                                Text("PERMISSIONS ANDROID", style = MaterialTheme.typography.labelSmall.copy(color = MutedGrey, fontWeight = FontWeight.Bold))
                                WEB2APK_PERMISSION_OPTIONS.forEach { (permission, label) ->
                                    Web2ApkConfigRow(label, permission, selectedPermissions.value.contains(permission)) { enabled ->
                                        selectedPermissions.value = if (enabled) {
                                            selectedPermissions.value + permission
                                        } else selectedPermissions.value - permission
                                    }
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = {
                        val trimmedWebsite = websiteUrl.trim()
                        val trimmedPackage = packageName.trim()
                        val versionCodeInt = versionCode.trim().toIntOrNull()
                        val versionNameValue = versionName.trim()
                        val splashMsInt = splashMs.trim().toIntOrNull() ?: 2000

                        when {
                            appName.isBlank() -> onShowSnackbar("Nama aplikasi wajib diisi.")
                            !isValidHttpUrl(trimmedWebsite) -> onShowSnackbar("URL website tidak valid. Gunakan format https://contoh.com")
                            !isValidPackageName(trimmedPackage) -> onShowSnackbar("Package name tidak valid. Contoh: com.nama.aplikasi")
                            versionCodeInt == null || versionCodeInt <= 0 -> onShowSnackbar("Version code harus berupa angka positif.")
                            versionNameValue.isBlank() -> onShowSnackbar("Version wajib diisi.")
                            splashMsInt !in 250..60000 -> onShowSnackbar("Durasi splash harus 250–60000 ms.")
                            !isValidHexColor(splashBg) || !isValidHexColor(splashFg) || !isValidHexColor(headerBg) || !isValidHexColor(headerFg) -> onShowSnackbar("Warna harus dalam format #RRGGBB atau #RRGGBBAA.")
                            appIconUrl.isNotBlank() && !isValidHttpUrl(appIconUrl.trim()) -> onShowSnackbar("URL icon tidak valid.")
                            else -> {
                                scope.launch {
                                    isBuilding = true
                                    buildProgress = 0
                                    buildResult = null
                                    statusMessage = "Menyiapkan template SDKForge..."

                                    val config = linkedMapOf<String, Any?>(
                                        "url" to trimmedWebsite,
                                        "splash" to splashEnabled,
                                        "splashType" to splashType,
                                        "splashMs" to splashMsInt,
                                        "splashText" to appName.trim(),
                                        "splashSubtitle" to splashSubtitle,
                                        "splashBg" to splashBg,
                                        "splashFg" to splashFg,
                                        "header" to headerEnabled,
                                        "headerText" to headerText.ifBlank { appName.trim() },
                                        "headerBg" to headerBg,
                                        "headerFg" to headerFg,
                                        "js" to jsEnabled,
                                        "zoom" to zoomEnabled,
                                        "desktop" to desktopEnabled,
                                        "externalBrowser" to externalBrowser,
                                        "sameHost" to sameHost,
                                        "orientation" to orientation
                                    )

                                    when (val result = repository.forgeWeb2Apk(
                                        req = Web2ApkBuildRequest(
                                            appName = appName.trim(),
                                            websiteUrl = trimmedWebsite,
                                            packageName = trimmedPackage,
                                            versionName = versionNameValue,
                                            versionCode = versionCodeInt.toString(),
                                            appIconUrl = appIconUrl.trim(),
                                            iconPng = iconPng,
                                            permissions = selectedPermissions.value.toList(),
                                            config = config
                                        ),
                                        onStep = { step ->
                                            buildProgress = step.coerceIn(0, 5)
                                            statusMessage = when (step) {
                                                0 -> "Mengambil template APK..."
                                                1 -> "Mengambil material signing..."
                                                2 -> "Memodifikasi Manifest, resource, icon & config..."
                                                3 -> "Menandatangani APK..."
                                                4 -> "Menyusun arsip APK..."
                                                5 -> "APK tersimpan di perangkat."
                                                else -> "Memproses..."
                                            }
                                        }
                                    )) {
                                        is ResultState.Success -> {
                                            buildResult = result.data
                                            statusMessage = "Build selesai • ${result.data.fileName}"
                                            onShowSnackbar("APK berhasil dibuat.")
                                        }
                                        is ResultState.Error -> {
                                            statusMessage = "Build gagal: ${result.message}"
                                            onShowSnackbar(statusMessage)
                                        }
                                    }
                                    isBuilding = false
                                }
                            }
                        }
                    },
                    enabled = appName.isNotBlank() && websiteUrl.isNotBlank() && !isBuilding,
                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("btn_start_web2apk"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
                ) {
                    if (isBuilding) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = CyberBlack, strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Membangun APK • ${((buildProgress / 5f) * 100).toInt()}%", fontWeight = FontWeight.Bold)
                    } else {
                        Icon(Icons.Default.Android, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Mulai Build APK", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (statusMessage.isNotBlank()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberDarkNavy)
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(statusMessage, style = MaterialTheme.typography.bodyMedium.copy(color = Color.White))
                    if (isBuilding) {
                        LinearProgressIndicator(
                            progress = { (buildProgress / 5f).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                            color = BrightCyan,
                            trackColor = CyberSurfaceVariant
                        )
                    }
                }
            }
        }

        buildResult?.let { result ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
    containerColor = CyberDarkNavy
),
                border = androidx.compose.foundation.BorderStroke(1.dp, BrightGreen)
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Android, contentDescription = null, tint = BrightGreen)
                        Text("APK SIAP DIPAKAI", style = MaterialTheme.typography.titleSmall.copy(color = BrightGreen, fontWeight = FontWeight.Bold))
                    }
                    Text(result.fileName, style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold))
                    Text(
                        "${result.sizeBytes / 1024} KB • ${result.packageName}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey)
                    )
                    Text(
                        result.websiteUrl,
                        style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey),
                        maxLines = 1
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                runCatching { openLocalApk(context, result.filePath) }
                                    .onFailure { onShowSnackbar("Tidak ada aplikasi untuk membuka APK: ${it.message}") }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrightGreen, contentColor = CyberBlack)
                        ) {
                            Icon(Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Buka / Install", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { saveLauncher.launch(result.fileName) },
                            modifier = Modifier.weight(1f).testTag("btn_download_apk"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = BrightCyan)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Simpan APK")
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            runCatching { shareLocalApk(context, result.filePath) }
                                .onFailure { onShowSnackbar("Gagal membagikan APK: ${it.message}") }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Bagikan APK")
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------
// 2. PAGE SOURCE TAB
// ----------------------------------------------------------------
@Composable
private fun PageSourceTab(
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit
) {
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var urlInput by remember { mutableStateOf("https://") }
    var isFetching by remember { mutableStateOf(false) }
    var pageResult by remember { mutableStateOf<PageSourceResult?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = urlInput,
            onValueChange = { urlInput = it },
            label = { Text("URL Website Target") },
            placeholder = { Text("https://contoh.com") },
            modifier = Modifier.fillMaxWidth().testTag("input_page_source_url"),
            colors = defaultFieldColors(),
            shape = RoundedCornerShape(8.dp)
        )

        Button(
            onClick = {
                if (urlInput.isBlank() || urlInput == "https://") {
                    onShowSnackbar("Masukkan URL website yang valid.")
                    return@Button
                }
                scope.launch {
                    isFetching = true
                    pageResult = null
                    when (val res = repository.fetchPageSource(urlInput.trim())) {
                        is ResultState.Success -> {
                            pageResult = res.data
                            onShowSnackbar("Page source berhasil diambil.")
                        }
                        is ResultState.Error -> {
                            onShowSnackbar("Gagal: ${res.message}")
                        }
                    }
                    isFetching = false
                }
            },
            enabled = urlInput.isNotBlank() && !isFetching,
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("btn_fetch_page_source"),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
        ) {
            if (isFetching) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = CyberBlack)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Mengambil Source Code...")
            } else {
                Icon(imageVector = Icons.Default.Code, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Ambil Source Code", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
            }
        }

        if (pageResult != null) {
            val res = pageResult!!

            // Metrics Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberDarkNavy)
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "METRIK HALAMAN",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFFE5E7EB),
                            fontFamily = FontFamily.Default,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Ukuran: ${res.totalSize ?: "-"} · Karakter: ${res.totalChars ?: "-"} · Baris: ${res.totalLines ?: "-"}",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color.White, fontFamily = FontFamily.Default)
                    )
                    Text(
                        text = "Waktu: ${res.timingMs ?: "-"} · Server: ${res.server ?: "-"} · Status HTTP: ${res.httpCode ?: "200"}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey, fontFamily = FontFamily.Default)
                    )
                }
            }

            // HTML Source Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 180.dp, max = 300.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberBlack)
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .horizontalScroll(rememberScrollState())
                ) {
                    Text(
                        text = if (res.html.length > 5000) res.html.take(5000) + "\n\n... [Dipangkas untuk preview tampilan, gunakan tombol salin untuk full source] ..." else res.html,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Default,
                            color = Color(0xFFCBD5E1),
                            fontSize = 11.sp
                        )
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        clipboard.setText(AnnotatedString(res.html))
                        onShowSnackbar("Source code HTML (${res.html.length} chars) disalin.")
                    },
                    modifier = Modifier.weight(1f).testTag("btn_copy_html_source"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Salin HTML")
                }

                OutlinedButton(
                    onClick = {
                        val host = Uri.parse(res.url).host ?: "source"
                        val fileName = "${host}_pagesource.html"
                        val uri = repository.workspaceManager.saveToDownloads(fileName, "text/html", res.html.toByteArray(Charsets.UTF_8))
                        if (uri != null) {
                            onShowSnackbar("Disimpan ke Download: $fileName")
                        } else {
                            onShowSnackbar("Gagal menyimpan file.")
                        }
                    },
                    modifier = Modifier.weight(1f).testTag("btn_save_html_file"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BrightCyan)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Simpan .html")
                }
            }
        }
    }
}

// ----------------------------------------------------------------
// 3. WEB TO ZIP TAB
// ----------------------------------------------------------------
@Composable
private fun WebToZipTab(
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var targetUrl by remember { mutableStateOf("https://") }
    var isConverting by remember { mutableStateOf(false) }
    var zipResult by remember { mutableStateOf<WebToZipResult?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Konversi halaman web menjadi arsip file ZIP lengkap (Aspose API Converter).",
            style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey)
        )

        OutlinedTextField(
            value = targetUrl,
            onValueChange = { targetUrl = it },
            label = { Text("URL Web") },
            placeholder = { Text("https://contoh.com") },
            modifier = Modifier.fillMaxWidth().testTag("input_web_to_zip_url"),
            colors = defaultFieldColors(),
            shape = RoundedCornerShape(8.dp)
        )

        Button(
            onClick = {
                if (targetUrl.isBlank() || targetUrl == "https://") {
                    onShowSnackbar("Masukkan URL website.")
                    return@Button
                }
                scope.launch {
                    isConverting = true
                    zipResult = null
                    when (val res = repository.webToZip(targetUrl.trim())) {
                        is ResultState.Success -> {
                            zipResult = res.data
                            onShowSnackbar("Konversi Web to ZIP berhasil!")
                        }
                        is ResultState.Error -> {
                            onShowSnackbar("Gagal: ${res.message}")
                        }
                    }
                    isConverting = false
                }
            },
            enabled = targetUrl.isNotBlank() && !isConverting,
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("btn_convert_web_to_zip"),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5E7EB), contentColor = Color(0xFF0C0D10))
        ) {
            if (isConverting) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color(0xFF0C0D10))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sedang Mengonversi...", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold))
            } else {
                Icon(imageVector = Icons.Default.Image, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Konversi ke ZIP", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
            }
        }

        if (zipResult != null) {
            val res = zipResult!!
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberDarkNavy)
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (res.isLocalArchive) "ARSIP TERSIMPAN DI PERANGKAT" else "ARSIP ZIP SIAP DIUNDUH",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = BrightGreen,
                            fontFamily = FontFamily.Default,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "File: ${res.fileName}",
                        style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                    )
                    if (res.note != null) {
                        Text(
                            text = res.note,
                            style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey, fontSize = 11.sp)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(res.downloadUrl))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.weight(1f).testTag("btn_download_zip"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5E7EB), contentColor = Color(0xFF0C0D10))
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (res.isLocalArchive) "Buka Arsip" else "Download ZIP", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                        }

                        OutlinedButton(
                            onClick = {
                                val share = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, res.downloadUrl)
                                }
                                context.startActivity(Intent.createChooser(share, "Bagikan Link ZIP"))
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Bagikan Link")
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------
// 4. SHORT URL TAB
// ----------------------------------------------------------------
@Composable
private fun ShortUrlTab(
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit
) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var urlInput by remember { mutableStateOf("https://") }
    var isShortening by remember { mutableStateOf(false) }
    var shortResult by remember { mutableStateOf<com.baklava.projectlv.data.models.ShortUrlResult?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Perpendek URL panjang menjadi tautan singkat yang mudah dibagikan (TinyURL).",
            style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey)
        )

        OutlinedTextField(
            value = urlInput,
            onValueChange = { urlInput = it },
            label = { Text("URL Panjang") },
            placeholder = { Text("https://contoh.com/link/yang/panjang") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_short_url"),
            colors = defaultFieldColors(),
            shape = RoundedCornerShape(8.dp)
        )

        Button(
            onClick = {
                if (urlInput.isBlank() || urlInput == "https://") {
                    onShowSnackbar("Masukkan URL yang valid.")
                    return@Button
                }
                scope.launch {
                    isShortening = true
                    shortResult = null
                    when (val res = repository.shortenUrl(urlInput.trim())) {
                        is ResultState.Success -> {
                            shortResult = res.data
                            onShowSnackbar("URL berhasil diperpendek!")
                        }
                        is ResultState.Error -> {
                            onShowSnackbar("Gagal: ${res.message}")
                        }
                    }
                    isShortening = false
                }
            },
            enabled = urlInput.isNotBlank() && !isShortening,
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("btn_shorten_url"),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
        ) {
            if (isShortening) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = CyberBlack)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Memperpendek URL...")
            } else {
                Icon(imageVector = Icons.Default.Link, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Perpendek URL", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
            }
        }

        if (shortResult != null) {
            val res = shortResult!!
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberDarkNavy)
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "URL SINGKAT SIAP DIBAGIKAN",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = BrightGreen,
                            fontFamily = FontFamily.Default,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = res.shortUrl,
                        style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Asal: ${res.originalUrl}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey, fontSize = 11.sp),
                        maxLines = 2
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                clipboard.setText(AnnotatedString(res.shortUrl))
                                onShowSnackbar("Link disalin ke clipboard.")
                            },
                            modifier = Modifier.weight(1f).testTag("btn_copy_short_url"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Salin Link")
                        }

                        OutlinedButton(
                            onClick = {
                                val share = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, res.shortUrl)
                                }
                                context.startActivity(Intent.createChooser(share, "Bagikan Link"))
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Bagikan")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun defaultFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Color(0xFFE5E7EB),
    unfocusedBorderColor = CyberCardBorder,
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedContainerColor = CyberDarkNavy,
    unfocusedContainerColor = CyberDarkNavy,
    cursorColor = Color(0xFFE5E7EB),
    focusedLabelColor = Color(0xFFE5E7EB),
    unfocusedLabelColor = MutedGrey
)
