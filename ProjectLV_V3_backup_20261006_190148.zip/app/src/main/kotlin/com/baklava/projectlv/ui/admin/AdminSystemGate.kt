package com.baklava.projectlv.ui.admin

import androidx.compose.foundation.background
import com.baklava.projectlv.ui.components.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import com.baklava.projectlv.ui.components.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberDarkNavy

/**
 * Feature-only maintenance gate. This composable is rendered inside the
 * scaffold content area, so bottom navigation remains available.
 */
@Composable
fun AdminSystemGate(message: String, toolName: String? = null) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack.copy(alpha = 0.72f))
            .clickable { /* consume touches while the feature is blocked */ },
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .padding(horizontal = 28.dp)
                .widthIn(max = 420.dp),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.Block, contentDescription = null, tint = BrightRed)
                Text(
                    if (toolName.isNullOrBlank()) "FITUR DINONAKTIFKAN" else "$toolName DINONAKTIFKAN",
                    color = Color.White,
                    fontSize = 18.sp
                )
                Text(
                    message.ifBlank { "Fitur sedang dikendalikan admin." },
                    color = Color(0xFFCBD5E1),
                    fontSize = 13.sp
                )
            }
        }
    }
}
