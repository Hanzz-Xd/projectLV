package com.baklava.projectlv.ui.modules.base64

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import com.baklava.projectlv.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import com.baklava.projectlv.ui.components.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.data.repository.LeviathanRepository
import com.baklava.projectlv.ui.components.AppWindowSize
import com.baklava.projectlv.ui.components.ModuleHeaderCard
import com.baklava.projectlv.ui.theme.BrightAmber
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurface
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DecimalFormat

@Composable
fun Base64LabScreen(
    repository: LeviathanRepository,
    windowSize: AppWindowSize,
    onShowSnackbar: (String) -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("Encode File", "Decode File", "Encode Teks", "Decode Teks")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
    ) {
        // Module Header
        ModuleHeaderCard(
            icon = Icons.Default.Code,
            title = "BASE64 LAB",
            subtitle = "Offline Engine · Enkripsi & Dekripsi Base64 Aman Tanpa Server",
            modifier = Modifier.padding(16.dp)
        )

        // Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = CyberDarkNavy,
            contentColor = BrightCyan,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = BrightCyan
                )
            },
            divider = { Box(modifier = Modifier.height(1.dp).background(CyberCardBorder)) }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) BrightCyan else MutedGrey
                            )
                        )
                    },
                    modifier = Modifier.testTag("tab_base64_$index")
                )
            }
        }

        // Content body based on tab
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            when (selectedTabIndex) {
                0 -> EncodeFileTab(repository, onShowSnackbar)
                1 -> DecodeFileTab(repository, onShowSnackbar)
                2 -> EncodeTextTab(repository, onShowSnackbar)
                3 -> DecodeTextTab(repository, onShowSnackbar)
            }
        }
    }
}

// -----------------------------------------------------------
// 1. ENCODE FILE TAB
// -----------------------------------------------------------
@Composable
private fun EncodeFileTab(
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var fileName by remember { mutableStateOf<String?>(null) }
    var fileSize by remember { mutableStateOf<Long?>(null) }
    var mimeType by remember { mutableStateOf<String?>(null) }
    var base64Result by remember { mutableStateOf("") }
    var isProcessing by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                isProcessing = true
                try {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                            if (cursor.moveToFirst()) {
                                fileName = cursor.getString(nameIndex)
                                fileSize = cursor.getLong(sizeIndex)
                            }
                        }
                        mimeType = context.contentResolver.getType(uri) ?: "application/octet-stream"

                        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                        base64Result = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    }
                    onShowSnackbar("File berhasil di-encode (${formatBytes(fileSize ?: 0)}).")
                } catch (e: Exception) {
                    onShowSnackbar("Gagal memproses file: ${e.message}")
                } finally {
                    isProcessing = false
                }
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Button(
            onClick = { filePicker.launch("*/*") },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("btn_select_file_encode"),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = BrightCyan,
                contentColor = CyberBlack
            )
        ) {
            Icon(imageVector = Icons.Default.AttachFile, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Pilih File dari Perangkat",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
            )
        }

        if (fileName != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberDarkNavy)
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "File: $fileName",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Text(
                        text = "Ukuran: ${formatBytes(fileSize ?: 0)} · MIME: $mimeType",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MutedGrey,
                            fontFamily = FontFamily.Default
                        )
                    )
                    if ((fileSize ?: 0) > 5 * 1024 * 1024) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = BrightAmber,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Peringatan: File > 5MB dapat memakan memori besar saat ditampilkan.",
                                style = MaterialTheme.typography.labelSmall.copy(color = BrightAmber)
                            )
                        }
                    }
                }
            }
        }

        if (isProcessing) {
            Box(
                modifier = Modifier.fillMaxWidth().padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = BrightCyan)
            }
        }

        if (base64Result.isNotBlank()) {
            OutlinedTextField(
                value = if (base64Result.length > 2000) base64Result.take(2000) + "\n... [Dipangkas untuk preview tampilan, total ${base64Result.length} karakter] ..." else base64Result,
                onValueChange = {},
                readOnly = true,
                label = { Text("Output Base64 (${base64Result.length} chars)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 140.dp, max = 220.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrightCyan,
                    unfocusedBorderColor = CyberCardBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = CyberDarkNavy,
                    unfocusedContainerColor = CyberDarkNavy
                ),
                shape = RoundedCornerShape(8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        clipboard.setText(AnnotatedString(base64Result))
                        onShowSnackbar("Base64 string berhasil disalin ke clipboard.")
                    },
                    modifier = Modifier.weight(1f).testTag("btn_copy_base64"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Salin Base64", style = MaterialTheme.typography.labelMedium)
                }

                OutlinedButton(
                    onClick = {
                        val dataUri = "data:${mimeType ?: "application/octet-stream"};base64,$base64Result"
                        clipboard.setText(AnnotatedString(dataUri))
                        onShowSnackbar("Data URI berhasil disalin ke clipboard.")
                    },
                    modifier = Modifier.weight(1f).testTag("btn_copy_data_uri"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BrightCyan)
                ) {
                    Text("Salin Data URI", style = MaterialTheme.typography.labelMedium)
                }
            }

            Button(
                onClick = {
                    val outName = (fileName ?: "encoded_file") + "_base64.txt"
                    val uri = repository.workspaceManager.saveToDownloads(outName, "text/plain", base64Result.toByteArray(Charsets.UTF_8))
                    if (uri != null) {
                        onShowSnackbar("Disimpan ke Download: $outName")
                    } else {
                        onShowSnackbar("Gagal menyimpan ke Download.")
                    }
                },
                modifier = Modifier.fillMaxWidth().testTag("btn_save_base64_txt"),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceVariant, contentColor = Color.White)
            ) {
                Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Simpan ke File .txt")
            }
        }
    }
}

// -----------------------------------------------------------
// 2. DECODE FILE TAB
// -----------------------------------------------------------
@Composable
private fun DecodeFileTab(
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit
) {
    var base64Input by remember { mutableStateOf("") }
    var outputFileName by remember { mutableStateOf("decoded_file") }
    var outputMime by remember { mutableStateOf("application/octet-stream") }
    var lastSavedUri by remember { mutableStateOf<Uri?>(null) }
    var isDecoding by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            // Load text file
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = base64Input,
            onValueChange = { input ->
                base64Input = input
                // Auto detect data URI mime if present
                if (input.startsWith("data:", ignoreCase = true)) {
                    val semicolon = input.indexOf(';')
                    if (semicolon != -1) {
                        val detected = input.substring(5, semicolon).trim()
                        if (detected.isNotBlank()) outputMime = detected
                    }
                }
            },
            label = { Text("Masukkan String Base64 / Data URI") },
            placeholder = { Text("Tempel data base64 atau format data:image/png;base64,...") },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 120.dp, max = 200.dp)
                .testTag("input_base64_to_decode"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrightCyan,
                unfocusedBorderColor = CyberCardBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedContainerColor = CyberDarkNavy,
                unfocusedContainerColor = CyberDarkNavy
            ),
            shape = RoundedCornerShape(8.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = outputFileName,
                onValueChange = { outputFileName = it },
                label = { Text("Nama File Output") },
                modifier = Modifier.weight(1f).testTag("input_output_filename"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrightCyan,
                    unfocusedBorderColor = CyberCardBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = CyberDarkNavy,
                    unfocusedContainerColor = CyberDarkNavy
                ),
                shape = RoundedCornerShape(8.dp)
            )

            OutlinedTextField(
                value = outputMime,
                onValueChange = { outputMime = it },
                label = { Text("MIME Type") },
                modifier = Modifier.weight(1f).testTag("input_output_mime"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrightCyan,
                    unfocusedBorderColor = CyberCardBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = CyberDarkNavy,
                    unfocusedContainerColor = CyberDarkNavy
                ),
                shape = RoundedCornerShape(8.dp)
            )
        }

        Button(
            onClick = {
                if (base64Input.isBlank()) {
                    onShowSnackbar("Masukkan string Base64 terlebih dahulu.")
                    return@Button
                }
                isDecoding = true
                try {
                    val bytes = repository.decodeBytesBase64(base64Input)
                    val uri = repository.workspaceManager.saveToDownloads(outputFileName, outputMime, bytes)
                    if (uri != null) {
                        lastSavedUri = uri
                        onShowSnackbar("Berhasil didecode & disimpan (${formatBytes(bytes.size.toLong())}) ke Download.")
                    } else {
                        onShowSnackbar("Gagal menyimpan file ke Download.")
                    }
                } catch (e: Exception) {
                    onShowSnackbar("Error dekripsi: Format Base64 tidak valid.")
                } finally {
                    isDecoding = false
                }
            },
            enabled = base64Input.isNotBlank() && !isDecoding,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("btn_decode_save_file"),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = BrightCyan,
                contentColor = CyberBlack
            )
        ) {
            if (isDecoding) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = CyberBlack)
            } else {
                Icon(imageVector = Icons.Default.Download, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Decode & Simpan ke Download", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
            }
        }

        if (lastSavedUri != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        lastSavedUri?.let { repository.workspaceManager.openFileUri(it, outputMime) }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightGreen, contentColor = CyberBlack)
                ) {
                    Text("Buka File", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                }

                OutlinedButton(
                    onClick = {
                        lastSavedUri?.let { repository.workspaceManager.shareFileUri(it, outputMime, "Bagikan File Hasil Decode") }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BrightCyan)
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Bagikan")
                }
            }
        }
    }
}

// -----------------------------------------------------------
// 3. ENCODE TEKS TAB
// -----------------------------------------------------------
@Composable
private fun EncodeTextTab(
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var inputText by remember { mutableStateOf("") }
    var encodedText by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = inputText,
            onValueChange = {
                inputText = it
                encodedText = if (it.isNotBlank()) repository.encodeTextBase64(it) else ""
            },
            label = { Text("Teks Asli (Plain Text)") },
            placeholder = { Text("Ketik teks untuk di-encode ke Base64...") },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 120.dp, max = 180.dp)
                .testTag("input_plain_text_encode"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrightCyan,
                unfocusedBorderColor = CyberCardBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedContainerColor = CyberDarkNavy,
                unfocusedContainerColor = CyberDarkNavy
            ),
            shape = RoundedCornerShape(8.dp)
        )

        OutlinedTextField(
            value = encodedText,
            onValueChange = {},
            readOnly = true,
            label = { Text("Hasil Base64") },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 120.dp, max = 180.dp)
                .testTag("output_base64_encoded_text"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrightCyan,
                unfocusedBorderColor = CyberCardBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedContainerColor = CyberDarkNavy,
                unfocusedContainerColor = CyberDarkNavy
            ),
            shape = RoundedCornerShape(8.dp)
        )

        Button(
            onClick = {
                clipboard.setText(AnnotatedString(encodedText))
                onShowSnackbar("Hasil Base64 berhasil disalin.")
            },
            enabled = encodedText.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(46.dp),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
        ) {
            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Salin Hasil Base64", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
        }
    }
}

// -----------------------------------------------------------
// 4. DECODE TEKS TAB
// -----------------------------------------------------------
@Composable
private fun DecodeTextTab(
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var inputBase64 by remember { mutableStateOf("") }
    var decodedResult by remember { mutableStateOf("") }
    var decodeError by remember { mutableStateOf<String?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = inputBase64,
            onValueChange = {
                inputBase64 = it
                decodeError = null
                if (it.isBlank()) {
                    decodedResult = ""
                } else {
                    try {
                        decodedResult = repository.decodeTextBase64(it)
                    } catch (e: Exception) {
                        decodeError = "Format Base64 tidak valid."
                        decodedResult = ""
                    }
                }
            },
            label = { Text("Input Base64") },
            placeholder = { Text("Tempel teks Base64 untuk didecode...") },
            isError = decodeError != null,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 120.dp, max = 180.dp)
                .testTag("input_base64_text_decode"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrightCyan,
                unfocusedBorderColor = CyberCardBorder,
                errorBorderColor = BrightRed,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedContainerColor = CyberDarkNavy,
                unfocusedContainerColor = CyberDarkNavy
            ),
            shape = RoundedCornerShape(8.dp)
        )

        if (decodeError != null) {
            Text(
                text = decodeError.orEmpty(),
                style = MaterialTheme.typography.bodySmall.copy(color = BrightRed)
            )
        }

        OutlinedTextField(
            value = decodedResult,
            onValueChange = {},
            readOnly = true,
            label = { Text("Hasil Decode (Plain Text)") },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 120.dp, max = 180.dp)
                .testTag("output_decoded_plain_text"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrightCyan,
                unfocusedBorderColor = CyberCardBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedContainerColor = CyberDarkNavy,
                unfocusedContainerColor = CyberDarkNavy
            ),
            shape = RoundedCornerShape(8.dp)
        )

        Button(
            onClick = {
                clipboard.setText(AnnotatedString(decodedResult))
                onShowSnackbar("Hasil teks berhasil disalin.")
            },
            enabled = decodedResult.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(46.dp),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
        ) {
            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Salin Hasil Teks", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    val df = DecimalFormat("#,##0.#")
    return "${df.format(bytes / Math.pow(1024.0, digitGroups.toDouble()))} ${units[digitGroups]}"
}
