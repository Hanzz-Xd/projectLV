package com.baklava.projectlv.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.clickable as foundationClickable
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * Konstanta gerak yang dipakai di seluruh aplikasi supaya semua animasi terasa seragam.
 */
object Motion {
    const val ENTER_MS = 460
    const val STAGGER_MS = 55
    const val MAX_STAGGER_ITEMS = 10
    const val PRESSED_SCALE = 0.965f
}

/**
 * Efek "tekan" yang halus: elemen mengecil sedikit saat ditekan lalu kembali dengan pegas.
 */
fun Modifier.pressScale(
    interactionSource: InteractionSource,
    pressedScale: Float = Motion.PRESSED_SCALE,
    enabled: Boolean = true
): Modifier = composed {
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) pressedScale else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "press_scale"
    )
    graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

/**
 * Pengganti `Modifier.clickable` dari foundation. Perilaku klik & ripple tetap sama,
 * ditambah efek tekan (scale) yang halus. Cukup ganti import
 * `androidx.compose.foundation.clickable` menjadi `com.baklava.projectlv.ui.components.clickable`.
 */
fun Modifier.clickable(
    enabled: Boolean = true,
    onClickLabel: String? = null,
    role: Role? = null,
    onClick: () -> Unit
): Modifier = composed {
    val interactionSource = remember { MutableInteractionSource() }
    pressScale(interactionSource, enabled = enabled)
        .foundationClickable(
            interactionSource = interactionSource,
            indication = LocalIndication.current,
            enabled = enabled,
            onClickLabel = onClickLabel,
            role = role,
            onClick = onClick
        )
}

/**
 * Animasi masuk (fade + naik + sedikit membesar). [index] dipakai untuk jeda bertahap
 * antar elemen. Hanya diputar sekali per elemen (tidak berulang saat scroll / rotasi).
 */
fun Modifier.staggeredEntrance(
    index: Int = 0,
    offsetY: Dp = 22.dp,
    durationMs: Int = Motion.ENTER_MS,
    startScale: Float = 0.96f
): Modifier = composed {
    var played by rememberSaveable { mutableStateOf(false) }
    val progress = remember { Animatable(if (played) 1f else 0f) }

    LaunchedEffect(Unit) {
        if (!played) {
            val steps = index.coerceIn(0, Motion.MAX_STAGGER_ITEMS)
            delay((steps * Motion.STAGGER_MS).toLong())
            progress.animateTo(1f, tween(durationMillis = durationMs, easing = FastOutSlowInEasing))
            played = true
        }
    }

    graphicsLayer {
        val p = progress.value
        alpha = p
        translationY = (1f - p) * offsetY.toPx()
        val s = startScale + (1f - startScale) * p
        scaleX = s
        scaleY = s
    }
}
