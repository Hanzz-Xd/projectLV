package com.baklava.projectlv.data.admin

/** Maps UI destinations to stable admin-controlled tool IDs. */
object GlobalToolPolicy {
    const val BASE64 = "base64"
    const val MAGIC_LINK = "magiclink"
    const val WEB_TOOLS = "webtools"
    const val STROM_AI = "stromai"
    const val DOWNLOADER = "downloader"
    const val MEDIA = "media"
    const val QUALITY_METHOD = "tiktok_quality"
    const val PY_OBFUSCATOR = "py_obfuscator"
    const val PTERODACTYL_WHATSAPP = "pterodactyl_whatsapp"
    const val ALIGHT_MOTION_FINDER = "alight_motion_finder"
    const val SFL_BYPASS = "sfl_bypass"

    /** Every tool exposed to Global Control, in stable UI order. */
    val ALL_TOOL_IDS: List<String> = listOf(
        BASE64,
        MAGIC_LINK,
        WEB_TOOLS,
        STROM_AI,
        DOWNLOADER,
        MEDIA,
        QUALITY_METHOD,
        PY_OBFUSCATOR,
        PTERODACTYL_WHATSAPP,
        ALIGHT_MOTION_FINDER,
        SFL_BYPASS
    )

    fun forDestination(name: String): String? = when (name) {
        "BASE64_LAB" -> BASE64
        "MAGIC_LINK" -> MAGIC_LINK
        "WEB_TOOLS" -> WEB_TOOLS
        "STROM_AI" -> STROM_AI
        "DOWNLOADER" -> DOWNLOADER
        "MEDIA" -> MEDIA
        "TIKTOK_QUALITY" -> QUALITY_METHOD
        "PY_OBFUSCATOR" -> PY_OBFUSCATOR
        "PTERODACTYL_WHATSAPP" -> PTERODACTYL_WHATSAPP
        "ALIGHT_MOTION_FINDER" -> ALIGHT_MOTION_FINDER
        "SFL_BYPASS" -> SFL_BYPASS
        else -> null
    }

    fun label(toolId: String): String = when (toolId) {
        BASE64 -> "Base64"
        MAGIC_LINK -> "Magic Link"
        WEB_TOOLS -> "Web Tools"
        STROM_AI -> "Strom AI"
        DOWNLOADER -> "Downloader"
        MEDIA -> "Media"
        QUALITY_METHOD -> "TikTok Quality"
        PY_OBFUSCATOR -> "Py Obfuscator"
        PTERODACTYL_WHATSAPP -> "cPanel Pterodactyl"
        ALIGHT_MOTION_FINDER -> "Alight Motion Finder"
        SFL_BYPASS -> "SFL Link Bypass"
        else -> toolId
    }
}
