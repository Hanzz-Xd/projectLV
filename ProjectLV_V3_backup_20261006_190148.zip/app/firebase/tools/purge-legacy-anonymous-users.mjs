import admin from 'firebase-admin';

const execute = process.argv.includes('--execute');
const projectId = process.env.FIREBASE_PROJECT_ID || undefined;

admin.initializeApp(projectId ? { projectId } : undefined);
const auth = admin.auth();
const db = admin.firestore();

async function listAllUsers() {
  const users = [];
  let pageToken;
  do {
    const page = await auth.listUsers(1000, pageToken);
    users.push(...page.users);
    pageToken = page.pageToken;
  } while (pageToken);
  return users;
}

function isLegacyAnonymous(user) {
  return user.providerData.length === 0 && !user.email && !user.phoneNumber;
}

async function deleteDeviceTree(deviceRef) {
  const events = await deviceRef.collection('securityEvents').listDocuments();
  for (const eventRef of events) {
    await eventRef.delete();
  }
  await deviceRef.delete();
}

const users = await listAllUsers();
const anonymousUsers = users.filter(isLegacyAnonymous);
const anonymousUids = new Set(anonymousUsers.map((user) => user.uid));

const deviceSnapshot = await db.collection('devices').get();
const legacyDevices = deviceSnapshot.docs.filter((doc) => anonymousUids.has(doc.get('ownerUid')));

console.log(`Firebase project: ${projectId ?? '(default credentials)'}`);
console.log(`Total Auth users: ${users.length}`);
console.log(`Legacy anonymous users: ${anonymousUsers.length}`);
console.log(`Legacy device records linked to them: ${legacyDevices.length}`);

for (const user of anonymousUsers) {
  console.log(`ANON USER ${user.uid}`);
}
for (const doc of legacyDevices) {
  console.log(`DEVICE ${doc.id} ownerUid=${doc.get('ownerUid')}`);
}

if (!execute) {
  console.log('\nDRY RUN ONLY. No account or Firestore record was deleted.');
  console.log('Run again with --execute to perform the irreversible cleanup.');
  process.exit(0);
}

for (const doc of legacyDevices) {
  await deleteDeviceTree(doc.ref);
}

for (let i = 0; i < anonymousUsers.length; i += 1000) {
  const chunk = anonymousUsers.slice(i, i + 1000).map((user) => user.uid);
  const result = await auth.deleteUsers(chunk);
  console.log(`Deleted Auth users: ${result.successCount}; failed: ${result.failureCount}`);
  if (result.errors.length) {
    for (const failure of result.errors) {
      console.error(`FAILED ${failure.uid}: ${failure.error.message}`);
    }
  }
}

console.log('\nCleanup complete. Verify Firestore + Authentication before publishing the new build.');
