package com.baklava.projectlv.ui.modules.webtools

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.baklava.projectlv.data.webtools.HtmlObfuscatorEngine
import com.baklava.projectlv.ui.components.Button
import com.baklava.projectlv.ui.components.OutlinedButton
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.charset.StandardCharsets
import java.security.SecureRandom

private const val MAX_INPUT_BYTES = 8 * 1024 * 1024

@Composable
fun HtmlObfuscatorTab(
    onShowSnackbar: (String) -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var html by remember { mutableStateOf("") }
    var css by remember { mutableStateOf("") }
    var js by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var paddingRepeat by remember { mutableStateOf("2500") }
    var paddingLines by remember { mutableStateOf("20") }
    var result by remember { mutableStateOf<HtmlObfuscatorEngine.Result?>(null) }
    var preview by remember { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }
    var outputName by remember { mutableStateOf("encrypted_web.html") }

    fun readText(uri: Uri): String? {
        return try {
            val resolver = context.contentResolver
            val bytes = resolver.openInputStream(uri)?.use { input ->
                val stream = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(16 * 1024)
                var total = 0
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    total += read
                    if (total > MAX_INPUT_BYTES) return null
                    stream.write(buffer, 0, read)
                }
                stream.toByteArray()
            } ?: return null
            bytes.toString(StandardCharsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }

    fun readPreview(file: File, maxChars: Int = 12_000): String {
        return try {
            file.inputStream().bufferedReader(StandardCharsets.UTF_8).use { reader ->
                val buffer = CharArray(maxChars)
                val count = reader.read(buffer)
                if (count <= 0) "" else String(buffer, 0, count)
            }
        } catch (_: Exception) {
            ""
        }
    }

    fun clearResultFile() {
        result?.outputFile?.let { runCatching { it.delete() } }
        result = null
        preview = ""
    }

    fun generateKey() {
        val random = ByteArray(18)
        SecureRandom().nextBytes(random)
        key = buildString(random.size * 2) {
            random.forEach { byte ->
                append("%02x".format(byte.toInt() and 0xFF))
            }
        }
    }

    val htmlPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val text = readText(uri)
        if (text == null) {
            onShowSnackbar("HTML gagal dibaca atau ukurannya melebihi 8 MB.")
        } else {
            html = text
            result = null
            onShowSnackbar("index.html berhasil dimuat.")
        }
    }

    val cssPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val text = readText(uri)
        if (text == null) {
            onShowSnackbar("CSS gagal dibaca atau ukurannya melebihi 8 MB.")
        } else {
            css = text
            onShowSnackbar("CSS berhasil dimuat.")
        }
    }

    val jsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val text = readText(uri)
        if (text == null) {
            onShowSnackbar("JavaScript gagal dibaca atau ukurannya melebihi 8 MB.")
        } else {
            js = text
            onShowSnackbar("JavaScript berhasil dimuat.")
        }
    }

    val savePicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        if (uri == null || result == null) return@rememberLauncherForActivityResult
        scope.launch(Dispatchers.IO) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    result!!.outputFile.inputStream().use { input ->
                        input.copyTo(out, 64 * 1024)
                    }
                } ?: throw IllegalStateException("Tidak bisa membuka output stream.")
                withContext(Dispatchers.Main) {
                    onShowSnackbar("HTML berhasil disimpan.")
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onShowSnackbar("Gagal menyimpan: ${e.message ?: "unknown error"}")
                }
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "ENC / OBF HTML",
            style = MaterialTheme.typography.titleMedium.copy(
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        )
        Text(
            text = "Port Android dari w.py · HTML wajib, CSS/JS opsional · hasilnya reversible obfuscation.",
            style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CyberDarkNavy)
                .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp))
                .padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.Info, contentDescription = null, tint = BrightCyan)
                Text(
                    text = "Ini bukan enkripsi kriptografis. Seed masuk ke loader browser karena browser harus dapat membalik payload.",
                    style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey)
                )
            }
        }

        Text(
            text = "HTML SOURCE",
            style = MaterialTheme.typography.labelSmall.copy(color = BrightCyan, fontWeight = FontWeight.Bold)
        )
        OutlinedTextField(
            value = html,
            onValueChange = { html = it; clearResultFile() },
            modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp),
            label = { Text("index.html / HTML") },
            placeholder = { Text("Tempel source HTML di sini…") },
            minLines = 8,
            maxLines = 14,
            colors = webToolFieldColors(),
            shape = RoundedCornerShape(8.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    htmlPicker.launch(arrayOf("text/html", "text/plain", "application/xhtml+xml"))
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
            ) {
                Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Upload index.html", fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
                onClick = { html = ""; css = ""; js = ""; clearResultFile() },
                modifier = Modifier.weight(0.42f),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
            ) {
                Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Clear")
            }
        }

        Text(
            text = "OPTIONAL CSS",
            style = MaterialTheme.typography.labelSmall.copy(color = BrightCyan, fontWeight = FontWeight.Bold)
        )
        OutlinedTextField(
            value = css,
            onValueChange = { css = it; clearResultFile() },
            modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp),
            label = { Text("CSS inline") },
            minLines = 4,
            maxLines = 8,
            colors = webToolFieldColors(),
            shape = RoundedCornerShape(8.dp)
        )
        OutlinedButton(
            onClick = { cssPicker.launch(arrayOf("text/css", "text/plain")) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
        ) {
            Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("Upload .css")
        }

        Text(
            text = "OPTIONAL JAVASCRIPT",
            style = MaterialTheme.typography.labelSmall.copy(color = BrightCyan, fontWeight = FontWeight.Bold)
        )
        OutlinedTextField(
            value = js,
            onValueChange = { js = it; clearResultFile() },
            modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp),
            label = { Text("JavaScript inline") },
            minLines = 4,
            maxLines = 8,
            colors = webToolFieldColors(),
            shape = RoundedCornerShape(8.dp)
        )
        OutlinedButton(
            onClick = { jsPicker.launch(arrayOf("text/javascript", "application/javascript", "text/plain")) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
        ) {
            Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("Upload .js")
        }

        Text(
            text = "KEY / SEED",
            style = MaterialTheme.typography.labelSmall.copy(color = BrightCyan, fontWeight = FontWeight.Bold)
        )
        OutlinedTextField(
            value = key,
            onValueChange = { key = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Key seed") },
            placeholder = { Text("Masukkan key unik") },
            singleLine = true,
            colors = webToolFieldColors(),
            shape = RoundedCornerShape(8.dp),
            leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) }
        )
        OutlinedButton(
            onClick = { generateKey() },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = BrightCyan)
        ) {
            Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("Generate key")
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = paddingRepeat,
                onValueChange = { paddingRepeat = it.filter(Char::isDigit) },
                modifier = Modifier.weight(1f),
                label = { Text("Pad repeat") },
                singleLine = true,
                colors = webToolFieldColors(),
                shape = RoundedCornerShape(8.dp)
            )
            OutlinedTextField(
                value = paddingLines,
                onValueChange = { paddingLines = it.filter(Char::isDigit) },
                modifier = Modifier.weight(1f),
                label = { Text("Pad lines") },
                singleLine = true,
                colors = webToolFieldColors(),
                shape = RoundedCornerShape(8.dp)
            )
        }

        OutlinedTextField(
            value = outputName,
            onValueChange = { outputName = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Output filename") },
            singleLine = true,
            colors = webToolFieldColors(),
            shape = RoundedCornerShape(8.dp)
        )

        Button(
            onClick = {
                val repeat = paddingRepeat.toIntOrNull()
                val lines = paddingLines.toIntOrNull()
                if (html.isBlank()) {
                    onShowSnackbar("Masukkan atau upload HTML terlebih dahulu.")
                    return@Button
                }
                if (key.isBlank()) {
                    onShowSnackbar("Key seed wajib diisi.")
                    return@Button
                }
                if (repeat == null || lines == null) {
                    onShowSnackbar("Padding harus berupa angka.")
                    return@Button
                }

                scope.launch {
                    working = true
                    result?.outputFile?.let { runCatching { it.delete() } }
                    result = null
                    preview = ""
                    try {

                        val generatedFile = File(
                            context.cacheDir,
                            "encrypted_web_${System.currentTimeMillis()}.html"
                        )

                        val generated = withContext(Dispatchers.Default) {
                            HtmlObfuscatorEngine.obfuscateToFile(
                                htmlSource = html,
                                cssSource = css,
                                jsSource = js,
                                config = HtmlObfuscatorEngine.Config(
                                    keySeed = key,
                                    paddingRepeat = repeat,
                                    paddingLines = lines
                                ),
                                outputFile = generatedFile
                            )
                        }
                        result = generated
                        preview = withContext(Dispatchers.IO) {
                            readPreview(generated.outputFile)
                        }
                        onShowSnackbar("Enc/Obf HTML berhasil dibuat tanpa menahan payload besar di UI.")
                    } catch (e: Exception) {
                        onShowSnackbar("Gagal: ${e.message ?: "error tidak diketahui"}")
                    } finally {
                        working = false
                    }
                }
            },
            enabled = !working,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = BrightGreen, contentColor = CyberBlack)
        ) {
            if (working) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = CyberBlack, strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text("Memproses…")
            } else {
                Icon(Icons.Default.Code, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Encode / Obfuscate HTML", fontWeight = FontWeight.Bold)
            }
        }

        result?.let { generated ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(CyberSurfaceVariant)
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "HASIL SIAP DIGUNAKAN",
                        style = MaterialTheme.typography.labelSmall.copy(color = BrightGreen, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Version ${generated.version} · Payload ${generated.payloadChars.format()} chars · Output ${generated.outputBytes.format()} bytes",
                        style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey)
                    )
                    Text(
                        text = "Source SHA-256: ${generated.sourceSha256}",
                        style = MaterialTheme.typography.labelSmall.copy(color = MutedGrey, fontFamily = FontFamily.Monospace)
                    )

                    Text(
                        text = "Payload disimpan langsung sebagai file. Hanya preview kecil yang ditampilkan agar UI tidak freeze/crash.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey)
                    )
                    OutlinedTextField(
                        value = preview,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 280.dp),
                        label = { Text("Preview encrypted_web.html") },
                        minLines = 8,
                        maxLines = 12,
                        colors = webToolFieldColors(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                scope.launch(Dispatchers.IO) {
                                    try {
                                        val text = generated.outputFile.readText(StandardCharsets.UTF_8)
                                        withContext(Dispatchers.Main) {
                                            clipboard.setText(AnnotatedString(text))
                                            onShowSnackbar("Hasil HTML disalin.")
                                        }
                                    } catch (e: Exception) {
                                        withContext(Dispatchers.Main) {
                                            onShowSnackbar("Gagal menyalin. Untuk output besar, gunakan Simpan atau Bagikan.")
                                        }
                                    }
                                }
                            },
                            enabled = generated.outputBytes <= 1_000_000,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(if (generated.outputBytes <= 1_000_000) "Salin" else "Salin <1MB")
                        }
                        OutlinedButton(
                            onClick = { savePicker.launch(outputName.ifBlank { "encrypted_web.html" }.let { if (it.endsWith(".html", true)) it else "$it.html" }) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("Simpan")
                        }
                        OutlinedButton(
                            onClick = {
                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", generated.outputFile)
                                val share = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/html"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    clipData = android.content.ClipData.newRawUri("encrypted_web.html", uri)
                                }
                                context.startActivity(Intent.createChooser(share, "Bagikan HTML"))
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("Bagikan")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun webToolFieldColors() = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
    focusedBorderColor = BrightCyan,
    unfocusedBorderColor = CyberCardBorder,
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedContainerColor = CyberDarkNavy,
    unfocusedContainerColor = CyberDarkNavy,
    cursorColor = BrightCyan,
    focusedLabelColor = BrightCyan,
    unfocusedLabelColor = MutedGrey
)

private fun Int.format(): String = "%,d".format(this)
