package com.baklava.projectlv.data.streaming

import com.baklava.projectlv.data.security.FirebaseUserAuthManager
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Base64

/**
 * Account-backed persistence for Streaming Mode.
 *
 * Firestore is the canonical cross-device copy. SharedPreferences is kept as a
 * fast local cache, and both sides are merged by the newest timestamp so an
 * offline device does not overwrite newer progress from another device.
 */
class StreamingCloudSyncManager(
    private val localStore: StreamingLocalStore,
    private val authManager: FirebaseUserAuthManager
) {
    private val firestore by lazy { FirebaseFirestore.getInstance() }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val syncMutex = Mutex()

    private var authJob: Job? = null
    private var uploadJob: Job? = null
    private var activeUid: String? = null
    private var syncReady = false
    private var historyListener: ListenerRegistration? = null
    private var myListListener: ListenerRegistration? = null
    private val pendingChanges = LinkedHashMap<String, StreamingLocalChange>()

    @Volatile
    private var started = false

    fun start() {
        if (started) return
        started = true

        localStore.setSyncListener(::onLocalChange)
        authJob = scope.launch {
            authManager.observeAuthState().collectLatest { user ->
                switchUser(user?.takeIf { it.isEmailVerified }?.uid)
            }
        }
    }

    fun close() {
        if (!started) return
        started = false
        authJob?.cancel()
        uploadJob?.cancel()
        authJob = null
        uploadJob = null
        detachListeners()
        activeUid = null
        syncReady = false
        pendingChanges.clear()
        localStore.setSyncListener(null)
        scope.coroutineContext[Job]?.cancel()
    }

    private suspend fun switchUser(uid: String?) {
        if (uid == activeUid && syncReady) return
        syncMutex.lock()
        try {
            detachListeners()
            uploadJob?.cancel()
            pendingChanges.clear()
            activeUid = uid
            syncReady = false
            localStore.activateUser(uid)
            if (uid == null) return

            initialMerge(uid)
            syncReady = true
            attachListeners(uid)
        } finally {
            syncMutex.unlock()
        }
    }

    private suspend fun initialMerge(uid: String) {
        val historyRef = historyCollection(uid)
        val myListRef = myListCollection(uid)

        val cloudHistory: List<WatchRecord> = try {
            historyRef.get().await().documents.mapNotNull(::watchRecordFrom)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            emptyList()
        }
        val cloudMyList: List<MyListEntry> = try {
            myListRef.get().await().documents.mapNotNull(::myListFrom)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            emptyList()
        }

        val localHistory = localStore.history.value
        val localMyList = localStore.myList.value

        val mergedHistoryByKey = LinkedHashMap<String, WatchRecord>()
        (cloudHistory + localHistory).forEach { incoming ->
            val current = mergedHistoryByKey[incoming.key]
            if (current == null || incoming.lastWatchedAt >= current.lastWatchedAt) {
                mergedHistoryByKey[incoming.key] = incoming
            }
        }
        val mergedHistory = mergedHistoryByKey.values
            .sortedByDescending { it.lastWatchedAt }
            .take(80)

        val mergedMyListBySeries = LinkedHashMap<String, MyListEntry>()
        (cloudMyList + localMyList).forEach { incoming ->
            val normalized = incoming.copy(updatedAt = incoming.updatedAt.takeIf { it > 0L } ?: incoming.addedAt)
            val current = mergedMyListBySeries[normalized.seriesId]
            if (current == null || normalized.updatedAt >= current.updatedAt) {
                mergedMyListBySeries[normalized.seriesId] = normalized
            }
        }
        val mergedMyList = mergedMyListBySeries.values.sortedByDescending { it.addedAt }

        localStore.replaceHistoryFromCloud(mergedHistory)
        localStore.replaceMyListFromCloud(mergedMyList)

        // Upload only local records that were newer/missing on the cloud side.
        // This keeps re-login/reinstall sync cheap and avoids needless writes.
        val cloudHistoryByKey = cloudHistory.associateBy { it.key }
        val cloudMyListBySeries = cloudMyList.associateBy { it.seriesId }
        val batch = firestore.batch()
        var operations = 0

        localHistory.forEach { local ->
            val cloud = cloudHistoryByKey[local.key]
            if (cloud == null || local.lastWatchedAt > cloud.lastWatchedAt) {
                batch.set(historyCollection(uid).document(docId(local.key)), historyMap(local, uid))
                operations++
            }
        }
        localMyList.forEach { localRaw ->
            val local = localRaw.copy(updatedAt = localRaw.updatedAt.takeIf { it > 0L } ?: localRaw.addedAt)
            val cloudRaw = cloudMyListBySeries[local.seriesId]
            val cloud = cloudRaw?.copy(updatedAt = cloudRaw.updatedAt.takeIf { it > 0L } ?: cloudRaw.addedAt)
            if (cloud == null || local.updatedAt > cloud.updatedAt) {
                batch.set(myListCollection(uid).document(docId(local.seriesId)), myListMap(local, uid))
                operations++
            }
        }

        if (operations > 0) {
            try {
                batch.commit().await()
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // The local cache is retained; the next mutation will retry the
                // upload and the realtime listener can reconcile remote state.
            }
        }
    }

    private fun onLocalChange(change: StreamingLocalChange) {
        if (!syncReady || activeUid == null) return
        synchronized(pendingChanges) {
            pendingChanges[change.syncKey] = change
        }
        // Do not cancel an upload that is already running: that could cancel an
        // in-flight Firestore commit. A single short debounce is enough because
        // all changes accumulated during the window are flushed together.
        if (uploadJob?.isActive != true) {
            uploadJob = scope.launch {
                delay(900L)
                flushPendingChanges()
            }
        }
    }

    private suspend fun flushPendingChanges() {
        val uid = activeUid ?: return
        val changes: List<StreamingLocalChange> = synchronized(pendingChanges) {
            if (pendingChanges.isEmpty()) return
            val copied = pendingChanges.values.toList()
            pendingChanges.clear()
            copied
        }

        syncMutex.lock()
        try {
            if (!syncReady || activeUid != uid) return
            val historyRef = historyCollection(uid)
            val myListRef = myListCollection(uid)
            val batch = firestore.batch()

            // A clear operation must remove every current history document.
            if (changes.any { it is StreamingLocalChange.HistoryClear }) {
                try {
                    historyRef.get().await().documents.forEach { batch.delete(it.reference) }
                } catch (e: CancellationException) {
                    requeue(changes)
                    throw e
                } catch (_: Exception) {
                    requeue(changes)
                    return
                }
            }

            changes.forEach { change ->
                when (change) {
                    is StreamingLocalChange.HistoryUpsert -> {
                        batch.set(historyRef.document(docId(change.record.key)), historyMap(change.record, uid))
                    }
                    is StreamingLocalChange.HistoryRemove -> {
                        batch.delete(historyRef.document(docId(change.key)))
                    }
                    StreamingLocalChange.HistoryClear -> Unit
                    is StreamingLocalChange.MyListUpsert -> {
                        batch.set(myListRef.document(docId(change.entry.seriesId)), myListMap(change.entry, uid))
                    }
                    is StreamingLocalChange.MyListRemove -> {
                        batch.delete(myListRef.document(docId(change.seriesId)))
                    }
                }
            }

            try {
                batch.commit().await()
            } catch (e: CancellationException) {
                requeue(changes)
                throw e
            } catch (_: Exception) {
                // Keep failed mutations pending so an offline/temporary error
                // cannot silently prevent eventual account synchronization.
                requeue(changes)
            }
        } finally {
            syncMutex.unlock()
        }
    }

    private fun requeue(changes: List<StreamingLocalChange>) {
        synchronized(pendingChanges) {
            changes.forEach { change ->
                pendingChanges[change.syncKey] = change
            }
        }
        scope.launch {
            delay(3000L)
            if (activeUid != null && syncReady) flushPendingChanges()
        }
    }

    private fun attachListeners(uid: String) {
        historyListener = historyCollection(uid).addSnapshotListener { snapshot, error ->
            if (error != null || snapshot == null || activeUid != uid) return@addSnapshotListener
            scope.launch { applyRemoteHistoryChanges(snapshot) }
        }
        myListListener = myListCollection(uid).addSnapshotListener { snapshot, error ->
            if (error != null || snapshot == null || activeUid != uid) return@addSnapshotListener
            scope.launch { applyRemoteMyListChanges(snapshot) }
        }
    }

    private suspend fun applyRemoteHistoryChanges(snapshot: com.google.firebase.firestore.QuerySnapshot) {
        syncMutex.withLock {
            if (!syncReady || activeUid == null) return
            val localByKey = localStore.history.value.associateBy { it.key }
            snapshot.documentChanges.forEach { change ->
                when (change.type) {
                    com.google.firebase.firestore.DocumentChange.Type.ADDED,
                    com.google.firebase.firestore.DocumentChange.Type.MODIFIED -> {
                        val remote = watchRecordFrom(change.document) ?: return@forEach
                        val local = localByKey[remote.key]
                        when {
                            local == null || remote.lastWatchedAt > local.lastWatchedAt -> {
                                val merged = localStore.history.value.filterNot { it.key == remote.key } + remote
                                localStore.replaceHistoryFromCloud(merged)
                            }
                            local.lastWatchedAt > remote.lastWatchedAt -> onLocalChange(StreamingLocalChange.HistoryUpsert(local))
                        }
                    }
                    com.google.firebase.firestore.DocumentChange.Type.REMOVED -> {
                        val key = change.document.getString("key") ?: return@forEach
                        localStore.removeHistoryFromCloud(key)
                    }
                }
            }
        }
    }

    private suspend fun applyRemoteMyListChanges(snapshot: com.google.firebase.firestore.QuerySnapshot) {
        syncMutex.withLock {
            if (!syncReady || activeUid == null) return
            val localBySeries = localStore.myList.value.associateBy { it.seriesId }
            snapshot.documentChanges.forEach { change ->
                when (change.type) {
                    com.google.firebase.firestore.DocumentChange.Type.ADDED,
                    com.google.firebase.firestore.DocumentChange.Type.MODIFIED -> {
                        val remoteRaw = myListFrom(change.document) ?: return@forEach
                        val remote = remoteRaw.copy(updatedAt = remoteRaw.updatedAt.takeIf { it > 0L } ?: remoteRaw.addedAt)
                        val localRaw = localBySeries[remote.seriesId]
                        val local = localRaw?.copy(updatedAt = localRaw.updatedAt.takeIf { it > 0L } ?: localRaw.addedAt)
                        when {
                            local == null || remote.updatedAt > local.updatedAt -> {
                                val merged = localStore.myList.value.filterNot { it.seriesId == remote.seriesId } + remote
                                localStore.replaceMyListFromCloud(merged)
                            }
                            local.updatedAt > remote.updatedAt -> onLocalChange(StreamingLocalChange.MyListUpsert(local))
                        }
                    }
                    com.google.firebase.firestore.DocumentChange.Type.REMOVED -> {
                        val seriesId = change.document.getString("seriesId") ?: return@forEach
                        localStore.removeMyListFromCloud(seriesId)
                    }
                }
            }
        }
    }

    private fun detachListeners() {
        historyListener?.remove()
        historyListener = null
        myListListener?.remove()
        myListListener = null
    }

    private fun historyCollection(uid: String) =
        firestore.collection("accounts").document(uid).collection("streamingHistory")

    private fun myListCollection(uid: String) =
        firestore.collection("accounts").document(uid).collection("streamingMyList")

    private fun historyMap(record: WatchRecord, uid: String) = mapOf(
        "ownerUid" to uid,
        "key" to record.key,
        "seriesId" to record.seriesId,
        "seriesTitle" to record.seriesTitle,
        "cover" to record.cover,
        "episodeId" to record.episodeId,
        "episodeLabel" to record.episodeLabel,
        "episodeUrl" to record.episodeUrl,
        "positionMs" to record.positionMs,
        "durationMs" to record.durationMs,
        "lastWatchedAt" to record.lastWatchedAt,
        "completed" to record.completed
    )

    private fun myListMap(entry: MyListEntry, uid: String) = mapOf(
        "ownerUid" to uid,
        "seriesId" to entry.seriesId,
        "title" to entry.title,
        "cover" to entry.cover,
        "addedAt" to entry.addedAt,
        "status" to entry.status,
        "totalEpisodes" to entry.totalEpisodes,
        "updatedAt" to entry.updatedAt,
        "slug" to entry.slug
    )

    private fun watchRecordFrom(doc: DocumentSnapshot): WatchRecord? = runCatching {
        WatchRecord(
            key = doc.getString("key") ?: doc.id,
            seriesId = doc.getString("seriesId") ?: return@runCatching null,
            seriesTitle = doc.getString("seriesTitle").orEmpty(),
            cover = doc.getString("cover"),
            episodeId = doc.getLong("episodeId") ?: return@runCatching null,
            episodeLabel = doc.getString("episodeLabel").orEmpty(),
            episodeUrl = doc.getString("episodeUrl").orEmpty(),
            positionMs = doc.getLong("positionMs") ?: 0L,
            durationMs = doc.getLong("durationMs") ?: 0L,
            lastWatchedAt = doc.getLong("lastWatchedAt") ?: 0L,
            completed = doc.getBoolean("completed") ?: false
        )
    }.getOrNull()

    private fun myListFrom(doc: DocumentSnapshot): MyListEntry? = runCatching {
        val addedAt = doc.getLong("addedAt") ?: 0L
        MyListEntry(
            seriesId = doc.getString("seriesId") ?: return@runCatching null,
            title = doc.getString("title").orEmpty(),
            cover = doc.getString("cover"),
            addedAt = addedAt,
            status = doc.getString("status") ?: "PLANNED",
            totalEpisodes = doc.getLong("totalEpisodes")?.toInt(),
            updatedAt = doc.getLong("updatedAt") ?: addedAt,
            slug = doc.getString("slug")
        )
    }.getOrNull()

    private fun docId(value: String): String =
        Base64.getUrlEncoder().withoutPadding().encodeToString(value.toByteArray(Charsets.UTF_8))
}
