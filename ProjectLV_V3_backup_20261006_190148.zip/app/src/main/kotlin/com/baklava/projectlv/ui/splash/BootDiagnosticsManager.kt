package com.baklava.projectlv.ui.splash

import android.content.Context
import com.baklava.projectlv.data.network.ConnectivityCheckResult
import com.baklava.projectlv.data.network.DeviceIntegrityChecker
import com.baklava.projectlv.data.network.EnvironmentCheckResult
import com.baklava.projectlv.data.network.HttpClientProvider
import com.baklava.projectlv.data.network.NetworkMonitor
import com.baklava.projectlv.data.repository.ErrorReportManager
import com.baklava.projectlv.data.security.FirebaseSecurityManager
import com.baklava.projectlv.data.repository.LeviathanRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URI

enum class BootStep(val label: String) {
    BOOTING_CORE("Booting Leviathan Core"),
    VERIFYING_MODULES("Verifying application modules"),
    INIT_HTTP_ENGINE("Initializing HTTP engine"),
    CHECKING_NETWORK("Checking network"),
    TESTING_ENDPOINTS("Testing API endpoints"),
    SECURITY_ENVIRONMENT("Scanning environment & security"),
    PREPARING_WORKSPACE("Preparing workspace"),
    CHECKING_LICENSE("Checking license"),
    COMPLETE("System Ready")
}

/** Hasil pengujian satu endpoint API individual, ditampilkan di panel diagnostics. */
data class ApiEndpointResult(
    val label: String,
    val host: String,
    val isReachable: Boolean,
    val latencyMs: Long,
    val statusCode: Int
)

data class BootStepState(
    val step: BootStep,
    val isRunning: Boolean = false,
    val isSuccess: Boolean = false,
    val isWarning: Boolean = false,
    val detailMessage: String = "",
    val elapsedMs: Long = 0L
)

data class BootDiagnosticsState(
    val currentStepIndex: Int = 0,
    val totalSteps: Int = 8,
    val steps: List<BootStepState> = BootStep.values().filter { it != BootStep.COMPLETE }.map {
        BootStepState(step = it)
    },
    val isFinished: Boolean = false,
    val isOfflineMode: Boolean = false,
    val isSecurityBlocked: Boolean = false,
    val securityBlockMessage: String = "",
    val securityBanExpiresAt: Long? = null,
    val isLicenseExpired: Boolean = false,
    val hasFatalError: Boolean = false,
    val fatalErrorMessage: String = "",
    val networkCheckResult: ConnectivityCheckResult? = null,
    val environmentCheckResult: EnvironmentCheckResult? = null,
    val apiEndpointResults: List<ApiEndpointResult> = emptyList(),
    val currentStepDescription: String = "Booting Leviathan Core",
    val totalElapsedMs: Long = 0L
)

class BootDiagnosticsManager(
    private val context: Context,
    private val networkMonitor: NetworkMonitor,
    private val repository: LeviathanRepository,
    private val errorReportManager: ErrorReportManager,
    private val firebaseSecurityManager: FirebaseSecurityManager
) {
    private val _state = MutableStateFlow(BootDiagnosticsState())
    val state: StateFlow<BootDiagnosticsState> = _state.asStateFlow()

    // Diagnostics (including the Firestore security check/report) run on this
    // internal scope instead of a scope owned by a Composable. Those Firestore
    // writes can themselves trigger a UI change (a real-time ban swapping the
    // screen away from Splash) — if the write were running on a Composable's
    // scope, that very screen swap would cancel it mid-write. This scope only
    // dies when dispose() is called (from the Activity's onDestroy), so it
    // always survives navigation/recomposition.
    private val managerScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val deviceIntegrityChecker by lazy { DeviceIntegrityChecker(context) }

    /**
     * Endpoint API nyata yang dipakai fitur-fitur aplikasi. Diuji langsung dengan
     * HEAD/GET request pada boot untuk memastikan setiap gateway benar-benar
     * dapat dijangkau sebelum pengguna masuk ke dashboard.
     */
    private val apiEndpointsToTest = listOf(
        "AI Gateway" to "https://api.alfisy.my.id/api/ai/claude-chat",
        "Uploader Service" to "https://bintangapi.my.id/api/uploader/uguu",
        "Tools API" to "https://api.siputzx.my.id",
        "Web2Apk SDKForge" to "https://code-v-compiler-sr.vercel.app/api/public/apk/template"
    )

    /**
     * Starts diagnostics on [managerScope] instead of the caller's scope, so it
     * keeps running to completion even if the composable that triggered it
     * (SplashScreen) leaves composition partway through — see the comment on
     * [managerScope]. Safe to call multiple times (e.g. from a retry button);
     * each call runs independently.
     */
    fun start() {
        managerScope.launch { runDiagnostics() }
    }

    /** Cancels any in-flight diagnostics. Call from the Activity's onDestroy(). */
    fun dispose() {
        managerScope.cancel()
    }

    suspend fun runDiagnostics() = withContext(Dispatchers.IO) {
        val bootStart = System.currentTimeMillis()
        _state.value = BootDiagnosticsState()
        val steps = _state.value.steps.toMutableList()

        suspend fun executeStep(
            index: Int,
            action: suspend () -> Pair<Boolean, String>,
            isWarningStep: Boolean = false
        ): Boolean {
            val step = steps[index].step
            _state.value = _state.value.copy(
                currentStepIndex = index,
                currentStepDescription = step.label
            )
            steps[index] = steps[index].copy(isRunning = true)
            _state.value = _state.value.copy(steps = steps.toList())

            val startTime = System.currentTimeMillis()
            val (success, detail) = try {
                action()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                errorReportManager.capture(e, "BOOT / ${step.name}")
                Pair(false, e.message ?: "Failed")
            }

            val elapsed = System.currentTimeMillis() - startTime
            val minFloor = 180L
            if (elapsed < minFloor) {
                delay(minFloor - elapsed)
            }
            val displayedElapsed = System.currentTimeMillis() - startTime

            steps[index] = steps[index].copy(
                isRunning = false,
                isSuccess = success,
                isWarning = !success && isWarningStep,
                detailMessage = detail,
                elapsedMs = displayedElapsed
            )
            _state.value = _state.value.copy(
                steps = steps.toList(),
                totalElapsedMs = System.currentTimeMillis() - bootStart
            )
            return success
        }

        // 1. Booting Leviathan Core
        val step1Success = executeStep(0, {
            val prefs = context.getSharedPreferences("leviathan_core_config", Context.MODE_PRIVATE)
            val firstRun = prefs.getBoolean("init_completed", false)
            if (!firstRun) {
                prefs.edit().putBoolean("init_completed", true).apply()
            }
            Pair(true, "Core graph initialized")
        })

        if (!step1Success) {
            _state.value = _state.value.copy(
                hasFatalError = true,
                fatalErrorMessage = "Gagal inisialisasi Leviathan Core."
            )
            return@withContext
        }

        // 2. Verifying application modules — real element/dependency checks, not a placeholder delay.
        val step2Success = executeStep(1, {
            val checks = mutableListOf<Pair<String, Boolean>>()
            checks += "Repository" to true
            checks += "NetworkMonitor" to true
            checks += "ErrorReportManager" to true
            checks += "Workspace dir accessible" to runCatching {
                repository.workspaceManager.getInternalWorkspaceDir().exists()
            }.getOrDefault(false)
            checks += "SharedPreferences writable" to runCatching {
                val test = context.getSharedPreferences("leviathan_boot_probe", Context.MODE_PRIVATE)
                test.edit().putLong("probe_ts", System.currentTimeMillis()).commit()
            }.getOrDefault(false)
            checks += "Cache dir writable" to runCatching {
                context.cacheDir.canWrite()
            }.getOrDefault(false)

            val passed = checks.count { it.second }
            val allOk = passed == checks.size
            val failedNames = checks.filterNot { it.second }.joinToString { it.first }
            Pair(allOk, "$passed/${checks.size} modul aktif" + if (!allOk) " • $failedNames gagal" else "")
        })

        // 3. Initializing HTTP engine
        val step3Success = executeStep(2, {
            val client = HttpClientProvider.okHttpClient
            val hasInterceptors = client.interceptors.isNotEmpty()
            val connectTimeoutOk = client.connectTimeoutMillis > 0
            Pair(hasInterceptors && connectTimeoutOk, "OkHttp + SecretRedactor active")
        })

        if (!step3Success) {
            _state.value = _state.value.copy(
                hasFatalError = true,
                fatalErrorMessage = "HTTP Engine initialization failed."
            )
            return@withContext
        }

        // 4. Checking network (real DNS resolution & neutral host probe)
        var isOnline = false
        var netResult: ConnectivityCheckResult? = null
        executeStep(3, {
            val result = networkMonitor.checkRealConnectivity()
            netResult = result
            isOnline = result.isConnected
            Pair(result.isConnected, result.message)
        }, isWarningStep = true)

        _state.value = _state.value.copy(networkCheckResult = netResult)

        // 5. Testing each configured API endpoint individually with a real HEAD/GET probe.
        var endpointFailures = 0
        executeStep(4, {
            val results = mutableListOf<ApiEndpointResult>()
            if (isOnline) {
                for ((label, urlString) in apiEndpointsToTest) {
                    val uri = URI(urlString)
                    val started = System.currentTimeMillis()
                    val (reachable, code) = try {
                        InetAddress.getByName(uri.host)
                        val connection = (uri.toURL().openConnection() as HttpURLConnection).apply {
                            requestMethod = "HEAD"
                            connectTimeout = 3500
                            readTimeout = 3500
                            instanceFollowRedirects = true
                        }
                        val responseCode = runCatching { connection.responseCode }.getOrDefault(-1)
                        connection.disconnect()
                        Pair(responseCode in 200..499, responseCode)
                    } catch (e: Exception) {
                        Pair(false, -1)
                    }
                    val latency = System.currentTimeMillis() - started
                    results += ApiEndpointResult(
                        label = label,
                        host = uri.host ?: urlString,
                        isReachable = reachable,
                        latencyMs = latency,
                        statusCode = code
                    )
                }
            }
            _state.value = _state.value.copy(apiEndpointResults = results)
            endpointFailures = results.count { !it.isReachable }
            val detail = if (!isOnline) {
                "Dilewati — tidak ada koneksi internet"
            } else {
                "${results.size - endpointFailures}/${results.size} endpoint merespons"
            }
            Pair(isOnline && endpointFailures == 0, detail)
        }, isWarningStep = true)

        // 6. Security & environment scan — VPN, root indicators, debugger, emulator heuristics.
        executeStep(5, {
            val result = deviceIntegrityChecker.runFullCheck()
            _state.value = _state.value.copy(environmentCheckResult = result)

            val flags = mutableListOf<String>()
            if (result.vpnActive) flags += "VPN aktif"
            if (result.rootIndicatorsFound > 0) flags += "${result.rootIndicatorsFound} indikator root"
            if (result.debuggerAttached) flags += "debugger terpasang"
            if (result.isProbableEmulator) flags += "kemungkinan emulator"

            val detail = if (flags.isEmpty()) {
                "Lingkungan bersih • tidak ada anomali terdeteksi"
            } else {
                flags.joinToString(", ")
            }

            // Security findings are now sent to the trusted Firebase backend.
            // They no longer force offline mode or crash the process.
            if (flags.isNotEmpty()) {
                val access = firebaseSecurityManager.reportSecurityViolation(result)
                applyAccessVerdict(
                    access,
                    fallbackBlockedMessage = "Pelanggaran keamanan terdeteksi. Akses perangkat diblokir."
                )
            } else {
                val access = firebaseSecurityManager.checkAccess()
                applyAccessVerdict(
                    access,
                    fallbackBlockedMessage = "Akses perangkat ditolak oleh server."
                )
            }

            Pair(flags.isEmpty(), detail)
        }, isWarningStep = true)

        // 7. Preparing workspace
        executeStep(6, {
            val workspace = repository.workspaceManager.getInternalWorkspaceDir()
            val writable = workspace.canWrite()
            Pair(writable, "Download storage validated")
        })

        // 8. Preparing final ready state. Legacy expiry/license checks are removed.

        if (_state.value.isSecurityBlocked) {
            _state.value = _state.value.copy(isFinished = true, isOfflineMode = false)
        } else if (!isOnline) {
            // Offline is a network state, not a security verdict. Keep the retry UI.
            _state.value = _state.value.copy(
                isOfflineMode = true,
                isFinished = false
            )
        } else {
            delay(200)
            _state.value = _state.value.copy(isFinished = true, isOfflineMode = false)
        }
    }

    /**
     * Turns a [FirebaseSecurityManager.AccessState] into boot-state changes,
     * distinguishing an actual server verdict (banned / account-device mismatch — a real
     * reason to block) from a verification failure (Firestore rules not
     * deployed, App Check rejecting the request, no network, etc. —
     * [FirebaseSecurityManager.AccessState.verificationFailed]).
     *
     * A verification failure is an infrastructure problem, not evidence the
     * device did anything wrong, so — same as the network-offline case above —
     * it must NOT show the "DEVICE BLOCKED" screen. It only gets logged so the
     * misconfiguration (e.g. undeployed firestore.rules) is still visible in
     * error reports.
     */
    private fun applyAccessVerdict(
        access: FirebaseSecurityManager.AccessState,
        fallbackBlockedMessage: String
    ) {
        when {
            access.allowed -> {
            }
            access.verificationFailed -> {
                // Authentication transitions such as a missing verification
                // claim are expected during the login gate and should not be
                // written as a fatal-looking error. A real Firebase access
                // failure (for example App Check or Firestore Rules rejection)
                // must still stop boot so it cannot become an access bypass.
                val expectedAuthTransition = access.message.contains("belum terverifikasi", ignoreCase = true)
                    || access.message.contains("Login diperlukan", ignoreCase = true)
                    || access.message.contains("Sesi Firebase berakhir", ignoreCase = true)

                if (!expectedAuthTransition) {
                    errorReportManager.capture(
                        IllegalStateException(access.message),
                        "BOOT / FIREBASE_VERIFICATION_FAILED"
                    )
                    _state.value = _state.value.copy(
                        hasFatalError = true,
                        fatalErrorMessage = access.message.ifBlank { "Akses Firebase gagal diverifikasi." },
                        isFinished = false,
                        isOfflineMode = false
                    )
                } else {
                    _state.value = _state.value.copy(
                        isFinished = false,
                        isOfflineMode = false
                    )
                }
            }
            else -> {
                // A genuine verdict from the backend: banned or account-device mismatch.
                _state.value = _state.value.copy(
                    isSecurityBlocked = true,
                    securityBlockMessage = access.message.ifBlank { fallbackBlockedMessage },
                    securityBanExpiresAt = access.banExpiresAt
                )
            }
        }
    }

    fun proceedToOfflineDashboard() {
        // Intentionally do not bypass Firebase access verification.
        _state.value = _state.value.copy(isFinished = false, isOfflineMode = true)
    }

    /**
     * Real-time device access observer. Unlike [runDiagnostics], which only
     * checks access once during boot, this exposes a live Firestore listener
     * so a ban (or unban) applied by an admin while the app is already open
     * is reflected immediately, without requiring a restart.
     *
     * Intended to be collected for the lifetime of the app (e.g. from
     * MainActivity), independent of which screen/nav-state is currently shown.
     */
    fun observeSecurityAccess() = firebaseSecurityManager.observeAccess()
}
