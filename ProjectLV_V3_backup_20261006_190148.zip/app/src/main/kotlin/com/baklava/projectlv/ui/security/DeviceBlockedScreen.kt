package com.baklava.projectlv.ui.security

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import com.baklava.projectlv.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import com.baklava.projectlv.ui.components.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.MutedGrey

/** Telegram username/link for the admin contact button. Adjust to your actual support channel. */
internal const val ADMIN_TELEGRAM_URL = "https://t.me/projectleviathan_admin"

@Composable
fun DeviceBlockedScreen(
    message: String,
    banExpiresAt: Long? = null,
    onOk: () -> Unit = {}
) {
    val context = LocalContext.current

    Box(
        modifier = Modifier.fillMaxSize().background(CyberBlack).padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                .background(CyberDarkNavy).border(2.dp, BrightRed, RoundedCornerShape(18.dp))
                .padding(30.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Block, contentDescription = "Blocked", tint = BrightRed)
                Spacer(Modifier.height(18.dp))
                Text("DEVICE BLOCKED", color = BrightRed, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
                Spacer(Modifier.height(12.dp))
                Text(
                    message.ifBlank { "Perangkat ini diblokir sementara karena pelanggaran keamanan." },
                    color = Color.White,
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center
                )
                banExpiresAt?.let {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Ban berakhir: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(it))}",
                        color = MutedGrey,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(Modifier.height(26.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(ADMIN_TELEGRAM_URL))
                                context.startActivity(intent)
                            } catch (_: ActivityNotFoundException) {
                                // No app can handle the link (e.g. no browser installed).
                                // Silently ignore rather than crash the blocked screen.
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Hubungi Admin")
                    }

                    Button(
                        onClick = onOk,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BrightRed,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("OK")
                    }
                }
            }
        }
    }
}
