package com.baklava.projectlv.data.models

import java.text.SimpleDateFormat
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

object LicenseManager {
    const val LICENSE_NAME = "PROJECT-LEVIATHAN"
    
    private const val DEFAULT_EXPIRY_ISO = "2026-10-30T23:59:59+07:00"

    private var expiryEpochMillis: Long = parseIsoExpiry(DEFAULT_EXPIRY_ISO)

    @Synchronized
    fun setServerExpiryMillis(epochMillis: Long?) {
        if (epochMillis != null && epochMillis > 0L) {
            expiryEpochMillis = epochMillis
        }
    }

    private fun parseIsoExpiry(isoString: String): Long {
        return try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                val zdt = ZonedDateTime.parse(isoString, DateTimeFormatter.ISO_OFFSET_DATE_TIME)
                zdt.toInstant().toEpochMilli()
            } else {
                val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
                sdf.parse(isoString)?.time ?: (System.currentTimeMillis() + 86400000L)
            }
        } catch (_: Exception) {
            System.currentTimeMillis() + 86400000L
        }
    }

    fun setCustomExpiry(isoString: String) {
        expiryEpochMillis = parseIsoExpiry(isoString)
    }

    fun remainingSeconds(): Long {
        val diffMs = expiryEpochMillis - System.currentTimeMillis()
        return if (diffMs > 0) diffMs / 1000 else 0L
    }

    fun isExpired(): Boolean {
        return remainingSeconds() <= 0
    }

    fun formattedRemaining(): String {
        var seconds = remainingSeconds()
        if (seconds <= 0) return "EXPIRED"

        val days = seconds / 86400
        seconds %= 86400
        val hours = seconds / 3600
        seconds %= 3600
        val minutes = seconds / 60
        seconds %= 60

        return String.format(Locale.US, "%dd %02dh %02dm %02ds", days, hours, minutes, seconds)
    }

    fun formattedExpiry(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss (z)", Locale.getDefault())
        return sdf.format(Date(expiryEpochMillis))
    }
}
