# ProjectLV — Firebase Boot Access Fix

## Fixed
- FirebaseSecurityManager now reloads the FirebaseUser before the protected Firestore device check.
- FirebaseSecurityManager refreshes the Firebase ID token with getIdToken(true) so the `email_verified` claim used by Firestore Rules is current.
- Unverified/non-email-password sessions no longer attempt protected device access.
- Security violation reporting also refreshes the session before Firestore access.
- The real-time access observer refreshes the session before attaching its device listener.
- BootDiagnosticsManager no longer records expected authentication transitions such as an unverified email as a fatal-looking error.
- A real Firebase verification failure (for example Firestore Rules/App Check rejection) now stops the boot instead of being silently allowed through to the main dashboard.
- SplashScreen now provides a `Coba Lagi` recovery action for a genuine Firebase verification failure.

## Security behavior
The rules were not weakened to hide PERMISSION_DENIED. A verified Firebase Email/Password session is still required for protected application data. This change specifically prevents a stale Auth token from being used against rules that depend on `email_verified`.

## App Check
The project continues to use Debug App Check for debug builds and Play Integrity for release builds. If Firestore App Check enforcement is enabled and the debug token for the AndroidIDE/sideloaded debug build is not registered in Firebase Console, Firestore can still return PERMISSION_DENIED. In that case register the displayed debug token or use a properly configured release/Play Integrity build.

## Build status
Static source inspection completed. Full Gradle compilation was not verifiable in this environment because the wrapper requires Gradle 9.0.0 from services.gradle.org and the environment cannot resolve that host.
