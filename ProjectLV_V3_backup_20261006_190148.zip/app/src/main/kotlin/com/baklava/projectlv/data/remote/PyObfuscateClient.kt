package com.baklava.projectlv.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Client untuk API:
 * https://api.pyobfuscate.com/obfuscate
 *
 * Payload berdasarkan source.txt:
 * {
 *   "code": "...",
 *   "mode": "pro",
 *   "options": {
 *      "rename": true,
 *      "encrypt": true,
 *      "flatten": true,
 *      "builtins": true,
 *      "imports": true,
 *      "attrs": true,
 *      "junk": true
 *   }
 * }
 */
class PyObfuscateClient(
    private val client: OkHttpClient = defaultClient()
) {

    companion object {
        private const val BASE_URL =
            "https://api.pyobfuscate.com/obfuscate"

        private const val ORIGIN =
            "https://pyobfuscate.com"

        private const val REFERER =
            "https://pyobfuscate.com/"

        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 10; K) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/152.0.0.0 Mobile Safari/537.36"

        private const val ACCEPT_LANGUAGE =
            "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"

        private val JSON_MEDIA_TYPE =
            "application/json; charset=utf-8".toMediaType()

        fun defaultClient(): OkHttpClient {
            return OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .readTimeout(120, TimeUnit.SECONDS)
                .callTimeout(180, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build()
        }
    }

    /**
     * Semua layer obfuscation tersedia sesuai payload dari source.txt.
     */
    data class Options(
        val rename: Boolean = true,
        val encrypt: Boolean = true,
        val flatten: Boolean = true,
        val builtins: Boolean = true,
        val imports: Boolean = true,
        val attrs: Boolean = true,
        val junk: Boolean = true
    ) {

        fun toJson(): JSONObject {
            return JSONObject().apply {
                put("rename", rename)
                put("encrypt", encrypt)
                put("flatten", flatten)
                put("builtins", builtins)
                put("imports", imports)
                put("attrs", attrs)
                put("junk", junk)
            }
        }
    }

    data class Diagnostic(
        val code: String?,
        val message: String?,
        val severity: String?
    )

    data class Metrics(
        val inputBytes: Int? = null,
        val outputBytes: Int? = null,
        val astNodes: Int? = null,
        val astDepth: Int? = null,
        val intsEncoded: Int? = null,
        val stringsEncoded: Int? = null
    )

    data class ObfuscationResult(
        val result: String,
        val diagnostics: List<Diagnostic> = emptyList(),
        val metrics: Metrics? = null
    )

    /**
     * Obfuscate Python source.
     *
     * @param code source Python asli
     * @param mode mode API, default "pro"
     * @param options konfigurasi obfuscation
     */
    suspend fun obfuscate(
        code: String,
        mode: String = "pro",
        options: Options = Options()
    ): Result<ObfuscationResult> = withContext(Dispatchers.IO) {

        runCatching {
            require(code.isNotBlank()) {
                "Python source tidak boleh kosong."
            }

            val payload = JSONObject().apply {
                put("code", code)
                put("mode", mode)
                put("options", options.toJson())
            }

            val requestBody = payload
                .toString()
                .toRequestBody(JSON_MEDIA_TYPE)

            val request = Request.Builder()
                .url(BASE_URL)
                .post(requestBody)
                .header("User-Agent", USER_AGENT)
                // PENTING: jangan set header Accept-Encoding secara manual.
                // OkHttp otomatis meminta gzip dan men-decompress body secara
                // transparan HANYA jika header ini tidak disentuh aplikasi.
                // Begitu di-override manual (mis. "gzip, deflate, br, zstd"),
                // OkHttp menganggap aplikasi ingin menangani decoding sendiri
                // dan berhenti men-decompress -- padahal OkHttp tidak punya
                // decoder Brotli ("br") bawaan sama sekali. Akibatnya body
                // yang diterima adalah bytes Brotli mentah yang gagal
                // di-parse sebagai JSON ("Response server tidak dapat
                // dibaca"), padahal server sebenarnya membalas 200 OK valid.
                .header("Content-Type", "application/json")
                .header("Origin", ORIGIN)
                .header("Referer", REFERER)
                .header("Accept-Language", ACCEPT_LANGUAGE)
                .header("Accept", "application/json, text/plain, */*")
                .build()

            client.newCall(request).execute().use { response ->

                val responseBody = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    throw PyObfuscateException.HttpError(
                        code = response.code,
                        message = extractServerError(responseBody)
                    )
                }

                if (responseBody.isBlank()) {
                    throw PyObfuscateException.EmptyResponse
                }

                parseResponse(responseBody)
            }
        }
    }

    /**
     * Synchronous helper.
     *
     * Jangan panggil function ini pada Main Thread.
     */
    fun obfuscateBlocking(
        code: String,
        mode: String = "pro",
        options: Options = Options()
    ): Result<ObfuscationResult> {

        return try {
            if (code.isBlank()) {
                return Result.failure(
                    IllegalArgumentException("Python source tidak boleh kosong.")
                )
            }

            val payload = JSONObject().apply {
                put("code", code)
                put("mode", mode)
                put("options", options.toJson())
            }

            val requestBody = payload
                .toString()
                .toRequestBody(JSON_MEDIA_TYPE)

            val request = Request.Builder()
                .url(BASE_URL)
                .post(requestBody)
                .header("User-Agent", USER_AGENT)
                // PENTING: jangan set header Accept-Encoding secara manual.
                // OkHttp otomatis meminta gzip dan men-decompress body secara
                // transparan HANYA jika header ini tidak disentuh aplikasi.
                // Begitu di-override manual (mis. "gzip, deflate, br, zstd"),
                // OkHttp menganggap aplikasi ingin menangani decoding sendiri
                // dan berhenti men-decompress -- padahal OkHttp tidak punya
                // decoder Brotli ("br") bawaan sama sekali. Akibatnya body
                // yang diterima adalah bytes Brotli mentah yang gagal
                // di-parse sebagai JSON ("Response server tidak dapat
                // dibaca"), padahal server sebenarnya membalas 200 OK valid.
                .header("Content-Type", "application/json")
                .header("Origin", ORIGIN)
                .header("Referer", REFERER)
                .header("Accept-Language", ACCEPT_LANGUAGE)
                .header("Accept", "application/json, text/plain, */*")
                .build()

            client.newCall(request).execute().use { response ->

                val responseBody = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    return Result.failure(
                        PyObfuscateException.HttpError(
                            response.code,
                            extractServerError(responseBody)
                        )
                    )
                }

                if (responseBody.isBlank()) {
                    return Result.failure(
                        PyObfuscateException.EmptyResponse
                    )
                }

                Result.success(parseResponse(responseBody))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Parse response:
     *
     * {
     *   "result": "...",
     *   "diagnostics": [...],
     *   "metrics": {...}
     * }
     */
    private fun parseResponse(
        rawJson: String
    ): ObfuscationResult {

        val trimmed = rawJson.trim()

        // Deteksi dini: server sering membalas halaman HTML (mis. blokir WAF/
        // Cloudflare, halaman maintenance, atau rate-limit) alih-alih JSON.
        // Ini ditangkap terpisah supaya pesannya jelas, bukan sekadar
        // "bukan JSON yang valid" tanpa konteks.
        if (trimmed.startsWith("<")) {
            throw PyObfuscateException.InvalidJson(
                rawJson = rawJson,
                cause = IllegalStateException("Response berupa HTML, kemungkinan server memblokir/rate-limit request."),
                reasonHint = "Server membalas halaman HTML, bukan JSON (kemungkinan diblokir atau sedang gangguan)."
            )
        }

        // Deteksi dini kedua: body yang tidak diawali '{' atau '[' dan berisi
        // banyak karakter kontrol/non-printable biasanya adalah body
        // terkompresi (mis. Brotli/gzip) yang gagal didekompresi oleh HTTP
        // client -- paling sering terjadi kalau header Accept-Encoding
        // di-set manual sehingga OkHttp berhenti men-decompress otomatis.
        // Ini bukan error dari server (statusnya tetap 200 OK), jadi
        // pesannya dibedakan dari "JSON tidak valid" biasa.
        if (!trimmed.startsWith("{") && !trimmed.startsWith("[")) {
            val controlCharRatio = trimmed.take(200)
                .count { it.code < 0x09 || (it.code in 0x0E..0x1F) }
                .toDouble() / trimmed.take(200).length.coerceAtLeast(1)

            if (controlCharRatio > 0.1) {
                throw PyObfuscateException.InvalidJson(
                    rawJson = rawJson,
                    cause = IllegalStateException("Response tampak berupa data biner/terkompresi, bukan teks JSON."),
                    reasonHint = "Response tampak masih terkompresi (biner), bukan JSON teks biasa. Kemungkinan ada masalah decoding di HTTP client."
                )
            }
        }


        val root = try {
            JSONObject(trimmed)
        } catch (e: Exception) {
            // Root JSON berupa array `[...]` juga valid JSON tapi bukan bentuk
            // yang API ini dokumentasikan — tangani secara eksplisit alih-alih
            // gagal generik.
            val looksLikeArray = trimmed.startsWith("[")
            throw PyObfuscateException.InvalidJson(
                rawJson = rawJson,
                cause = e,
                reasonHint = if (looksLikeArray) {
                    "Response berupa JSON array, bukan objek seperti yang diharapkan."
                } else {
                    null
                }
            )
        }

        val result = root.optString("result", "")

        if (result.isBlank()) {
            val serverError = extractServerError(rawJson)

            if (!serverError.isNullOrBlank()) {
                throw PyObfuscateException.ApiError(serverError)
            }

            throw PyObfuscateException.MissingResult
        }

        val diagnostics = parseDiagnostics(
            root.optJSONArray("diagnostics")
        )

        val metrics = parseMetrics(
            root.optJSONObject("metrics")
        )

        return ObfuscationResult(
            result = result,
            diagnostics = diagnostics,
            metrics = metrics
        )
    }

    private fun parseDiagnostics(
        array: JSONArray?
    ): List<Diagnostic> {

        if (array == null) {
            return emptyList()
        }

        val list = ArrayList<Diagnostic>(array.length())

        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue

            list += Diagnostic(
                code = item.optStringOrNull("code"),
                message = item.optStringOrNull("message"),
                severity = item.optStringOrNull("severity")
            )
        }

        return list
    }

    private fun parseMetrics(
        json: JSONObject?
    ): Metrics? {

        if (json == null) {
            return null
        }

        return Metrics(
            inputBytes = json.optIntOrNull("input_bytes"),
            outputBytes = json.optIntOrNull("output_bytes"),
            astNodes = json.optIntOrNull("ast_nodes"),
            astDepth = json.optIntOrNull("ast_depth"),
            intsEncoded = json.optIntOrNull("ints_encoded"),
            stringsEncoded = json.optIntOrNull("strings_encoded")
        )
    }

    private fun extractServerError(
        rawBody: String
    ): String? {

        if (rawBody.isBlank()) {
            return null
        }

        return try {
            val json = JSONObject(rawBody)

            json.optStringOrNull("error")
                ?: json.optStringOrNull("message")
                ?: json.optStringOrNull("detail")
                ?: json.optJSONObject("error")
                    ?.optStringOrNull("message")
                ?: rawBody.take(1000)

        } catch (_: Exception) {
            rawBody.take(1000)
        }
    }

    class PyObfuscateException {

        class HttpError(
            val code: Int,
            override val message: String?
        ) : IOException(
            message ?: "HTTP error $code"
        )

        object EmptyResponse :
            IOException("Server mengembalikan response kosong.")

        object MissingResult :
            IOException("Field 'result' tidak ditemukan pada response API.")

        class ApiError(
            message: String
        ) : IOException(message)

        class InvalidJson(
            val rawJson: String,
            cause: Throwable,
            val reasonHint: String? = null
        ) : IOException(
            buildString {
                append(reasonHint ?: "Response API bukan JSON yang valid.")
                val snippet = rawJson.trim().take(160)
                if (snippet.isNotBlank()) {
                    append(" Cuplikan: ")
                    append(snippet)
                }
            },
            cause
        )
    }
}

/**
 * JSONObject helper.
 *
 * optString() biasanya mengembalikan string kosong
 * saat key tidak tersedia. Helper ini mengubahnya menjadi null.
 */
private fun JSONObject.optStringOrNull(
    key: String
): String? {

    if (!has(key) || isNull(key)) {
        return null
    }

    return optString(key).takeIf { it.isNotBlank() }
}

/**
 * JSONObject helper untuk nullable Int.
 */
private fun JSONObject.optIntOrNull(
    key: String
): Int? {

    if (!has(key) || isNull(key)) {
        return null
    }

    return try {
        getInt(key)
    } catch (_: Exception) {
        null
    }
}


