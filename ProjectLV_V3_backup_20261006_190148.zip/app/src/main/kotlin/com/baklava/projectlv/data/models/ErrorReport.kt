package com.baklava.projectlv.data.models

import com.baklava.projectlv.BuildConfig
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ErrorReport(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val appVersion: String = BuildConfig.VERSION_NAME,
    val buildVersion: String = BuildConfig.VERSION_CODE.toString(),
    val deviceModel: String = "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}",
    val androidVersion: String = "Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})",
    val windowSizeClass: String = "Compact",
    val networkStatus: String = "UNKNOWN",
    val moduleContext: String,
    val sanitizedErrorMessage: String,
    val sanitizedStackTrace: String,
    val httpStatusCode: Int? = null,
    val sanitizedHost: String? = null
) {
    fun formattedDate(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun toFullTechnicalReport(): String {
        return buildString {
            appendLine("=== LEVIATHAN ERROR REPORT ===")
            appendLine("ID: $id")
            appendLine("Timestamp: ${formattedDate()}")
            appendLine("App Version: $appVersion (Build $buildVersion)")
            appendLine("Device: $deviceModel")
            appendLine("OS: $androidVersion")
            appendLine("Window Class: $windowSizeClass")
            appendLine("Network Status: $networkStatus")
            appendLine("Module Context: $moduleContext")
            if (httpStatusCode != null) {
                appendLine("HTTP Status: $httpStatusCode")
            }
            if (!sanitizedHost.isNullOrBlank()) {
                appendLine("Host Alias: $sanitizedHost")
            }
            appendLine("\n[ERROR MESSAGE]")
            appendLine(sanitizedErrorMessage)
            appendLine("\n[SANITIZED STACK TRACE]")
            appendLine(sanitizedStackTrace)
            appendLine("=== END REPORT (ALL SECRETS REDACTED) ===")
        }
    }
}
