package com.baklava.projectlv.data.storage

import android.content.Context
import com.baklava.projectlv.data.models.ChatSessionHistory
import com.baklava.projectlv.data.models.toChatSessionHistory
import com.baklava.projectlv.data.models.toJson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File

class ChatHistoryManager(context: Context) {
    private val file = File(context.filesDir, "strom_ai_chat_history.json")

    suspend fun load(): List<ChatSessionHistory> = withContext(Dispatchers.IO) {
        runCatching {
            if (!file.exists()) return@runCatching emptyList()
            val array = JSONArray(file.readText(Charsets.UTF_8))
            buildList {
                for (i in 0 until array.length()) {
                    array.optJSONObject(i)?.let { add(it.toChatSessionHistory()) }
                }
            }.sortedByDescending { it.updatedAt }
        }.getOrDefault(emptyList())
    }

    suspend fun save(history: List<ChatSessionHistory>) = withContext(Dispatchers.IO) {
        val normalized = history.sortedByDescending { it.updatedAt }.take(100)
        val array = JSONArray().apply { normalized.forEach { put(it.toJson()) } }
        file.writeText(array.toString(), Charsets.UTF_8)
    }

    suspend fun upsert(session: ChatSessionHistory) {
        val current = load().filterNot { it.id == session.id }
        save(listOf(session) + current)
    }

    suspend fun delete(sessionId: String) {
        save(load().filterNot { it.id == sessionId })
    }
}
