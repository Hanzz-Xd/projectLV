package com.baklava.projectlv.data.admin

import android.content.Context
import android.os.Build
import android.provider.Settings
import com.baklava.projectlv.BuildConfig
import com.baklava.projectlv.data.models.ErrorReport
import com.baklava.projectlv.data.network.SecretRedactor
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Shared Firebase control-plane for ProjectLV.
 *
 * Spark-compatible design: Firestore + Auth + App Check only. There is no
 * privileged Cloud Function in this implementation because Cloud Functions
 * requires Blaze. The class therefore intentionally separates client telemetry
 * from admin operations and never stores secret API credentials for clients.
 */
class AdminControlManager(private val context: Context) {
    private val appContext = context.applicationContext
    private val firestore by lazy { FirebaseFirestore.getInstance() }
    private val auth by lazy { FirebaseAuth.getInstance() }

    private val enabled: Boolean
        get() = FirebaseApp.getApps(appContext).isNotEmpty()

    fun deviceIdHash(): String {
        val androidId = Settings.Secure.getString(
            appContext.contentResolver,
            Settings.Secure.ANDROID_ID
        ).orEmpty().ifBlank { "unknown-android-id" }
        val stableMaterial = listOf(
            appContext.packageName,
            androidId,
            Build.BRAND,
            Build.DEVICE
        ).joinToString("|")
        return sha256(stableMaterial)
    }

    suspend fun signInAdmin(email: String, password: String): Result<Unit> = runCatching {
        if (!enabled) error("Firebase belum dikonfigurasi.")
        auth.signInWithEmailAndPassword(email.trim(), password).await()
        val signedInUser = requireNotNull(auth.currentUser)
        signedInUser.reload().await()
        signedInUser.getIdToken(true).await()
        check(signedInUser.isEmailVerified) {
            auth.signOut()
            error("Email admin belum terverifikasi.")
        }
        val uid = signedInUser.uid
        val snap = firestore.collection("admins").document(uid).get().await()
        val adminDeviceHash = snap.getString("deviceIdHash").orEmpty()
        val active = snap.exists() && snap.getBoolean("enabled") == true
        if (!active || adminDeviceHash.isBlank() || !adminDeviceHash.equals(deviceIdHash(), true)) {
            auth.signOut()
            error("Akun bukan admin aktif untuk perangkat ini.")
        }
    }

    suspend fun logoutAdmin() {
        if (!enabled) return
        auth.signOut()
    }

    fun isCurrentlySignedInAsEmailUser(): Boolean =
        auth.currentUser?.let(::isPasswordUser) == true

    suspend fun refreshAdminDeviceBinding(): Result<Unit> = runCatching {
        val user = auth.currentUser ?: error("Belum login admin.")
        user.reload().await()
        user.getIdToken(true).await()
        check(isPasswordUser(user)) { "Login admin harus menggunakan Email/Password." }
        check(user.isEmailVerified) { "Email admin belum terverifikasi." }
        val uid = user.uid
        val snap = firestore.collection("admins").document(uid).get().await()
        check(snap.exists() && snap.getBoolean("enabled") == true) { "Akun admin tidak aktif." }
        check(snap.getString("deviceIdHash").equals(deviceIdHash(), true)) {
            "Perangkat admin tidak cocok."
        }
    }

    fun observeGlobalControl(): Flow<GlobalControlState> = callbackFlow {
        if (!enabled) {
            trySend(GlobalControlState())
            awaitClose { }
            return@callbackFlow
        }
        if (auth.currentUser == null || !isPasswordUser(auth.currentUser!!)) {
            trySend(GlobalControlState())
            awaitClose { }
            return@callbackFlow
        }
        val ref = firestore.collection("control").document("global")
        val registration = ref.addSnapshotListener { snap, error ->
            if (error != null) {
                trySend(GlobalControlState(enabled = true, message = "Kontrol global belum tersedia."))
                return@addSnapshotListener
            }
            trySend(parseGlobalControl(snap))
        }
        awaitClose { registration.remove() }
    }

    fun observeAnnouncements(includeDisabled: Boolean = false): Flow<List<AnnouncementRecord>> = callbackFlow {
        if (!enabled) {
            trySend(emptyList())
            awaitClose { }
            return@callbackFlow
        }
        if (auth.currentUser == null || !isPasswordUser(auth.currentUser!!)) {
            trySend(emptyList())
            awaitClose { }
            return@callbackFlow
        }
        val baseQuery = firestore.collection("announcements")
        val query = if (includeDisabled) baseQuery else baseQuery.whereEqualTo("enabled", true)
        val registration = query.addSnapshotListener { snap, error ->
                if (error != null || snap == null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val items = snap.documents.mapNotNull { parseAnnouncement(it) }
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: 0L }
                trySend(items)
            }
        awaitClose { registration.remove() }
    }

    fun observeDevices(): Flow<List<DeviceRecord>> = callbackFlow {
        if (!enabled) {
            trySend(emptyList())
            awaitClose { }
            return@callbackFlow
        }
        // The actual Firestore rules gate this collection to admins. Anonymous
        // users simply receive PERMISSION_DENIED and an empty UI state.
        val registration = firestore.collection("devices")
            .limit(250)
            .addSnapshotListener { snap, error ->
                if (error != null || snap == null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                trySend(snap.documents.mapNotNull(::parseDevice)
                    .sortedByDescending { it.lastSeenAt ?: it.createdAt ?: 0L })
            }
        awaitClose { registration.remove() }
    }

    fun observeBugReports(): Flow<List<BugReportRecord>> = callbackFlow {
        if (!enabled) {
            trySend(emptyList())
            awaitClose { }
            return@callbackFlow
        }
        val registration = firestore.collection("bugReports")
            .limit(250)
            .addSnapshotListener { snap, error ->
                if (error != null || snap == null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                trySend(snap.documents.mapNotNull(::parseBugReport)
                    .sortedByDescending { it.createdAt ?: 0L })
            }
        awaitClose { registration.remove() }
    }

    fun observeAdminRecord(): Flow<Boolean> = callbackFlow {
        if (!enabled) {
            trySend(false)
            awaitClose { }
            return@callbackFlow
        }

        var registration: ListenerRegistration? = null
        val authListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            registration?.remove()
            registration = null
            val user = firebaseAuth.currentUser
            if (user == null || !isPasswordUser(user) || !user.isEmailVerified) {
                trySend(false)
            } else {
                registration = firestore.collection("admins").document(user.uid)
                    .addSnapshotListener { snap, error ->
                        if (error != null || snap == null) {
                            trySend(false)
                            return@addSnapshotListener
                        }
                        val ok = snap.exists() && snap.getBoolean("enabled") == true &&
                            snap.getString("deviceIdHash").equals(deviceIdHash(), true)
                        trySend(ok)
                    }
            }
        }
        auth.addAuthStateListener(authListener)

        awaitClose {
            registration?.remove()
            auth.removeAuthStateListener(authListener)
        }
    }

    suspend fun setGlobalControl(
        enabled: Boolean,
        message: String,
        toolStates: Map<String, Boolean>,
        apiControls: Map<String, ApiControlState>
    ) {
        requireAdmin()
        val apiMap = apiControls.mapValues { (_, v) ->
            mapOf(
                "enabled" to v.enabled,
                "keyRevision" to v.keyRevision.take(32),
                "endpointAlias" to SecretRedactor.redactText(v.endpointAlias).take(120)
            )
        }
        firestore.collection("control").document("global").set(
            mapOf(
                "enabled" to enabled,
                "message" to message.take(300),
                // The legacy global expiry feature has been removed. Delete any
                // old field left by previous builds during the same write.
                "globalExpiresAt" to FieldValue.delete(),
                "toolStates" to toolStates,
                "apiControls" to apiMap,
                "updatedAt" to FieldValue.serverTimestamp(),
                "updatedBy" to auth.currentUser?.uid
            ),
            SetOptions.merge()
        ).await()
    }

    suspend fun setDeviceBan(deviceIdHash: String, durationMillis: Long?, reason: String, warning: String) {
        requireAdmin()
        validateHash(deviceIdHash)
        val now = System.currentTimeMillis()
        firestore.collection("devices").document(deviceIdHash).set(
            mapOf(
                "banned" to true,
                "banStartedAt" to com.google.firebase.Timestamp(java.util.Date(now)),
                "banExpiresAt" to durationMillis?.let { com.google.firebase.Timestamp(java.util.Date(now + it)) },
                "banReason" to reason.take(500),
                "banWarning" to warning.take(500),
                "updatedAt" to FieldValue.serverTimestamp(),
                "updatedBy" to auth.currentUser?.uid
            ), SetOptions.merge()
        ).await()
    }

    suspend fun setDevicesBan(
        deviceIdHashes: List<String>,
        durationMillis: Long?,
        reason: String,
        warning: String
    ) {
        requireAdmin()
        val ids = deviceIdHashes.distinct().also { list -> list.forEach(::validateHash) }
        if (ids.isEmpty()) return
        val now = System.currentTimeMillis()
        ids.chunked(400).forEach { chunk ->
            val batch = firestore.batch()
            chunk.forEach { id ->
                batch.set(
                    firestore.collection("devices").document(id),
                    mapOf(
                        "banned" to true,
                        "banStartedAt" to com.google.firebase.Timestamp(java.util.Date(now)),
                        "banExpiresAt" to durationMillis?.let { com.google.firebase.Timestamp(java.util.Date(now + it)) },
                        "banReason" to reason.take(500),
                        "banWarning" to warning.take(500),
                        "updatedAt" to FieldValue.serverTimestamp(),
                        "updatedBy" to auth.currentUser?.uid
                    ),
                    SetOptions.merge()
                )
            }
            batch.commit().await()
        }
    }

    suspend fun deleteDevices(deviceIdHashes: List<String>) {
        requireAdmin()
        val ids = deviceIdHashes.distinct().also { list -> list.forEach(::validateHash) }
        for (id in ids) {
            val deviceRef = firestore.collection("devices").document(id)
            val eventDocs = deviceRef.collection("securityEvents").get().await().documents
            var batch = firestore.batch()
            var operationCount = 0
            eventDocs.forEach { event ->
                batch.delete(event.reference)
                operationCount++
                if (operationCount >= 450) {
                    batch.commit().await()
                    batch = firestore.batch()
                    operationCount = 0
                }
            }
            batch.delete(deviceRef)
            batch.commit().await()
        }
    }

    suspend fun sendPasswordResetForAccount(email: String) {
        requireAdmin()
        val normalized = email.trim()
        require(normalized.isNotBlank()) { "Email wajib diisi." }
        auth.sendPasswordResetEmail(normalized).await()
    }

    suspend fun unbanDevice(deviceIdHash: String) {
        requireAdmin()
        validateHash(deviceIdHash)
        firestore.collection("devices").document(deviceIdHash).set(
            mapOf(
                "banned" to false,
                "banStartedAt" to null,
                "banExpiresAt" to null,
                "banReason" to "",
                "banWarning" to "",
                "updatedAt" to FieldValue.serverTimestamp(),
                "updatedBy" to auth.currentUser?.uid
            ), SetOptions.merge()
        ).await()
    }

    suspend fun publishAnnouncement(
        id: String?,
        context: AnnouncementContext,
        title: String,
        body: String,
        enabled: Boolean
    ) {
        requireAdmin()
        require(title.isNotBlank() && body.isNotBlank()) { "Judul dan isi wajib diisi." }
        val ref = id?.let { firestore.collection("announcements").document(it) }
            ?: firestore.collection("announcements").document()
        val data = mapOf(
            "context" to context.key,
            "title" to title.take(120),
            "body" to body.take(4000),
            "enabled" to enabled,
            "updatedAt" to FieldValue.serverTimestamp(),
            "updatedBy" to auth.currentUser?.uid
        )
        ref.set(data, SetOptions.merge()).await()
    }

    suspend fun deleteAnnouncement(id: String) {
        requireAdmin()
        firestore.collection("announcements").document(id).delete().await()
    }

    suspend fun setBugStatus(id: String, status: String) {
        requireAdmin()
        require(status in setOf("open", "reviewing", "resolved", "ignored"))
        firestore.collection("bugReports").document(id).update(
            "status", status,
            "reviewedAt", FieldValue.serverTimestamp(),
            "reviewedBy", auth.currentUser?.uid
        ).await()
    }

    suspend fun recordPresence(lastTool: String? = null) = withContext(Dispatchers.IO) {
        if (!enabled) return@withContext
        try {
            val user = auth.currentUser
            if (user == null || !isPasswordUser(user) || !user.isEmailVerified) return@withContext
            val hash = deviceIdHash()
            val ref = firestore.collection("devices").document(hash)
            val exists = ref.get().await().exists()
            val ip = lookupPublicIp()
            val updates = mutableMapOf<String, Any?>(
                "deviceIdHash" to hash,
                "ownerUid" to user.uid,
                "ownerEmail" to user.email.orEmpty().take(320),
                "manufacturer" to Build.MANUFACTURER,
                "brand" to Build.BRAND,
                "model" to Build.MODEL,
                "device" to Build.DEVICE,
                "androidVersion" to Build.VERSION.RELEASE,
                "sdkInt" to Build.VERSION.SDK_INT,
                "appVersion" to BuildConfig.VERSION_NAME,
                "versionCode" to BuildConfig.VERSION_CODE,
                "lastIp" to ip.orEmpty(),
                "lastSeenAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!lastTool.isNullOrBlank()) {
                val safeTool = lastTool.lowercase().replace("[^a-z0-9_-]".toRegex(), "_").take(40)
                updates["lastTool"] = lastTool.take(80)
                updates["totalToolUses"] = FieldValue.increment(1L)
                updates["toolUsage.$safeTool"] = FieldValue.increment(1L)
            }
            if (exists) {
                ref.set(updates, SetOptions.merge()).await()
            } else {
                updates["banned"] = false
                updates["banStartedAt"] = null
                updates["banExpiresAt"] = null
                updates["banReason"] = ""
                updates["banWarning"] = ""
                updates["violationCount"] = 0L
                updates["createdAt"] = FieldValue.serverTimestamp()
                ref.set(updates).await()
            }
        } catch (_: CancellationException) {
            throw CancellationException()
        } catch (_: Exception) {
            // Telemetry is best-effort and must never block the toolkit.
        }
    }

    suspend fun submitBugReport(report: ErrorReport): Boolean = withContext(Dispatchers.IO) {
        if (!enabled) return@withContext false
        try {
            val user = auth.currentUser
            if (user == null || !isPasswordUser(user)) return@withContext false
            val hash = deviceIdHash()
            val ref = firestore.collection("bugReports").document(report.id)
            ref.set(
                mapOf(
                    "deviceIdHash" to hash,
                    "ownerUid" to user.uid,
                    "ownerEmail" to user.email.orEmpty().take(320),
                    "moduleContext" to SecretRedactor.redactText(report.moduleContext).take(120),
                    "message" to SecretRedactor.redactText(report.sanitizedErrorMessage).take(1200),
                    "stackTrace" to SecretRedactor.redactText(report.sanitizedStackTrace).take(12000),
                    "hostAlias" to SecretRedactor.redactText(report.sanitizedHost.orEmpty()).take(120),
                    "httpStatusCode" to report.httpStatusCode,
                    "model" to Build.MODEL,
                    "manufacturer" to Build.MANUFACTURER,
                    "androidVersion" to Build.VERSION.RELEASE,
                    "sdkInt" to Build.VERSION.SDK_INT,
                    "publicIp" to lookupPublicIp().orEmpty(),
                    "appVersion" to BuildConfig.VERSION_NAME,
                    "versionCode" to BuildConfig.VERSION_CODE,
                    "networkStatus" to report.networkStatus,
                    "severity" to if (report.moduleContext.contains("FATAL", true)) "fatal" else "error",
                    "status" to "open",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            true
        } catch (_: CancellationException) {
            throw CancellationException()
        } catch (_: Exception) {
            false
        }
    }

    private suspend fun requireAdmin() {
        refreshAdminDeviceBinding().getOrThrow()
    }

    private fun Any?.asMillis(): Long? = when (this) {
        is com.google.firebase.Timestamp -> this.toDate().time
        is java.util.Date -> this.time
        is Number -> this.toLong()
        else -> null
    }

    private fun isPasswordUser(user: FirebaseUser): Boolean =
        user.providerData.any { it.providerId == EmailAuthProvider.PROVIDER_ID }

    /**
     * Field `enabled` biasanya Boolean, tapi kalau diedit manual di Firebase Console
     * bisa saja tersimpan sebagai string "false" / angka 0. Tanpa ini maintenance
     * dianggap tidak aktif dan layarnya tidak pernah muncul.
     */
    private fun Any?.asEnabledFlag(): Boolean = when (this) {
        is Boolean -> this
        is Number -> this.toInt() != 0
        is String -> this.trim().lowercase() !in setOf("false", "0", "off", "no", "nonaktif")
        else -> true
    }

    private fun parseGlobalControl(snapshot: DocumentSnapshot?): GlobalControlState {
        if (snapshot == null || !snapshot.exists()) return GlobalControlState()
        val tools = snapshot.get("toolStates") as? Map<*, *> ?: emptyMap<Any, Any>()
        val api = snapshot.get("apiControls") as? Map<*, *> ?: emptyMap<Any, Any>()
        val toolStates = tools.mapNotNull { (k, v) ->
            val key = k as? String ?: return@mapNotNull null
            key to (v as? Boolean ?: true)
        }.toMap()
        val apiControls = api.mapNotNull { (k, v) ->
            val key = k as? String ?: return@mapNotNull null
            val map = v as? Map<*, *> ?: emptyMap<Any, Any>()
            key to ApiControlState(
                enabled = map["enabled"] as? Boolean ?: true,
                keyRevision = map["keyRevision"] as? String ?: "default",
                endpointAlias = map["endpointAlias"] as? String ?: ""
            )
        }.toMap()
        return GlobalControlState(
            enabled = snapshot.get("enabled").asEnabledFlag(),
            message = snapshot.getString("message") ?: ":)",
            toolStates = toolStates,
            apiControls = apiControls,
            updatedAt = snapshot.get("updatedAt").asMillis()
        )
    }

    private fun parseDevice(snapshot: DocumentSnapshot): DeviceRecord? {
        val hash = snapshot.id.takeIf { it.matches(Regex("[a-fA-F0-9]{64}")) } ?: return null
        val toolUsageRaw = snapshot.get("toolUsage") as? Map<*, *> ?: emptyMap<Any, Any>()
        val toolUsage = toolUsageRaw.mapNotNull { (k, v) ->
            (k as? String)?.let { it to ((v as? Number)?.toLong() ?: 0L) }
        }.toMap()
        return DeviceRecord(
            id = hash,
            ownerUid = snapshot.getString("ownerUid").orEmpty(),
            ownerEmail = snapshot.getString("ownerEmail").orEmpty(),
            manufacturer = snapshot.getString("manufacturer").orEmpty().ifBlank { "Unknown" },
            model = snapshot.getString("model").orEmpty().ifBlank { "Unknown" },
            androidVersion = snapshot.getString("androidVersion").orEmpty().ifBlank { "Unknown" },
            sdkInt = snapshot.getLong("sdkInt") ?: 0L,
            appVersion = snapshot.getString("appVersion").orEmpty().ifBlank { "Unknown" },
            lastIp = snapshot.getString("lastIp").orEmpty(),
            lastTool = snapshot.getString("lastTool").orEmpty(),
            totalToolUses = snapshot.getLong("totalToolUses") ?: 0L,
            toolUsage = toolUsage,
            banned = snapshot.getBoolean("banned") == true,
            banStartedAt = snapshot.get("banStartedAt").asMillis(),
            banExpiresAt = snapshot.get("banExpiresAt").asMillis(),
            banReason = snapshot.getString("banReason").orEmpty(),
            banWarning = snapshot.getString("banWarning").orEmpty(),
            violationCount = snapshot.getLong("violationCount") ?: 0L,
            lastViolation = snapshot.getString("lastViolation").orEmpty(),
            lastSeenAt = snapshot.get("lastSeenAt").asMillis(),
            createdAt = snapshot.get("createdAt").asMillis(),
            updatedAt = snapshot.get("updatedAt").asMillis()
        )
    }

    private fun parseAnnouncement(snapshot: DocumentSnapshot): AnnouncementRecord? {
        val title = snapshot.getString("title") ?: return null
        val body = snapshot.getString("body") ?: return null
        return AnnouncementRecord(
            id = snapshot.id,
            context = AnnouncementContext.fromKey(snapshot.getString("context")),
            title = title,
            body = body,
            enabled = snapshot.getBoolean("enabled") != false,
            createdAt = snapshot.get("createdAt").asMillis(),
            updatedAt = snapshot.get("updatedAt").asMillis()
        )
    }

    private fun parseBugReport(snapshot: DocumentSnapshot): BugReportRecord? =
        BugReportRecord(
            id = snapshot.id,
            deviceIdHash = snapshot.getString("deviceIdHash").orEmpty(),
            moduleContext = snapshot.getString("moduleContext").orEmpty(),
            message = snapshot.getString("message").orEmpty(),
            stackTrace = snapshot.getString("stackTrace").orEmpty(),
            hostAlias = snapshot.getString("hostAlias").orEmpty(),
            httpStatusCode = snapshot.getLong("httpStatusCode"),
            model = listOfNotNull(
                snapshot.getString("manufacturer"),
                snapshot.getString("model")
            ).joinToString(" ").ifBlank { "Unknown" },
            androidVersion = snapshot.getString("androidVersion").orEmpty(),
            publicIp = snapshot.getString("publicIp").orEmpty(),
            appVersion = snapshot.getString("appVersion").orEmpty(),
            severity = snapshot.getString("severity") ?: "error",
            createdAt = snapshot.get("createdAt").asMillis(),
            status = snapshot.getString("status") ?: "open"
        )

    private fun validateHash(value: String) {
        require(value.matches(Regex("[a-fA-F0-9]{64}"))) { "deviceIdHash tidak valid." }
    }

    private fun sha256(value: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    private fun lookupPublicIp(): String? {
        return runCatching {
            val connection = (URL("https://api.ipify.org?format=json").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 2500
                readTimeout = 2500
                instanceFollowRedirects = true
            }
            connection.inputStream.use { input ->
                val body = BufferedReader(InputStreamReader(input)).use { it.readText() }
                JSONObject(body).optString("ip").takeIf { it.isNotBlank() }
            }
        }.getOrNull()
    }
}
