package com.baklava.projectlv.data.security

import com.baklava.projectlv.data.network.EnvironmentCheckResult

/** Security findings that are reported to the trusted Firebase backend. */
enum class SecurityViolationType {
    ROOT,
    VPN,
    DEBUGGER,
    EMULATOR
}

data class SecurityViolation(
    val type: SecurityViolationType,
    val detail: String
)

data class SecurityEvaluation(
    val violations: List<SecurityViolation> = emptyList()
) {
    val hasViolation: Boolean get() = violations.isNotEmpty()

    companion object {
        fun from(result: EnvironmentCheckResult): SecurityEvaluation {
            val violations = buildList {
                if (result.rootIndicatorsFound > 0) {
                    add(SecurityViolation(SecurityViolationType.ROOT, "${result.rootIndicatorsFound} root indicators"))
                }
                if (result.vpnActive) {
                    add(SecurityViolation(SecurityViolationType.VPN, "Active VPN transport/interface"))
                }
                if (result.debuggerAttached) {
                    add(SecurityViolation(SecurityViolationType.DEBUGGER, "Debugger is attached"))
                }
                if (result.isProbableEmulator) {
                    add(SecurityViolation(SecurityViolationType.EMULATOR, "Emulator heuristics matched"))
                }
            }
            return SecurityEvaluation(violations)
        }
    }
}
