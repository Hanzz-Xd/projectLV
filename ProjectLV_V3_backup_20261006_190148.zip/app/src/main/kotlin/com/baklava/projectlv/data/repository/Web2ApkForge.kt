package com.baklava.projectlv.data.repository

import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Calendar
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Native/Kotlin port of the supplied SDKForge forge.js pipeline.
 *
 * The network layer still consumes the supplied /template and /signkey APIs; this
 * class keeps the actual binary APK forge on-device so there is no server-side
 * build queue.
 */
internal object Web2ApkForge {
    private const val ANDROID_NAMESPACE = "http://schemas.android.com/apk/res/android"
    private const val DEFAULT_PACKAGE = "com.sdkforge.web2apk"
    private const val DEFAULT_APP_NAME = "Web2APK"
    private const val DEFAULT_VERSION = "1.0.0"
    private const val CRLF = "\r\n"

    data class SignKey(
        val pkcs8: String,
        val certRsa: String,
        val sigOffset: Int
    )

    private data class ZipData(val name: String, val data: ByteArray)

    private data class StringPool(
        val stringCount: Int,
        val styleCount: Int,
        val flags: Int,
        val stringsStart: Int,
        val stylesStart: Int,
        val utf8: Boolean,
        val strings: List<String>,
        var styleOffsets: IntArray? = null,
        var styleBytes: ByteArray = ByteArray(0)
    )

    fun forge(
        template: ByteArray,
        signKey: SignKey,
        packageName: String,
        appName: String,
        versionName: String,
        versionCode: Int,
        iconPng: ByteArray?,
        permissions: List<String>,
        config: Map<String, Any?>,
        onStep: (Int) -> Unit = {}
    ): ByteArray {
        require(validatePackage(packageName)) { "Package name tidak valid: $packageName" }

        onStep(0)
        val entries = readZip(template)
        require(entries.isNotEmpty()) { "Template APK kosong" }

        onStep(1)
        val out = ArrayList<ZipData>(entries.size)
        for (entry in entries) {
            if (entry.name.startsWith("META-INF/")) continue

            when {
                entry.name == "AndroidManifest.xml" -> {
                    var m = patchAxmlInt(entry.data, "versionCode", versionCode)
                    val safePermissions = permissions.filter { it.isNotBlank() && it != "android.permission.INTERNET" }
                    m = addAxmlPermissions(m, safePermissions)
                    m = replacePoolStrings(
                        m,
                        8,
                        mapOf(
                            DEFAULT_PACKAGE to packageName,
                            DEFAULT_VERSION to versionName
                        )
                    )
                    out += ZipData(entry.name, m)
                }

                entry.name == "resources.arsc" -> {
                    out += ZipData(
                        entry.name,
                        replacePoolStrings(entry.data, 12, mapOf(DEFAULT_APP_NAME to appName))
                    )
                }

                entry.name.matches(Regex(".*ic_launcher\\.png$")) && iconPng != null -> {
                    out += ZipData(entry.name, iconPng.copyOf())
                }

                entry.name == "assets/config.json" -> {
                    val cfg = LinkedHashMap<String, Any?>()
                    cfg["name"] = appName
                    cfg.putAll(config)
                    out += ZipData(entry.name, JSONObject(cfg).toString().toByteArray(Charsets.UTF_8))
                }

                else -> out += entry
            }
        }

        onStep(2)
        val signed = signV1(out, signKey)
        onStep(3)
        val apk = writeZip(out + signed)
        onStep(4)
        return apk
    }

    fun validatePackage(name: String): Boolean =
        Regex("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$").matches(name)

    private fun readZip(bytes: ByteArray): List<ZipData> {
        val result = ArrayList<ZipData>()
        ZipInputStream(bytes.inputStream()).use { zis ->
            while (true) {
                val entry = zis.nextEntry ?: break
                if (!entry.isDirectory) {
                    val buffer = ByteArrayOutputStream()
                    zis.copyTo(buffer)
                    result += ZipData(entry.name, buffer.toByteArray())
                }
                zis.closeEntry()
            }
        }
        return result
    }

    private fun writeZip(entries: List<ZipData>): ByteArray {
        val output = ByteArrayOutputStream()
        ZipOutputStream(output).use { zos ->
            for (entry in entries) {
                val data = entry.data
                val ze = ZipEntry(entry.name)
                ze.method = ZipEntry.STORED
                ze.size = data.size.toLong()
                ze.compressedSize = data.size.toLong()
                ze.crc = crc32(data)
                val now = Calendar.getInstance()
                ze.time = now.timeInMillis
                zos.putNextEntry(ze)
                zos.write(data)
                zos.closeEntry()
            }
        }
        return output.toByteArray()
    }

    private fun poolStrings(bytes: ByteArray, off: Int): StringPool {
        val dv = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val stringCount = dv.u32(off + 8)
        val styleCount = dv.u32(off + 12)
        val flags = dv.u32(off + 16)
        val stringsStart = dv.u32(off + 20)
        val stylesStart = dv.u32(off + 24)
        val utf8 = (flags and (1 shl 8)) != 0
        val strings = ArrayList<String>(stringCount)

        for (i in 0 until stringCount) {
            var p = off + stringsStart + dv.u32(off + 28 + i * 4)
            if (utf8) {
                var n = bytes[p++].toInt() and 0xff
                if ((n and 0x80) != 0) n = ((n and 0x7f) shl 8) or (bytes[p++].toInt() and 0xff)
                var m = bytes[p++].toInt() and 0xff
                if ((m and 0x80) != 0) m = ((m and 0x7f) shl 8) or (bytes[p++].toInt() and 0xff)
                strings += bytes.copyOfRange(p, p + m).toString(Charsets.UTF_8)
            } else {
                var n = dv.u16(p)
                p += 2
                if ((n and 0x8000) != 0) {
                    n = ((n and 0x7fff) shl 16) or dv.u16(p)
                    p += 2
                }
                val chars = CharArray(n)
                for (k in 0 until n) chars[k] = bytesToChar(dv.u16(p + k * 2))
                strings += String(chars)
            }
        }
        return StringPool(stringCount, styleCount, flags, stringsStart, stylesStart, utf8, strings)
    }

    private fun enrichStyle(pool: StringPool, bytes: ByteArray, poolOffset: Int, poolSize: Int) {
        if (pool.styleCount == 0) return
        val dv = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val offsets = IntArray(pool.styleCount)
        for (i in 0 until pool.styleCount) {
            offsets[i] = dv.u32(poolOffset + 28 + pool.stringCount * 4 + i * 4)
        }
        pool.styleOffsets = offsets
        pool.styleBytes = bytes.copyOfRange(poolOffset + pool.stylesStart, poolOffset + poolSize)
    }

    private fun buildPool(pool: StringPool, strings: List<String>): ByteArray {
        val chunks = ArrayList<ByteArray>()
        val offsets = IntArray(strings.size)
        var len = 0
        for ((index, s) in strings.withIndex()) {
            offsets[index] = len
            val encoded = if (pool.utf8) encodeUtf8String(s) else encodeUtf16String(s)
            chunks += encoded
            len += encoded.size
        }
        while (len % 4 != 0) {
            chunks += byteArrayOf(0)
            len++
        }
        val data = concat(*chunks.toTypedArray())
        val stringsStart = 28 + strings.size * 4 + pool.styleCount * 4
        val styleData = pool.styleBytes
        val size = stringsStart + data.size + styleData.size
        val out = ByteArray(size)
        val dv = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        dv.putU16(0, 0x0001)
        dv.putU16(2, 28)
        dv.putU32(4, size)
        dv.putU32(8, strings.size)
        dv.putU32(12, pool.styleCount)
        dv.putU32(16, pool.flags)
        dv.putU32(20, stringsStart)
        dv.putU32(24, if (pool.styleCount != 0) stringsStart + data.size else 0)
        offsets.forEachIndexed { i, offset -> dv.putU32(28 + i * 4, offset) }
        pool.styleOffsets?.forEachIndexed { i, offset -> dv.putU32(28 + strings.size * 4 + i * 4, offset) }
        data.copyInto(out, stringsStart)
        if (styleData.isNotEmpty()) styleData.copyInto(out, stringsStart + data.size)
        return out
    }

    private fun replacePoolStrings(bytes: ByteArray, poolOffset: Int, replacements: Map<String, String>): ByteArray {
        val pool = poolStrings(bytes, poolOffset)
        val dv = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val poolSize = dv.u32(poolOffset + 4)
        enrichStyle(pool, bytes, poolOffset, poolSize)
        var changed = false
        val next = pool.strings.map { old ->
            val replacement = replacements[old]
            if (replacement != null) {
                if (replacement != old) changed = true
                replacement
            } else old
        }
        if (!changed) return bytes
        val newPool = buildPool(pool, next)
        val out = concat(bytes.copyOfRange(0, poolOffset), newPool, bytes.copyOfRange(poolOffset + poolSize, bytes.size))
        ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN).putU32(4, out.size)
        return out
    }

    private fun patchAxmlInt(bytes: ByteArray, attrName: String, value: Int): ByteArray {
        val b = bytes.copyOf()
        val dv = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        val pool = poolStrings(b, 8)
        val nameIdx = pool.strings.indexOf(attrName)
        if (nameIdx < 0) return b

        var p = dv.u16(2)
        val end = dv.u32(4)
        while (p < end - 8) {
            val type = dv.u16(p)
            val size = dv.u32(p + 4)
            if (size <= 0) break
            if (type == 0x0102) {
                val attrStart = dv.u16(p + 16 + 8)
                val attrSize = dv.u16(p + 16 + 10)
                val attrCount = dv.u16(p + 16 + 12)
                for (i in 0 until attrCount) {
                    val a = p + 16 + attrStart + i * attrSize
                    if (dv.u32(a + 4) == nameIdx) {
                        dv.putU32(a + 16, value)
                        return b
                    }
                }
            }
            p += size
        }
        return b
    }

    private fun addAxmlPermissions(bytes: ByteArray, permissions: List<String>): ByteArray {
        if (permissions.isEmpty()) return bytes
        val b = bytes.copyOf()
        val dv = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        val pool = poolStrings(b, 8)
        val poolSize = dv.u32(12)
        enrichStyle(pool, b, 8, poolSize)

        val strings = pool.strings.toMutableList()
        fun idxOf(s: String): Int {
            val existing = strings.indexOf(s)
            if (existing >= 0) return existing
            strings += s
            return strings.lastIndex
        }

        val wanted = permissions.filter { it.isNotBlank() && pool.strings.indexOf(it) < 0 }
        if (wanted.isEmpty()) return b

        val nsIdx = idxOf(ANDROID_NAMESPACE)
        val nameIdx = pool.strings.indexOf("name")
        val tagIdx = idxOf("uses-permission")
        if (nameIdx < 0) return b
        val permIdx = wanted.map(::idxOf)

        val newPool = buildPool(pool, strings)
        var out = concat(b.copyOfRange(0, 8), newPool, b.copyOfRange(8 + poolSize, b.size))
        var odv = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)

        val appIdx = strings.indexOf("application")
        var insertAt = -1
        var p = 8 + newPool.size
        val end = out.size
        while (p < end - 8) {
            val type = odv.u16(p)
            val size = odv.u32(p + 4)
            if (size <= 0) break
            if (type == 0x0102) {
                val tag = odv.u32(p + 16 + 4)
                if (tag == appIdx) {
                    insertAt = p
                    break
                }
                if (insertAt < 0) insertAt = p + size
            }
            p += size
        }
        if (insertAt < 0) return b

        val chunks = ArrayList<ByteArray>(permIdx.size * 2)
        for (pi in permIdx) {
            val start = ByteArray(56)
            val sdv = ByteBuffer.wrap(start).order(ByteOrder.LITTLE_ENDIAN)
            sdv.putU16(0, 0x0102)
            sdv.putU16(2, 16)
            sdv.putU32(4, 56)
            sdv.putU32(8, 1)
            sdv.putU32(12, 0xffffffff.toInt())
            sdv.putU32(16, 0xffffffff.toInt())
            sdv.putU32(20, tagIdx)
            sdv.putU16(24, 20)
            sdv.putU16(26, 20)
            sdv.putU16(28, 1)
            sdv.putU16(30, 0)
            sdv.putU16(32, 0)
            sdv.putU16(34, 0)
            sdv.putU32(36, nsIdx)
            sdv.putU32(40, nameIdx)
            sdv.putU32(44, pi)
            sdv.putU16(48, 8)
            start[50] = 0
            start[51] = 0x03
            sdv.putU32(52, pi)

            val close = ByteArray(24)
            val cdv = ByteBuffer.wrap(close).order(ByteOrder.LITTLE_ENDIAN)
            cdv.putU16(0, 0x0103)
            cdv.putU16(2, 16)
            cdv.putU32(4, 24)
            cdv.putU32(8, 1)
            cdv.putU32(12, 0xffffffff.toInt())
            cdv.putU32(16, 0xffffffff.toInt())
            cdv.putU32(20, tagIdx)
            chunks += start
            chunks += close
        }

        out = concat(out.copyOfRange(0, insertAt), concat(*chunks.toTypedArray()), out.copyOfRange(insertAt, out.size))
        odv = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        odv.putU32(4, out.size)
        return out
    }

    private fun signV1(entries: List<ZipData>, signKey: SignKey): List<ZipData> {
        val files = entries
            .filterNot { it.name.startsWith("META-INF/") }
            .sortedBy { it.name }

        val manifest = StringBuilder("Manifest-Version: 1.0$CRLF$CRLF")
        val sections = ArrayList<Pair<String, String>>()
        for (entry in files) {
            val section = section(entry.name, sha256b64(entry.data))
            sections += entry.name to section
            manifest.append(section)
        }
        val manifestBytes = manifest.toString().toByteArray(Charsets.UTF_8)

        val sf = StringBuilder()
            .append("Signature-Version: 1.0$CRLF")
            .append("Created-By: 1.0 (SDKForge Web2APK)$CRLF")
            .append("SHA-256-Digest-Manifest: ")
            .append(sha256b64(manifestBytes))
            .append(CRLF)
            .append(CRLF)
        for ((name, value) in sections) sf.append(section(name, sha256b64(value.toByteArray(Charsets.UTF_8))))
        val sfBytes = sf.toString().toByteArray(Charsets.UTF_8)

        val privateKey = importPrivateKey(android.util.Base64.decode(signKey.pkcs8, android.util.Base64.DEFAULT))
        val signature = Signature.getInstance("SHA256withRSA").apply {
            initSign(privateKey)
            update(sfBytes)
        }.sign()

        val rsa = android.util.Base64.decode(signKey.certRsa, android.util.Base64.DEFAULT)
        require(signKey.sigOffset >= 0 && signKey.sigOffset + signature.size <= rsa.size) {
            "Signing response tidak valid: sigOffset di luar certificate container"
        }
        signature.copyInto(rsa, signKey.sigOffset)

        return listOf(
            ZipData("META-INF/MANIFEST.MF", manifestBytes),
            ZipData("META-INF/K.SF", sfBytes),
            ZipData("META-INF/K.RSA", rsa)
        )
    }

    private fun importPrivateKey(bytes: ByteArray): PrivateKey =
        KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(bytes))

    private fun sha256b64(bytes: ByteArray): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256").digest(bytes)
        return android.util.Base64.encodeToString(digest, android.util.Base64.NO_WRAP)
    }

    private fun section(name: String, digest: String): String =
        "Name: $name$CRLF" +
            "SHA-256-Digest: $digest$CRLF" +
            CRLF

    private fun encodeUtf8String(s: String): ByteArray {
        val bytes = s.toByteArray(Charsets.UTF_8)
        val u16len = s.length
        val head = ByteArrayOutputStream()
        if (u16len > 0x7f) {
            head.write(0x80 or (u16len shr 8))
            head.write(u16len and 0xff)
        } else head.write(u16len)
        if (bytes.size > 0x7f) {
            head.write(0x80 or (bytes.size shr 8))
            head.write(bytes.size and 0xff)
        } else head.write(bytes.size)
        head.write(bytes)
        head.write(0)
        return head.toByteArray()
    }

    private fun encodeUtf16String(s: String): ByteArray {
        val out = ByteArray(2 + s.length * 2 + 2)
        val dv = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        dv.putU16(0, s.length)
        for (i in s.indices) dv.putU16(2 + i * 2, s[i].code)
        dv.putU16(2 + s.length * 2, 0)
        return out
    }

    private fun crc32(bytes: ByteArray): Long {
        val table = CRC_TABLE
        var c = -1
        for (byte in bytes) {
            c = table[(c xor (byte.toInt() and 0xff)) and 0xff] xor (c ushr 8)
        }
        return (c.inv().toLong()) and 0xffffffffL
    }

    private fun bytesToChar(value: Int): Char = value.toChar()

    private fun concat(vararg arrays: ByteArray): ByteArray {
        val total = arrays.sumOf { it.size }
        val out = ByteArray(total)
        var offset = 0
        arrays.forEach {
            it.copyInto(out, offset)
            offset += it.size
        }
        return out
    }

    private val CRC_TABLE: IntArray = IntArray(256).also { table ->
        for (i in 0 until 256) {
            var c = i
            repeat(8) {
                c = if ((c and 1) != 0) (0xedb88320.toInt() xor (c ushr 1)) else (c ushr 1)
            }
            table[i] = c
        }
    }

    private fun ByteBuffer.u16(offset: Int): Int = getShort(offset).toInt() and 0xffff
    private fun ByteBuffer.u32(offset: Int): Int = getInt(offset)
    private fun ByteBuffer.putU16(offset: Int, value: Int) { putShort(offset, value.toShort()) }
    private fun ByteBuffer.putU32(offset: Int, value: Int) { putInt(offset, value) }
}
