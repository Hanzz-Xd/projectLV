package com.baklava.projectlv.data.repository

import com.baklava.projectlv.BuildConfig
import android.content.Context
import com.baklava.projectlv.data.admin.AdminControlManager
import com.baklava.projectlv.data.models.ErrorReport
import com.baklava.projectlv.data.network.NetworkMonitor
import com.baklava.projectlv.data.network.SecretRedactor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ErrorReportManager(
    private val context: Context,
    private val networkMonitor: NetworkMonitor,
    private val adminControlManager: AdminControlManager
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val storageFile = File(context.filesDir, "leviathan_error_reports.json")

    private val _activeDialogReport = MutableStateFlow<ErrorReport?>(null)
    val activeDialogReport: StateFlow<ErrorReport?> = _activeDialogReport.asStateFlow()

    private val _reportsHistory = MutableStateFlow<List<ErrorReport>>(emptyList())
    val reportsHistory: StateFlow<List<ErrorReport>> = _reportsHistory.asStateFlow()

    private val _queuedOfflineReports = mutableListOf<ErrorReport>()

    init {
        loadHistory()
        setupUncaughtExceptionHandler()

        // Observe network to retry sending queued reports when online
        scope.launch {
            networkMonitor.status.collect { status ->
                if (status is com.baklava.projectlv.data.network.NetworkStatus.Connected && _queuedOfflineReports.isNotEmpty()) {
                    flushQueuedReports()
                }
            }
        }
    }

    private fun setupUncaughtExceptionHandler() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                captureCrash(throwable, "SYSTEM_FATAL_CRASH")
            } catch (_: Exception) {
            }
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    fun capture(
        throwable: Throwable,
        moduleContext: String,
        httpStatusCode: Int? = null,
        rawHost: String? = null,
        showDialogImmediately: Boolean = false
    ): ErrorReport {
        val sanitizedMessage = SecretRedactor.redactText(throwable.message ?: throwable.javaClass.simpleName)
        val sanitizedStack = SecretRedactor.sanitizeStackTrace(throwable)
        val sanitizedHost = rawHost?.let { SecretRedactor.maskHost(it) }
        val netStatus = if (networkMonitor.isCurrentlyOnline()) "ONLINE" else "OFFLINE"

        val report = ErrorReport(
            moduleContext = moduleContext,
            sanitizedErrorMessage = sanitizedMessage,
            sanitizedStackTrace = sanitizedStack,
            httpStatusCode = httpStatusCode,
            sanitizedHost = sanitizedHost,
            networkStatus = netStatus
        )

        if (shouldSuppressDuplicate(report)) return report
        saveReport(report)

        // Automatic error telemetry is silent on the client. The detailed, redacted
        // technical payload is sent to the admin control-plane for review.
        scope.launch { adminControlManager.submitBugReport(report) }

        if (showDialogImmediately) {
            _activeDialogReport.value = report
        }

        return report
    }

    private fun captureCrash(throwable: Throwable, moduleContext: String) {
        val sanitizedMessage = SecretRedactor.redactText(throwable.message ?: "Fatal unhandled exception")
        val sanitizedStack = SecretRedactor.sanitizeStackTrace(throwable)

        val report = ErrorReport(
            moduleContext = moduleContext,
            sanitizedErrorMessage = sanitizedMessage,
            sanitizedStackTrace = sanitizedStack,
            networkStatus = if (networkMonitor.isCurrentlyOnline()) "ONLINE" else "OFFLINE"
        )
        saveReport(report)
        scope.launch { adminControlManager.submitBugReport(report) }
    }

    fun dismissDialog() {
        _activeDialogReport.value = null
    }

    fun sendReport(
        report: ErrorReport,
        onSuccess: (String) -> Unit,
        onQueued: (String) -> Unit
    ) {
        if (!networkMonitor.isCurrentlyOnline()) {
            _queuedOfflineReports.add(report)
            onQueued("Tidak ada koneksi. Laporan disimpan dan akan dikirim ke bugReports saat online.")
            dismissDialog()
            return
        }

        scope.launch {
            val delivered = adminControlManager.submitBugReport(report)
            if (delivered) {
                onSuccess("Laporan berhasil dikirim ke Firestore / admin panel.")
                dismissDialog()
            } else {
                _queuedOfflineReports.add(report)
                onQueued("Pengiriman gagal. Laporan disimpan dan akan dicoba lagi saat online.")
                dismissDialog()
            }
        }
    }

    private fun flushQueuedReports() {
        scope.launch {
            val pending = ArrayList(_queuedOfflineReports)
            for (report in pending) {
                if (adminControlManager.submitBugReport(report)) {
                    _queuedOfflineReports.remove(report)
                }
            }
        }
    }

    @Synchronized
    private fun saveReport(report: ErrorReport) {
        val updated = listOf(report) + _reportsHistory.value
        _reportsHistory.value = updated.take(50) // Keep latest 50
        scope.launch {
            try {
                val array = JSONArray()
                for (r in _reportsHistory.value) {
                    val obj = JSONObject().apply {
                        put("id", r.id)
                        put("timestamp", r.timestamp)
                        put("appVersion", r.appVersion)
                        put("buildVersion", r.buildVersion)
                        put("deviceModel", r.deviceModel)
                        put("androidVersion", r.androidVersion)
                        put("windowSizeClass", r.windowSizeClass)
                        put("networkStatus", r.networkStatus)
                        put("moduleContext", r.moduleContext)
                        put("sanitizedErrorMessage", r.sanitizedErrorMessage)
                        put("sanitizedStackTrace", r.sanitizedStackTrace)
                        put("httpStatusCode", r.httpStatusCode ?: -1)
                        put("sanitizedHost", r.sanitizedHost ?: "")
                    }
                    array.put(obj)
                }
                storageFile.writeText(array.toString(), Charsets.UTF_8)
            } catch (_: Exception) {
            }
        }
    }

    private fun loadHistory() {
        scope.launch {
            try {
                if (!storageFile.exists()) return@launch
                val json = storageFile.readText(Charsets.UTF_8)
                val array = JSONArray(json)
                val list = mutableListOf<ErrorReport>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val httpCode = obj.optInt("httpStatusCode", -1)
                    val host = obj.optString("sanitizedHost", "")
                    list.add(
                        ErrorReport(
                            id = obj.getString("id"),
                            timestamp = obj.getLong("timestamp"),
                            appVersion = obj.optString("appVersion", BuildConfig.VERSION_NAME),
                            buildVersion = obj.optString("buildVersion", BuildConfig.VERSION_CODE.toString()),
                            deviceModel = obj.optString("deviceModel", "Unknown"),
                            androidVersion = obj.optString("androidVersion", ""),
                            windowSizeClass = obj.optString("windowSizeClass", "Compact"),
                            networkStatus = obj.optString("networkStatus", "UNKNOWN"),
                            moduleContext = obj.getString("moduleContext"),
                            sanitizedErrorMessage = obj.getString("sanitizedErrorMessage"),
                            sanitizedStackTrace = obj.getString("sanitizedStackTrace"),
                            httpStatusCode = if (httpCode != -1) httpCode else null,
                            sanitizedHost = if (host.isNotBlank()) host else null
                        )
                    )
                }
                _reportsHistory.value = list
            } catch (_: Exception) {
            }
        }
    }
    private fun shouldSuppressDuplicate(report: ErrorReport): Boolean {
        val prefs = context.getSharedPreferences("leviathan_error_dedupe", Context.MODE_PRIVATE)
        val key = (report.moduleContext + "|" + report.sanitizedErrorMessage).hashCode().toString()
        val now = System.currentTimeMillis()
        val last = prefs.getLong(key, 0L)
        if (now - last < 10L * 60L * 1000L) return true
        prefs.edit().putLong(key, now).apply()
        return false
    }

}
