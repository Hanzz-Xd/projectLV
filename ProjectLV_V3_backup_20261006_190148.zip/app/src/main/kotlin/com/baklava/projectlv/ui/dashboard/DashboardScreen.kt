package com.baklava.projectlv.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import com.baklava.projectlv.ui.components.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.WifiOff
import com.baklava.projectlv.ui.components.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.ui.components.AppWindowSize
import com.baklava.projectlv.ui.components.CategoryLabelRow
import com.baklava.projectlv.ui.components.LeviathanDestination
import com.baklava.projectlv.ui.components.LeviathanHeaderCard
import com.baklava.projectlv.ui.components.staggeredEntrance
import com.baklava.projectlv.ui.theme.BrightAmber
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.DarkGrey
import com.baklava.projectlv.ui.theme.MutedGrey

data class ToolModuleItem(
    val id: String,
    val number: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val icon: ImageVector,
    val destination: LeviathanDestination,
    val accentColor: Color,
    val requiresInternet: Boolean,
    val category: String
)

/** Urutan tampil kategori pada Dashboard, dari yang paling sering dipakai. */
private val DASHBOARD_CATEGORY_ORDER = listOf(
    "AI",
    "DOWNLOADER",
    "MEDIA",
    "WEB TOOLS",
    "DEV TOOLS",
    "UTILITAS"
)

@Composable
fun DashboardScreen(
    windowSize: AppWindowSize,
    isOnline: Boolean,
    onNavigateTo: (LeviathanDestination) -> Unit,
    onOfflineModuleBlocked: (String) -> Unit,
    onSecretAdminGesture: () -> Unit = {},
    isToolEnabled: (String) -> Boolean = { true }
) {
    val modules = remember {
        listOf(
            ToolModuleItem(
                id = "base64",
                number = "01",
                title = "BASE64 LAB",
                subtitle = "Encode / Decode Engine",
                description = "Konversi file dan teks ke Base64, Data URI generator, serta decode Base64 kembali ke file asli.",
                icon = Icons.Default.Code,
                destination = LeviathanDestination.BASE64_LAB,
                accentColor = Color(0xFFE5E7EB),
                requiresInternet = false,
                category = "DEV TOOLS"
            ),
            ToolModuleItem(
                id = "magiclink",
                number = "02",
                title = "MAGIC LINK",
                subtitle = "Alight Motion V1 / V2",
                description = "Proses pengiriman dan verifikasi magic link Alight Motion dengan ekstraksi kode order otomatis.",
                icon = Icons.Default.AutoFixHigh,
                destination = LeviathanDestination.MAGIC_LINK,
                accentColor = Color(0xFFE5E7EB),
                requiresInternet = true,
                category = "UTILITAS"
            ),
            ToolModuleItem(
                id = "webtools",
                number = "03",
                title = "WEB TOOLS",
                subtitle = "Web Automation Center",
                description = "Web to APK, inspeksi Page Source HTML, Web to ZIP, Short URL, serta Enc / Obf HTML dengan input teks atau upload index.html + CSS/JS.",
                icon = Icons.Default.Language,
                destination = LeviathanDestination.WEB_TOOLS,
                accentColor = Color(0xFFE5E7EB),
                requiresInternet = true,
                category = "DEV TOOLS"
            ),
            ToolModuleItem(
                id = "stromai",
                number = "04",
                title = "STROM AI",
                subtitle = "Interactive AI Console",
                description = "Asisten kecerdasan buatan interaktif berbasis Strom AI engine dengan manajemen sesi chat.",
                icon = Icons.Default.Psychology,
                destination = LeviathanDestination.STROM_AI,
                accentColor = Color(0xFFE5E7EB),
                requiresInternet = true,
                category = "AI"
            ),
            ToolModuleItem(
                id = "downloader",
                number = "05",
                title = "DOWNLOADER",
                subtitle = "TikTok, YouTube & Drive Saver",
                description = "Pengunduh media publik TikTok (no watermark), YouTube (multi kualitas + preview HD), dan file Google Drive langsung ke Downloads.",
                icon = Icons.Default.Download,
                destination = LeviathanDestination.DOWNLOADER,
                accentColor = Color(0xFFE5E7EB),
                requiresInternet = true,
                category = "DOWNLOADER"
            ),
            ToolModuleItem(
                id = "media",
                number = "06",
                title = "MEDIA",
                subtitle = "Upload, Upscale & Remove BG",
                description = "Upload file (gambar, PDF, DOC, XLS, PPT), upscale gambar hingga 8x, dan hapus background gambar secara otomatis.",
                icon = Icons.Default.Image,
                destination = LeviathanDestination.MEDIA,
                accentColor = Color(0xFFE5E7EB),
                requiresInternet = true,
                category = "MEDIA"
            ),
            ToolModuleItem(
                id = "tiktok_quality",
                number = "07",
                title = "QUALITY METHOD",
                subtitle = "TikTok HQ Upload",
                description = "Client-side video preparation dengan WMV, Binary MP4 Patch, FPS Presentation Patch, serta compression 720p/1080p.",
                icon = Icons.Default.HighQuality,
                destination = LeviathanDestination.TIKTOK_QUALITY,
                accentColor = Color(0xFFE5E7EB),
                requiresInternet = false,
                category = "MEDIA"
            ),
            ToolModuleItem(
                id = "pyobfuscator",
                number = "08",
                title = "PY OBFUSCATOR",
                subtitle = "Python Code Protection",
                description = "Obfuscate source Python (rename, encrypt, flatten, junk code) lengkap dengan preview perbedaan sebelum & sesudah.",
                icon = Icons.Default.Terminal,
                destination = LeviathanDestination.PY_OBFUSCATOR,
                accentColor = Color(0xFFE5E7EB),
                requiresInternet = true,
                category = "WEB TOOLS"
            )
            ,
            ToolModuleItem(
                id = "pterodactyl_whatsapp",
                number = "09",
                title = "cPANEL PTERODACTYL",
                subtitle = "Pterodactyl Panel Gratis",
                description = "Buat cPanel Pterodactyl gratis khusus konfigurasi WhatsApp. Konfigurasi Python/egg lain tidak tersedia di modul ini.",
                icon = Icons.Default.Cloud,
                destination = LeviathanDestination.PTERODACTYL_WHATSAPP,
                accentColor = Color(0xFFE5E7EB),
                requiresInternet = true,
                category = "UTILITAS"
            ),
            ToolModuleItem(
                id = "alight_motion_finder",
                number = "10",
                title = "ALIGHT MOTION FINDER",
                subtitle = "Cari Link Preset",
                description = "Temukan link preset Alight Motion dari caption, komentar, dan reply pada link TikTok.",
                icon = Icons.Default.Search,
                destination = LeviathanDestination.ALIGHT_MOTION_FINDER,
                accentColor = Color(0xFFE5E7EB),
                requiresInternet = true,
                category = "UTILITAS"
            ),
            ToolModuleItem(
                id = "sfl_bypass",
                number = "11",
                title = "SFL LINK BYPASS",
                subtitle = "Lewati shortlink SFL",
                description = "Resolusi link sfl.gl menjadi URL tujuan menggunakan layanan bypass ProjectLV.",
                icon = Icons.Default.Search,
                destination = LeviathanDestination.SFL_BYPASS,
                accentColor = Color(0xFFE5E7EB),
                requiresInternet = true,
                category = "UTILITAS"
            )
        )
    }

    val columns = if (windowSize.isCompact) 1 else 2

    LazyVerticalGrid(
        columns = GridCells.Fixed(columns),
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
            .testTag("dashboard_grid"),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Header Card (Spans all columns)
        item(span = { GridItemSpan(maxLineSpan) }) {
            LeviathanHeaderCard(
                isOnline = isOnline,
                onSecretAdminGesture = onSecretAdminGesture
            )
        }

        // Tools are intentionally surfaced directly on Beranda.
        // Streaming Anime is a global navigation destination, so no duplicate
        // entry card/overlay is shown here.

        // 2. Section Title: TOOL CENTER (ringkasan total, tetap ada di atas kategori)
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .staggeredEntrance(index = 2, offsetY = 10.dp, durationMs = 380)
                    .fillMaxWidth()
                    .padding(vertical = 4.dp, horizontal = 2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE5E7EB))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "TOOL CENTER",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                )
                Spacer(modifier = Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(CyberSurfaceVariant)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${modules.size} MODUL AKTIF",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MutedGrey,
                            fontFamily = FontFamily.Default,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }

        // 3. Module Cards — dikelompokkan per kategori fungsi agar rapi
        val groupedModules = modules.groupBy { it.category }
        val orderedCategories = DASHBOARD_CATEGORY_ORDER.filter { groupedModules.containsKey(it) } +
            groupedModules.keys.filter { it !in DASHBOARD_CATEGORY_ORDER }

        orderedCategories.forEach { category ->
            val categoryModules = groupedModules[category].orEmpty()

            item(span = { GridItemSpan(maxLineSpan) }) {
                CategoryLabelRow(
                    title = category,
                    countLabel = "${categoryModules.size} MODUL",
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            items(categoryModules, key = { it.id }) { module ->
                val isNetworkBlocked = module.requiresInternet && !isOnline
                val isPolicyBlocked = !isToolEnabled(module.id)
                val isBlocked = isNetworkBlocked || isPolicyBlocked
                ToolModuleCard(
                    module = module,
                    isBlocked = isBlocked,
                    modifier = Modifier.staggeredEntrance(index = modules.indexOf(module) + 3),
                    onClick = {
                        when {
                            isPolicyBlocked -> onOfflineModuleBlocked("${module.title} sedang dinonaktifkan admin.")
                            isNetworkBlocked -> onOfflineModuleBlocked(module.title)
                            else -> onNavigateTo(module.destination)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun ToolModuleCard(
    module: ToolModuleItem,
    isBlocked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .testTag("card_module_${module.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isBlocked) CyberDarkNavy.copy(alpha = 0.6f) else CyberDarkNavy
        ),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyberSurfaceVariant)
                            .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = module.icon,
                            contentDescription = module.title,
                            tint = if (isBlocked) DarkGrey else Color(0xFFE5E7EB),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = module.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isBlocked) DarkGrey else Color.White,
                                fontSize = 14.sp
                            )
                        )
                        Text(
                            text = module.subtitle,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (isBlocked) DarkGrey else MutedGrey,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                if (isBlocked) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(BrightAmber.copy(alpha = 0.15f))
                            .border(1.dp, BrightAmber.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.WifiOff,
                                contentDescription = "Offline",
                                tint = BrightAmber,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "OFFLINE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = BrightAmber,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(CyberSurfaceVariant)
                            .border(1.dp, CyberCardBorder, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Buka",
                            tint = Color(0xFFE5E7EB),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = module.description,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = if (isBlocked) DarkGrey else MutedGrey,
                    lineHeight = 18.sp,
                    fontSize = 12.sp
                )
            )
        }
    }
}

