package com.baklava.projectlv.data.admin

import android.content.Context

/**
 * Persists the last announcement revision already shown to each account.
 * The revision includes the Firestore document id and updatedAt timestamp, so
 * editing/publishing a new admin message produces a new revision and shows once.
 */
class AnnouncementSeenStore(context: Context) {
    private val prefs = context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    fun keyFor(item: AnnouncementRecord): String =
        "${item.id}:${item.updatedAt ?: item.createdAt ?: 0L}"

    fun isSeen(uid: String, item: AnnouncementRecord): Boolean =
        prefs.getString(seenKey(uid), null) == keyFor(item)

    fun markSeen(uid: String, item: AnnouncementRecord) {
        prefs.edit().putString(seenKey(uid), keyFor(item)).apply()
    }

    fun clear(uid: String) {
        prefs.edit().remove(seenKey(uid)).apply()
    }

    private fun seenKey(uid: String) = "seen_global_announcement_$uid"

    private companion object {
        const val FILE_NAME = "project_lv_notification_state"
    }
}
