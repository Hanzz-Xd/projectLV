package com.baklava.projectlv.data.admin

/** Realtime global controls published from the admin panel. */
data class GlobalControlState(
    /** Existing field kept for compatibility: false means maintenance/offline for normal users. */
    val enabled: Boolean = true,
    val message: String = ":)",
    /** This remains a global application expiry, not a per-device/account expiry. */
    val toolStates: Map<String, Boolean> = emptyMap(),
    val apiControls: Map<String, ApiControlState> = emptyMap(),
    val updatedAt: Long? = null
) {
    /**
     * Returns the state of an individual feature gate only.
     * Global maintenance is handled separately by MainActivity so admins can
     * bypass global maintenance while still respecting an explicitly disabled
     * feature.
     */
    fun isToolEnabled(toolId: String): Boolean =
        toolStates[toolId] != false && apiControls[toolId]?.enabled != false

    fun isMaintenanceActive(): Boolean = !enabled
}

data class ApiControlState(
    val enabled: Boolean = true,
    val keyRevision: String = "default",
    val endpointAlias: String = ""
)

data class DeviceRecord(
    val id: String,
    val ownerUid: String = "",
    val ownerEmail: String = "",
    val manufacturer: String = "Unknown",
    val model: String = "Unknown",
    val androidVersion: String = "Unknown",
    val sdkInt: Long = 0L,
    val appVersion: String = "Unknown",
    val lastIp: String = "",
    val lastTool: String = "",
    val totalToolUses: Long = 0L,
    val toolUsage: Map<String, Long> = emptyMap(),
    val banned: Boolean = false,
    val banStartedAt: Long? = null,
    val banExpiresAt: Long? = null,
    val banReason: String = "",
    val banWarning: String = "",
    val violationCount: Long = 0L,
    val lastViolation: String = "",
    val lastSeenAt: Long? = null,
    val createdAt: Long? = null,
    val updatedAt: Long? = null
)

enum class AnnouncementContext(val key: String, val label: String, val meaning: String) {
    INFORMATION("information", "Informasi", "Pemberitahuan umum tanpa urgensi."),
    WARNING("warning", "Peringatan", "Perhatian pengguna dibutuhkan."),
    HARD_WARNING("hard_warning", "Peringatan Keras", "Gangguan/risiko serius yang perlu segera diketahui."),
    UPDATE("update", "Update", "Perubahan atau rilis baru.");

    companion object {
        fun fromKey(value: String?): AnnouncementContext = entries.firstOrNull { it.key == value } ?: INFORMATION
    }
}

data class AnnouncementRecord(
    val id: String,
    val context: AnnouncementContext,
    val title: String,
    val body: String,
    val enabled: Boolean,
    val createdAt: Long? = null,
    val updatedAt: Long? = null
)

data class BugReportRecord(
    val id: String,
    val deviceIdHash: String,
    val moduleContext: String,
    val message: String,
    val stackTrace: String,
    val hostAlias: String,
    val httpStatusCode: Long?,
    val model: String,
    val androidVersion: String,
    val publicIp: String,
    val appVersion: String,
    val severity: String,
    val createdAt: Long?,
    val status: String
)
