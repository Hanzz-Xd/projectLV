#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import hashlib
import json
import logging
import os
import secrets
import zlib
from datetime import datetime, timezone


SCRIPT_VERSION = "2.0.0"
MAX_PAD_REPEAT = 5000
MAX_PAD_LINES = 100

HEX_TO_SPECIAL = {
    "0": "E͐",
    "1": "͙",
    "2": "͏",
    "3": "͂",
    "4": "͆",
    "5": "͕",
    "6": "͓",
    "7": "̓",
    "8": "́",
    "9": "͔",
    "a": "ͅ",
    "b": "̝",
    "c": "̈",
    "d": "͌",
    "e": "͍",
    "f": "̈́",
}

SPECIAL_TO_HEX = {value: key for key, value in HEX_TO_SPECIAL.items()}

LOGGER = logging.getLogger("javasiaenc24")


def configure_logging(verbose: bool, quiet: bool) -> None:
    """Configure CLI logging without exposing key material."""
    if quiet:
        level = logging.ERROR
    elif verbose:
        level = logging.DEBUG
    else:
        level = logging.INFO

    logging.basicConfig(
        level=level,
        format="%(levelname)s: %(message)s",
    )


class WebEncryptor:
    """
    HTML/CSS/JavaScript obfuscator based on the supplied implementation.

    Pipeline:
        UTF-8 -> zlib(level 9) -> XOR(SHA-512(seed*777))
        -> nibble swap -> hex -> special Unicode characters

    The generated HTML contains a JavaScript loader that reverses that
    pipeline in the browser.

    IMPORTANT:
        This is reversible obfuscation, not modern cryptographic encryption.
        The seed is embedded into the generated browser loader because the
        browser needs it to reconstruct the payload.
    """

    def __init__(self, key_seed: str):
        if not isinstance(key_seed, str) or not key_seed:
            raise ValueError("Key seed harus berupa string dan tidak boleh kosong.")

        self.key_seed = key_seed
        self.master_key = hashlib.sha512(
            key_seed.encode("utf-8") * 777
        ).digest()

    def _simple_encrypt(self, data: bytes) -> bytes:
        encrypted = bytearray()

        for i, byte in enumerate(data):
            encrypted.append(
                byte ^ self.master_key[i % len(self.master_key)]
            )

        rotated = bytearray()

        for byte in encrypted:
            rotated.append(((byte << 4) | (byte >> 4)) & 0xFF)

        return bytes(rotated)

    def encrypt_data(self, data):
        if isinstance(data, str):
            data = data.encode("utf-8")

        compressed = zlib.compress(data, 9)
        encrypted = self._simple_encrypt(compressed)

        return encrypted.hex()

    @staticmethod
    def hex_to_special_chars(hex_text: str) -> str:
        return "".join(
            HEX_TO_SPECIAL.get(char, char)
            for char in hex_text.lower()
        )

    @staticmethod
    def decrypt_data_python(encrypted_hex: str, key_seed: str) -> bytes:
        """
        Python-side round-trip helper for testing only.
        It mirrors the browser loader but does not execute the result.
        """
        if not isinstance(key_seed, str) or not key_seed:
            raise ValueError("Key seed harus berupa string dan tidak boleh kosong.")

        master_key = hashlib.sha512(
            key_seed.encode("utf-8") * 777
        ).digest()

        encrypted = bytes.fromhex(encrypted_hex)

        unrotated = bytearray()
        for byte in encrypted:
            unrotated.append(
                ((byte >> 4) | ((byte << 4) & 0xFF)) & 0xFF
            )

        decrypted = bytearray()
        for i, byte in enumerate(unrotated):
            decrypted.append(
                byte ^ master_key[i % len(master_key)]
            )

        return zlib.decompress(bytes(decrypted))


def inject_before_closing_tag(html: str, tag_name: str, block: str) -> str:
    """
    Inline CSS/JS into an existing HTML document.
    If the closing tag is absent, append the block instead.
    """
    marker = f"</{tag_name}>"
    lower_html = html.lower()
    index = lower_html.rfind(marker.lower())

    if index != -1:
        return html[:index] + block + "\n" + html[index:]

    return html.rstrip() + "\n" + block + "\n"


def build_final_html(
    html_source: str,
    css_source: str = "",
    js_source: str = "",
) -> str:
    """
    Combine optional external CSS and JS into the HTML before encryption.
    CSS is inserted before </head>; JS before </body>.
    """
    result = html_source

    if css_source:
        css_block = (
            "\n<!-- Protected CSS -->\n"
            "<style>\n"
            f"{css_source}\n"
            "</style>\n"
            "<!-- /Protected CSS -->\n"
        )
        result = inject_before_closing_tag(result, "head", css_block)

    if js_source:
        js_block = (
            "\n<!-- Protected JavaScript -->\n"
            "<script>\n"
            f"{js_source}\n"
            "</script>\n"
            "<!-- /Protected JavaScript -->\n"
        )
        result = inject_before_closing_tag(result, "body", js_block)

    return result


def read_text_file(path: str) -> str:
    """
    Read UTF-8 first. If that fails, explicitly warn before using latin-1.

    latin-1 is intentionally kept as a compatibility fallback because the
    original script allowed arbitrary byte values to be decoded losslessly.
    """
    try:
        with open(path, "r", encoding="utf-8") as file:
            return file.read()
    except UnicodeDecodeError as exc:
        LOGGER.warning(
            "File '%s' bukan UTF-8 yang valid (%s). "
            "Fallback ke latin-1 digunakan; periksa hasilnya jika encoding "
            "asli berbeda.",
            path,
            exc,
        )

        try:
            with open(path, "r", encoding="latin-1") as file:
                return file.read()
        except OSError:
            raise


def validate_padding(padding_repeat: int, padding_lines: int) -> None:
    if padding_repeat < 0:
        raise ValueError("padding_repeat tidak boleh negatif.")
    if padding_lines < 0:
        raise ValueError("padding_lines tidak boleh negatif.")
    if padding_repeat > MAX_PAD_REPEAT:
        raise ValueError(
            f"padding_repeat melebihi maksimum {MAX_PAD_REPEAT}."
        )
    if padding_lines > MAX_PAD_LINES:
        raise ValueError(
            f"padding_lines melebihi maksimum {MAX_PAD_LINES}."
        )


def build_metadata_comment(
    source_sha256: str,
    generated_at: str,
) -> str:
    """Return non-secret build metadata outside the encrypted payload."""
    return (
        "<!-- JAVASIAENC24 BUILD METADATA -->\n"
        f"<!-- Version: {SCRIPT_VERSION} -->\n"
        f"<!-- Generated: {generated_at} -->\n"
        f"<!-- Source-SHA256: {source_sha256} -->\n"
        "<!-- NOTE: Metadata is diagnostic only; it provides no protection. -->\n"
        "<!-- /JAVASIAENC24 BUILD METADATA -->"
    )


def create_loader_html(
    encrypted_special: str,
    key_seed: str,
    padding_repeat: int = 2500,
    padding_lines: int = 20,
    metadata_comment: str = "",
) -> str:
    """
    Build the self-decrypting HTML loader.

    The key is intentionally embedded in the loader because the browser
    needs it to decrypt the payload. This is obfuscation, not secret storage.
    """
    validate_padding(padding_repeat, padding_lines)

    special_text = "JavasiaEnc24" * padding_repeat
    padding_block = "\n".join(
        f"<!-- {special_text} -->"
        for _ in range(padding_lines)
    )

    enc_literal = json.dumps(
        encrypted_special,
        ensure_ascii=True,
        separators=(",", ":"),
    )
    key_literal = json.dumps(
        key_seed,
        ensure_ascii=True,
        separators=(",", ":"),
    )

    # Keep the reverse map in exactly the same spirit as the supplied
    # encryptor: special Unicode sequence -> original hex character.
    reverse_map_lines = ",\n".join(
        f"                [{json.dumps(special)}, {json.dumps(hex_char)}]"
        for special, hex_char in SPECIAL_TO_HEX.items()
    )

    loader_script = f"""<script>
(() => {{
    "use strict";

    const _key_seed_ = {key_literal};
    const _enc_special_ = {enc_literal};

    const _special_to_hex_dict_ = new Map([
{reverse_map_lines}
    ]);

    function _special_to_hex_(text) {{
        const chars = [];
        let i = 0;

        while (i < text.length) {{
            let found = false;

            for (const [_special_char_, _hex_char_] of _special_to_hex_dict_) {{
                if (text.startsWith(_special_char_, i)) {{
                    chars.push(_hex_char_);
                    i += _special_char_.length;
                    found = true;
                    break;
                }}
            }}

            if (!found) {{
                i += 1;
            }}
        }}

        return chars.join("");
    }}

    function _hex_to_bytes_(hex) {{
        if ((hex.length & 1) !== 0) {{
            throw new Error("Encrypted payload memiliki panjang hex ganjil.");
        }}

        const bytes = new Uint8Array(hex.length / 2);

        for (let i = 0; i < hex.length; i += 2) {{
            bytes[i / 2] = parseInt(hex.slice(i, i + 2), 16);
        }}

        return bytes;
    }}

    async function _sha512_key_(seed) {{
        const seedBytes = new TextEncoder().encode(seed.repeat(777));
        const digest = await crypto.subtle.digest("SHA-512", seedBytes);
        return new Uint8Array(digest);
    }}

    function _reverse_nibble_swap_(bytes) {{
        const result = new Uint8Array(bytes.length);

        for (let i = 0; i < bytes.length; i++) {{
            const byte = bytes[i];
            result[i] = ((byte >>> 4) | ((byte << 4) & 0xFF)) & 0xFF;
        }}

        return result;
    }}

    function _reverse_xor_(bytes, key) {{
        const result = new Uint8Array(bytes.length);

        for (let i = 0; i < bytes.length; i++) {{
            result[i] = bytes[i] ^ key[i % key.length];
        }}

        return result;
    }}

    async function _zlib_decompress_(bytes) {{
        if (typeof DecompressionStream === "undefined") {{
            throw new Error(
                "Browser tidak mendukung DecompressionStream('deflate'). " +
                "Gunakan browser Chromium/Android modern."
            );
        }}

        const stream = new Blob([bytes])
            .stream()
            .pipeThrough(new DecompressionStream("deflate"));

        const arrayBuffer = await new Response(stream).arrayBuffer();
        return new Uint8Array(arrayBuffer);
    }}

    function _show_error_(error) {{
        document.documentElement.innerHTML = `
            <body style="margin:0;padding:24px;background:#111;color:#eee;
                         font-family:system-ui,sans-serif;">
                <h2>JavasiaEnc24 Loader Error</h2>
                <pre style="white-space:pre-wrap;color:#ff8080;">${{String(error)}}</pre>
            </body>
        `;
    }}

    async function _decrypt_and_run_() {{
        const _enc_hex_ = _special_to_hex_(_enc_special_);
        const _enc_bytes_ = _hex_to_bytes_(_enc_hex_);
        const _key_ = await _sha512_key_(_key_seed_);

        const _unrotated_ = _reverse_nibble_swap_(_enc_bytes_);
        const _decrypted_ = _reverse_xor_(_unrotated_, _key_);
        const _final_bytes_ = await _zlib_decompress_(_decrypted_);
        const _final_html_ = new TextDecoder("utf-8", {{ fatal: true }})
            .decode(_final_bytes_);

        document.open();
        document.write(_final_html_);
        document.close();
    }}

    _decrypt_and_run_().catch(_show_error_);
}})();
</script>"""

    parts = []

    if metadata_comment:
        parts.append(metadata_comment)

    if padding_block:
        parts.append(padding_block)

    parts.append("<!-- ===== JAVASIAENC24 ENCRYPTED LOADER ===== -->")
    parts.append(loader_script)
    parts.append("<!-- ===== /JAVASIAENC24 ENCRYPTED LOADER ===== -->")

    if padding_block:
        parts.append(padding_block)

    return (
        "<!doctype html>\n"
        "<html><head><meta charset=\"utf-8\"></head><body>\n"
        + "\n".join(parts)
        + "\n</body></html>\n"
    )


def get_source_sha256(final_html: str) -> str:
    return hashlib.sha256(final_html.encode("utf-8")).hexdigest()


def validate_output_path(
    html_file: str,
    css_file: str | None,
    js_file: str | None,
    output_file: str,
) -> None:
    """
    Prevent accidental self-overwrite of any input file.
    """
    output_abs = os.path.realpath(os.path.abspath(output_file))
    inputs = [html_file]
    if css_file:
        inputs.append(css_file)
    if js_file:
        inputs.append(js_file)

    for input_file in inputs:
        input_abs = os.path.realpath(os.path.abspath(input_file))
        if output_abs == input_abs:
            raise ValueError(
                f"Output '{output_file}' tidak boleh sama dengan input "
                f"'{input_file}'."
            )


def process_files(
    html_file: str,
    css_file: str | None,
    js_file: str | None,
    output_file: str,
    key_seed: str,
    padding_repeat: int,
    padding_lines: int,
    verbose: bool = False,
    quiet: bool = False,
) -> bool:
    if not os.path.exists(html_file):
        LOGGER.error("File HTML '%s' tidak ditemukan.", html_file)
        return False

    if css_file and not os.path.exists(css_file):
        LOGGER.error("File CSS '%s' tidak ditemukan.", css_file)
        return False

    if js_file and not os.path.exists(js_file):
        LOGGER.error("File JavaScript '%s' tidak ditemukan.", js_file)
        return False

    try:
        validate_padding(padding_repeat, padding_lines)
        validate_output_path(html_file, css_file, js_file, output_file)

        html_source = read_text_file(html_file)
        css_source = read_text_file(css_file) if css_file else ""
        js_source = read_text_file(js_file) if js_file else ""

        final_html = build_final_html(
            html_source,
            css_source,
            js_source,
        )

        source_sha256 = get_source_sha256(final_html)
        generated_at = datetime.now(timezone.utc).isoformat(timespec="seconds")

        if verbose:
            LOGGER.debug("Final source SHA-256: %s", source_sha256)
            LOGGER.debug("Generated timestamp (UTC): %s", generated_at)

        encryptor = WebEncryptor(key_seed)

        encrypted_hex = encryptor.encrypt_data(final_html)
        encrypted_special = encryptor.hex_to_special_chars(encrypted_hex)

        metadata_comment = build_metadata_comment(
            source_sha256=source_sha256,
            generated_at=generated_at,
        )

        protected_html = create_loader_html(
            encrypted_special=encrypted_special,
            key_seed=key_seed,
            padding_repeat=padding_repeat,
            padding_lines=padding_lines,
            metadata_comment=metadata_comment,
        )

        # Verify the compression/obfuscation round-trip without executing HTML.
        recovered = WebEncryptor.decrypt_data_python(
            encrypted_hex,
            key_seed,
        ).decode("utf-8")

        if recovered != final_html:
            raise RuntimeError("Round-trip verification gagal.")

        with open(output_file, "w", encoding="utf-8", newline="\n") as file:
            file.write(protected_html)

        LOGGER.info(
            "Berhasil membuat '%s' (%s bytes).",
            output_file,
            len(protected_html),
        )

        if not quiet:
            print()  # Preserve the original readable summary in normal mode.
            print("=" * 62)
            print("JAVASIAENC24 WEB OBFUSCATOR")
            print("=" * 62)
            print(f"HTML   : {html_file}")
            print(f"CSS    : {css_file or '-'}")
            print(f"JS     : {js_file or '-'}")
            print("KEY    : [REDACTED]")
            print(f"PAYLOAD: {len(encrypted_special):,} chars")
            print(f"OUTPUT : {output_file}")
            print(f"SIZE   : {len(protected_html):,} bytes")
            print(f"VERSION: {SCRIPT_VERSION}")
            print(f"SOURCE : {source_sha256}")
            print("=" * 62)
            print("Round-trip test: OK")
            print("Loader browser: DecompressionStream('deflate')")
            print("Mode: reversible obfuscation (not cryptographic encryption)")

        return True

    except FileNotFoundError as exc:
        LOGGER.error("File tidak ditemukan saat proses: %s", exc)
        return False
    except PermissionError as exc:
        LOGGER.error("Akses file ditolak: %s", exc)
        return False
    except UnicodeError as exc:
        LOGGER.error("Masalah encoding teks: %s", exc)
        return False
    except zlib.error as exc:
        LOGGER.error("Kompresi/dekompresi zlib gagal: %s", exc)
        return False
    except (ValueError, OSError) as exc:
        LOGGER.error("Input/output tidak valid: %s", exc)
        return False
    except RuntimeError as exc:
        LOGGER.error("Verifikasi pipeline gagal: %s", exc)
        return False


def run_self_test(quiet: bool = False) -> None:
    test_html = """<!doctype html>
<html>
<head><meta charset="utf-8"><title>Test</title></head>
<body><h1>Hello JavasiaEnc24</h1></body>
</html>
"""
    test_css = "body { font-family: sans-serif; }"
    test_js = "console.log('JavasiaEnc24 test');"

    final_html = build_final_html(test_html, test_css, test_js)

    enc = WebEncryptor("TEST_KEY")
    encrypted_hex = enc.encrypt_data(final_html)
    special = enc.hex_to_special_chars(encrypted_hex)

    recovered = enc.decrypt_data_python(
        encrypted_hex,
        "TEST_KEY",
    ).decode("utf-8")

    assert recovered == final_html
    assert special
    assert all(
        char in SPECIAL_TO_HEX or char not in HEX_TO_SPECIAL
        for char in special
    )

    # Also test padding validation boundaries.
    validate_padding(MAX_PAD_REPEAT, MAX_PAD_LINES)

    for invalid_repeat in (-1, MAX_PAD_REPEAT + 1):
        try:
            validate_padding(invalid_repeat, 0)
        except ValueError:
            pass
        else:
            raise AssertionError("Invalid padding_repeat diterima.")

    for invalid_lines in (-1, MAX_PAD_LINES + 1):
        try:
            validate_padding(0, invalid_lines)
        except ValueError:
            pass
        else:
            raise AssertionError("Invalid padding_lines diterima.")

    if not quiet:
        print("SELF-TEST: OK")
        print(f"Version     : {SCRIPT_VERSION}")
        print(f"Plain HTML  : {len(final_html.encode('utf-8')):,} bytes")
        print(f"Encrypted   : {len(encrypted_hex):,} hex chars")
        print(f"Special     : {len(special):,} chars")
        print("Padding max : validated")
        print("Key output  : never printed")


def resolve_key(args: argparse.Namespace, parser: argparse.ArgumentParser) -> str:
    if args.test:
        return "TEST_KEY"

    if args.key is not None and args.key_env is not None:
        parser.error("Gunakan salah satu --key atau --key-env, bukan keduanya.")

    if args.key is not None:
        if not args.key:
            parser.error("--key tidak boleh kosong.")
        return args.key

    if args.key_env is not None:
        if not args.key_env.strip():
            parser.error("--key-env tidak boleh kosong.")

        value = os.environ.get(args.key_env)
        if value is None:
            parser.error(
                f"Environment variable '{args.key_env}' tidak ditemukan."
            )
        if not value:
            parser.error(
                f"Environment variable '{args.key_env}' ditemukan tetapi kosong."
            )
        return value

    # Do not silently fall back to the old "asu" default.
    parser.error(
        "Key wajib diberikan melalui --key atau --key-env "
        "(kecuali memakai --test)."
    )
    raise AssertionError("unreachable")


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "HTML/CSS/JavaScript reversible obfuscator using the same "
            "zlib/XOR/nibble-swap/special-character pipeline."
        ),
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {SCRIPT_VERSION}",
    )

    parser.add_argument(
        "--html",
        required=False,
        help="Input HTML file.",
    )
    parser.add_argument(
        "--css",
        default=None,
        help="Optional CSS file to inline before obfuscation.",
    )
    parser.add_argument(
        "--js",
        default=None,
        help="Optional JavaScript file to inline before obfuscation.",
    )
    parser.add_argument(
        "--out",
        default="encrypted_web.html",
        help="Output HTML filename.",
    )

    key_group = parser.add_mutually_exclusive_group()
    key_group.add_argument(
        "--key",
        default=None,
        help="Key seed. Perhatikan: key akan tertanam di loader browser.",
    )
    key_group.add_argument(
        "--key-env",
        default=None,
        metavar="ENV_NAME",
        help=(
            "Ambil key seed dari environment variable. Ini menghindari "
            "key muncul di shell history/command line, tetapi bukan "
            "jaminan bahwa environment bersifat rahasia."
        ),
    )

    parser.add_argument(
        "--pad-repeat",
        type=int,
        default=2500,
        help=(
            f"Berapa kali JavasiaEnc24 diulang pada tiap padding block "
            f"(0-{MAX_PAD_REPEAT}, default: 2500)."
        ),
    )
    parser.add_argument(
        "--pad-lines",
        type=int,
        default=20,
        help=(
            f"Jumlah HTML-comment padding lines sebelum/sesudah loader "
            f"(0-{MAX_PAD_LINES}, default: 20)."
        ),
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Aktifkan logging debug tambahan tanpa menampilkan key.",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Hanya tampilkan error.",
    )
    parser.add_argument(
        "--test",
        action="store_true",
        help="Run internal round-trip test and exit.",
    )

    return parser


def main() -> int:
    parser = build_arg_parser()
    args = parser.parse_args()

    if args.verbose and args.quiet:
        parser.error("--verbose dan --quiet tidak dapat digunakan bersamaan.")

    configure_logging(args.verbose, args.quiet)

    if args.test:
        try:
            run_self_test(quiet=args.quiet)
            return 0
        except (AssertionError, UnicodeError, ValueError, zlib.error) as exc:
            LOGGER.error("SELF-TEST gagal: %s", exc)
            return 1

    if not args.html:
        parser.error("--html wajib diberikan, kecuali memakai --test.")

    if args.pad_repeat < 0 or args.pad_lines < 0:
        parser.error("--pad-repeat dan --pad-lines tidak boleh negatif.")

    if args.pad_repeat > MAX_PAD_REPEAT:
        parser.error(
            f"--pad-repeat maksimum {MAX_PAD_REPEAT}."
        )

    if args.pad_lines > MAX_PAD_LINES:
        parser.error(
            f"--pad-lines maksimum {MAX_PAD_LINES}."
        )

    key_seed = resolve_key(args, parser)

    ok = process_files(
        html_file=args.html,
        css_file=args.css,
        js_file=args.js,
        output_file=args.out,
        key_seed=key_seed,
        padding_repeat=args.pad_repeat,
        padding_lines=args.pad_lines,
        verbose=args.verbose,
        quiet=args.quiet,
    )

    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
