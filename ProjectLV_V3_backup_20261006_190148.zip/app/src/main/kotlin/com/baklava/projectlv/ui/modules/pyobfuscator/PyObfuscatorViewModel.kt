package com.baklava.projectlv.ui.modules.pyobfuscator

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.baklava.projectlv.data.remote.PyObfuscateClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.IOException

class PyObfuscatorViewModel(
    private val api: PyObfuscateClient = PyObfuscateClient()
) : ViewModel() {

    sealed interface UiState {

        data object Idle : UiState

        data object Loading : UiState

        data class Success(
            val originalCode: String,
            val code: String,
            val diagnostics: List<PyObfuscateClient.Diagnostic>,
            val metrics: PyObfuscateClient.Metrics?
        ) : UiState

        data class Error(
            val message: String,
            /** Kode asli yang tadi diketik user, supaya tidak hilang saat menampilkan error. */
            val originalCode: String? = null
        ) : UiState
    }

    private val _state =
        MutableStateFlow<UiState>(UiState.Idle)

    val state: StateFlow<UiState> =
        _state.asStateFlow()

    /**
     * Fitur ini KHUSUS untuk kode Python — bahasa pemrograman lain wajib ditolak
     * sebelum request dikirim ke API obfuscator, supaya tidak membuang kuota
     * request untuk source yang jelas bukan Python.
     */
    fun obfuscate(
        sourceCode: String,
        options: PyObfuscateClient.Options =
            PyObfuscateClient.Options()
    ) {

        if (sourceCode.isBlank()) {
            _state.value =
                UiState.Error("Masukkan kode Python terlebih dahulu.")
            return
        }

        val validation = PythonSourceValidator.validate(sourceCode)
        if (validation is PythonSourceValidator.Result.Rejected) {
            _state.value = UiState.Error(
                message = validation.reason,
                originalCode = sourceCode
            )
            return
        }

        viewModelScope.launch {

            _state.value =
                UiState.Loading

            val response = api.obfuscate(
                code = sourceCode,
                mode = "pro",
                options = options
            )

            response
                .onSuccess { result ->

                    _state.value =
                        UiState.Success(
                            originalCode = sourceCode,
                            code = result.result,
                            diagnostics = result.diagnostics,
                            metrics = result.metrics
                        )
                }
                .onFailure { throwable ->

                    _state.value =
                        UiState.Error(
                            message = throwable.toReadableMessage(),
                            originalCode = sourceCode
                        )
                }
        }
    }

    fun reset() {
        _state.value = UiState.Idle
    }
}

private fun Throwable.toReadableMessage(): String {

    return when (this) {

        is PyObfuscateClient.PyObfuscateException.HttpError -> {
            "HTTP $code: ${message ?: "Request gagal"}"
        }

        is PyObfuscateClient.PyObfuscateException.ApiError -> {
            message ?: "API mengembalikan error."
        }

        is PyObfuscateClient.PyObfuscateException.InvalidJson -> {
            message ?: "Response server tidak dapat dibaca."
        }

        is PyObfuscateClient.PyObfuscateException.EmptyResponse -> {
            "Server tidak mengembalikan data."
        }

        is PyObfuscateClient.PyObfuscateException.MissingResult -> {
            "Hasil obfuscation tidak ditemukan."
        }

        is java.net.UnknownHostException -> {
            "Tidak ada koneksi internet atau server tidak dapat diakses."
        }

        is java.net.SocketTimeoutException -> {
            "Request timeout. Silakan coba lagi."
        }

        is IOException -> {
            message ?: "Terjadi kesalahan jaringan."
        }

        else -> {
            message ?: "Terjadi kesalahan yang tidak diketahui."
        }
    }
}

/**
 * Heuristik ringan untuk memastikan source yang dikirim adalah kode Python,
 * dan menolak bahasa pemrograman lain (Kotlin/Java, JavaScript, PHP, C/C++,
 * dsb) sebelum sempat dikirim ke API obfuscator.
 *
 * Ini bukan parser penuh — tujuannya menangkap penanda sintaks yang jelas
 * dari bahasa lain (mis. `public class`, `function foo()`, `<?php`,
 * `#include`) dan memastikan ada penanda umum Python (mis. `def `,
 * `import `, `print(`, indentasi blok, baris berakhiran `:`).
 */
object PythonSourceValidator {

    sealed interface Result {
        data object Accepted : Result
        data class Rejected(val reason: String) : Result
    }

    private val otherLanguageMarkers: List<Pair<Regex, String>> = listOf(
        Regex("""\bpublic\s+(class|static|void)\b""") to "Kotlin/Java",
        Regex("""\bprivate\s+(val|var|fun)\b""") to "Kotlin",
        Regex("""\bfun\s+\w+\s*\(""") to "Kotlin",
        Regex("""^\s*package\s+[\w.]+;?\s*$""", RegexOption.MULTILINE) to "Kotlin/Java",
        Regex("""\bfunction\s+\w*\s*\(""") to "JavaScript",
        Regex("""\bconsole\.log\s*\(""") to "JavaScript",
        Regex("""=>\s*\{""") to "JavaScript/TypeScript",
        Regex("""<\?php""") to "PHP",
        Regex("""\$\w+\s*=""") to "PHP",
        Regex("""#include\s*<""") to "C/C++",
        Regex("""\bstd::\w+""") to "C++",
        Regex("""\bSystem\.out\.println\s*\(""") to "Java",
        Regex("""^\s*<html[\s>]""", RegexOption.IGNORE_CASE) to "HTML",
        Regex("""^\s*using\s+System;""", RegexOption.MULTILINE) to "C#",
        Regex("""\bend\s+(function|if|sub)\b""", RegexOption.IGNORE_CASE) to "VB/Basic"
    )

    private val pythonMarkers: List<Regex> = listOf(
        Regex("""^\s*def\s+\w+\s*\(.*\)\s*:"""),
        Regex("""^\s*class\s+\w+.*:\s*$"""),
        Regex("""^\s*import\s+[\w.]+\s*$"""),
        Regex("""^\s*from\s+[\w.]+\s+import\s+"""),
        Regex("""\bprint\s*\("""),
        Regex("""^\s*if\s+__name__\s*==\s*['"]__main__['"]\s*:"""),
        Regex("""^\s*(if|elif|for|while|with|try|except|finally)\b.*:\s*$""")
    )

    fun validate(source: String): Result {
        val trimmed = source.trim()
        if (trimmed.isEmpty()) {
            return Result.Rejected("Kode Python tidak boleh kosong.")
        }

        for ((pattern, language) in otherLanguageMarkers) {
            if (pattern.containsMatchIn(trimmed)) {
                return Result.Rejected(
                    "Fitur ini khusus untuk kode Python. Terdeteksi sintaks yang menyerupai $language, bukan Python."
                )
            }
        }

        val matchedPythonMarkers = pythonMarkers.count { it.containsMatchIn(trimmed) }
        // Tab/space indentation yang konsisten juga jadi sinyal kuat Python,
        // tapi tidak dijadikan syarat mutlak karena satu-baris script pun valid.
        val hasIndentedBlock = Regex("""\n[ \t]+\S""").containsMatchIn(trimmed)

        if (matchedPythonMarkers == 0 && !hasIndentedBlock) {
            return Result.Rejected(
                "Kode yang dimasukkan tidak terdeteksi sebagai Python. Pastikan menggunakan sintaks Python (def, import, print, indentasi, dll)."
            )
        }

        // Penanda kurung kurawal blok gaya C-family yang kental pada source
        // yang justru mayoritas berisi block "{ ... }" biasanya bukan Python.
        val braceBlockCount = Regex("""\{\s*\n""").findAll(trimmed).count()
        if (braceBlockCount >= 3 && matchedPythonMarkers == 0) {
            return Result.Rejected(
                "Fitur ini khusus untuk kode Python. Struktur blok kurung kurawal '{ }' yang terdeteksi bukan gaya Python."
            )
        }

        return Result.Accepted
    }
}
