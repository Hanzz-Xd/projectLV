package com.baklava.projectlv.data.pterodactyl

import com.baklava.projectlv.data.network.HttpClientProvider
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.UUID

data class PterodactylPanelResult(
    val panelUrl: String,
    val loginUrl: String,
    val email: String,
    val username: String,
    val password: String,
    val serverId: String?,
    val serverUuid: String?,
    val serverIdentifier: String?,
    val serverName: String,
    val ram: Int,
    val disk: Int,
    val cpu: Int,
    val message: String
)

class PterodactylWhatsAppApi {

    companion object {
        private const val BASE_URL = "https://panell-free-by-less.vercel.app"
        private const val CREATE_PATH = "/api/create"
        private const val WHATSAPP_EGG_ID = 15
        private const val DEFAULT_RAM = 100000
        private const val DEFAULT_DISK = 100000
        private const val DEFAULT_CPU = 200
    }

    private val client = HttpClientProvider.okHttpClient

    suspend fun createPanel(
        username: String,
        serverName: String,
        ram: Int,
        disk: Int
    ): Result<PterodactylPanelResult> = withContext(Dispatchers.IO) {
        runCatching {
            val generatedEmail = generateRandomGmail()

            require(ram in 1..DEFAULT_RAM) { "RAM harus antara 1 sampai $DEFAULT_RAM MB." }
            require(disk in 1..DEFAULT_DISK) { "Disk harus antara 1 sampai $DEFAULT_DISK MB." }

            val payload = JSONObject().apply {
                put("username", username)
                put("email", generatedEmail)
                put("serverName", serverName)
                put("ram", ram)
                put("disk", disk)
                put("cpu", DEFAULT_CPU)
                put("eggId", WHATSAPP_EGG_ID)
            }

            val request = Request.Builder()
                .url(BASE_URL + CREATE_PATH)
                .post(
                    payload.toString()
                        .toRequestBody("application/json; charset=utf-8".toMediaType())
                )
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .build()

            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    val message = parseErrorMessage(raw)
                    throw IOException(
                        if (message.isNotBlank()) {
                            "Server mengembalikan HTTP ${response.code}: $message"
                        } else {
                            "Server mengembalikan HTTP ${response.code}."
                        }
                    )
                }

                if (raw.isBlank()) {
                    throw IOException("Respons server kosong.")
                }

                val json = runCatching { JSONObject(raw) }
                    .getOrElse { throw IOException("Respons API bukan JSON yang valid.") }

                if (json.optBoolean("ok", false).not()) {
                    throw IOException(parseErrorMessage(raw).ifBlank {
                        "Panel gagal dibuat oleh server."
                    })
                }

                val data = json.optJSONObject("data")
                    ?: throw IOException("Respons API tidak memiliki data panel.")

                val panelUrl = data.optString("panel")
                val loginUrl = data.optString("loginUrl")
                val resultEmail = data.optString("email")
                val resultUsername = data.optString("username")
                val password = data.optString("password")
                val resultServerName = data.optString("serverName", serverName)

                if (panelUrl.isBlank() || loginUrl.isBlank() ||
                    resultUsername.isBlank() || password.isBlank()
                ) {
                    throw IOException("Data login panel dari API tidak lengkap.")
                }

                PterodactylPanelResult(
                    panelUrl = panelUrl,
                    loginUrl = loginUrl,
                    email = resultEmail.ifBlank { generatedEmail },
                    username = resultUsername,
                    password = password,
                    serverId = data.opt("serverId")?.toString()?.takeIf { it.isNotBlank() },
                    serverUuid = data.optString("serverUuid").takeIf { it.isNotBlank() },
                    serverIdentifier = data.optString("serverIdentifier").takeIf { it.isNotBlank() },
                    serverName = resultServerName,
                    ram = data.optInt("ram", DEFAULT_RAM),
                    disk = data.optInt("disk", DEFAULT_DISK),
                    cpu = data.optInt("cpu", DEFAULT_CPU),
                    message = json.optString("message", "Panel berhasil dibuat.")
                )
            }
        }
    }

    private fun generateRandomGmail(): String {
        val suffix = UUID.randomUUID().toString().replace("-", "").take(16)
        return "projectlv$suffix@gmail.com"
    }

    private fun parseErrorMessage(raw: String): String {
        if (raw.isBlank()) return ""
        return runCatching {
            val json = JSONObject(raw)
            listOfNotNull(
                json.optString("message").takeIf { it.isNotBlank() },
                json.optString("error").takeIf { it.isNotBlank() },
                json.optJSONObject("data")?.optString("message")?.takeIf { it.isNotBlank() }
            ).firstOrNull().orEmpty()
        }.getOrElse {
            raw.replace(Regex("\\s+"), " ").trim().take(240)
        }
    }
}
