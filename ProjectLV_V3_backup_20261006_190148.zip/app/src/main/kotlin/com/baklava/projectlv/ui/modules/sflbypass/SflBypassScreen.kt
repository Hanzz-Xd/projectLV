package com.baklava.projectlv.ui.modules.sflbypass

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.rememberInfiniteTransition
import com.baklava.projectlv.data.remote.SflBypassClient
import com.baklava.projectlv.data.remote.SflBypassResult
import com.baklava.projectlv.ui.components.AppWindowSize
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun SflLoadingIndicator(
    modifier: Modifier = Modifier,
    size: androidx.compose.ui.unit.Dp = 22.dp,
    strokeWidth: androidx.compose.ui.unit.Dp = 2.4.dp
) {
    val transition = rememberInfiniteTransition(label = "sfl_loading")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(1200, easing = LinearEasing)
        ),
        label = "rotation"
    )
    val sweep by transition.animateFloat(
        initialValue = 46f,
        targetValue = 300f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 1500
                46f at 0 with FastOutSlowInEasing
                300f at 750 with FastOutSlowInEasing
                46f at 1500 with FastOutSlowInEasing
            },
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep"
    )

    val trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.22f)
    val progressColor = MaterialTheme.colorScheme.primary

    Canvas(modifier = modifier.width(size).height(size)) {
        val stroke = Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round)
        val inset = stroke.width / 2f
        val diameter = size.toPx() - stroke.width

        drawArc(
            color = trackColor,
            startAngle = 0f,
            sweepAngle = 360f,
            useCenter = false,
            topLeft = androidx.compose.ui.geometry.Offset(inset, inset),
            size = androidx.compose.ui.geometry.Size(diameter, diameter),
            style = stroke
        )

        drawArc(
            color = progressColor,
            startAngle = rotation - 90f,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = androidx.compose.ui.geometry.Offset(inset, inset),
            size = androidx.compose.ui.geometry.Size(diameter, diameter),
            style = stroke
        )
    }
}

@Composable
fun SflBypassScreen(
    windowSize: AppWindowSize,
    onShowSnackbar: (String) -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val client = remember { SflBypassClient() }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<SflBypassResult?>(null) }

    fun openUrl(url: String) {
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }.onFailure {
            onShowSnackbar("Tidak ada aplikasi yang dapat membuka link tersebut.")
        }
    }

    fun copyUrl(url: String) {
        clipboard.setText(AnnotatedString(url))
        onShowSnackbar("Link tujuan disalin.")
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack),
        contentPadding = PaddingValues(
            horizontal = if (windowSize.isCompact) 12.dp else 24.dp,
            vertical = 16.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Kembali",
                        tint = Color.White
                    )
                }
                Column(modifier = Modifier.padding(start = 4.dp)) {
                    Text(
                        "SFL LINK BYPASS",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Text(
                        "Ubah link sfl.gl menjadi link tujuan",
                        color = MutedGrey,
                        fontSize = 12.sp
                    )
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                border = BorderStroke(1.dp, CyberCardBorder),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        label = { Text("Link SFL") },
                        placeholder = { Text("https://sfl.gl/gOfplaB") }
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val target = input.trim()
                            if (!target.startsWith("https://sfl.gl/", ignoreCase = true)) {
                                onShowSnackbar("Masukkan link https://sfl.gl/ yang valid.")
                                return@Button
                            }
                            loading = true
                            error = null
                            result = null
                            scope.launch {
                                runCatching {
                                    withContext(Dispatchers.IO) { client.bypass(target) }
                                }.onSuccess {
                                    result = it
                                }.onFailure {
                                    error = it.message ?: "Bypass gagal diproses."
                                }
                                loading = false
                            }
                        },
                        enabled = !loading,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (loading) {
                            SflLoadingIndicator(size = 20.dp, strokeWidth = 2.2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("MEMPROSES...")
                        } else {
                            Icon(Icons.Default.Search, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("BYPASS LINK")
                        }
                    }
                }
            }
        }

        error?.let { message ->
            item {
                Text(
                    message,
                    color = Color(0xFFFF6B6B),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        }

        result?.let { data ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                    border = BorderStroke(1.dp, CyberCardBorder),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(
                            "LINK BERHASIL DIBYPASS",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(10.dp))
                        Text("Link tujuan", color = MutedGrey, fontSize = 12.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(data.url, color = Color.White, fontSize = 12.sp)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { copyUrl(data.url) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("SALIN")
                            }
                            Button(
                                onClick = { openUrl(data.url) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.OpenInNew, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("BUKA")
                            }
                        }
                        if (data.needsManual) {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Link ini membutuhkan langkah manual pada layanan bypass.",
                                color = Color(0xFFFFC857),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
