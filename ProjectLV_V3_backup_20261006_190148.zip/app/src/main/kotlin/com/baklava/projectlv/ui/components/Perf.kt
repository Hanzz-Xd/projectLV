package com.baklava.projectlv.ui.components

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf

/**
 * Deteksi perangkat lawas / spesifikasi rendah. Hasilnya dipakai untuk memilih
 * "mode animasi hemat" secara otomatis supaya perpindahan layar tidak patah-patah.
 */
object DevicePerf {

    @Volatile
    private var cachedLowEnd: Boolean? = null

    fun isLowEnd(context: Context): Boolean {
        cachedLowEnd?.let { return it }
        val app = context.applicationContext
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val lowRam = am?.isLowRamDevice == true
        val memoryClassMb = am?.memoryClass ?: 256
        val cores = Runtime.getRuntime().availableProcessors()
        // Android 8.1 (API 27) ke bawah dianggap perangkat lawas.
        val oldAndroid = Build.VERSION.SDK_INT <= Build.VERSION_CODES.O_MR1

        val result = oldAndroid || lowRam || memoryClassMb <= 192 || cores <= 4
        cachedLowEnd = result
        return result
    }

    /** Pengguna mematikan animasi dari Opsi Pengembang / aksesibilitas. */
    fun isSystemAnimationOff(context: Context): Boolean = try {
        Settings.Global.getFloat(
            context.contentResolver,
            Settings.Global.ANIMATOR_DURATION_SCALE,
            1f
        ) == 0f
    } catch (_: Throwable) {
        false
    }
}

/**
 * Pilihan mode animasi yang disimpan di perangkat.
 *  - AUTO : otomatis (hemat di perangkat lawas, penuh di perangkat kencang)
 *  - LITE : hemat  — tanpa animasi masuk/scale, transisi layar cukup fade singkat
 *  - FULL : penuh  — semua animasi halus aktif
 */
object MotionPrefs {
    const val AUTO = 0
    const val LITE = 1
    const val FULL = 2

    private const val PREFS = "ui_prefs"
    private const val KEY_MODE = "motion_mode"

    var mode by mutableIntStateOf(AUTO)
        private set

    fun init(context: Context) {
        mode = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_MODE, AUTO)
            .coerceIn(AUTO, FULL)
    }

    fun setMode(context: Context, value: Int) {
        val safe = value.coerceIn(AUTO, FULL)
        mode = safe
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_MODE, safe)
            .apply()
    }

    /** true bila animasi harus dihemat. Membaca state Compose, jadi UI ikut update saat mode diganti. */
    fun isLite(context: Context): Boolean = when (mode) {
        LITE -> true
        FULL -> false
        else -> DevicePerf.isLowEnd(context) || DevicePerf.isSystemAnimationOff(context)
    }
}

/** true = mode animasi hemat. Diisi di MainActivity, dibaca oleh semua komponen animasi. */
val LocalLiteMotion = staticCompositionLocalOf { false }
