package com.baklava.projectlv.ui.streaming

import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import com.baklava.projectlv.ui.components.clickable
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AssistChip
import com.baklava.projectlv.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import com.baklava.projectlv.ui.components.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import com.baklava.projectlv.ui.components.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import com.baklava.projectlv.ui.components.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import com.baklava.projectlv.ui.components.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.baklava.projectlv.data.streaming.AnimeDetail
import com.baklava.projectlv.data.streaming.AnimeListItem
import com.baklava.projectlv.data.streaming.ContentType
import com.baklava.projectlv.data.streaming.Episode
import com.baklava.projectlv.data.streaming.MyListEntry
import com.baklava.projectlv.data.streaming.StreamCandidate
import com.baklava.projectlv.data.streaming.StreamingLocalStore
import com.baklava.projectlv.data.streaming.StreamingViewModel
import com.baklava.projectlv.data.streaming.StreamingViewModelFactory
import com.baklava.projectlv.data.streaming.WatchRecord
import com.baklava.projectlv.ui.theme.BrightAmber
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurface
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.map
import androidx.compose.runtime.snapshotFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private sealed interface StreamRoute {
    data object Home : StreamRoute
    data object Catalog : StreamRoute
    data object MyList : StreamRoute
    data object History : StreamRoute
    data object Search : StreamRoute
    data class Detail(val slug: String) : StreamRoute
    data class Player(val slug: String, val episodeIndex: Int) : StreamRoute
}

private fun encodeStreamRoute(route: StreamRoute): List<Any?> = when (route) {
    StreamRoute.Home -> listOf("home")
    StreamRoute.Catalog -> listOf("catalog")
    StreamRoute.MyList -> listOf("my_list")
    StreamRoute.History -> listOf("history")
    StreamRoute.Search -> listOf("search")
    is StreamRoute.Detail -> listOf("detail", route.slug)
    // Link stream hidup di ViewModel, jadi setelah process recreation kita
    // kembali ke detail; halaman sebelum detail tetap ada di back stack.
    is StreamRoute.Player -> listOf("detail", route.slug)
}

private fun decodeStreamRoute(saved: List<Any?>): StreamRoute? = when (saved.firstOrNull() as? String) {
    "home" -> StreamRoute.Home
    "catalog" -> StreamRoute.Catalog
    "my_list" -> StreamRoute.MyList
    "history" -> StreamRoute.History
    "search" -> StreamRoute.Search
    "detail" -> (saved.getOrNull(1) as? String)?.let(StreamRoute::Detail)
    "player" -> {
        val slug = saved.getOrNull(1) as? String
        val index = (saved.getOrNull(2) as? Number)?.toInt()
        if (slug != null && index != null) StreamRoute.Player(slug, index) else null
    }
    else -> null
}

private val streamRouteSaver = Saver<StreamRoute, List<Any?>>(
    save = { route -> encodeStreamRoute(route) },
    restore = { decodeStreamRoute(it) ?: StreamRoute.Home }
)

private val streamRouteStackSaver = Saver<List<StreamRoute>, List<List<Any?>>>(
    save = { stack -> stack.map { route -> encodeStreamRoute(route) } },
    restore = { saved -> saved.mapNotNull { route -> decodeStreamRoute(route) } }
)

private enum class StreamTab { HOME, EXPLORE, MY_LIST, HISTORY, SEARCH }

// Lompatan durasi untuk tombol -/+ dan double tap kiri/kanan di player.
private const val SEEK_STEP_SEC = 10
private const val SEEK_STEP_MS = SEEK_STEP_SEC * 1000L
// Selama jeda ini tap tunggal berikutnya dianggap lanjutan seek (seperti YouTube).
private const val SEEK_CHAIN_WINDOW_MS = 700L

private val COMMON_GENRES = listOf(
    "Action", "Adventure", "Comedy", "Drama", "Fantasy", "Horror", "Mystery",
    "Romance", "School", "Sci-Fi", "Slice Of Life", "Sports", "Supernatural",
    "Isekai", "Shounen", "Seinen", "Shoujo", "Historical", "Magic", "Music",
    "Mecha", "Psychological", "Thriller", "Military", "Harem"
)

@Composable
fun StreamingScreen(
    localStore: StreamingLocalStore,
    windowCompact: Boolean,
    onShowSnackbar: (String) -> Unit = {},
    onOpenTools: () -> Unit = {},
    onImmersiveChange: (Boolean) -> Unit = {}
) {
    val vm: StreamingViewModel = viewModel(factory = StreamingViewModelFactory(localStore))
    val route = rememberSaveable(stateSaver = streamRouteSaver) { mutableStateOf<StreamRoute>(StreamRoute.Home) }
    val backStack = rememberSaveable(stateSaver = streamRouteStackSaver) {
        mutableStateOf<List<StreamRoute>>(emptyList())
    }
    val homeTab = rememberSaveable { mutableStateOf(StreamTab.HOME) }
    val selectedGenre = rememberSaveable { mutableStateOf("Semua") }
    // Query tetap hidup saat membuka Detail sehingga kembali selalu ke aksi pencarian sebelumnya.
    val searchText = rememberSaveable { mutableStateOf("") }

    fun pushRoute(target: StreamRoute) {
        if (target == route.value) return
        backStack.value = (backStack.value + route.value).takeLast(16)
        route.value = target
    }

    fun replaceRoute(target: StreamRoute) {
        route.value = target
    }

    fun popRoute() {
        val previous = backStack.value.lastOrNull()
        if (previous == null) {
            route.value = StreamRoute.Home
            homeTab.value = StreamTab.HOME
            return
        }
        backStack.value = backStack.value.dropLast(1)
        route.value = previous
    }

    fun navigateRoot(target: StreamRoute, tab: StreamTab) {
        backStack.value = emptyList()
        route.value = target
        homeTab.value = tab
    }

    val ongoing by vm.ongoing.collectAsState()
    val latest by vm.latest.collectAsState()
    val allAnime by vm.allAnime.collectAsState()
    val allLoading by vm.allLoading.collectAsState()
    val allHasMore by vm.allHasMore.collectAsState()
    val allError by vm.allError.collectAsState()
    val loading by vm.loading.collectAsState()
    val error by vm.error.collectAsState()
    val selectedAnime by vm.selectedAnime.collectAsState()
    val streams by vm.streams.collectAsState()
    val searchResults by vm.searchResults.collectAsState()
    val searchLoading by vm.searchLoading.collectAsState()
    val searchErrorState by vm.searchError.collectAsState()
    val contentType by vm.contentType.collectAsState()
    val movies by vm.movies.collectAsState()
    val movieLoading by vm.movieLoading.collectAsState()
    val movieError by vm.movieError.collectAsState()
    val donghua by vm.donghua.collectAsState()
    val donghuaLoading by vm.donghuaLoading.collectAsState()
    val donghuaHasMore by vm.donghuaHasMore.collectAsState()
    val donghuaError by vm.donghuaError.collectAsState()
    val history by localStore.history.collectAsState()
    val myList by localStore.myList.collectAsState()

    // Orientasi landscape + fullscreen dikendalikan oleh ROUTE, bukan oleh siklus hidup ExoPlayer.
    //
    // Efek ini hanya restart ketika masuk/keluar route Player (key = isPlayerRoute), jadi tidak ada
    // onDispose "nyasar" saat recomposition biasa. Rotasi layar TIDAK lagi membuang StreamingScreen
    // karena LeviathanScaffold sekarang memanggil content() di satu posisi tetap.
    val activity = LocalContext.current as? Activity
    val isPlayerRoute = route.value is StreamRoute.Player

    DisposableEffect(activity, isPlayerRoute) {
        val hostActivity = activity
        if (isPlayerRoute && hostActivity != null) {
            hostActivity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            WindowCompat.getInsetsController(hostActivity.window, hostActivity.window.decorView).apply {
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                hide(WindowInsetsCompat.Type.systemBars())
            }
            onImmersiveChange(true)
        }
        onDispose {
            if (isPlayerRoute && hostActivity != null) {
                hostActivity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.getInsetsController(hostActivity.window, hostActivity.window.decorView)
                    .show(WindowInsetsCompat.Type.systemBars())
                onImmersiveChange(false)
            }
        }
    }

    val openDetail: (String) -> Unit = { id ->
        // MyList/History hanya menyimpan id + judul. Pakai slug asli yang tersimpan
        // (kalau ada) dan kirim judul sebagai cadangan bila slug sudah tidak valid.
        val entry = myList.firstOrNull { it.seriesId == id }
        val record = history.firstOrNull { it.seriesId == id }
        val slug = entry?.slug?.takeIf { it.isNotBlank() } ?: id
        val titleHint = entry?.title?.takeIf { it.isNotBlank() }
            ?: record?.seriesTitle?.takeIf { it.isNotBlank() }
        vm.clearStreams()
        vm.openAnime(slug, titleHint)
        pushRoute(StreamRoute.Detail(slug))
    }

    val openEpisode: (AnimeDetail, Int) -> Unit = { anime, index ->
        anime.chapter.sortedByEpisodeNumber().getOrNull(index)?.let { episode ->
            vm.openEpisode(anime, episode) {
                val target = StreamRoute.Player(anime.series_id, index)
                // Next/Previous hanya mengganti player, tidak menambah stack Detail baru.
                if (route.value is StreamRoute.Player) replaceRoute(target) else pushRoute(target)
            }
        }
    }

    LaunchedEffect(route.value) {
        if (route.value == StreamRoute.Catalog) vm.loadNextAllPage()
    }

    BackHandler(enabled = route.value !is StreamRoute.Home) {
        when (route.value) {
            is StreamRoute.Player,
            is StreamRoute.Detail -> vm.clearStreams()
            StreamRoute.Search,
            StreamRoute.Catalog,
            StreamRoute.MyList,
            StreamRoute.History,
            StreamRoute.Home -> Unit
        }
        // Jangan reset ke Home. Kembali ke halaman streaming sebelumnya.
        // Search query/results juga sengaja tidak dibersihkan.
        popRoute()
    }

    val showStreamBottomBar = windowCompact && route.value !is StreamRoute.Detail && route.value !is StreamRoute.Player
    val streamTab = when (route.value) {
        StreamRoute.Home -> StreamTab.HOME
        StreamRoute.Catalog -> StreamTab.EXPLORE
        StreamRoute.MyList -> StreamTab.MY_LIST
        StreamRoute.History -> StreamTab.HISTORY
        StreamRoute.Search -> StreamTab.SEARCH
        is StreamRoute.Detail, is StreamRoute.Player -> homeTab.value
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = CyberBlack,
        // StreamingScreen lives inside MainActivity's status-bar guard. Only reserve
        // navigation-bar space here so status-bar padding is never applied twice.
        contentWindowInsets = WindowInsets.navigationBars,
        bottomBar = {
            if (showStreamBottomBar) {
                StreamingBottomBar(
                    selectedTab = streamTab,
                    onHome = { navigateRoot(StreamRoute.Home, StreamTab.HOME) },
                    onAnime = { vm.selectContentType(ContentType.ANIME); navigateRoot(StreamRoute.Catalog, StreamTab.EXPLORE) },
                    onMyList = { navigateRoot(StreamRoute.MyList, StreamTab.MY_LIST) },
                    onHistory = { navigateRoot(StreamRoute.History, StreamTab.HISTORY) },
                    onSearch = { navigateRoot(StreamRoute.Search, StreamTab.SEARCH) },
                    onTools = onOpenTools
                )
            }
        }
    ) { innerPadding ->
        Box(Modifier.fillMaxSize().padding(innerPadding)) {
        when (val current = route.value) {
            StreamRoute.Home -> {
                val homeGenres = remember(allAnime) { genreOptions(allAnime) }
                StreamingHome(
                    compact = windowCompact,
                    ongoing = ongoing,
                    latest = latest,
                    allAnime = allAnime,
                    history = history,
                    myList = myList,
                    selectedGenre = selectedGenre.value,
                    genres = homeGenres,
                    loading = loading,
                    error = error,
                    onGenre = { selectedGenre.value = it },
                    onOpen = openDetail,
                    onOpenCatalog = { pushRoute(StreamRoute.Catalog); homeTab.value = StreamTab.EXPLORE },
                    onHistory = { pushRoute(StreamRoute.History); homeTab.value = StreamTab.HISTORY },
                    onMyList = { pushRoute(StreamRoute.MyList); homeTab.value = StreamTab.MY_LIST },
                    onSearch = { pushRoute(StreamRoute.Search); homeTab.value = StreamTab.SEARCH },
                    onRefresh = { vm.refreshHome(); vm.resetAllCatalog() },
                )
            }

            StreamRoute.Catalog -> {
                // Sumber list, loading/hasMore/error, dan availability genre
                // berganti sesuai tab (Anime/Donghua/Movie) yang dipilih.
                // Movie tidak punya data genre dari movie.php, jadi chip
                // genre disembunyikan untuk tab itu (lihat CatalogScreen).
                val catalogSourceItems = when (contentType) {
                    ContentType.ANIME -> allAnime
                    ContentType.DONGHUA -> donghua
                    ContentType.MOVIE -> movies
                }
                val catalogGenres = remember(catalogSourceItems, contentType) {
                    if (contentType == ContentType.MOVIE) emptyList() else genreOptions(catalogSourceItems)
                }
                val catalogItems = remember(catalogSourceItems, selectedGenre.value, contentType) {
                    if (contentType == ContentType.MOVIE) catalogSourceItems
                    else filterByGenre(catalogSourceItems, selectedGenre.value)
                }
                CatalogScreen(
                    items = catalogItems,
                    totalLoaded = catalogSourceItems.size,
                    genres = catalogGenres,
                    selectedGenre = selectedGenre.value,
                    contentType = contentType,
                    loading = when (contentType) {
                        ContentType.ANIME -> allLoading
                        ContentType.DONGHUA -> donghuaLoading
                        ContentType.MOVIE -> movieLoading
                    },
                    hasMore = when (contentType) {
                        ContentType.ANIME -> allHasMore
                        ContentType.DONGHUA -> donghuaHasMore
                        ContentType.MOVIE -> false
                    },
                    error = when (contentType) {
                        ContentType.ANIME -> allError
                        ContentType.DONGHUA -> donghuaError
                        ContentType.MOVIE -> movieError
                    },
                    onGenre = { selectedGenre.value = it },
                    onContentType = vm::selectContentType,
                    onOpen = openDetail,
                    onBack = { popRoute() },
                    onLoadMore = {
                        when (contentType) {
                            ContentType.ANIME -> vm.loadNextAllPage()
                            ContentType.DONGHUA -> vm.loadAllDonghua()
                            ContentType.MOVIE -> Unit
                        }
                    },
                    onRetry = {
                        when (contentType) {
                            ContentType.ANIME -> vm.loadNextAllPage()
                            ContentType.DONGHUA -> vm.loadAllDonghua()
                            ContentType.MOVIE -> vm.loadMovies()
                        }
                    }
                )
            }

            StreamRoute.MyList -> MyListScreen(
                myList = myList,
                history = history,
                onBack = { popRoute() },
                onOpen = openDetail,
                onRemove = { localStore.removeFromMyList(it) },
                onStatus = { id, status -> localStore.setMyListStatus(id, status) }
            )

            StreamRoute.History -> HistoryScreen(
                history = history,
                onBack = { popRoute() },
                onOpen = { record -> openDetail(record.seriesId) },
                onDelete = localStore::removeHistory,
                onClear = localStore::clearHistory
            )

            StreamRoute.Search -> SearchScreen(
                query = searchText.value,
                onQueryChange = {
                    searchText.value = it
                    vm.search(it)
                },
                results = searchResults,
                loading = searchLoading,
                error = searchErrorState,
                onBack = { popRoute() },
                onOpen = openDetail
            )

            is StreamRoute.Detail -> {
                val anime = selectedAnime
                LaunchedEffect(current.slug) {
                    if (selectedAnime == null && !loading && error == null) vm.openAnime(current.slug)
                }
                when {
                    anime == null && loading -> CenterLoading(onBack = { popRoute() })
                    anime == null -> ErrorState(
                        message = error ?: "Anime tidak ditemukan",
                        onRetry = { vm.openAnime(current.slug) },
                        onBack = { popRoute() }
                    )
                    else -> AnimeDetailScreen(
                        anime = anime,
                        history = history,
                        myList = myList,
                        loading = loading,
                        error = error,
                        onBack = { popRoute() },
                        onPlay = { index -> openEpisode(anime, index) },
                        onToggleMyList = {
                            val exists = myList.any { it.seriesId == anime.series_id }
                            if (exists) {
                                localStore.removeFromMyList(anime.series_id)
                                onShowSnackbar("Dihapus dari MyList")
                            } else {
                                localStore.addToMyList(
                                    MyListEntry(
                                        seriesId = anime.series_id,
                                        title = anime.judul,
                                        cover = anime.cover,
                                        addedAt = System.currentTimeMillis(),
                                        status = "PLANNED",
                                        totalEpisodes = anime.chapter.size.takeIf { it > 0 },
                                        slug = current.slug
                                    )
                                )
                                onShowSnackbar("Ditambahkan ke MyList")
                            }
                        }
                    )
                }
            }

            is StreamRoute.Player -> {
                val anime = selectedAnime
                val playbackEpisodes = remember(anime?.chapter) { anime?.chapter?.sortedByEpisodeNumber().orEmpty() }
                val episode = playbackEpisodes.getOrNull(current.episodeIndex)
                if (anime == null || episode == null || streams == null) {
                    CenterLoading(onBack = {
                        vm.clearStreams()
                        popRoute()
                    })
                } else {
                    PlayerScreen(
                        anime = anime,
                        episode = episode,
                        episodeIndex = current.episodeIndex,
                        streams = streams!!,
                        localStore = localStore,
                        onBack = {
                            vm.clearStreams()
                            popRoute()
                        },
                        onNext = {
                            if (current.episodeIndex + 1 < playbackEpisodes.size) {
                                openEpisode(anime, current.episodeIndex + 1)
                            } else {
                                onShowSnackbar("Ini adalah episode terakhir")
                            }
                        },
                        onPrevious = {
                            if (current.episodeIndex > 0) openEpisode(anime, current.episodeIndex - 1)
                        },
                        onOpenEpisode = { index -> openEpisode(anime, index) }
                    )
                }
            }
        }
        }
    }
}


@Composable
private fun StreamingBottomBar(
    selectedTab: StreamTab,
    onHome: () -> Unit,
    onAnime: () -> Unit,
    onMyList: () -> Unit,
    onHistory: () -> Unit,
    onSearch: () -> Unit,
    onTools: () -> Unit
) {
    val items = listOf(
        StreamNavItem(StreamTab.HOME, "Beranda", Icons.Default.Home, onHome),
        StreamNavItem(StreamTab.EXPLORE, "Anime", Icons.Default.GridView, onAnime),
        StreamNavItem(StreamTab.MY_LIST, "MyList", Icons.Default.BookmarkBorder, onMyList),
        StreamNavItem(StreamTab.HISTORY, "Riwayat", Icons.Default.History, onHistory),
        StreamNavItem(StreamTab.SEARCH, "Cari", Icons.Default.Search, onSearch),
        StreamNavItem(null, "Tools", Icons.Default.Settings, onTools)
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp)
            .navigationBarsPadding()
            .padding(bottom = 5.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(CyberDarkNavy)
            .border(1.dp, CyberCardBorder, RoundedCornerShape(28.dp))
            .padding(horizontal = 8.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { item ->
            val selected = item.tab != null && item.tab == selectedTab
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(22.dp))
                    .clickable(onClick = item.onClick)
                    .background(if (selected) CyberSurfaceVariant else Color.Transparent)
                    .padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = item.label,
                    modifier = Modifier.size(22.dp),
                    tint = if (selected) Color.White else MutedGrey
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    text = item.label,
                    fontSize = 9.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    color = if (selected) Color.White else MutedGrey,
                    maxLines = 1
                )
            }
        }
    }
}

private data class StreamNavItem(
    val tab: StreamTab?,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val onClick: () -> Unit
)

@Composable
private fun StreamingHome(
    compact: Boolean,
    ongoing: List<AnimeListItem>,
    latest: List<AnimeListItem>,
    allAnime: List<AnimeListItem>,
    history: List<WatchRecord>,
    myList: List<MyListEntry>,
    selectedGenre: String,
    genres: List<String>,
    loading: Boolean,
    error: String?,
    onGenre: (String) -> Unit,
    onOpen: (String) -> Unit,
    onOpenCatalog: () -> Unit,
    onHistory: () -> Unit,
    onMyList: () -> Unit,
    onSearch: () -> Unit,
    onRefresh: () -> Unit,
) {
    val hero = ongoing.firstOrNull() ?: latest.firstOrNull()
    val continueRecords = history.filterNot { it.completed }.take(6)
    val filteredOngoing = remember(ongoing, selectedGenre) { filterByGenre(ongoing, selectedGenre) }
    val filteredLatest = remember(latest, selectedGenre) { filterByGenre(latest, selectedGenre) }
    // allAnime bisa berisi ribuan item sekarang (auto-load-all) — wajib
    // di-remember, jangan di-filter ulang di setiap recomposition.
    val popularFallback = remember(allAnime, selectedGenre) { filterByGenre(allAnime, selectedGenre) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            StreamTopBar(onSearch = onSearch, onRefresh = onRefresh)
        }

        hero?.let {
            item {
                HeroBanner(item = it, onOpen = { onOpen(it.url) })
            }
        }

        if (continueRecords.isNotEmpty()) {
            item {
                SectionHeader("LANJUTKAN MENONTON", "${continueRecords.size} episode", onHistory)
                ContinueRow(records = continueRecords, onOpen = { onOpen(it.seriesId) })
            }
        }

        item {
            SectionHeader("GENRE", trailing = if (selectedGenre == "Semua") "Pilih" else selectedGenre)
            GenreRow(genres = genres, selected = selectedGenre, onSelected = onGenre)
        }

        item {
            SectionHeader("MY LIST", "${myList.size} anime", onMyList)
            if (myList.isEmpty()) {
                EmptyInline("Tambahkan anime ke MyList supaya mudah dilanjutkan nanti.", Icons.Default.BookmarkBorder)
            } else {
                MyListRow(myList = myList.take(6), history = history, onOpen = { onOpen(it.seriesId) })
            }
        }

        item {
            SectionHeader("ONGOING", "Update terbaru")
            if (filteredOngoing.isEmpty()) {
                EmptyInline("Tidak ada anime untuk genre ini.", Icons.Default.Tune)
            } else {
                PosterRow(items = filteredOngoing.take(12), onOpen = onOpen)
            }
        }

        item {
            SectionHeader("TERBARU", "Baru di-upload")
            if (filteredLatest.isEmpty()) {
                EmptyInline("Belum ada item pada genre ini.", Icons.Default.VideoLibrary)
            } else {
                PosterRow(items = filteredLatest.take(12), onOpen = onOpen)
            }
        }

        item {
            SectionHeader("SEMUA ANIME", "", onOpenCatalog)
            if (popularFallback.isEmpty()) {
                EmptyInline("Buka katalog untuk memuat halaman berikutnya.", Icons.Default.GridView)
            } else {
                PosterRow(items = popularFallback.take(12), onOpen = onOpen)
            }
        }

        if (error != null && ongoing.isEmpty() && latest.isEmpty()) {
            item { ErrorCard(error, onRefresh) }
        } else if (loading && hero == null) {
            item { LoadingInline("Menyiapkan beranda...") }
        }
    }
}

@Composable
private fun StreamTopBar(onSearch: () -> Unit, onRefresh: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(Brush.linearGradient(listOf(CyberSurfaceVariant, CyberDarkNavy)))
                .border(1.dp, CyberCardBorder, RoundedCornerShape(11.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(17.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("PROJECT LV", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp, letterSpacing = 0.6.sp)
            Text("ANIME STREAMING", color = BrightCyan, fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 1.6.sp)
        }
        TopBarIconButton(icon = Icons.Default.Search, contentDescription = "Cari", onClick = onSearch, emphasized = true)
        Spacer(Modifier.width(7.dp))
        TopBarIconButton(icon = Icons.Default.Refresh, contentDescription = "Refresh", onClick = onRefresh)
    }
}

@Composable
private fun TopBarIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    emphasized: Boolean = false
) {
    Box(
        Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(if (emphasized) Color.White.copy(alpha = 0.08f) else Color.Transparent)
            .border(1.dp, CyberCardBorder, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription, tint = if (emphasized) Color.White else MutedGrey, modifier = Modifier.size(15.dp))
    }
}

@Composable
private fun HeroBanner(item: AnimeListItem, onOpen: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(265.dp)
            .padding(horizontal = 12.dp)
            .clip(RoundedCornerShape(22.dp))
            .clickable(onClick = onOpen)
    ) {
        AsyncImage(
            model = item.cover,
            contentDescription = item.judul,
            modifier = Modifier.fillMaxSize().background(CyberSurfaceVariant),
            contentScale = ContentScale.Crop
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color.Transparent, CyberBlack.copy(alpha = 0.18f), CyberBlack.copy(alpha = 0.95f))
                )
            )
        )
        Column(
            Modifier.align(Alignment.BottomStart).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                MetaPill(item.status ?: "Ongoing", BrightGreen)
                item.score?.takeIf { it.isNotBlank() }?.let { MetaPill("★ $it", BrightAmber) }
            }
            Text(item.judul, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                item.sinopsis.orEmpty().ifBlank { "Tonton sekarang di Project LV Streaming." },
                color = Color.White.copy(alpha = 0.84f),
                fontSize = 10.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Button(
                onClick = onOpen,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = CyberBlack),
                shape = RoundedCornerShape(9.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 7.dp)
            ) {
                Icon(Icons.Default.PlayArrow, null, Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("TONTON", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String, trailing: String? = null, onClick: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(5.dp).clip(CircleShape).background(BrightCyan))
        Spacer(Modifier.width(8.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp, letterSpacing = 0.8.sp)
        Spacer(Modifier.weight(1f))
        if (onClick != null) {
            TextButton(onClick = onClick, contentPadding = PaddingValues(0.dp)) {
                Text(trailing ?: "Lihat semua", color = BrightCyan, fontSize = 9.sp)
            }
        } else if (trailing != null) {
            Text(trailing, color = MutedGrey, fontSize = 10.sp)
        }
    }
}

@Composable
private fun GenreRow(genres: List<String>, selected: String, onSelected: (String) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        items(genres, key = { it }) { genre ->
            FilterChip(
                selected = selected.equals(genre, ignoreCase = true),
                onClick = { onSelected(genre) },
                label = { Text(genre, fontSize = 10.sp) }
            )
        }
    }
}

@Composable
private fun ContinueRow(records: List<WatchRecord>, onOpen: (WatchRecord) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(records, key = { it.key }) { record -> ContinueCard(record, onOpen = { onOpen(record) }) }
    }
}

@Composable
private fun ContinueCard(record: WatchRecord, onOpen: () -> Unit) {
    Card(
        Modifier.width(270.dp).clickable(onClick = onOpen),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
        border = BorderStroke(1.dp, CyberCardBorder)
    ) {
        Row(Modifier.padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = record.cover,
                contentDescription = record.seriesTitle,
                modifier = Modifier.size(70.dp, 94.dp).clip(RoundedCornerShape(10.dp)).background(CyberSurfaceVariant),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(record.seriesTitle, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text(record.episodeLabel, color = BrightCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(9.dp))
                LinearProgressIndicator(
                    progress = { record.progress },
                    Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(8.dp)),
                    color = BrightCyan,
                    trackColor = CyberSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                Text("${formatTime(record.positionMs)} / ${formatTime(record.durationMs)}", color = MutedGrey, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun MyListRow(myList: List<MyListEntry>, history: List<WatchRecord>, onOpen: (MyListEntry) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(myList, key = { it.seriesId }) { entry ->
            val progress = history.firstOrNull { it.seriesId == entry.seriesId }
            MyListCompactCard(entry = entry, progress = progress, onOpen = { onOpen(entry) })
        }
    }
}

@Composable
private fun MyListCompactCard(entry: MyListEntry, progress: WatchRecord?, onOpen: () -> Unit) {
    Card(
        Modifier.width(126.dp).clickable(onClick = onOpen),
        shape = RoundedCornerShape(13.dp),
        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
        border = BorderStroke(1.dp, CyberCardBorder)
    ) {
        Box {
            AsyncImage(
                model = entry.cover,
                contentDescription = entry.title,
                modifier = Modifier.fillMaxWidth().height(176.dp).clip(RoundedCornerShape(topStart = 13.dp, topEnd = 13.dp)).background(CyberSurfaceVariant),
                contentScale = ContentScale.Crop
            )
            Surface(
                Modifier.align(Alignment.TopEnd).padding(6.dp),
                color = CyberBlack.copy(alpha = 0.78f),
                shape = CircleShape
            ) {
                Icon(
                    when (entry.status) {
                        "COMPLETED" -> Icons.Default.CheckCircle
                        "WATCHING" -> Icons.Default.PlayArrow
                        else -> Icons.Default.Bookmark
                    },
                    null,
                    tint = Color.White,
                    modifier = Modifier.padding(4.dp).size(15.dp)
                )
            }
        }
        Column(Modifier.padding(8.dp)) {
            Text(entry.title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(3.dp))
            Text(progress?.episodeLabel ?: statusText(entry.status), color = MutedGrey, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            progress?.let {
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(progress = { it.progress }, Modifier.fillMaxWidth().height(2.dp), color = BrightCyan, trackColor = CyberSurfaceVariant)
            }
        }
    }
}

@Composable
private fun PosterRow(items: List<AnimeListItem>, onOpen: (String) -> Unit) {
    if (items.isEmpty()) return
    val width = posterWidth()
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        items(items, key = { it.url }) { item ->
            AnimePosterCard(item = item, width = width, onClick = { onOpen(item.url) })
        }
    }
}

@Composable
private fun AnimePosterCard(item: AnimeListItem, width: androidx.compose.ui.unit.Dp, onClick: () -> Unit) {
    Column(Modifier.width(width).clickable(onClick = onClick)) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(width * 1.44f)
                .clip(RoundedCornerShape(12.dp))
                .background(CyberSurfaceVariant)
                .border(1.dp, CyberCardBorder, RoundedCornerShape(12.dp))
        ) {
            AsyncImage(
                model = item.cover,
                contentDescription = item.judul,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, CyberBlack.copy(alpha = 0.72f))))
            )
            Row(
                Modifier.align(Alignment.BottomStart).padding(5.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                item.lastch?.takeIf { it.isNotBlank() }?.let { TinyBadge(it) }
                item.score?.takeIf { it.isNotBlank() }?.let { TinyBadge("★ $it") }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(item.judul, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun CatalogScreen(
    items: List<AnimeListItem>,
    totalLoaded: Int,
    genres: List<String>,
    selectedGenre: String,
    contentType: ContentType,
    loading: Boolean,
    hasMore: Boolean,
    error: String?,
    onGenre: (String) -> Unit,
    onContentType: (ContentType) -> Unit,
    onOpen: (String) -> Unit,
    onBack: () -> Unit,
    onLoadMore: () -> Unit,
    onRetry: () -> Unit
) {
    val gridState = rememberLazyGridState()

    // Reset posisi scroll grid tiap ganti tab/genre biar tidak nyangkut di
    // tengah list konten yang berbeda.
    LaunchedEffect(contentType, selectedGenre) {
        gridState.scrollToItem(0)
    }

    LaunchedEffect(gridState, items.size, hasMore) {
        snapshotFlow { gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1 }
            .distinctUntilChanged()
            .filter { it >= 0 }
            .collectLatest { lastIndex ->
                if (lastIndex >= items.lastIndex - 5 && hasMore) onLoadMore()
            }
    }

    LaunchedEffect(items.size, selectedGenre, hasMore) {
        if (items.size < 8 && hasMore) {
            delay(250)
            onLoadMore()
        }
    }

    Column(Modifier.fillMaxSize()) {
        CatalogHeader(
            title = when (contentType) {
                ContentType.ANIME -> "SEMUA ANIME"
                ContentType.DONGHUA -> "DONGHUA"
                ContentType.MOVIE -> "MOVIE"
            },
            subtitle = if (loading && totalLoaded == 0) "Memuat..." else "",
            onBack = onBack
        )

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ContentType.entries.forEach { type ->
                val label = when (type) {
                    ContentType.ANIME -> "Anime"
                    ContentType.DONGHUA -> "Donghua"
                    ContentType.MOVIE -> "Movie"
                }
                FilterChip(
                    selected = contentType == type,
                    onClick = { onContentType(type) },
                    label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                )
            }
        }

        if (genres.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                items(genres, key = { it }) { genre ->
                    FilterChip(
                        selected = selectedGenre.equals(genre, true),
                        onClick = { onGenre(genre) },
                        label = { Text(genre, fontSize = 10.sp) }
                    )
                }
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(catalogColumns()),
            state = gridState,
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(items, key = { it.url }) { item ->
                AnimePosterCard(item = item, width = catalogPosterWidth(), onClick = { onOpen(item.url) })
            }
            if (loading) {
                item(key = "loading") {
                    Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(Modifier.size(20.dp), color = BrightCyan)
                    }
                }
            }
        }

        if (error != null && items.isEmpty()) {
            ErrorCard(error, onRetry)
        } else if (!loading && items.isEmpty()) {
            val emptyMessage = when (contentType) {
                ContentType.MOVIE -> "Belum ada movie yang bisa ditampilkan."
                else -> "Belum ada anime untuk genre ini."
            }
            EmptyState(emptyMessage, Icons.Default.GridView)
        }
    }
}

@Composable
private fun CatalogHeader(title: String, subtitle: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        HeaderBackButton(onBack = onBack)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp, letterSpacing = 0.3.sp)
            Text(subtitle, color = MutedGrey, fontSize = 10.sp)
        }
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.White.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.GridView, null, tint = Color.White, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun HeaderBackButton(onBack: () -> Unit) {
    Box(
        Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(CyberSurfaceVariant)
            .border(1.dp, CyberCardBorder, CircleShape)
            .clickable(onClick = onBack),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali", tint = Color.White, modifier = Modifier.size(17.dp))
    }
}

private fun List<Episode>.sortedByEpisodeNumber(): List<Episode> =
    sortedWith(
        compareBy<Episode> { episodeNumber(it.ch) ?: Int.MAX_VALUE }
            .thenBy { it.id }
    )

private fun episodeNumber(label: String): Int? =
    Regex("\\d+").find(label)?.value?.toIntOrNull()

@Composable
private fun AnimeDetailScreen(
    anime: AnimeDetail,
    history: List<WatchRecord>,
    myList: List<MyListEntry>,
    loading: Boolean,
    error: String?,
    onBack: () -> Unit,
    onPlay: (Int) -> Unit,
    onToggleMyList: () -> Unit
) {
    val inMyList = myList.any { it.seriesId == anime.series_id }
    val lastProgress = history.firstOrNull { it.seriesId == anime.series_id }
    val orderedEpisodes = remember(anime.chapter) { anime.chapter.sortedByEpisodeNumber() }
    val resumableProgress = lastProgress?.takeIf { !it.completed && it.positionMs > 0L }
    val resumeIndex = resumableProgress?.let { progress ->
        orderedEpisodes.indexOfFirst { it.id == progress.episodeId }.takeIf { it >= 0 }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 18.dp)
    ) {
        item {
            Box(Modifier.fillMaxWidth().height(285.dp)) {
                AsyncImage(
                    model = anime.cover,
                    contentDescription = anime.judul,
                    modifier = Modifier.fillMaxSize().background(CyberSurfaceVariant),
                    contentScale = ContentScale.Crop
                )
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color.Transparent, CyberBlack.copy(alpha = 0.2f), CyberBlack))
                    )
                )
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(top = 10.dp, start = 10.dp)
                        .size(34.dp)
                        .background(Color.Black.copy(alpha = 0.45f), CircleShape)
                ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali", tint = Color.White, modifier = Modifier.size(17.dp)) }
            }
        }

        item {
            Column(Modifier.padding(horizontal = 12.dp)) {
                Text(anime.judul, color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    anime.status?.let { MetaPill(it, if (it.contains("ongoing", true)) BrightGreen else MutedGrey) }
                    anime.type?.let { MetaPill(it, BrightCyan) }
                    anime.rating?.takeIf { it.isNotBlank() }?.let { MetaPill("★ $it", BrightAmber) }
                }
                Spacer(Modifier.height(7.dp))
                if (anime.genre.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(anime.genre.take(8), key = { it }) { genre -> MetaPill(genre, MutedGrey) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { onPlay(resumeIndex ?: 0) },
                        colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack),
                        shape = RoundedCornerShape(9.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(if (resumableProgress != null) "LANJUTKAN" else "TONTON", fontSize = 9.sp, fontWeight = FontWeight.Black)
                    }
                    OutlinedButton(
                        onClick = onToggleMyList,
                        shape = RoundedCornerShape(9.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(if (inMyList) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null, Modifier.size(17.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (inMyList) "MY LIST" else "SIMPAN", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("SINOPSIS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp, letterSpacing = 0.6.sp)
                Spacer(Modifier.height(5.dp))
                Text(anime.sinopsis.orEmpty().ifBlank { "Sinopsis tidak tersedia." }, color = MutedGrey, fontSize = 10.sp, lineHeight = 15.sp)
                Spacer(Modifier.height(12.dp))
                if (loading) LoadingInline("Mengambil informasi episode...")
                error?.let { ErrorCard(it) }
            }
        }

        item { SectionHeader("EPISODE", "${anime.chapter.size} episode") }

        itemsIndexed(orderedEpisodes, key = { _, ep -> ep.id }) { playbackIndex, episode ->
            val progress = history.firstOrNull { it.episodeId == episode.id && it.seriesId == anime.series_id }
            EpisodeRow(
                episode = episode,
                progress = progress,
                isLatest = playbackIndex == orderedEpisodes.lastIndex,
                onPlay = { onPlay(playbackIndex) }
            )
        }
    }
}

@Composable
private fun EpisodeRow(
    episode: Episode,
    progress: WatchRecord?,
    isLatest: Boolean,
    onPlay: () -> Unit
) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp).clickable(onClick = onPlay),
        colors = CardDefaults.cardColors(containerColor = if (isLatest) CyberSurface else CyberDarkNavy),
        border = BorderStroke(1.dp, if (isLatest) BrightCyan.copy(alpha = 0.24f) else CyberCardBorder),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(9.dp)).background(CyberSurfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.PlayArrow, null, tint = BrightCyan, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(episode.ch, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(episode.date.orEmpty().ifBlank { "Episode tersedia" }, color = MutedGrey, fontSize = 8.sp)
                progress?.let {
                    Spacer(Modifier.height(5.dp))
                    LinearProgressIndicator(progress = { it.progress }, Modifier.fillMaxWidth().height(3.dp), color = BrightCyan, trackColor = CyberSurfaceVariant)
                }
            }
            if (progress?.completed == true) {
                Icon(Icons.Default.CheckCircle, null, tint = BrightGreen, modifier = Modifier.size(18.dp))
            } else if (progress != null) {
                Text(formatTime(progress.positionMs), color = MutedGrey, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun PlayerScreen(
    anime: AnimeDetail,
    episode: Episode,
    episodeIndex: Int,
    streams: com.baklava.projectlv.data.streaming.EpisodeStreamData,
    localStore: StreamingLocalStore,
    onBack: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onOpenEpisode: (Int) -> Unit
) {
    val context = LocalContext.current
    val qualities = remember(streams) { qualityOptions(streams) }
    var selectedQuality by rememberSaveable(episode.id) {
        mutableStateOf(
            qualities.firstOrNull { it == localStore.preferredQuality }
                ?: qualities.firstOrNull().orEmpty()
        )
    }
    var candidateIndex by remember(episode.id, selectedQuality) { mutableIntStateOf(0) }
    var playerError by remember(episode.id, selectedQuality) { mutableStateOf<String?>(null) }
    var speed by rememberSaveable(episode.id) { mutableStateOf(1f) }
    var isSpeedBoostActive by remember(episode.id) { mutableStateOf(false) }
    var positionState by remember(episode.id) { mutableLongStateOf(0L) }
    var durationState by remember(episode.id) { mutableLongStateOf(0L) }
    var controlsVisible by rememberSaveable(episode.id) { mutableStateOf(true) }
    var isPlaying by remember(episode.id) { mutableStateOf(true) }
    var muted by rememberSaveable(episode.id) { mutableStateOf(false) }
    var autoNextEnabled by rememberSaveable { mutableStateOf(localStore.autoPlayNext) }
    var autoNextHandled by remember(episode.id, candidateIndex, selectedQuality) { mutableStateOf(false) }
    // true ketika pengguna menekan pause (playWhenReady = false). Berbeda dari isPlaying yang
    // juga false saat buffering, sehingga overlay tidak ikut "nyangkut" ketika video buffering.
    var userPaused by remember(episode.id, selectedQuality) { mutableStateOf(false) }
    // Double tap seek: -1 = kiri (mundur), 1 = kanan (maju), 0 = tidak aktif.
    var seekSide by remember(episode.id) { mutableIntStateOf(0) }
    var seekAccumSec by remember(episode.id) { mutableIntStateOf(0) }
    var seekTick by remember(episode.id) { mutableIntStateOf(0) }

    val candidates = remember(streams, selectedQuality) {
        streams.streams[selectedQuality].orEmpty()
            .filter { it.link.isNotBlank() }
            .sortedWith(compareBy<StreamCandidate> { it.provide != 871 }.thenBy { it.provide != 99 })
    }

    val player = remember(context, episode.id, selectedQuality) {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = true
            volume = 1f
        }
    }

    fun saveCurrentProgress() {
        val duration = when {
            player.duration > 0 && player.duration != C.TIME_UNSET -> player.duration
            durationState > 0 -> durationState
            else -> 0L
        }
        val position = player.currentPosition.coerceAtLeast(0L)
        if (position > 0L || duration > 0L) {
            val completed = duration > 0L && position >= (duration - 15_000L).coerceAtLeast(0L)
            localStore.saveProgress(
                WatchRecord(
                    key = "${anime.series_id}:${episode.id}",
                    seriesId = anime.series_id,
                    seriesTitle = anime.judul,
                    cover = anime.cover,
                    episodeId = episode.id,
                    episodeLabel = episode.ch,
                    episodeUrl = episode.url,
                    positionMs = position.coerceAtMost(duration.takeIf { it > 0 } ?: Long.MAX_VALUE),
                    durationMs = duration,
                    lastWatchedAt = System.currentTimeMillis(),
                    completed = completed
                )
            )
            if (localStore.isInMyList(anime.series_id)) {
                localStore.setMyListStatus(anime.series_id, if (completed) "COMPLETED" else "WATCHING")
            }
        }
    }

    fun seekBy(deltaMs: Long) {
        val duration = when {
            player.duration > 0L && player.duration != C.TIME_UNSET -> player.duration
            durationState > 0L -> durationState
            else -> 0L
        }
        var target = (player.currentPosition + deltaMs).coerceAtLeast(0L)
        if (duration > 0L) target = target.coerceAtMost(duration)
        player.seekTo(target)
        positionState = target
    }

    fun doubleTapSeek(side: Int) {
        // side baru / rantai baru -> mulai hitung dari nol
        if (seekSide != side) seekAccumSec = 0
        seekSide = side
        seekAccumSec += SEEK_STEP_SEC
        seekTick += 1
        seekBy(side * SEEK_STEP_MS)
    }

    DisposableEffect(player) {
        onDispose {
            saveCurrentProgress()
            player.release()
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                userPaused = !playWhenReady
                // Saat di-pause, tampilkan kontrol sekali; setelah itu pengguna bebas
                // menyembunyikannya (tap layar / tombol sembunyikan) dan kontrol tidak auto-hide.
                if (!playWhenReady) controlsVisible = true
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                durationState = player.duration.takeIf { it > 0 && it != C.TIME_UNSET } ?: durationState
                if (playbackState == Player.STATE_READY) {
                    playerError = null
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                if (candidateIndex + 1 < candidates.size) {
                    candidateIndex += 1
                    playerError = "Sumber gagal. Mencoba provider cadangan…"
                } else {
                    playerError = "Semua sumber $selectedQuality gagal diputar.\n(${error.errorCodeName})"
                }
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    LaunchedEffect(candidates, candidateIndex, episode.id, selectedQuality) {
        if (candidates.isEmpty()) {
            playerError = "Link streaming untuk $selectedQuality tidak tersedia."
            return@LaunchedEffect
        }
        playerError = null
        val item = MediaItem.fromUri(candidates[candidateIndex].link)
        val resume = localStore.progressFor(anime.series_id, episode.id)?.positionMs ?: 0L
        player.setMediaItem(item)
        player.prepare()
        if (resume > 0L) player.seekTo(resume)
        player.playWhenReady = true
        isPlaying = true
        durationState = localStore.progressFor(anime.series_id, episode.id)?.durationMs ?: 0L
    }

    LaunchedEffect(player, episode.id) {
        while (true) {
            positionState = player.currentPosition.coerceAtLeast(0L)
            durationState = when {
                player.duration > 0L && player.duration != C.TIME_UNSET -> player.duration
                else -> durationState
            }

            if (player.playbackState == Player.STATE_ENDED && !autoNextHandled) {
                autoNextHandled = true
                saveCurrentProgress()
                if (autoNextEnabled && episodeIndex + 1 < anime.chapter.sortedByEpisodeNumber().size) {
                    delay(650)
                    onNext()
                    break
                }
            }

            delay(1000L)
            if (isPlaying) saveCurrentProgress()
        }
    }

    LaunchedEffect(controlsVisible, userPaused, playerError) {
        if (controlsVisible && !userPaused && playerError == null) {
            delay(4200L)
            controlsVisible = false
        }
    }

    // Tutup indikator seek setelah tidak ada tap lanjutan.
    LaunchedEffect(seekTick) {
        if (seekTick > 0) {
            delay(SEEK_CHAIN_WINDOW_MS)
            seekSide = 0
        }
    }

    LaunchedEffect(speed) { player.setPlaybackSpeed(speed) }
    LaunchedEffect(muted) { player.volume = if (muted) 0f else 1f }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .windowInsetsPadding(WindowInsets.displayCutout)
    ) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    useController = false
                    controllerAutoShow = false
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                    resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                    setBackgroundColor(android.graphics.Color.BLACK)
                    setOnClickListener { controlsVisible = !controlsVisible }
                }
            },
            update = { it.player = player },
            modifier = Modifier.fillMaxSize()
        )

        // Touch layer sits below the actual controls so buttons/sliders keep priority.
        //  - Tap           : tampilkan / sembunyikan kontrol (juga saat video di-pause)
        //  - Double tap    : kiri = mundur 10 dtk, kanan = maju 10 dtk. Tap lanjutan dalam
        //                    jeda singkat menambah lompatan (seperti YouTube).
        //  - Long press    : boost 2x selama ditahan, kembali normal saat dilepas.
        // Key `player` wajib: ExoPlayer dibuat ulang saat ganti kualitas, jangan pakai instance lama.
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(speed, player) {
                    detectTapGestures(
                        onTap = { offset ->
                            if (seekSide != 0) {
                                doubleTapSeek(if (offset.x < size.width / 2f) -1 else 1)
                            } else {
                                controlsVisible = !controlsVisible
                            }
                        },
                        onDoubleTap = { offset ->
                            doubleTapSeek(if (offset.x < size.width / 2f) -1 else 1)
                        },
                        onLongPress = {
                            isSpeedBoostActive = true
                            controlsVisible = false
                            player.setPlaybackSpeed(2f)
                        },
                        onPress = {
                            tryAwaitRelease()
                            if (isSpeedBoostActive) {
                                isSpeedBoostActive = false
                                player.setPlaybackSpeed(speed)
                            }
                        }
                    )
                }
        )

        AnimatedVisibility(
            visible = seekSide < 0,
            modifier = Modifier.align(Alignment.CenterStart),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            SeekIndicator(forward = false, seconds = seekAccumSec, modifier = Modifier.padding(start = 56.dp))
        }
        AnimatedVisibility(
            visible = seekSide > 0,
            modifier = Modifier.align(Alignment.CenterEnd),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            SeekIndicator(forward = true, seconds = seekAccumSec, modifier = Modifier.padding(end = 56.dp))
        }

        if (isSpeedBoostActive) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 26.dp),
                color = Color.Black.copy(alpha = 0.62f),
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f))
            ) {
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.FastForward, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("2x Kecepatan", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // Saat pause overlay TIDAK dipaksa tampil: pengguna bisa menyembunyikannya untuk melihat
        // frame bersih. Overlay hanya dipaksa tampil ketika ada error.
        if (controlsVisible || playerError != null) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0f to Color.Black.copy(alpha = 0.78f),
                            0.25f to Color.Transparent,
                            0.66f to Color.Transparent,
                            1f to Color.Black.copy(alpha = 0.90f)
                        )
                    )
            )

            Row(
                Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 20.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = Color.Black.copy(alpha = 0.58f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.10f))
                ) {
                    Row(
                        Modifier.padding(end = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali", tint = Color.White, modifier = Modifier.size(22.dp))
                        }
                        Column(Modifier.widthIn(max = 220.dp)) {
                            Text(
                                anime.judul,
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                "Episode ${episode.ch}",
                                color = BrightCyan,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(Modifier.weight(1f))

                IconButton(
                    onClick = { controlsVisible = false },
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color.Black.copy(alpha = 0.45f), CircleShape)
                ) {
                    Icon(Icons.Default.VisibilityOff, "Sembunyikan tampilan", tint = Color.White, modifier = Modifier.size(18.dp))
                }
                FilterChip(
                    selected = autoNextEnabled,
                    onClick = {
                        autoNextEnabled = !autoNextEnabled
                        localStore.autoPlayNext = autoNextEnabled
                    },
                    label = { Text("AUTO", fontSize = 8.sp, fontWeight = FontWeight.Bold) },
                    leadingIcon = { Icon(Icons.Default.SkipNext, "Auto-next", Modifier.size(13.dp)) },
                    modifier = Modifier.height(30.dp)
                )
                QualityMenu(
                    selected = selectedQuality,
                    options = qualities,
                    onSelected = {
                        if (it != selectedQuality) {
                            saveCurrentProgress()
                            selectedQuality = it
                            localStore.saveQuality(it)
                            candidateIndex = 0
                        }
                    }
                )
                SpeedMenu(speed = speed, onSpeed = { speed = it })
                IconButton(
                    onClick = { muted = !muted },
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color.Black.copy(alpha = 0.45f), CircleShape)
                ) {
                    Text(if (muted) "M" else "V", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            Row(
                Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                PlayerControlButton(
                    Icons.Default.SkipPrevious,
                    "Episode sebelumnya",
                    onPrevious,
                    enabled = episodeIndex > 0
                )

                IconButton(
                    onClick = { seekBy(-SEEK_STEP_MS) },
                    modifier = Modifier
                        .size(44.dp)
                        .background(Color.Black.copy(alpha = 0.38f), CircleShape)
                ) {
                    Text("−$SEEK_STEP_SEC", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                }

                IconButton(
                    onClick = {
                        when {
                            player.playbackState == Player.STATE_ENDED -> {
                                player.seekTo(0L)
                                player.play()
                            }
                            player.playWhenReady -> player.pause()
                            else -> player.play()
                        }
                    },
                    modifier = Modifier
                        .size(60.dp)
                        .background(Color.White, CircleShape)
                ) {
                    Icon(
                        if (userPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        if (userPaused) "Putar" else "Pause",
                        tint = CyberBlack,
                        modifier = Modifier.size(34.dp)
                    )
                }

                IconButton(
                    onClick = { seekBy(SEEK_STEP_MS) },
                    modifier = Modifier
                        .size(44.dp)
                        .background(Color.Black.copy(alpha = 0.38f), CircleShape)
                ) {
                    Text("+$SEEK_STEP_SEC", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
                }

                PlayerControlButton(
                    Icons.Default.SkipNext,
                    "Episode berikutnya",
                    onNext,
                    enabled = episodeIndex + 1 < anime.chapter.size
                )
            }

            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(formatTime(positionState), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text(formatTime(durationState), color = Color.White.copy(alpha = 0.70f), fontSize = 10.sp)
                }
                Slider(
                    value = if (durationState > 0L) {
                        positionState.coerceIn(0L, durationState).toFloat()
                    } else 0f,
                    onValueChange = { player.seekTo(it.toLong()) },
                    valueRange = 0f..durationState.coerceAtLeast(1L).toFloat(),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Episode ${episode.ch}",
                        color = Color.White.copy(alpha = 0.82f),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.weight(1f))
                    if (localStore.autoPlayNext && episodeIndex + 1 < anime.chapter.size) {
                        Text(
                            "Auto-next aktif",
                            color = BrightGreen,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        playerError?.let { message ->
            Surface(
                Modifier
                    .align(Alignment.Center)
                    .padding(16.dp),
                color = Color.Black.copy(alpha = 0.90f),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, BrightRed.copy(alpha = 0.38f))
            ) {
                Column(
                    Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.ErrorOutline, null, tint = BrightRed, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(message, color = Color.White, fontSize = 10.sp, textAlign = TextAlign.Center)
                    if (candidateIndex + 1 < candidates.size) {
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = { candidateIndex += 1 },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = BrightCyan,
                                contentColor = CyberBlack
                            )
                        ) {
                            Text("COBA PROVIDER LAIN", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SeekIndicator(forward: Boolean, seconds: Int, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = Color.Black.copy(alpha = 0.58f),
        shape = RoundedCornerShape(26.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
    ) {
        Column(
            Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                if (forward) Icons.Default.FastForward else Icons.Default.FastRewind,
                if (forward) "Maju" else "Mundur",
                tint = Color.White,
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.height(3.dp))
            val sign = if (forward) "+" else "−"
            Text(
                "$sign$seconds dtk",
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun PlayerControlButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    enabled: Boolean = true
) {
    IconButton(onClick = onClick, enabled = enabled) {
        Icon(icon, label, tint = if (enabled) Color.White else MutedGrey, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun QualityMenu(selected: String, options: List<String>, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        AssistChip(onClick = { expanded = true }, label = { Text(selected, fontSize = 9.sp) }, trailingIcon = { Icon(Icons.Default.KeyboardArrowDown, null, Modifier.size(14.dp)) })
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option, fontSize = 11.sp) },
                    onClick = { expanded = false; onSelected(option) }
                )
            }
        }
    }
}

@Composable
private fun SpeedMenu(speed: Float, onSpeed: (Float) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { expanded = true }) { Icon(Icons.Default.Speed, "Kecepatan", tint = Color.White, modifier = Modifier.size(20.dp)) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            listOf(0.75f, 1f, 1.25f, 1.5f, 2f).forEach { value ->
                DropdownMenuItem(
                    text = { Text("${value}x", fontSize = 11.sp) },
                    onClick = { expanded = false; onSpeed(value) }
                )
            }
        }
    }
}

@Composable
private fun MyListScreen(
    myList: List<MyListEntry>,
    history: List<WatchRecord>,
    onBack: () -> Unit,
    onOpen: (String) -> Unit,
    onRemove: (String) -> Unit,
    onStatus: (String, String) -> Unit
) {
    var selectedStatus by rememberSaveable { mutableStateOf("ALL") }
    val filtered = if (selectedStatus == "ALL") myList else myList.filter { it.status == selectedStatus }

    Column(Modifier.fillMaxSize()) {
        CatalogHeader(title = "MY LIST", subtitle = "${myList.size} anime tersimpan", onBack = onBack)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            listOf("ALL", "PLANNED", "WATCHING", "COMPLETED").forEach { status ->
                item {
                    FilterChip(
                        selected = selectedStatus == status,
                        onClick = { selectedStatus = status },
                        label = { Text(statusText(status), fontSize = 10.sp) }
                    )
                }
            }
        }
        if (filtered.isEmpty()) {
            EmptyState("Belum ada anime pada kategori ini.", Icons.Default.BookmarkBorder)
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 18.dp, top = 8.dp)) {
                items(filtered, key = { it.seriesId }) { entry ->
                    MyListFullRow(
                        entry = entry,
                        progress = history.firstOrNull { it.seriesId == entry.seriesId },
                        onOpen = { onOpen(entry.seriesId) },
                        onRemove = { onRemove(entry.seriesId) },
                        onStatus = { onStatus(entry.seriesId, it) }
                    )
                }
            }
        }
    }
}

@Composable
private fun MyListFullRow(
    entry: MyListEntry,
    progress: WatchRecord?,
    onOpen: () -> Unit,
    onRemove: () -> Unit,
    onStatus: (String) -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
        border = BorderStroke(1.dp, CyberCardBorder),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(model = entry.cover, contentDescription = entry.title, modifier = Modifier.size(78.dp, 110.dp).clip(RoundedCornerShape(10.dp)).background(CyberSurfaceVariant), contentScale = ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(5.dp))
                Text(statusText(entry.status), color = statusColor(entry.status), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                progress?.let {
                    Spacer(Modifier.height(7.dp))
                    Text("${it.episodeLabel} • ${formatTime(it.positionMs)} / ${formatTime(it.durationMs)}", color = MutedGrey, fontSize = 9.sp)
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(progress = { it.progress }, Modifier.fillMaxWidth().height(4.dp), color = BrightCyan, trackColor = CyberSurfaceVariant)
                }
                entry.totalEpisodes?.let { total ->
                    Spacer(Modifier.height(5.dp))
                    Text("$total episode", color = MutedGrey, fontSize = 9.sp)
                }
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menu", tint = MutedGrey) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    listOf("PLANNED", "WATCHING", "COMPLETED").forEach { status ->
                        DropdownMenuItem(
                            text = { Text("Jadikan ${statusText(status)}", fontSize = 10.sp) },
                            onClick = { menu = false; onStatus(status) }
                        )
                    }
                    DropdownMenuItem(text = { Text("Hapus dari MyList", fontSize = 10.sp) }, onClick = { menu = false; onRemove() })
                }
            }
        }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun HistoryScreen(
    history: List<WatchRecord>,
    onBack: () -> Unit,
    onOpen: (WatchRecord) -> Unit,
    onDelete: (String) -> Unit,
    onClear: () -> Unit
) {
    var confirmClear by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            HeaderBackButton(onBack = onBack)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("RIWAYAT", color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp, letterSpacing = 0.3.sp)
                Text("${history.size} aktivitas terakhir", color = MutedGrey, fontSize = 10.sp)
            }
            if (history.isNotEmpty()) {
                Box(
                    Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(BrightRed.copy(alpha = 0.12f))
                        .clickable { confirmClear = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Delete, "Hapus semua", tint = BrightRed, modifier = Modifier.size(16.dp))
                }
            }
        }
        if (history.isEmpty()) {
            EmptyState("Belum ada riwayat tontonan.", Icons.Default.History)
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 18.dp, top = 4.dp)) {
                history.groupByDay().forEach { (label, records) ->
                    item(key = "day:$label") {
                        Text(label, color = MutedGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                    }
                    items(records, key = { it.key }) { record ->
                        HistoryRow(record = record, onOpen = { onOpen(record) }, onDelete = { onDelete(record.key) })
                    }
                }
            }
        }
    }
    if (confirmClear) {
        ModalBottomSheet(onDismissRequest = { confirmClear = false }, sheetState = rememberModalBottomSheetState()) {
            Column(Modifier.padding(22.dp).navigationBarsPadding(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Hapus seluruh riwayat?", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                Text("Progress episode dan waktu terakhir ditonton akan dihapus dari perangkat.", color = MutedGrey, fontSize = 11.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { confirmClear = false }) { Text("BATAL") }
                    Button(onClick = { confirmClear = false; onClear() }, colors = ButtonDefaults.buttonColors(containerColor = BrightRed, contentColor = Color.White)) { Text("HAPUS") }
                }
            }
        }
    }
}

@Composable
private fun HistoryRow(record: WatchRecord, onOpen: () -> Unit, onDelete: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
        border = BorderStroke(1.dp, CyberCardBorder),
        shape = RoundedCornerShape(13.dp)
    ) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(model = record.cover, contentDescription = record.seriesTitle, modifier = Modifier.size(72.dp, 96.dp).clip(RoundedCornerShape(10.dp)).background(CyberSurfaceVariant), contentScale = ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(record.seriesTitle, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text(record.episodeLabel, color = BrightCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(7.dp))
                LinearProgressIndicator(progress = { record.progress }, Modifier.fillMaxWidth().height(4.dp), color = if (record.completed) BrightGreen else BrightCyan, trackColor = CyberSurfaceVariant)
                Spacer(Modifier.height(4.dp))
                Text(if (record.completed) "Selesai" else "${formatTime(record.positionMs)} / ${formatTime(record.durationMs)}", color = if (record.completed) BrightGreen else MutedGrey, fontSize = 9.sp)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Hapus", tint = MutedGrey, modifier = Modifier.size(18.dp)) }
        }
    }
}

@Composable
private fun SearchScreen(
    query: String,
    onQueryChange: (String) -> Unit,
    results: List<AnimeListItem>,
    loading: Boolean,
    error: String?,
    onBack: () -> Unit,
    onOpen: (String) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            HeaderBackButton(onBack = onBack)
            Spacer(Modifier.width(10.dp))
            androidx.compose.material3.OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(14.dp),
                singleLine = true,
                placeholder = { Text("Cari judul, genre, studio...", fontSize = 11.sp) },
                trailingIcon = {
                    if (query.isNotBlank()) IconButton(onClick = { onQueryChange("") }) { Icon(Icons.Default.Close, null) }
                }
            )
        }
        when {
            query.isBlank() -> EmptyState("Ketik sesuatu untuk mencari anime.", Icons.Default.Search)
            loading && results.isEmpty() -> LoadingInline("Mencari \"$query\" di server 1 & 2...")
            error != null && results.isEmpty() -> ErrorCard(message = error)
            results.isEmpty() -> EmptyState("Anime \"$query\" tidak ditemukan di server 1 maupun server 2.", Icons.Default.Search)
            else -> LazyColumn(contentPadding = PaddingValues(bottom = 18.dp, top = 6.dp)) {
                if (loading) {
                    item { LoadingInline("Masih memindai halaman lain...") }
                }
                items(results, key = { it.url }) { item ->
                    SearchRow(item, onOpen = { onOpen(item.url) })
                }
            }
        }
    }
}

@Composable
private fun SearchRow(item: AnimeListItem, onOpen: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp).clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
        border = BorderStroke(1.dp, CyberCardBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(model = item.cover, contentDescription = item.judul, modifier = Modifier.size(56.dp, 76.dp).clip(RoundedCornerShape(10.dp)).background(CyberSurfaceVariant), contentScale = ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(item.judul, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text(item.genre.take(3).joinToString(" • "), color = MutedGrey, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text(item.status ?: item.lastch.orEmpty(), color = BrightCyan, fontSize = 9.sp)
            }
            Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = MutedGrey, modifier = Modifier.size(17.dp))
        }
    }
}

@Composable
private fun MetaPill(text: String, color: Color) {
    Surface(color = color.copy(alpha = 0.15f), shape = RoundedCornerShape(7.dp), border = BorderStroke(1.dp, color.copy(alpha = 0.23f))) {
        Text(text, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp))
    }
}

@Composable
private fun TinyBadge(text: String) {
    Surface(color = CyberBlack.copy(alpha = 0.79f), shape = RoundedCornerShape(6.dp)) {
        Text(text, color = Color.White, fontSize = 8.sp, modifier = Modifier.padding(horizontal = 5.dp, vertical = 3.dp), maxLines = 1)
    }
}

@Composable
private fun EmptyInline(message: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), colors = CardDefaults.cardColors(containerColor = CyberDarkNavy), border = BorderStroke(1.dp, CyberCardBorder), shape = RoundedCornerShape(12.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MutedGrey, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(message, color = MutedGrey, fontSize = 10.sp)
        }
    }
}

@Composable
private fun LoadingInline(message: String) {
    Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = BrightCyan)
        Spacer(Modifier.width(8.dp))
        Text(message, color = MutedGrey, fontSize = 10.sp)
    }
}

@Composable
private fun EmptyState(message: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Box(Modifier.fillMaxSize().padding(30.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = MutedGrey, modifier = Modifier.size(42.dp))
            Spacer(Modifier.height(10.dp))
            Text(message, color = MutedGrey, fontSize = 11.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun CenterLoading(onBack: () -> Unit) {
    Box(Modifier.fillMaxSize().background(CyberBlack)) {
        IconButton(onClick = onBack, modifier = Modifier.padding(7.dp)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali", tint = Color.White) }
        CircularProgressIndicator(Modifier.align(Alignment.Center), color = BrightCyan)
    }
}

@Composable
private fun ErrorState(message: String, onRetry: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(CyberBlack), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth().padding(7.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali", tint = Color.White) }
            Text("Streaming", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        Spacer(Modifier.height(120.dp))
        Icon(Icons.Default.ErrorOutline, null, tint = BrightRed, modifier = Modifier.size(42.dp))
        Spacer(Modifier.height(10.dp))
        Text(message, color = Color.White, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 30.dp))
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onRetry) { Text("COBA LAGI") }
    }
}

@Composable
private fun ErrorCard(message: String, onRetry: (() -> Unit)? = null) {
    Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = BrightRed.copy(alpha = 0.08f)), border = BorderStroke(1.dp, BrightRed.copy(alpha = 0.28f)), shape = RoundedCornerShape(12.dp)) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ErrorOutline, null, tint = BrightRed, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(message, Modifier.weight(1f), color = Color.White, fontSize = 10.sp)
            onRetry?.let { TextButton(onClick = it) { Text("Retry", fontSize = 9.sp) } }
        }
    }
}

private fun filterByGenre(items: List<AnimeListItem>, genre: String): List<AnimeListItem> =
    if (genre == "Semua") items else items.filter { anime -> anime.genre.any { it.equals(genre, true) } }

private fun genreOptions(allAnime: List<AnimeListItem>): List<String> {
    val discovered = allAnime.asSequence().flatMap { it.genre.asSequence() }.filter { it.isNotBlank() }.distinctBy { it.lowercase(Locale.ROOT) }.sorted().toList()
    return listOf("Semua") + (COMMON_GENRES + discovered).distinctBy { it.lowercase(Locale.ROOT) }.filterNot { it.equals("Semua", true) }
}

private fun qualityOptions(data: com.baklava.projectlv.data.streaming.EpisodeStreamData): List<String> {
    val known = data.reso + data.streams.keys
    val preferredOrder = listOf("1080p", "720p", "480p", "360p")
    return preferredOrder.filter { known.contains(it) }.ifEmpty { known.distinct() }.distinct()
}

@Composable
private fun posterWidth(): androidx.compose.ui.unit.Dp {
    val width = LocalConfiguration.current.screenWidthDp
    val columns = when {
        width >= 900 -> 6
        width >= 700 -> 5
        width >= 520 -> 4
        else -> 3
    }
    val gap = 10 * (columns - 1) + 32
    return ((width - gap) / columns).coerceAtLeast(92).dp
}

@Composable
private fun catalogColumns(): Int {
    val width = LocalConfiguration.current.screenWidthDp
    return when {
        width >= 1000 -> 7
        width >= 760 -> 6
        width >= 600 -> 5
        else -> 3
    }
}

@Composable
private fun catalogPosterWidth(): androidx.compose.ui.unit.Dp {
    val width = LocalConfiguration.current.screenWidthDp
    val columns = catalogColumns()
    val gap = 10 * (columns - 1) + 28
    return ((width - gap) / columns).coerceAtLeast(84).dp
}

private fun List<WatchRecord>.groupByDay(): LinkedHashMap<String, List<WatchRecord>> {
    val locale = Locale.getDefault()
    val day = SimpleDateFormat("yyyy-MM-dd", locale)
    val title = SimpleDateFormat("dd MMM yyyy", locale)
    val sorted = sortedByDescending { it.lastWatchedAt }
    val result = linkedMapOf<String, MutableList<WatchRecord>>()
    val now = Date()
    val yesterdayKey = day.format(Date(System.currentTimeMillis() - 86_400_000L))
    val todayKey = day.format(now)
    sorted.forEach { record ->
        val key = day.format(Date(record.lastWatchedAt))
        val label = when (key) {
            todayKey -> "Hari ini"
            yesterdayKey -> "Kemarin"
            else -> title.format(Date(record.lastWatchedAt))
        }
        result.getOrPut(label) { mutableListOf() }.add(record)
    }
    return LinkedHashMap(result)
}

private fun formatTime(ms: Long): String {
    val totalSec = (ms.coerceAtLeast(0L) / 1000L)
    val hours = totalSec / 3600L
    val minutes = (totalSec % 3600L) / 60L
    val seconds = totalSec % 60L
    return if (hours > 0) "%d:%02d:%02d".format(hours, minutes, seconds) else "%02d:%02d".format(minutes, seconds)
}

private fun statusText(status: String): String = when (status) {
    "PLANNED" -> "Belum Ditonton"
    "WATCHING" -> "Sedang Ditonton"
    "COMPLETED" -> "Selesai"
    "ALL" -> "Semua"
    else -> status
}

private fun statusColor(status: String): Color = when (status) {
    "WATCHING" -> BrightCyan
    "COMPLETED" -> BrightGreen
    else -> MutedGrey
}
