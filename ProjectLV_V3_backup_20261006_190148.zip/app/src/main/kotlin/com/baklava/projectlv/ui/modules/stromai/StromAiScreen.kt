package com.baklava.projectlv.ui.modules.stromai

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import com.baklava.projectlv.ui.components.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import com.baklava.projectlv.ui.components.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import com.baklava.projectlv.ui.components.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.BuildConfig
import com.baklava.projectlv.data.models.ChatSessionHistory
import com.baklava.projectlv.data.models.PersistedChatMessage
import com.baklava.projectlv.data.repository.LeviathanRepository
import com.baklava.projectlv.data.repository.ResultState
import com.baklava.projectlv.data.repository.StromAiModel
import com.baklava.projectlv.data.storage.ChatHistoryManager
import com.baklava.projectlv.ui.components.AppWindowSize
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

// Disamakan dengan palet monokrom bersama (lihat ui/theme/Color.kt) agar layar
// ini identik secara visual dengan Dashboard & layar modul lain — bukan lagi
// palet lokal terpisah.
private val Bg = com.baklava.projectlv.ui.theme.CyberBlack
private val Header = com.baklava.projectlv.ui.theme.CyberDarkNavy
private val Surface1 = com.baklava.projectlv.ui.theme.CyberSurface
private val Surface2 = com.baklava.projectlv.ui.theme.CyberSurfaceVariant
private val Border = com.baklava.projectlv.ui.theme.CyberCardBorder
private val TextPrimary = com.baklava.projectlv.ui.theme.BrightCyan
private val TextSecondary = com.baklava.projectlv.ui.theme.MutedGrey
private val SendOn = com.baklava.projectlv.ui.theme.BrightCyan
private val AccentGreen = com.baklava.projectlv.ui.theme.BrightGreen
private val ErrorRed = com.baklava.projectlv.ui.theme.BrightRed

private val modelOrder = listOf(
    StromAiModel.STROM,
    StromAiModel.CLAUDE,
    StromAiModel.CHATGPT,
    StromAiModel.DEEPSEEK_FLASH,
    StromAiModel.DEEPSEEK_PRO
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val isUser: Boolean,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isError: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StromAiScreen(
    repository: LeviathanRepository,
    chatHistoryManager: ChatHistoryManager,
    windowSize: AppWindowSize,
    onShowSnackbar: (String) -> Unit
) {
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val isCompact = windowSize.isCompact

    var selectedModel by remember { mutableStateOf(StromAiModel.STROM) }
    var modelSheetOpen by remember { mutableStateOf(false) }
    var historySheetOpen by remember { mutableStateOf(false) }
    var overflowMenuExpanded by remember { mutableStateOf(false) }
    var histories by remember { mutableStateOf<List<ChatSessionHistory>>(emptyList()) }
    var currentHistoryId by remember { mutableStateOf<String?>(null) }
    var systemPrompt by remember { mutableStateOf("") }
    var showPromptDialog by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var inputText by remember { mutableStateOf("") }
    var isThinking by remember { mutableStateOf(false) }
    var attachedFileName by remember { mutableStateOf<String?>(null) }
    val messages = remember { mutableStateListOf<ChatMessage>() }

    val modelSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val historySheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Tampilkan tombol "scroll to bottom" saat user menggulir menjauhi pesan terbaru.
    val showScrollToBottom by remember {
        derivedStateOf {
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            messages.isNotEmpty() && lastVisible < messages.lastIndex - 1
        }
    }
    val scrollButtonAlpha by animateFloatAsState(
        targetValue = if (showScrollToBottom) 1f else 0f,
        animationSpec = tween(180),
        label = "scrollButtonAlpha"
    )

    fun defaultWelcome(model: StromAiModel) = ChatMessage(
        isUser = false,
        text = "${model.displayName} siap digunakan. Masukkan pertanyaan atau instruksi kamu."
    )

    fun toPersisted(messages: List<ChatMessage>) = messages.map {
        PersistedChatMessage(it.id, it.isUser, it.text, it.timestamp)
    }

    fun ensureHistory() {
        if (currentHistoryId != null) return
        val now = System.currentTimeMillis()
        val created = ChatSessionHistory(
            model = selectedModel,
            title = "Chat ${SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(now))}",
            systemPrompt = systemPrompt,
            messages = toPersisted(messages),
            createdAt = now,
            updatedAt = now
        )
        currentHistoryId = created.id
        histories = listOf(created) + histories
    }

    fun persistCurrent() {
        if (messages.isEmpty()) return
        ensureHistory()
        val id = currentHistoryId ?: return
        val current = histories.find { it.id == id }
        val updated = ChatSessionHistory(
            id = id,
            model = selectedModel,
            title = current?.title ?: messages.firstOrNull { it.isUser }?.text?.take(38)?.ifBlank { "Chat baru" } ?: "Chat baru",
            sessionId = current?.sessionId,
            systemPrompt = systemPrompt,
            messages = toPersisted(messages),
            createdAt = current?.createdAt ?: System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        histories = listOf(updated) + histories.filterNot { it.id == id }
        scope.launch { chatHistoryManager.upsert(updated) }
    }

    LaunchedEffect(Unit) {
        histories = chatHistoryManager.load()
        val latest = histories.firstOrNull()
        if (latest != null) {
            currentHistoryId = latest.id
            selectedModel = latest.model
            systemPrompt = latest.systemPrompt
            messages.clear()
            messages.addAll(latest.messages.map { ChatMessage(it.id, it.isUser, it.text, it.timestamp) })
        } else {
            messages.add(defaultWelcome(selectedModel))
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
            persistCurrent()
        }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null || isThinking || selectedModel != StromAiModel.STROM) return@rememberLauncherForActivityResult
        scope.launch {
            onShowSnackbar("Mengunggah file ke STROM AI...")
            when (val result = repository.uploadFileForAi(uri)) {
                is ResultState.Success -> {
                    val name = uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "Lampiran" } ?: "Lampiran"
                    attachedFileName = name
                    inputText = listOf(inputText.trim(), "Lampiran STROM AI: ${result.data}").filter { it.isNotBlank() }.joinToString("\n\n")
                    onShowSnackbar("File siap digunakan STROM AI.")
                }
                is ResultState.Error -> onShowSnackbar("Upload gagal: ${result.message}")
            }
        }
    }

    fun startNewChat() {
        persistCurrent()
        currentHistoryId = null
        systemPrompt = ""
        inputText = ""
        attachedFileName = null
        messages.clear()
        messages.add(defaultWelcome(selectedModel))
        onShowSnackbar("Chat baru dibuat.")
    }

    fun loadHistory(item: ChatSessionHistory) {
        currentHistoryId = item.id
        selectedModel = item.model
        systemPrompt = item.systemPrompt
        inputText = ""
        attachedFileName = null
        messages.clear()
        messages.addAll(item.messages.map { ChatMessage(it.id, it.isUser, it.text, it.timestamp) })
        historySheetOpen = false
        onShowSnackbar("Riwayat '${item.title}' dibuka.")
    }

    fun resetCurrentSession() {
        val id = currentHistoryId
        currentHistoryId = null
        messages.clear()
        messages.add(defaultWelcome(selectedModel))
        inputText = ""
        attachedFileName = null
        if (id != null) {
            histories = histories.filterNot { it.id == id }
            scope.launch { chatHistoryManager.delete(id) }
        }
        showClearConfirm = false
        onShowSnackbar("Riwayat dan session aktif dihapus.")
    }

    fun sendPrompt() {
        val prompt = inputText.trim()
        if (prompt.isBlank() || isThinking) return
        messages.add(ChatMessage(isUser = true, text = prompt))
        inputText = ""
        attachedFileName = null
        isThinking = true
        scope.launch {
            val activeId = currentHistoryId
            val sessionId = histories.find { it.id == activeId }?.sessionId
            when (val result = repository.chatStromAi(prompt, sessionId, selectedModel, systemPrompt.ifBlank { null })) {
                is ResultState.Success -> {
                    val response = result.data
                    messages.add(ChatMessage(isUser = false, text = response.text))
                    ensureHistory()
                    val h = histories.find { it.id == currentHistoryId }
                    if (h != null) {
                        val updated = h.copy(sessionId = response.sessionId ?: h.sessionId, model = selectedModel, systemPrompt = systemPrompt, messages = toPersisted(messages), updatedAt = System.currentTimeMillis())
                        histories = listOf(updated) + histories.filterNot { it.id == h.id }
                        chatHistoryManager.upsert(updated)
                    }
                }
                is ResultState.Error -> {
                    messages.add(ChatMessage(isUser = false, text = "Gagal mendapatkan respons AI: ${result.message}", isError = true))
                    onShowSnackbar("Gagal: ${result.message}")
                }
            }
            isThinking = false
        }
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        StromAiTopBar(
            selectedModel = selectedModel,
            systemPrompt = systemPrompt,
            isCompact = isCompact,
            overflowExpanded = overflowMenuExpanded,
            onOverflowExpandedChange = { overflowMenuExpanded = it },
            onOpenModelSheet = { modelSheetOpen = true },
            onOpenPromptDialog = { showPromptDialog = true; overflowMenuExpanded = false },
            onOpenHistorySheet = { historySheetOpen = true; overflowMenuExpanded = false },
            onNewChat = { startNewChat(); overflowMenuExpanded = false },
            onClearChat = { showClearConfirm = true; overflowMenuExpanded = false }
        )

        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(horizontal = if (isCompact) 10.dp else 20.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 4.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    ChatBubble(
                        message = message,
                        aiName = selectedModel.shortName,
                        isCompact = isCompact,
                        onCopy = {
                            clipboard.setText(AnnotatedString(message.text))
                            onShowSnackbar("Pesan disalin.")
                        }
                    )
                }
                if (isThinking) {
                    item {
                        Row(
                            Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Surface1)
                                .border(1.dp, Border, RoundedCornerShape(12.dp))
                                .padding(horizontal = 12.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(Modifier.size(15.dp), color = TextPrimary, strokeWidth = 2.dp)
                            Spacer(Modifier.width(9.dp))
                            Text("${selectedModel.shortName} sedang memproses...", color = TextPrimary, fontSize = 12.sp)
                        }
                    }
                }
            }

            if (showScrollToBottom) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 8.dp)
                        .alpha(scrollButtonAlpha)
                        .clip(CircleShape)
                        .clickable {
                            scope.launch { listState.animateScrollToItem(messages.lastIndex.coerceAtLeast(0)) }
                        },
                    color = Surface2,
                    shape = CircleShape,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Border)
                ) {
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Terbaru", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        StromAiInputBar(
            inputText = inputText,
            onInputChange = { inputText = it },
            selectedModel = selectedModel,
            attachedFileName = attachedFileName,
            isThinking = isThinking,
            isCompact = isCompact,
            onAttachClick = { filePicker.launch("*/*") },
            onSend = ::sendPrompt,
            onRemoveAttachment = { attachedFileName = null }
        )
    }

    if (modelSheetOpen) {
        ModalBottomSheet(
            onDismissRequest = { modelSheetOpen = false },
            sheetState = modelSheetState,
            containerColor = Surface1
        ) {
            Column(Modifier.padding(bottom = 24.dp)) {
                Text(
                    "Pilih model AI",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                )
                HorizontalDivider(color = Border)
                modelOrder.forEach { model ->
                    val active = model == selectedModel
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (model != selectedModel) {
                                    persistCurrent()
                                    selectedModel = model
                                    currentHistoryId = null
                                    systemPrompt = ""
                                    attachedFileName = null
                                    inputText = ""
                                    messages.clear()
                                    messages.add(defaultWelcome(model))
                                }
                                modelSheetOpen = false
                            }
                            .padding(horizontal = 18.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.SmartToy,
                            contentDescription = null,
                            tint = if (active) AccentGreen else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                model.displayName,
                                color = TextPrimary,
                                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 14.sp
                            )
                            Text(
                                if (model.supportsFileUpload) "Mendukung upload file" else "Chat teks saja",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        if (active) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Aktif", tint = AccentGreen, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    if (historySheetOpen) {
        ModalBottomSheet(
            onDismissRequest = { historySheetOpen = false },
            sheetState = historySheetState,
            containerColor = Surface1
        ) {
            Column(Modifier.padding(bottom = 24.dp)) {
                Text(
                    "Riwayat chat",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                )
                HorizontalDivider(color = Border)
                if (histories.isEmpty()) {
                    Text(
                        "Belum ada riwayat chat.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 20.dp)
                    )
                } else {
                    val rowHeight = 58.dp
                    val sheetHeight: Dp = rowHeight * histories.take(30).size.coerceAtMost(6)
                    LazyColumn(modifier = Modifier.height(sheetHeight)) {
                        items(histories.take(30), key = { it.id }) { item ->
                            val active = item.id == currentHistoryId
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { loadHistory(item) }
                                    .padding(horizontal = 18.dp, vertical = 13.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        item.title,
                                        color = TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        "${item.model.shortName} • ${item.messages.count { it.isUser }} pesan",
                                        color = TextSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                                if (active) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = "Aktif", tint = AccentGreen, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPromptDialog) {
        AlertDialog(
            onDismissRequest = { showPromptDialog = false },
            containerColor = Surface1,
            title = { Text("Custom prompt AI", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "Instruksi ini akan diterapkan sebagai system prompt untuk model yang aktif.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    OutlinedTextField(
                        value = systemPrompt,
                        onValueChange = { systemPrompt = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 5,
                        maxLines = 9,
                        placeholder = { Text("Contoh: Kamu adalah asisten coding yang ringkas dan fokus...", color = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = TextPrimary, unfocusedBorderColor = Border, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary, focusedContainerColor = Bg, unfocusedContainerColor = Bg)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showPromptDialog = false; persistCurrent(); onShowSnackbar("Custom prompt disimpan.") }) { Text("Simpan", color = TextPrimary) }
            },
            dismissButton = { TextButton(onClick = { systemPrompt = "" }) { Text("Kosongkan", color = TextSecondary) } }
        )
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            containerColor = Surface1,
            title = { Text("Hapus chat ini?", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("Riwayat percakapan aktif ini akan dihapus secara permanen.", color = TextSecondary, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = ::resetCurrentSession) { Text("Hapus", color = ErrorRed) }
            },
            dismissButton = { TextButton(onClick = { showClearConfirm = false }) { Text("Batal", color = TextSecondary) } }
        )
    }
}

@Composable
private fun StromAiTopBar(
    selectedModel: StromAiModel,
    systemPrompt: String,
    isCompact: Boolean,
    overflowExpanded: Boolean,
    onOverflowExpandedChange: (Boolean) -> Unit,
    onOpenModelSheet: () -> Unit,
    onOpenPromptDialog: () -> Unit,
    onOpenHistorySheet: () -> Unit,
    onNewChat: () -> Unit,
    onClearChat: () -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Header)
            .border(1.dp, Border, RoundedCornerShape(14.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Surface2)
                    .border(1.dp, Border, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Psychology, contentDescription = "AI", tint = TextPrimary, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("STROM AI", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp, fontSize = 18.sp)
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Surface2)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("v${BuildConfig.VERSION_NAME}", color = TextSecondary, fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
                    }
                }
                Text(
                    text = if (systemPrompt.isBlank()) "Interactive AI Console · History tersimpan lokal" else "Interactive AI Console · Custom prompt aktif",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(Modifier.width(6.dp))
            IconButton(onClick = onOpenHistorySheet, modifier = Modifier.testTag("btn_open_chat_history")) {
                Icon(Icons.Default.History, contentDescription = "Riwayat chat", tint = TextSecondary, modifier = Modifier.size(20.dp))
            }
            Box {
                IconButton(onClick = { onOverflowExpandedChange(true) }, modifier = Modifier.testTag("btn_ai_overflow_menu")) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Menu lainnya", tint = TextSecondary, modifier = Modifier.size(20.dp))
                }
                DropdownMenu(
                    expanded = overflowExpanded,
                    onDismissRequest = { onOverflowExpandedChange(false) },
                    modifier = Modifier.background(Surface1)
                ) {
                    DropdownMenuItem(
                        text = { Text("Chat baru", color = TextPrimary) },
                        leadingIcon = { Icon(Icons.Default.AddComment, contentDescription = null, tint = TextSecondary) },
                        onClick = onNewChat
                    )
                    DropdownMenuItem(
                        text = { Text("Custom prompt", color = TextPrimary) },
                        leadingIcon = { Icon(Icons.Default.Tune, contentDescription = null, tint = TextSecondary) },
                        onClick = onOpenPromptDialog
                    )
                    HorizontalDivider(color = Border)
                    DropdownMenuItem(
                        text = { Text("Hapus chat ini", color = ErrorRed) },
                        leadingIcon = { Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = ErrorRed) },
                        onClick = onClearChat
                    )
                }
            }
        }

        // Baris pemilih model dipisah dari baris judul supaya tidak berdesakan di layar sempit,
        // dan lebar tombol menyesuaikan konten (bukan dipaksa mepet ikon-ikon lain).
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
                .padding(bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(11.dp))
                    .clickable { onOpenModelSheet() }
                    .testTag("btn_open_ai_model_menu"),
                color = Surface1,
                shape = RoundedCornerShape(11.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Border)
            ) {
                Row(
                    Modifier.padding(start = 10.dp, end = 8.dp, top = 7.dp, bottom = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.SmartToy, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        selectedModel.shortName,
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.widthIn(max = if (isCompact) 130.dp else 220.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Default.ExpandMore, contentDescription = "Ganti model", tint = TextSecondary, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
private fun StromAiInputBar(
    inputText: String,
    onInputChange: (String) -> Unit,
    selectedModel: StromAiModel,
    attachedFileName: String?,
    isThinking: Boolean,
    isCompact: Boolean,
    onAttachClick: () -> Unit,
    onSend: () -> Unit,
    onRemoveAttachment: () -> Unit
) {
    val canSend = inputText.isNotBlank() && !isThinking

    /*
     * FIX (celah kecil tersisa):
     * imePadding() dan navigationBarsPadding() dipasang terpisah sebelumnya.
     * Saat keyboard terbuka, WindowInsets.ime di sebagian device SUDAH
     * mencakup ruang navigation bar di dalamnya — jadi memasang keduanya
     * sebagai dua modifier terpisah menjumlahkan inset tersebut dua kali,
     * menyisakan celah kecil (selisih beberapa dp) di atas keyboard.
     *
     * Perbaikan: gabungkan (union) kedua insets lalu ambil HANYA sisi bawah
     * dengan .only(WindowInsetsSides.Bottom), diterapkan sekali lewat
     * windowInsetsPadding(). Ini memastikan nilai bottom inset yang dipakai
     * adalah max(ime, navigationBars) — bukan ime + navigationBars.
     */
    val bottomInsets = WindowInsets.ime
        .union(WindowInsets.navigationBars)
        .only(WindowInsetsSides.Bottom)

    Column(
        Modifier
            .fillMaxWidth()
            .windowInsetsPadding(bottomInsets)
            .background(Header)
            .border(1.dp, Border)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        if (attachedFileName != null && selectedModel == StromAiModel.STROM) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Surface1)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.AttachFile, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    attachedFileName,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onRemoveAttachment, modifier = Modifier.size(20.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Hapus lampiran", tint = TextSecondary, modifier = Modifier.size(13.dp))
                }
            }
        }
        Row(verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(
                value = inputText,
                onValueChange = onInputChange,
                placeholder = {
                    Text(
                        if (isCompact) "Tulis pesan..." else "Tulis pesan untuk ${selectedModel.shortName}...",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                modifier = Modifier.weight(1f).testTag("input_strom_ai_prompt"),
                maxLines = 5,
                leadingIcon = if (selectedModel == StromAiModel.STROM) {
                    {
                        IconButton(onClick = onAttachClick, enabled = !isThinking, modifier = Modifier.testTag("btn_upload_strom_file")) {
                            Icon(Icons.Default.AttachFile, contentDescription = "Upload file", tint = if (!isThinking) TextPrimary else TextSecondary)
                        }
                    }
                } else null,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TextPrimary, unfocusedBorderColor = Border,
                    focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary,
                    focusedContainerColor = Surface1, unfocusedContainerColor = Surface1,
                    cursorColor = TextPrimary, focusedPlaceholderColor = TextSecondary, unfocusedPlaceholderColor = TextSecondary
                ),
                shape = RoundedCornerShape(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            IconButton(
                onClick = onSend,
                enabled = canSend,
                modifier = Modifier.size(46.dp).clip(CircleShape).background(if (canSend) SendOn else Surface2).testTag("btn_send_strom_prompt")
            ) {
                if (isThinking) {
                    CircularProgressIndicator(Modifier.size(18.dp), color = TextSecondary, strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Default.Send, contentDescription = "Kirim", tint = if (canSend) Bg else TextSecondary, modifier = Modifier.size(19.dp))
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(message: ChatMessage, aiName: String, isCompact: Boolean, onCopy: () -> Unit) {
    val user = message.isUser
    val maxWidthFraction = if (isCompact) {
        if (user) .88f else .96f
    } else {
        if (user) .72f else .82f
    }
    val bubbleColor = when {
        message.isError -> Color(0xFF2A1B1B)
        user -> Surface2
        else -> Surface1
    }
    val borderColor = if (message.isError) Color(0xFF7F1D1D) else Border

    Column(horizontalAlignment = if (user) Alignment.End else Alignment.Start, modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth(maxWidthFraction)
                .clip(RoundedCornerShape(14.dp))
                .background(bubbleColor)
                .border(1.dp, borderColor, RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Column {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (user) "YOU" else aiName,
                        color = if (message.isError) Color(0xFFF87171) else TextSecondary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = .8.sp,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onCopy, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Salin", tint = TextSecondary, modifier = Modifier.size(14.dp))
                    }
                }
                Spacer(Modifier.height(3.dp))
                Text(message.text, color = TextPrimary, fontSize = 13.sp, lineHeight = 19.sp)
            }
        }
    }
}
