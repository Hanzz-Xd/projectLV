package com.baklava.projectlv.data.remote

import com.baklava.projectlv.data.network.HttpClientProvider
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

data class SflBypassResult(
    val url: String,
    val intermediate: String?,
    val needsManual: Boolean,
    val steps: Int?,
    val elapsedMs: Long?,
    val method: String?
)

class SflBypassClient {
    companion object {
        private const val API_URL = "https://safebypass.vercel.app/api/bypass"
        private const val API_ORIGIN = "https://safebypass.vercel.app"
    }

    private val client = HttpClientProvider.okHttpClient

    fun bypass(target: String): SflBypassResult {
        val normalized = target.trim()
        require(isSupported(normalized)) { "Hanya link https://sfl.gl/ yang didukung." }

        val body = JSONObject().apply {
            put("url", normalized)
            put("apiKey", "")
        }.toString().toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url(API_URL)
            .post(body)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36")
            .header("Accept", "application/json, text/plain, */*")
            .header("Content-Type", "application/json")
            .header("sec-ch-ua-platform", "\"Android\"")
            .header("sec-ch-ua", "\"Chromium\";v=\"154\", \"Google Chrome\";v=\"154\", \"Not A(Brand\";v=\"99\"")
            .header("sec-ch-ua-mobile", "?1")
            .header("origin", API_ORIGIN)
            .header("sec-fetch-site", "same-origin")
            .header("sec-fetch-mode", "cors")
            .header("sec-fetch-dest", "empty")
            .header("referer", "$API_ORIGIN/")
            .header("accept-language", "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7")
            .header("priority", "u=1, i")
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IllegalStateException(parseError(raw).ifBlank { "Bypass gagal (HTTP ${response.code})." })
            }
            if (raw.isBlank()) {
                throw IllegalStateException("Respons bypass kosong.")
            }

            val json = runCatching { JSONObject(raw) }
                .getOrElse { throw IllegalStateException("Respons API bypass bukan JSON yang valid.") }

            if (!json.optBoolean("ok", false)) {
                throw IllegalStateException(parseError(raw).ifBlank { "Link SFL tidak dapat diproses." })
            }

            val resolved = json.optString("url").trim()
            if (!resolved.startsWith("http://") && !resolved.startsWith("https://")) {
                throw IllegalStateException("API tidak mengembalikan URL tujuan yang valid.")
            }

            return SflBypassResult(
                url = resolved,
                intermediate = json.optString("intermediate").takeIf { it.isNotBlank() },
                needsManual = json.optBoolean("needsManual", false),
                steps = json.optInt("steps").takeIf { json.has("steps") },
                elapsedMs = json.optLong("ms").takeIf { json.has("ms") },
                method = json.optString("method").takeIf { it.isNotBlank() }
            )
        }
    }

    private fun isSupported(value: String): Boolean = runCatching {
        val uri = android.net.Uri.parse(value)
        val host = uri.host?.lowercase().orEmpty()
        host == "sfl.gl" && uri.scheme.equals("https", ignoreCase = true)
    }.getOrDefault(false)

    private fun parseError(body: String): String {
        if (body.isBlank()) return ""
        return runCatching {
            val json = JSONObject(body)
            json.optString("message")
                .ifBlank { json.optString("error") }
                .ifBlank { json.optString("detail") }
        }.getOrDefault(body.take(300))
    }
}
