package com.baklava.projectlv.ui.theme

import androidx.compose.ui.graphics.Color

// ====================================================================
// PROJECT-LEVIATHAN MONOCHROME & NEUTRAL PALETTE
// Sleek, modern, and non-flashy dark-first theme
// ====================================================================

// Base Dark Canvas & Surfaces (Black / Charcoal / Obsidian)
val CyberBlack = Color(0xFF0C0D10)           // Deep luxury black canvas
val CyberDarkNavy = Color(0xFF14161A)        // Primary card container
val CyberSurface = Color(0xFF1A1C22)         // Elevated surface
val CyberSurfaceVariant = Color(0xFF22252C)  // Subtle container
val CyberCardBorder = Color(0xFF2A2D36)      // Crisp understated border

// Subtle Highlights & Text (Pure White, Light Silver, Platinum)
val BrightCyan = Color(0xFFE5E7EB)           // Titanium / Off-white primary
val BrightCyanDark = Color(0xFFCBD5E1)       // Light slate grey
val BrightCyanContainer = Color(0xFF22252C)   // Neutral dark container

val BrightMagenta = Color(0xFFD1D5DB)        // Cool silver accent
val BrightMagentaDark = Color(0xFF9CA3AF)    // Steel grey
val BrightMagentaContainer = Color(0xFF262931)

// Muted, Non-Garish Status Tones
val BrightGreen = Color(0xFF34D399)          // Muted sage green (Online / Success)
val BrightGreenContainer = Color(0xFF162B20)

val BrightRed = Color(0xFFF87171)            // Muted coral red (Offline / Error)
val BrightRedContainer = Color(0xFF341A1A)

val BrightAmber = Color(0xFFFBBF24)          // Muted warm amber (Warning / Pending)
val BrightAmberContainer = Color(0xFF332714)

// Neutral Text & Icons
val MutedGrey = Color(0xFF9AA0A6)            // Secondary body text
val DarkGrey = Color(0xFF6B7280)             // Low-emphasis tertiary text
val SubtleBorder = Color(0xFF2A2D36)

// Subtle Alpha Accents (Non-glowing, gentle highlight)
val CyberGlowCyan = Color(0x14E5E7EB)
val CyberGlowMagenta = Color(0x14D1D5DB)

// Light theme neutral palette (Clean Minimalist Grey & White)
val LightBg = Color(0xFFF6F8FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEAEEF2)
val LightBorder = Color(0xFFD0D7DE)


