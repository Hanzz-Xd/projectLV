# ProjectLV Firebase control plane — Spark compatible

ProjectLV uses Firebase Authentication + Cloud Firestore + App Check. The Android client does **not** use Anonymous Auth anymore.

## Authentication model

- Normal users: Firebase Authentication **Email/Password**.
- Admin/owner: the same Firebase email/password account, additionally provisioned in `admins/{uid}` with `enabled: true`, `role`, and the intended `deviceIdHash`.
- There is no silent fallback to Anonymous Auth.
- Device ownership is stored in `devices/{deviceIdHash}.ownerUid` and `ownerEmail` and is checked by Firestore Rules.

## Required Firebase Console configuration

1. Authentication → Sign-in method → enable **Email/Password**.
2. Disable **Anonymous** after the legacy anonymous-user cleanup is complete.
3. Firestore Database → create/verify the database.
4. App Check → Android app → configure **Play Integrity** for release builds.
5. For debug/sideloaded builds, register the App Check debug token printed by the debug provider.
6. Deploy `firestore.rules`.

## Admin provisioning

Create `admins/{ADMIN_AUTH_UID}` manually in Firestore:

```json
{
  "enabled": true,
  "role": "owner",
  "deviceIdHash": "64-character-lowercase-sha256"
}
```

The admin panel still uses the existing hidden entry gesture and preserves the existing visual style, but it now requires a real email/password-authenticated admin record.

## Device document

`devices/{deviceIdHash}` stores:

- `ownerUid`, `ownerEmail`
- device manufacturer/model/Android/app version
- `lastIp`, `lastSeenAt`, `lastTool`, usage counters
- `banned`, `banStartedAt`, `banExpiresAt`, `banReason`, `banWarning`
- violation counters

The old `trialStartedAt`, `trialExpiresAt`, and `accessExpiresAtOverride` fields are no longer created or read by the app.

The old `securityEvents` subcollection is also no longer written by the new client. Existing security-event data can be removed during migration.

## Global control / maintenance mode

`control/global` keeps the existing fields:

- `enabled` — when `false`, normal users see maintenance mode.
- `message`
- `globalExpiresAt` — **global application** expiry only.
- `toolStates`, `apiControls`
- `updatedAt`, `updatedBy`

An authenticated admin/owner bound in `admins/{uid}` bypasses maintenance mode so the admin can still open and navigate the app.

## Bug reports

`bugReports/{reportId}` is now the single source of truth for both automatic and user-submitted bug reports. `ErrorReportManager.sendReport()` writes to Firestore instead of launching a mail client. Failed/offline submissions are queued in memory and retried when connectivity returns.

## Migration / cleanup

Because the project stays on the Spark plan, privileged deletion of other Firebase Authentication accounts cannot be performed securely by the Android client. Use the included Admin SDK scripts from a trusted machine.

### Legacy anonymous users + linked devices

```bash
cd app/firebase/tools
npm install
export GOOGLE_APPLICATION_CREDENTIALS=/absolute/path/service-account.json
export FIREBASE_PROJECT_ID=projectlv-6036b
node purge-legacy-anonymous-users.mjs
node purge-legacy-anonymous-users.mjs --execute
```

The first command is a dry run. The second permanently removes matching legacy Anonymous Auth users and their linked `devices/{id}` documents plus `securityEvents`.

### Remove legacy per-device expiry and security logs

```bash
cd app/firebase/tools
node cleanup-legacy-expiry.mjs
node cleanup-legacy-expiry.mjs --execute
```

Run the dry run first and keep a backup/export before the destructive command.

## Account profile (name, email, password)

The app now has a **Setelan → Lihat Akun** screen and a **Nama** field on registration.

- `accounts/{uid}` gets a `name` field on registration.
- The owner may update only `name`, `email` and `updatedAt` on their own account document
  (`email` must equal the verified Firebase Auth email). Every other field stays admin-only.
- Changing the email uses `verifyBeforeUpdateEmail`: Firebase sends a verification link to the
  new address and the change only takes effect after the link is opened.
- Passwords are never stored in Firestore. The "view password" toggle only works with the
  password typed during the current app session (kept in memory, cleared on log out).

**You must redeploy the rules after updating the app**, otherwise name/email sync is denied:

```bash
cd app/firebase
firebase deploy --only firestore:rules
```

## Security limitations on Spark

Firestore Security Rules can strongly enforce:

- authenticated `request.auth` checks,
- account ownership of device records,
- admin-only Firestore writes/deletes,
- App Check enforcement on Firebase requests.

They cannot make Android client code a fully trusted server. In particular, an attacker controlling a modified APK can call Firebase client APIs themselves. There is also no privileged server-side Auth operation available to the app for deleting other users or changing their passwords. For those operations use the Firebase Console/Admin SDK from a trusted environment.

App Check/Play Integrity should be enforced in Firebase Console after the release setup is verified.

## API-key limitation

A credential required directly by the Android app cannot be made secret inside the APK. Firestore rules/App Check protect the Firebase control plane, not secrets embedded in client requests.
