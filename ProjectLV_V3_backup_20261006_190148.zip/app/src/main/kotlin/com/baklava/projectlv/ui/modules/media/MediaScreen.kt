package com.baklava.projectlv.ui.modules.media

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Share
import com.baklava.projectlv.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import com.baklava.projectlv.ui.components.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import com.baklava.projectlv.ui.components.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.baklava.projectlv.data.models.MediaFileType
import com.baklava.projectlv.data.models.MediaUploadResult
import com.baklava.projectlv.data.repository.LeviathanRepository
import com.baklava.projectlv.data.repository.ResultState
import com.baklava.projectlv.ui.components.AppWindowSize
import com.baklava.projectlv.ui.components.ModuleHeaderCard
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.BrightMagenta
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.launch
import java.io.File
import java.text.DecimalFormat

/*
 * CATATAN IMPLEMENTASI:
 * - Ketiga tab (Upload, Upscale, RemoveBG) memanggil LeviathanRepository yang sudah
 *   berisi fungsi uploadMediaFile(), upscaleImage(), removeBackground() — bukan
 *   implementasi network baru. Semua request berjalan di Dispatchers.IO lewat
 *   HttpClientProvider.okHttpClient yang sama dipakai module lain (lihat repository).
 * - Tidak ada dependency baru: Coil dan Media3 sudah ada di build.gradle.kts,
 *   dipakai kembali di sini untuk preview gambar.
 * - File picker memakai ActivityResultContracts.GetContent(), pola yang sama
 *   dengan Base64LabScreen (EncodeFileTab/DecodeFileTab).
 */

@Composable
fun MediaScreen(
    repository: LeviathanRepository,
    windowSize: AppWindowSize,
    onShowSnackbar: (String) -> Unit
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("Upload File", "Upscale Gambar", "Remove BG")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
    ) {
        ModuleHeaderCard(
            icon = Icons.Default.Image,
            title = "MEDIA",
            subtitle = "Upload File, Upscale Gambar (2x/4x/8x), dan Remove Background",
            modifier = Modifier.padding(16.dp)
        )

        ScrollableTabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = CyberDarkNavy,
            contentColor = BrightCyan,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = BrightCyan
                )
            },
            divider = { Box(modifier = Modifier.height(1.dp).background(CyberCardBorder)) }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) BrightCyan else MutedGrey
                            )
                        )
                    },
                    modifier = Modifier.testTag("tab_media_$index")
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            when (selectedTabIndex) {
                0 -> UploadFileTab(repository, onShowSnackbar)
                1 -> UpscaleTab(repository, onShowSnackbar)
                2 -> RemoveBgTab(repository, onShowSnackbar)
            }
        }
    }
}

// ----------------------------------------------------------------
// 1. UPLOAD FILE TAB
// ----------------------------------------------------------------
@Composable
private fun UploadFileTab(
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var pickedFileName by remember { mutableStateOf<String?>(null) }
    var pickedFileSize by remember { mutableStateOf<Long?>(null) }
    var isUploading by remember { mutableStateOf(false) }
    var uploadResult by remember { mutableStateOf<MediaUploadResult?>(null) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        // User membatalkan pemilihan file (uri null) -> tidak melakukan apa pun, tidak crash.
        if (uri == null) return@rememberLauncherForActivityResult
        if (isUploading) return@rememberLauncherForActivityResult // cegah trigger ganda tak sengaja

        scope.launch {
            isUploading = true
            uploadResult = null
            try {
                var displayName = "file"
                var size = 0L
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIndex >= 0) displayName = cursor.getString(nameIndex) ?: displayName
                        if (sizeIndex >= 0) size = cursor.getLong(sizeIndex)
                    }
                }
                pickedFileName = displayName
                pickedFileSize = size

                val extension = displayName.substringAfterLast('.', "")
                val detectedType = MediaFileType.fromExtension(extension)
                val mimeType = context.contentResolver.getType(uri)
                    ?: detectedType?.defaultMime
                    ?: "application/octet-stream"

                if (detectedType == null) {
                    onShowSnackbar("Tipe file .$extension tidak didukung. Gunakan gambar, PDF, DOC, XLS, atau PPT.")
                    isUploading = false
                    return@launch
                }

                when (val res = repository.uploadMediaFile(uri, displayName, mimeType)) {
                    is ResultState.Success -> {
                        uploadResult = res.data
                        onShowSnackbar("File berhasil di-upload!")
                    }
                    is ResultState.Error -> {
                        onShowSnackbar("Gagal upload: ${res.message}")
                    }
                }
            } catch (e: Exception) {
                onShowSnackbar("Gagal memproses file: ${e.message}")
            } finally {
                isUploading = false
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Mendukung: PNG, JPG, JPEG, GIF, WEBP, PDF, DOC/DOCX, XLS/XLSX, PPT/PPTX",
                    style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey)
                )

                Button(
                    onClick = {
                        if (!isUploading) {
                            filePicker.launch("*/*")
                        }
                    },
                    enabled = !isUploading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_select_file_media_upload"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightMagenta, contentColor = Color.White)
                ) {
                    if (isUploading) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Mengunggah File...")
                    } else {
                        Icon(imageVector = Icons.Default.CloudUpload, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Pilih & Upload File", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        }

        if (uploadResult != null) {
            val result = uploadResult!!
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BrightGreen.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = BrightGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "UPLOAD BERHASIL",
                            style = MaterialTheme.typography.labelSmall.copy(color = BrightGreen, fontWeight = FontWeight.Bold)
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(BrightCyan.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.InsertDriveFile, contentDescription = null, tint = BrightCyan, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = result.originalName,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Color.White),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${formatBytes(result.size)} · ${result.mimetype}",
                                style = MaterialTheme.typography.labelSmall.copy(color = MutedGrey)
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberBlack)
                            .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = result.directUrl,
                            style = MaterialTheme.typography.bodySmall.copy(color = BrightCyan),
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                clipboard.setText(AnnotatedString(result.directUrl))
                                onShowSnackbar("Link disalin ke clipboard.")
                            },
                            modifier = Modifier.weight(1f).testTag("btn_copy_upload_url"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Salin Link")
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------
// 2. UPSCALE TAB
// ----------------------------------------------------------------
@Composable
private fun UpscaleTab(
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var selectedScale by remember { mutableIntStateOf(2) }

    var isBusy by remember { mutableStateOf(false) } // true selama upload ATAU upscale berjalan
    var busyLabel by remember { mutableStateOf("") }
    var resultFile by remember { mutableStateOf<File?>(null) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        selectedImageUri = uri
        resultFile = null
    }

    fun runUpscale() {
        val uri = selectedImageUri ?: return
        if (isBusy) return // cegah request ganda tidak sengaja

        scope.launch {
            isBusy = true
            resultFile = null
            try {
                // Langkah 1: upload gambar dulu untuk mendapatkan directUrl publik
                busyLabel = "Mengunggah gambar..."
                val fileName = "upscale_source_${System.currentTimeMillis()}.png"
                val mimeType = context.contentResolver.getType(uri) ?: "image/png"

                val uploadRes = repository.uploadMediaFile(uri, fileName, mimeType)
                val directUrl = when (uploadRes) {
                    is ResultState.Success -> uploadRes.data.directUrl
                    is ResultState.Error -> {
                        onShowSnackbar("Gagal upload gambar: ${uploadRes.message}")
                        isBusy = false
                        return@launch
                    }
                }

                // Langkah 2: panggil upscale dengan directUrl hasil upload
                busyLabel = "Memproses upscale ${selectedScale}x..."
                when (val upscaleRes = repository.upscaleImage(directUrl, selectedScale)) {
                    is ResultState.Success -> {
                        resultFile = File(upscaleRes.data.localFilePath)
                        onShowSnackbar("Upscale ${selectedScale}x berhasil!")
                    }
                    is ResultState.Error -> {
                        onShowSnackbar("Gagal upscale: ${upscaleRes.message}")
                    }
                }
            } catch (e: Exception) {
                onShowSnackbar("Terjadi kesalahan: ${e.message}")
            } finally {
                isBusy = false
                busyLabel = ""
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { if (!isBusy) imagePicker.launch("image/*") },
                    enabled = !isBusy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_select_image_upscale"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightMagenta, contentColor = Color.White)
                ) {
                    Icon(imageVector = Icons.Default.Image, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Pilih Gambar", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                }

                if (selectedImageUri != null) {
                    AsyncImage(
                        model = ImageRequest.Builder(context).data(selectedImageUri).crossfade(true).build(),
                        contentDescription = "Gambar dipilih",
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyberBlack)
                            .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp)),
                        contentScale = ContentScale.Fit
                    )

                    Text(
                        text = "PILIH TINGKAT UPSCALE:",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        listOf(2, 4, 8).forEach { scale ->
                            val isSelected = selectedScale == scale
                            OutlinedButton(
                                onClick = { selectedScale = scale },
                                enabled = !isBusy,
                                modifier = Modifier.weight(1f).testTag("btn_scale_${scale}x"),
                                shape = RoundedCornerShape(8.dp),
                                colors = if (isSelected) {
                                    ButtonDefaults.outlinedButtonColors(containerColor = BrightMagenta, contentColor = Color.White)
                                } else {
                                    ButtonDefaults.outlinedButtonColors(contentColor = MutedGrey)
                                }
                            ) {
                                Text("${scale}x", fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }

                    Button(
                        onClick = { runUpscale() },
                        enabled = !isBusy,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_run_upscale"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
                    ) {
                        if (isBusy) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = CyberBlack, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(busyLabel.ifBlank { "Memproses..." })
                        } else {
                            Icon(imageVector = Icons.Default.HighQuality, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Upscale ${selectedScale}x", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        if (resultFile != null && resultFile!!.exists()) {
            MediaResultCard(
                title = "HASIL UPSCALE ${selectedScale}X",
                accentColor = BrightGreen,
                file = resultFile!!,
                repository = repository,
                onShowSnackbar = onShowSnackbar,
                downloadFileNamePrefix = "upscaled"
            )
        }
    }
}

// ----------------------------------------------------------------
// 3. REMOVE BACKGROUND TAB
// ----------------------------------------------------------------
@Composable
private fun RemoveBgTab(
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isProcessing by remember { mutableStateOf(false) }
    var resultFile by remember { mutableStateOf<File?>(null) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        selectedImageUri = uri
        resultFile = null
    }

    fun runRemoveBg() {
        val uri = selectedImageUri ?: return
        if (isProcessing) return // cegah request ganda tidak sengaja

        scope.launch {
            isProcessing = true
            resultFile = null
            try {
                when (val res = repository.removeBackground(uri)) {
                    is ResultState.Success -> {
                        resultFile = File(res.data.localFilePath)
                        onShowSnackbar("Background berhasil dihapus!")
                    }
                    is ResultState.Error -> {
                        onShowSnackbar("Gagal RemoveBG: ${res.message}")
                    }
                }
            } catch (e: Exception) {
                onShowSnackbar("Terjadi kesalahan: ${e.message}")
            } finally {
                isProcessing = false
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { if (!isProcessing) imagePicker.launch("image/*") },
                    enabled = !isProcessing,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_select_image_removebg"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightMagenta, contentColor = Color.White)
                ) {
                    Icon(imageVector = Icons.Default.Image, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Pilih Gambar", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                }

                if (selectedImageUri != null) {
                    AsyncImage(
                        model = ImageRequest.Builder(context).data(selectedImageUri).crossfade(true).build(),
                        contentDescription = "Gambar dipilih",
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyberBlack)
                            .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp)),
                        contentScale = ContentScale.Fit
                    )

                    Button(
                        onClick = { runRemoveBg() },
                        enabled = !isProcessing,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_run_removebg"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = CyberBlack, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Menghapus Background...")
                        } else {
                            Icon(imageVector = Icons.Default.AutoFixHigh, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Hapus Background", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        if (resultFile != null && resultFile!!.exists()) {
            MediaResultCard(
                title = "HASIL REMOVE BACKGROUND",
                accentColor = BrightGreen,
                file = resultFile!!,
                repository = repository,
                onShowSnackbar = onShowSnackbar,
                downloadFileNamePrefix = "removebg"
            )
        }
    }
}

// ----------------------------------------------------------------
// SHARED: KARTU HASIL GAMBAR (dipakai Upscale & RemoveBG)
// ----------------------------------------------------------------
@Composable
private fun MediaResultCard(
    title: String,
    accentColor: Color,
    file: File,
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit,
    downloadFileNamePrefix: String
) {
    val scope = rememberCoroutineScope()
    var isSaving by remember(file) { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall.copy(color = accentColor, fontWeight = FontWeight.Bold)
                )
            }

            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current).data(file).crossfade(true).build(),
                contentDescription = "Hasil gambar",
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(CyberBlack)
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp)),
                contentScale = ContentScale.Fit
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        if (isSaving) return@Button
                        scope.launch {
                            isSaving = true
                            try {
                                val bytes = file.readBytes()
                                val savedUri = repository.workspaceManager.saveToDownloads(
                                    "${downloadFileNamePrefix}_${System.currentTimeMillis()}.png",
                                    "image/png",
                                    bytes
                                )
                                if (savedUri != null) {
                                    onShowSnackbar("Gambar disimpan ke folder Download.")
                                } else {
                                    onShowSnackbar("Gagal menyimpan gambar.")
                                }
                            } catch (e: Exception) {
                                onShowSnackbar("Gagal menyimpan: ${e.message}")
                            } finally {
                                isSaving = false
                            }
                        }
                    },
                    enabled = !isSaving,
                    modifier = Modifier.weight(1f).testTag("btn_save_media_result"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightGreen, contentColor = CyberBlack)
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = CyberBlack, strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Simpan", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }

                OutlinedButton(
                    onClick = {
                        val fileUri = repository.workspaceManager.getFileProviderUri(file)
                        repository.workspaceManager.shareFileUri(fileUri, "image/png", "Bagikan Gambar")
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BrightCyan)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Bagikan")
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB")
    var value = bytes.toDouble()
    var unitIndex = 0
    while (value >= 1024 && unitIndex < units.lastIndex) {
        value /= 1024
        unitIndex++
    }
    return "${DecimalFormat("#,##0.#").format(value)} ${units[unitIndex]}"
}
