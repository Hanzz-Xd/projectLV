import admin from 'firebase-admin';

const projectId = process.env.FIREBASE_PROJECT_ID || undefined;
admin.initializeApp(projectId ? { projectId } : undefined);

const auth = admin.auth();
const db = admin.firestore();

async function listAllUsers() {
  const users = [];
  let pageToken;
  do {
    const page = await auth.listUsers(1000, pageToken);
    users.push(...page.users);
    pageToken = page.pageToken;
  } while (pageToken);
  return users;
}

const users = await listAllUsers();
const userUids = new Set(users.map((u) => u.uid));
const verifiedEmails = users.filter((u) => u.emailVerified).length;
const anonymous = users.filter((u) => u.providerData.length === 0 && !u.email && !u.phoneNumber);

const [devices, accounts, control] = await Promise.all([
  db.collection('devices').get(),
  db.collection('accounts').get(),
  db.collection('control').doc('global').get(),
]);

let validOwners = 0;
let orphanOwners = 0;
let bannedDevices = 0;
let legacyExpiryDevices = 0;
let securityEvents = 0;

for (const doc of devices.docs) {
  const data = doc.data();
  const ownerUid = String(data.ownerUid || '');
  if (userUids.has(ownerUid)) validOwners += 1;
  else orphanOwners += 1;
  if (data.banned === true) bannedDevices += 1;
  if (data.trialStartedAt !== undefined || data.trialExpiresAt !== undefined || data.accessExpiresAtOverride !== undefined) {
    legacyExpiryDevices += 1;
  }
  securityEvents += (await doc.ref.collection('securityEvents').listDocuments()).length;
}

const lockedAccounts = accounts.docs.filter((doc) => doc.get('locked') === true).length;
const maintenanceEnabled = control.exists && control.get('enabled') === false;

console.log(`Firebase project: ${projectId ?? '(default credentials)'}`);
console.log('');
console.log('=== AUTHENTICATION ===');
console.log(`Auth users                 : ${users.length}`);
console.log(`Email verified             : ${verifiedEmails}`);
console.log(`Anonymous legacy users     : ${anonymous.length}`);
console.log('');
console.log('=== FIRESTORE ===');
console.log(`Accounts documents         : ${accounts.size}`);
console.log(`Locked accounts            : ${lockedAccounts}`);
console.log(`Devices                    : ${devices.size}`);
console.log(`Devices with valid owner   : ${validOwners}`);
console.log(`Orphan device owners       : ${orphanOwners}`);
console.log(`Banned devices             : ${bannedDevices}`);
console.log(`Legacy expiry devices      : ${legacyExpiryDevices}`);
console.log(`Security events            : ${securityEvents}`);
console.log(`Maintenance active         : ${maintenanceEnabled}`);
console.log('');

if (anonymous.length > 0) {
  console.log('WARNING: Anonymous Auth users still exist. Review purge-legacy-anonymous-users.mjs.');
}
if (orphanOwners > 0) {
  console.log('WARNING: Some /devices records point to missing Auth UIDs. Do not auto-reassign them.');
}
if (legacyExpiryDevices > 0) {
  console.log('WARNING: Legacy expiry fields remain. Run cleanup-legacy-expiry.mjs --execute after review.');
}

console.log('\nAudit complete.');
