package com.baklava.projectlv.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey

/**
 * Kartu header standar untuk SETIAP layar fitur (Base64, Downloader, Magic Link,
 * Media, Py Obfuscator, Strom AI, Web Tools, Settings, Admin).
 *
 * Mengikuti gaya visual persis LeviathanHeaderCard di Dashboard:
 * - Card gelap monokrom (CyberDarkNavy) dengan border tipis 1dp (CyberCardBorder)
 * - Sudut membulat 14dp
 * - Kotak ikon bordered di kiri
 * - Judul tebal putih + badge kecil opsional untuk status/varian modul
 * - Subjudul abu-abu kecil di bawah judul
 * - Slot opsional "trailing" untuk status/aksi tambahan di kanan
 */
@Composable
fun ModuleHeaderCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    // Tidak menampilkan badge versi pada header kategori/tool secara default.
    // Badge tetap dapat dipakai oleh modul tertentu untuk status/varian non-versi.
    badgeText: String = "",
    trailing: (@Composable () -> Unit)? = null
) {
    Box(
        modifier = modifier
            .staggeredEntrance(index = 0, offsetY = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CyberDarkNavy)
            .border(1.dp, CyberCardBorder, RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(CyberSurfaceVariant)
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.material3.Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f, fill = true)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            letterSpacing = 0.5.sp
                        )
                    )
                    if (badgeText.isNotBlank()) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(CyberSurfaceVariant)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = badgeText,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = MutedGrey,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.width(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MutedGrey,
                        fontSize = 12.sp
                    )
                )
            }

            if (trailing != null) {
                Spacer(modifier = Modifier.width(8.dp))
                trailing()
            }
        }
    }
}

/**
 * Baris label kategori yang dipakai di Dashboard untuk mengelompokkan modul
 * berdasarkan fungsi (mis. "AI", "DOWNLOADER", "MEDIA TOOLS", "DEV TOOLS").
 * Konsisten dengan style section title "TOOL CENTER" yang sudah ada:
 * dot bulat kecil + judul + spacer + pill jumlah item.
 */
@Composable
fun CategoryLabelRow(
    title: String,
    countLabel: String,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .staggeredEntrance(index = 1, offsetY = 10.dp, durationMs = 380)
            .fillMaxWidth()
            .padding(vertical = 4.dp, horizontal = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(Color(0xFFE5E7EB))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall.copy(
                color = Color.White,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        )
        Spacer(modifier = Modifier.weight(1f))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(CyberSurfaceVariant)
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Text(
                text = countLabel,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = MutedGrey,
                    fontWeight = FontWeight.Medium
                )
            )
        }
    }
}
