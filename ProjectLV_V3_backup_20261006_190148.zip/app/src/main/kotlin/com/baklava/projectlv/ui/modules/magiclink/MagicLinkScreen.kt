package com.baklava.projectlv.ui.modules.magiclink

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Verified
import com.baklava.projectlv.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import com.baklava.projectlv.ui.components.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.data.repository.LeviathanRepository
import com.baklava.projectlv.data.repository.MagicLinkResult
import com.baklava.projectlv.data.repository.ResultState
import com.baklava.projectlv.ui.components.AppWindowSize
import com.baklava.projectlv.ui.components.ModuleHeaderCard
import com.baklava.projectlv.ui.theme.BrightAmber
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.BrightMagenta
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.launch

@Composable
fun MagicLinkScreen(
    repository: LeviathanRepository,
    windowSize: AppWindowSize,
    onShowSnackbar: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var selectedVersionIndex by remember { mutableIntStateOf(0) }
    val versions = listOf("V1", "V2")

    // Send state
    var sendEmail by remember { mutableStateOf("") }
    var isSending by remember { mutableStateOf(false) }
    var sendResultMsg by remember { mutableStateOf<String?>(null) }
    var isSendSuccess by remember { mutableStateOf(false) }

    // Verify state
    var verifyEmail by remember { mutableStateOf("") }
    var verifyLinkUrl by remember { mutableStateOf("") }
    var isVerifying by remember { mutableStateOf(false) }
    var verifyResult by remember { mutableStateOf<MagicLinkResult?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Module Header
        ModuleHeaderCard(
            icon = Icons.Default.AutoFixHigh,
            title = "MAGIC LINK",
            subtitle = "Alight Motion Activation & Verification Generator"
        )

        // Version Selector
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "VERSI ENGINE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MutedGrey,
                        fontFamily = FontFamily.Default
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                TabRow(
                    selectedTabIndex = selectedVersionIndex,
                    containerColor = CyberDarkNavy,
                    contentColor = Color.White,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedVersionIndex]),
                            color = BrightCyan
                        )
                    }
                ) {
                    versions.forEachIndexed { idx, title ->
                        Tab(
                            selected = selectedVersionIndex == idx,
                            onClick = { selectedVersionIndex = idx },
                            text = {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = if (selectedVersionIndex == idx) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selectedVersionIndex == idx) BrightCyan else MutedGrey
                                    )
                                )
                            },
                            modifier = Modifier.testTag("tab_version_$idx")
                        )
                    }
                }
            }
        }

        val currentVersion = if (selectedVersionIndex == 0) "v1" else "v2"

        // ----------------------------------------------------
        // CARD 1: SEND MAGIC LINK
        // ----------------------------------------------------
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = null,
                        tint = BrightCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "1. Send Magic Link",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }

                Text(
                    text = "Masukkan email Alight Motion untuk meminta pengiriman magic login link.",
                    style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey)
                )

                OutlinedTextField(
                    value = sendEmail,
                    onValueChange = { sendEmail = it },
                    label = { Text("Email Akun") },
                    placeholder = { Text("nama@gmail.com") },
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = MutedGrey) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_send_email"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrightCyan,
                        unfocusedBorderColor = CyberCardBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = CyberBlack,
                        unfocusedContainerColor = CyberBlack
                    ),
                    shape = RoundedCornerShape(8.dp)
                )

                Button(
                    onClick = {
                        val email = sendEmail.trim()
                        if (!email.contains("@") || !email.contains(".")) {
                            onShowSnackbar("Format email tidak valid.")
                            return@Button
                        }
                        scope.launch {
                            isSending = true
                            sendResultMsg = null
                            when (val res = repository.sendMagicLink(currentVersion, email)) {
                                is ResultState.Success<*> -> {
                                    val message = res.data as? String ?: "Magic link berhasil diproses."
                                    isSendSuccess = true
                                    sendResultMsg = message
                                    // Pre-fill verify email
                                    verifyEmail = email
                                    onShowSnackbar("Magic link berhasil dikirim.")
                                }
                                is ResultState.Error -> {
                                    isSendSuccess = false
                                    sendResultMsg = res.message
                                    onShowSnackbar("Gagal: ${res.message}")
                                }
                            }
                            isSending = false
                        }
                    },
                    enabled = sendEmail.isNotBlank() && !isSending,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("btn_send_magic_link"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
                ) {
                    if (isSending) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = CyberBlack)
                    } else {
                        Text(
                            text = "Kirim Magic Link",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }

                if (sendResultMsg != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSendSuccess) BrightGreen.copy(alpha = 0.12f) else BrightRed.copy(alpha = 0.12f))
                            .border(1.dp, if (isSendSuccess) BrightGreen.copy(alpha = 0.4f) else BrightRed.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = sendResultMsg.orEmpty(),
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (isSendSuccess) BrightGreen else BrightRed
                            )
                        )
                    }
                }
            }
        }

        // ----------------------------------------------------
        // CARD 2: VERIFY MAGIC LINK
        // ----------------------------------------------------
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = BrightMagenta,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "2. Verify Magic Link",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }

                Text(
                    text = "Masukkan email dan link verifikasi yang diterima di inbox/spam email Anda.",
                    style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey)
                )

                OutlinedTextField(
                    value = verifyEmail,
                    onValueChange = { verifyEmail = it },
                    label = { Text("Email Akun") },
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = MutedGrey) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_verify_email"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrightMagenta,
                        unfocusedBorderColor = CyberCardBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = CyberBlack,
                        unfocusedContainerColor = CyberBlack
                    ),
                    shape = RoundedCornerShape(8.dp)
                )

                OutlinedTextField(
                    value = verifyLinkUrl,
                    onValueChange = { verifyLinkUrl = it },
                    label = { Text("Link Magic dari Email (URL)") },
                    placeholder = { Text("https://alightcreative.com/...") },
                    leadingIcon = { Icon(Icons.Default.Link, contentDescription = null, tint = MutedGrey) },
                    modifier = Modifier.fillMaxWidth().testTag("input_verify_link_url"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrightMagenta,
                        unfocusedBorderColor = CyberCardBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = CyberBlack,
                        unfocusedContainerColor = CyberBlack
                    ),
                    shape = RoundedCornerShape(8.dp)
                )

                Button(
                    onClick = {
                        val email = verifyEmail.trim()
                        val link = verifyLinkUrl.trim()
                        if (email.isBlank() || link.isBlank()) {
                            onShowSnackbar("Lengkapi email dan link verifikasi.")
                            return@Button
                        }
                        if (!email.contains("@") || !email.contains(".")) {
                            onShowSnackbar("Format email tidak valid.")
                            return@Button
                        }
                        if (currentVersion == "v2" && !link.contains("alightcreative.com", ignoreCase = true)) {
                            onShowSnackbar("Link harus berisi URL Alight Creative yang dikirim lewat email.")
                            return@Button
                        }
                        scope.launch {
                            isVerifying = true
                            verifyResult = null
                            when (val res = repository.verifyMagicLink(currentVersion, email, link)) {
                                is ResultState.Success<*> -> {
                                    val result = res.data as? MagicLinkResult
                                    if (result != null) {
                                        verifyResult = result
                                        onShowSnackbar(if (result.isSuccess) "Verifikasi berhasil!" else "Verifikasi gagal.")
                                    } else {
                                        verifyResult = MagicLinkResult(isSuccess = false, message = "Respons verifikasi tidak valid.")
                                        onShowSnackbar("Respons verifikasi tidak valid.")
                                    }
                                }
                                is ResultState.Error -> {
                                    verifyResult = MagicLinkResult(isSuccess = false, message = res.message)
                                    onShowSnackbar("Error verifikasi: ${res.message}")
                                }
                            }
                            isVerifying = false
                        }
                    },
                    enabled = verifyEmail.isNotBlank() && verifyLinkUrl.isNotBlank() && !isVerifying,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("btn_verify_magic_link"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightMagenta, contentColor = Color.White)
                ) {
                    if (isVerifying) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                    } else {
                        Text(
                            text = "Verifikasi Link",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }

                if (verifyResult != null) {
                    val res = verifyResult!!
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (res.isSuccess) BrightGreen.copy(alpha = 0.12f) else BrightRed.copy(alpha = 0.12f))
                            .border(1.dp, if (res.isSuccess) BrightGreen.copy(alpha = 0.4f) else BrightRed.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(14.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (res.isSuccess) Icons.Default.CheckCircle else Icons.Default.Verified,
                                    contentDescription = null,
                                    tint = if (res.isSuccess) BrightGreen else BrightRed,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (res.isSuccess) "VERIFIKASI SUKSES" else "VERIFIKASI GAGAL",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (res.isSuccess) BrightGreen else BrightRed
                                    )
                                )
                            }

                            Text(
                                text = res.message,
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.White)
                            )

                            if (!res.email.isNullOrBlank()) {
                                Text(
                                    text = "Email: ${res.email}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Color.White)
                                )
                            }

                            if (!res.displayName.isNullOrBlank()) {
                                Text(
                                    text = "Nama: ${res.displayName}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Color.White)
                                )
                            }

                            if (!res.membershipStatus.isNullOrBlank()) {
                                Text(
                                    text = "Status: ${res.membershipStatus}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Color.White)
                                )
                            }

                            if (!res.planName.isNullOrBlank()) {
                                Text(
                                    text = "Paket: ${res.planName}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Color.White)
                                )
                            }

                            if (!res.validUntil.isNullOrBlank()) {
                                Text(
                                    text = "Berlaku sampai: ${res.validUntil}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Color.White)
                                )
                            }

                            if (res.premium != null) {
                                Text(
                                    text = "Premium: ${if (res.premium == true) "AKTIF" else "TIDAK AKTIF"}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = if (res.premium == true) BrightGreen else BrightRed,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }

                            if (res.features.isNotEmpty()) {
                                Text(
                                    text = "Fitur: ${res.features.joinToString(", ")}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Color.White)
                                )
                            }

                            if (!res.codeOrder.isNullOrBlank()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(CyberBlack)
                                        .padding(10.dp)
                                ) {
                                    Column {
                                        Text(
                                            text = "ORDER ID:",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = MutedGrey,
                                                fontFamily = FontFamily.Default,
                                                fontSize = 10.sp
                                            )
                                        )
                                        Text(
                                            text = res.codeOrder.orEmpty(),
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontFamily = FontFamily.Default,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        clipboard.setText(AnnotatedString(res.codeOrder.orEmpty()))
                                        onShowSnackbar("Order ID berhasil disalin.")
                                    },
                                    modifier = Modifier.fillMaxWidth().testTag("btn_copy_code_order"),
                                    shape = RoundedCornerShape(6.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5E7EB), contentColor = Color(0xFF0C0D10))
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Salin Order ID")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
