package com.baklava.projectlv.data.streaming

data class AnimeListItem(
    val url: String,
    val judul: String,
    val cover: String? = null,
    val lastch: String? = null,
    val lastup: String? = null,
    val type: String? = null,
    val genre: List<String> = emptyList(),
    val sinopsis: String? = null,
    val studio: String? = null,
    val score: String? = null,
    val status: String? = null,
    val rilis: String? = null,
    val total_episode: Int? = null
)

data class SeriesResponse(
    val data: List<AnimeDetail> = emptyList()
)

data class AnimeSearchResponse(
    val data: List<AnimeSearchPage> = emptyList()
)

data class AnimeSearchPage(
    val jumlah: Int = 0,
    val result: List<AnimeListItem> = emptyList(),
    val pagination: AnimeSearchPagination? = null
)

data class AnimeSearchPagination(
    val page: Int = 0,
    val per_page: Int = 0,
    val total: Int = 0,
    val total_pages: Int = 0,
    val has_next: Boolean = false,
    val next_page: String? = null,
    val next_offset: String? = null
)

data class AnimeDetail(
    val id: Long? = null,
    val series_id: String,
    val bookmark: Any? = null,
    val cover: String? = null,
    val judul: String,
    val type: String? = null,
    val countdown: Any? = null,
    val status: String? = null,
    val rating: String? = null,
    val published: String? = null,
    val author: String? = null,
    val genre: List<String> = emptyList(),
    val genreurl: List<String> = emptyList(),
    val sinopsis: String? = null,
    val history: List<String> = emptyList(),
    val historyDurasi: List<Long> = emptyList(),
    val historyDurasiFull: List<Long> = emptyList(),
    val chapter: List<Episode> = emptyList()
)

data class Episode(
    val id: Long,
    val ch: String,
    val url: String,
    val date: String? = null,
    val history: String? = null,
    val views: Long? = null,
    val lastDurasi: Long? = null,
    val fullDurasi: Long? = null
)

data class StreamCandidate(
    val link: String,
    val provide: Int? = null,
    val id: Long? = null,
    val reso: String? = null,
    val size_kb: Long? = null
)

data class EpisodeStreamData(
    val episode_id: Long? = null,
    val reso: List<String> = emptyList(),
    val streams: Map<String, List<StreamCandidate>> = emptyMap(),
    val resoSizeKb: Map<String, Long?> = emptyMap(),
    val resoSize: Map<String, String?> = emptyMap()
)

data class EpisodeStreamResponse(
    val is_cache: Boolean? = null,
    val cache_key: String? = null,
    val data: List<EpisodeStreamData> = emptyList()
)

data class SeriesRequest(
    val get: String = "top",
    val post_type: String = "1",
    val post_id: String,
    val token: String = ""
)

data class EpisodeRequest(
    val post_type: String = "2",
    val post_id: String,
    val series_id: String,
    val series_url: String,
    val episode: String,
    val token: String = ""
)

data class WatchRecord(
    val key: String,
    val seriesId: String,
    val seriesTitle: String,
    val cover: String? = null,
    val episodeId: Long,
    val episodeLabel: String,
    val episodeUrl: String,
    val positionMs: Long,
    val durationMs: Long,
    val lastWatchedAt: Long,
    val completed: Boolean = false
) {
    val progress: Float
        get() = if (durationMs <= 0L) 0f else (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
}

data class MyListEntry(
    val seriesId: String,
    val title: String,
    val cover: String? = null,
    val addedAt: Long,
    val status: String = "PLANNED",
    val totalEpisodes: Int? = null,
    val updatedAt: Long = addedAt,
    /** Slug yang dipakai untuk membuka detail (param `url` di series.php). */
    val slug: String? = null
)
