import admin from 'firebase-admin';

const execute = process.argv.includes('--execute');
const projectId = process.env.FIREBASE_PROJECT_ID || undefined;
admin.initializeApp(projectId ? { projectId } : undefined);
const db = admin.firestore();

const snapshot = await db.collection('devices').get();
const targets = snapshot.docs.filter((doc) =>
  ['trialStartedAt', 'trialExpiresAt', 'accessExpiresAtOverride'].some((field) => doc.get(field) !== undefined)
);

console.log(`Devices scanned: ${snapshot.size}`);
console.log(`Devices with legacy expiry fields: ${targets.length}`);

if (!execute) {
  console.log('DRY RUN ONLY. Run with --execute to remove the legacy fields.');
  process.exit(0);
}

for (const doc of targets) {
  await doc.ref.update({
    trialStartedAt: admin.firestore.FieldValue.delete(),
    trialExpiresAt: admin.firestore.FieldValue.delete(),
    accessExpiresAtOverride: admin.firestore.FieldValue.delete()
  });
  const events = await doc.ref.collection('securityEvents').listDocuments();
  for (const eventRef of events) {
    await eventRef.delete();
  }
}

console.log('Legacy expiry fields and securityEvents removed.');
