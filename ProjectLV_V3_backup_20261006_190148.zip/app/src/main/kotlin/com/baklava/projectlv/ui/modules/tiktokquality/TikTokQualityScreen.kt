package com.baklava.projectlv.ui.modules.tiktokquality

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.ui.components.AppWindowSize
import com.baklava.projectlv.ui.components.Button
import com.baklava.projectlv.ui.components.Card
import com.baklava.projectlv.ui.components.ModuleHeaderCard
import com.baklava.projectlv.ui.components.OutlinedButton
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.launch

@Composable
fun TikTokQualityScreen(
    windowSize: AppWindowSize,
    onShowSnackbar: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val logs = remember { mutableStateListOf<String>() }

    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedName by remember { mutableStateOf<String?>(null) }
    var version by remember { mutableStateOf(TikTokQualityProcessor.Version.FISH_STREAMSHIELD) }
    var compressMode by remember { mutableStateOf(TikTokQualityProcessor.CompressMode.OFF) }
    var fixAudio by remember { mutableStateOf(false) }
    var isProcessing by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0) }
    var output by remember { mutableStateOf<TikTokQualityProcessor.Result?>(null) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            selectedUri = uri
            selectedName = queryDisplayName(context, uri) ?: "video"
            output = null
            logs.clear()
            logs += "Selected: ${selectedName ?: "video"}"
        }
    }

    val savePicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("video/*")) { uri ->
        val current = output ?: return@rememberLauncherForActivityResult
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    current.file.inputStream().use { input -> input.copyTo(out, 1024 * 1024) }
                } ?: error("Tidak dapat membuka tujuan penyimpanan.")
            }.onSuccess {
                onShowSnackbar("Video berhasil disimpan.")
            }.onFailure {
                onShowSnackbar("Gagal menyimpan: ${it.message}")
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(CyberBlack)) {
        ModuleHeaderCard(
            icon = Icons.Default.HighQuality,
            title = "QUALITY METHOD",
            subtitle = "TikTok HQ Upload • FISH • BINARY • F R Y • FPS • WMV",
            modifier = Modifier.padding(16.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text("SOURCE VIDEO", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Pilih video langsung dari galeri perangkat", color = MutedGrey, fontSize = 10.sp)
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                            },
                            enabled = !isProcessing,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.VideoFile, null)
                            Spacer(Modifier.width(8.dp))
                            Text(selectedName ?: "Pilih video", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                        Icon(Icons.Default.Info, null, tint = BrightCyan, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Engine 2.4.x diperbarui mengikuti Quality Method terbaru. FISH/StreamShield menjadi default. Userscript Cloud Disabler v1.5.3 tetap merupakan komponen browser terpisah untuk alur upload TikTok Studio.",
                            color = MutedGrey,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }

            item {
                QualityOptionsCard(
                    version = version,
                    onVersionChange = {
                        version = it
                        if (it != TikTokQualityProcessor.Version.BINARY) fixAudio = false
                    },
                    compressMode = compressMode,
                    onCompressChange = { compressMode = it },
                    fixAudio = fixAudio,
                    onFixAudioChange = { fixAudio = it },
                    enabled = !isProcessing
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("PROCESS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            if (isProcessing) CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp, color = BrightCyan)
                        }
                        Spacer(Modifier.height(8.dp))
                        if (isProcessing) {
                            LinearProgressIndicator(
                                progress = { progress / 100f },
                                modifier = Modifier.fillMaxWidth(),
                                color = BrightCyan
                            )
                            Spacer(Modifier.height(6.dp))
                            Text("$progress%", color = MutedGrey, fontSize = 10.sp)
                            Spacer(Modifier.height(8.dp))
                        }
                        Button(
                            onClick = {
                                val uri = selectedUri ?: return@Button
                                val name = selectedName ?: "video.mp4"
                                logs.clear()
                                output = null
                                isProcessing = true
                                progress = 0
                                scope.launch {
                                    runCatching {
                                        TikTokQualityProcessor.process(
                                            context = context,
                                            sourceUri = uri,
                                            inputName = name,
                                            options = TikTokQualityProcessor.Options(
                                                version = version,
                                                compressMode = compressMode,
                                                fixAudio = fixAudio
                                            ),
                                            onProgress = { progress = it.coerceIn(0, 100) },
                                            onLog = { msg -> if (logs.size < 1600) logs += msg }
                                        )
                                    }.onSuccess {
                                        output = it
                                        progress = 100
                                        onShowSnackbar("${methodLabel(it.method)} selesai.")
                                    }.onFailure {
                                        logs += "ERROR: ${it.message}"
                                        onShowSnackbar("Gagal memproses: ${it.message}")
                                    }
                                    isProcessing = false
                                }
                            },
                            enabled = selectedUri != null && !isProcessing,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
                        ) {
                            Icon(Icons.Default.HighQuality, null)
                            Spacer(Modifier.width(8.dp))
                            Text("PROSES ${methodLabel(version).uppercase()}", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item {
                output?.let { result ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BrightGreen.copy(alpha = 0.35f)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, null, tint = BrightGreen, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("PROCESS SELESAI", color = BrightGreen, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(result.file.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("Method: ${methodLabel(result.method)}", color = MutedGrey, fontSize = 11.sp)
                            Text("Compression: ${compressLabel(result.compressMode)}", color = MutedGrey, fontSize = 11.sp)
                            Text("Output: ${formatMb(result.outputBytes)} MB", color = MutedGrey, fontSize = 11.sp)
                            if (result.inputFps != null && result.patchedFps != null) {
                                Text("FPS: ${result.inputFps} → ${result.patchedFps}", color = MutedGrey, fontSize = 11.sp)
                            }
                            if (result.realSamples != null) {
                                Text("Samples: ${result.realSamples} real / ${result.fakeSamples ?: 0} fake", color = MutedGrey, fontSize = 11.sp)
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                Button(onClick = { savePicker.launch(result.file.name) }, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.Download, null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("SIMPAN")
                                }
                                OutlinedButton(onClick = {
                                    clipboard.setText(AnnotatedString(result.file.absolutePath))
                                    onShowSnackbar("Path output disalin.")
                                }, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.ContentCopy, null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("PATH")
                                }
                            }
                        }
                    }
                }
            }

            item {
                if (logs.isNotEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("PROCESS LOG", color = Color.White, fontWeight = FontWeight.Bold)
                                    Text("Native port log / fallback info", color = MutedGrey, fontSize = 9.sp)
                                }
                                OutlinedButton(onClick = {
                                    clipboard.setText(AnnotatedString(logs.joinToString("\n")))
                                    onShowSnackbar("Log disalin.")
                                }) {
                                    Icon(Icons.Default.ContentCopy, null)
                                    Spacer(Modifier.width(4.dp))
                                    Text("COPY")
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            val logScrollState = androidx.compose.foundation.rememberScrollState()
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = if (windowSize.isCompact) 190.dp else 240.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF0A0B0E))
                                    .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp))
                                    .verticalScroll(logScrollState)
                                    .padding(10.dp)
                            ) {
                                Text(logs.takeLast(320).joinToString("\n"), color = MutedGrey, fontSize = 9.sp, lineHeight = 12.sp)
                            }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun QualityOptionsCard(
    version: TikTokQualityProcessor.Version,
    onVersionChange: (TikTokQualityProcessor.Version) -> Unit,
    compressMode: TikTokQualityProcessor.CompressMode,
    onCompressChange: (TikTokQualityProcessor.CompressMode) -> Unit,
    fixAudio: Boolean,
    onFixAudioChange: (Boolean) -> Unit,
    enabled: Boolean
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("PRIMARY METHODS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            SegmentedMethods(
                values = listOf(
                    TikTokQualityProcessor.Version.FISH_STREAMSHIELD to "FISH",
                    TikTokQualityProcessor.Version.BINARY to "BINARY",
                    TikTokQualityProcessor.Version.FRY to "F R Y"
                ),
                selected = version,
                onSelected = onVersionChange,
                enabled = enabled
            )

            Text("BACKUP METHODS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            SegmentedMethods(
                values = listOf(
                    TikTokQualityProcessor.Version.FPS to "FPS",
                    TikTokQualityProcessor.Version.V1_WMV to "WMV"
                ),
                selected = version,
                onSelected = onVersionChange,
                enabled = enabled
            )

            Text("COMPRESSION", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            SegmentedMethods(
                values = listOf(
                    TikTokQualityProcessor.CompressMode.OFF to "OFF",
                    TikTokQualityProcessor.CompressMode.P720 to "720P",
                    TikTokQualityProcessor.CompressMode.P1080 to "1080P"
                ),
                selected = compressMode,
                onSelected = onCompressChange,
                enabled = enabled
            )

            if (version == TikTokQualityProcessor.Version.BINARY) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Fix Audio", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Clone audio/fake samples seperti jalur Binary 2.4.0.", color = MutedGrey, fontSize = 10.sp)
                    }
                    Switch(checked = fixAudio, onCheckedChange = onFixAudioChange, enabled = enabled)
                }
            }
        }
    }
}

@Composable
private fun <T> SegmentedMethods(
    values: List<Pair<T, String>>,
    selected: T,
    onSelected: (T) -> Unit,
    enabled: Boolean
) {
    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
        values.forEachIndexed { index, (value, label) ->
            SegmentedButton(
                selected = selected == value,
                onClick = { onSelected(value) },
                shape = SegmentedButtonDefaults.itemShape(index = index, count = values.size),
                enabled = enabled,
                label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            )
        }
    }
}

private fun methodLabel(method: TikTokQualityProcessor.Version): String = when (method) {
    TikTokQualityProcessor.Version.FISH_STREAMSHIELD -> "FISH / StreamShield"
    TikTokQualityProcessor.Version.BINARY -> "BINARY"
    TikTokQualityProcessor.Version.FRY -> "F R Y"
    TikTokQualityProcessor.Version.FPS -> "FPS"
    TikTokQualityProcessor.Version.V1_WMV -> "WMV"
}

private fun compressLabel(mode: TikTokQualityProcessor.CompressMode): String = when (mode) {
    TikTokQualityProcessor.CompressMode.OFF -> "OFF"
    TikTokQualityProcessor.CompressMode.P720 -> "720P"
    TikTokQualityProcessor.CompressMode.P1080 -> "1080P"
}

private fun queryDisplayName(context: android.content.Context, uri: Uri): String? {
    context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) return c.getString(0)
    }
    return uri.lastPathSegment
}

private fun formatMb(bytes: Long): String = "%.2f".format(bytes / (1024.0 * 1024.0))
