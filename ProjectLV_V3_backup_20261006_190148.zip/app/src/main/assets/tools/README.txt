ProjectLV Web Tools - HTML Enc/Obf

w.py is the supplied reference implementation.
The Android app executes the same pipeline through HtmlObfuscatorEngine.kt so the
feature works natively inside the APK without bundling a Python runtime.
