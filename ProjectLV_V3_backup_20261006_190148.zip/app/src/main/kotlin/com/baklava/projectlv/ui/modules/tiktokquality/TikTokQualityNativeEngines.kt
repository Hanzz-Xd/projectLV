package com.baklava.projectlv.ui.modules.tiktokquality

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max

/**
 * Native ports of the source-provided TikTok HQ Quality Method 2.4.x engines.
 *
 * The web source uses JavaScript/Uint8Array atom manipulation. This file keeps
 * the same conceptual operations in native Kotlin so ProjectLV does not need
 * a browser JavaScript runtime.
 */
object TikTokQualityNativeEngines {

    data class EngineResult(
        val output: ByteArray,
        val notes: List<String> = emptyList()
    )

    private data class Box(
        val type: String,
        val offset: Int,
        val size: Int,
        val header: Int,
        val contentStart: Int,
        val end: Int,
        val children: List<Box> = emptyList()
    ) {
        fun raw(bytes: ByteArray): ByteArray = bytes.copyOfRange(offset, end)
        fun payload(bytes: ByteArray): ByteArray = bytes.copyOfRange(contentStart, end)
    }

    private val CONTAINERS = setOf("moov", "trak", "mdia", "minf", "stbl", "edts", "dinf", "udta", "meta", "ilst")

    private fun u32(bytes: ByteArray, off: Int): Long {
        require(off >= 0 && off + 4 <= bytes.size) { "u32 out of bounds" }
        return ByteBuffer.wrap(bytes, off, 4).order(ByteOrder.BIG_ENDIAN).int.toLong() and 0xffffffffL
    }

    private fun u64(bytes: ByteArray, off: Int): Long {
        require(off >= 0 && off + 8 <= bytes.size) { "u64 out of bounds" }
        return ByteBuffer.wrap(bytes, off, 8).order(ByteOrder.BIG_ENDIAN).long
    }

    private fun putU32(bytes: ByteArray, off: Int, value: Long) {
        require(off >= 0 && off + 4 <= bytes.size) { "putU32 out of bounds" }
        ByteBuffer.wrap(bytes, off, 4).order(ByteOrder.BIG_ENDIAN).putInt(value.toInt())
    }

    private fun putU64(bytes: ByteArray, off: Int, value: Long) {
        require(off >= 0 && off + 8 <= bytes.size) { "putU64 out of bounds" }
        ByteBuffer.wrap(bytes, off, 8).order(ByteOrder.BIG_ENDIAN).putLong(value)
    }

    private fun type(bytes: ByteArray, off: Int): String =
        if (off >= 0 && off + 4 <= bytes.size) bytes.copyOfRange(off, off + 4).toString(Charsets.ISO_8859_1) else ""

    private fun box(type: String, payload: ByteArray): ByteArray {
        require(type.length == 4)
        val total = 8L + payload.size
        require(total <= 0xffffffffL) { "$type is too large" }
        val out = ByteArray(total.toInt())
        putU32(out, 0, total)
        type.toByteArray(Charsets.ISO_8859_1).copyInto(out, 4)
        payload.copyInto(out, 8)
        return out
    }

    private fun concat(vararg parts: ByteArray?): ByteArray {
        val total = parts.sumOf { it?.size ?: 0 }
        val out = ByteArray(total)
        var p = 0
        for (part in parts) {
            if (part == null) continue
            part.copyInto(out, p)
            p += part.size
        }
        return out
    }

    private fun parseBoxes(bytes: ByteArray, start: Int, end: Int, parseMetaFullBox: Boolean = true): List<Box> {
        val list = ArrayList<Box>()
        var p = start
        while (p + 8 <= end) {
            var size = u32(bytes, p)
            var header = 8
            if (size == 1L) {
                if (p + 16 > end) break
                val raw = u64(bytes, p + 8)
                if (raw <= 0L) break
                size = raw
                header = 16
            } else if (size == 0L) {
                size = (end - p).toLong()
            }
            if (size < header || size > Int.MAX_VALUE || p.toLong() + size > end.toLong()) break
            val boxEnd = p + size.toInt()
            val t = type(bytes, p + 4)
            val childStart = if (t == "meta" && parseMetaFullBox) p + header + 4 else p + header
            val children = if (CONTAINERS.contains(t) && childStart <= boxEnd) {
                parseBoxes(bytes, childStart, boxEnd, parseMetaFullBox)
            } else emptyList()
            list += Box(t, p, size.toInt(), header, p + header, boxEnd, children)
            p = boxEnd
        }
        return list
    }

    private fun findChild(parent: Box, wanted: String): Box? = parent.children.firstOrNull { it.type == wanted }
    private fun findDesc(parent: Box, path: List<String>): Box? {
        var cur: Box? = parent
        for (part in path) {
            cur = cur?.let { findChild(it, part) } ?: return null
        }
        return cur
    }

    private fun handlerType(bytes: ByteArray, trak: Box): String? {
        val h = findDesc(trak, listOf("mdia", "hdlr")) ?: return null
        return if (h.contentStart + 12 <= h.end) type(bytes, h.contentStart + 8) else null
    }

    private fun findTop(boxes: List<Box>, wanted: String): Box? = boxes.firstOrNull { it.type == wanted }

    private fun buildMvhdSentinel(originalBytes: ByteArray, mvhd: Box): ByteArray {
        val payload = originalBytes.copyOfRange(mvhd.contentStart, mvhd.end)
        val version = payload[0].toInt() and 0xff
        return if (version == 1) {
            require(payload.size >= 32) { "mvhd v1 malformed" }
            val out = payload.copyOf()
            for (i in 0 until 8) out[24 + i] = 0xff.toByte()
            box("mvhd", out)
        } else {
            require(version == 0 && payload.size >= 100) { "Unsupported mvhd version" }
            val out = ByteArray(112)
            out[0] = 1
            payload.copyOfRange(1, 4).copyInto(out, 1)
            payload.copyOfRange(4, 8).copyInto(out, 4) // creation time (placeholder)
            payload.copyOfRange(8, 12).copyInto(out, 12) // modification time
            payload.copyOfRange(12, 16).copyInto(out, 20) // timescale
            for (i in 0 until 8) out[24 + i] = 0xff.toByte()
            payload.copyOfRange(20, payload.size).copyInto(out, 32)
            box("mvhd", out)
        }
    }

    private fun readOffsets(bytes: ByteArray, box: Box): LongArray {
        val count = u32(bytes, box.contentStart + 4).toInt()
        val itemSize = if (box.type == "co64") 8 else 4
        require(count >= 0 && box.contentStart + 8 + count * itemSize <= box.end) { "${box.type} malformed" }
        return LongArray(count) { i ->
            val off = box.contentStart + 8 + i * itemSize
            if (itemSize == 8) u64(bytes, off) else u32(bytes, off)
        }
    }

    private fun makeMvhdV1(): ByteArray {
        val payload = ByteArray(112)
        payload[0] = 1
        putU32(payload, 20, 1000)
        putU64(payload, 24, -1L)
        putU32(payload, 32, 0x00010000)
        payload[36] = 0x01
        payload[37] = 0x00
        putU32(payload, 48, 0x00010000)
        putU32(payload, 64, 0x00010000)
        putU32(payload, 80, 0x40000000)
        putU32(payload, 108, 4)
        return box("mvhd", payload)
    }

    /**
     * StreamShield v2.4.2 native port.
     * Preserves the original ftyp/media payload, replaces mvhd with the v1
     * infinite-duration form, rebuilds tracks, and appends the micro-shield payload.
     */
    fun patchStreamShield(input: ByteArray, onLog: (String) -> Unit = {}): EngineResult {
        val top = parseBoxes(input, 0, input.size, parseMetaFullBox = false)
        val ftyp = findTop(top, "ftyp") ?: error("MP4 tidak memiliki ftyp.")
        val moov = findTop(top, "moov") ?: error("MP4 tidak memiliki moov.")
        val mdat = findTop(top, "mdat") ?: error("MP4 tidak memiliki mdat.")
        val moovChildren = parseBoxes(input, moov.contentStart, moov.end, parseMetaFullBox = false)
        moovChildren.firstOrNull { it.type == "mvhd" } ?: error("mvhd tidak ditemukan.")
        val traks = moovChildren.filter { it.type == "trak" }
        require(traks.isNotEmpty()) { "Tidak ada track MP4." }

        val videoTrak = traks.firstOrNull { handlerType(input, it) == "vide" } ?: traks.first()
        val audioTrak = traks.firstOrNull { handlerType(input, it) == "soun" && it != videoTrak }
        val origMdatPayload = input.copyOfRange(mdat.contentStart, mdat.end)
        val ftypBytes = ftyp.raw(input)

        fun findStcoOrCo64(trak: Box): Box? {
            val stbl = findDesc(trak, listOf("mdia", "minf", "stbl")) ?: return null
            return findChild(stbl, "stco") ?: findChild(stbl, "co64")
        }

        val vStco = findStcoOrCo64(videoTrak) ?: error("Video chunk offsets tidak ditemukan.")
        val aStco = audioTrak?.let { findStcoOrCo64(it) }
        val origVideoOffsets = readOffsets(input, vStco)
        val origAudioOffsets = aStco?.let { readOffsets(input, it) } ?: LongArray(0)
        val origMdatStart = mdat.contentStart.toLong()
        val videoRel = origVideoOffsets.map { it - origMdatStart }.toLongArray()
        val audioRel = origAudioOffsets.map { it - origMdatStart }.toLongArray()

        val trapPayload = byteArrayOf(
            0, 0, 0, 4, 0, 0, 0, 0,
            0, 0, 0, 8, 0x66, 0x72, 0x65, 0x65
        )

        fun buildTrack3(fakeOffset: Long): ByteArray {
            val t3TkhdPayload = ByteArray(84)
            val t3Tkhd = t3TkhdPayload.apply {
                putU32(this, 0, 0x00000007)
                putU32(this, 12, 3)
                putU32(this, 20, 1000)
                putU32(this, 40, 0x00010000)
                putU32(this, 56, 0x00010000)
                putU32(this, 72, 0x40000000)
                this[36] = 0x01
                this[37] = 0x00
            }
            val mdhdPayload = ByteArray(24).apply {
                putU32(this, 12, 48000)
                putU32(this, 16, 48000)
            }
            val hdlrPayload = ByteArray(25).apply {
                typeBytes("soun").copyInto(this, 8)
                // Source JS allocates 25 bytes but attempts to write the full name at 24;
                // only the first byte (the leading 'S') actually fits. Mirror it exactly.
                this[24] = 'S'.code.toByte()
            }
            val audioStsd = audioTrak?.let {
                val stsd = findDesc(it, listOf("mdia", "minf", "stbl"))?.let { st -> findChild(st, "stsd") }
                stsd?.raw(input)
            } ?: run {
                val p = ByteArray(28)
                putU32(p, 4, 1)
                putU32(p, 8, 20)
                typeBytes("mp4a").copyInto(p, 12)
                box("stsd", p)
            }
            val sttsPayload = ByteArray(16).apply {
                putU32(this, 4, 1)
                putU32(this, 8, 1)
                putU32(this, 12, 1024)
            }
            val stszPayload = ByteArray(12).apply {
                putU32(this, 4, 8)
                putU32(this, 8, 1)
            }
            val stscPayload = ByteArray(20).apply {
                putU32(this, 4, 1)
                putU32(this, 8, 1)
                putU32(this, 12, 1)
                putU32(this, 16, 1)
            }
            val stcoPayload = ByteArray(12).apply {
                putU32(this, 4, 1)
                require(fakeOffset <= 0xffffffffL) { "StreamShield output exceeds stco address range." }
                putU32(this, 8, fakeOffset)
            }
            val drefEntry = byteArrayOf(0, 0, 0, 12, 0x75, 0x72, 0x6c, 0x20, 0, 0, 0, 1)
            val drefPayload = ByteArray(8 + drefEntry.size).apply {
                putU32(this, 4, 1)
                drefEntry.copyInto(this, 8)
            }
            val stbl = box("stbl", concat(audioStsd, box("stts", sttsPayload), box("stsz", stszPayload), box("stsc", stscPayload), box("stco", stcoPayload)))
            val minf = box("minf", concat(box("smhd", ByteArray(8)), box("dinf", box("dref", drefPayload)), stbl))
            val mdia = box("mdia", concat(box("mdhd", mdhdPayload), box("hdlr", hdlrPayload), minf))
            return box("trak", concat(box("tkhd", t3Tkhd), mdia))
        }

        fun rebuildTrack(original: Box, relativeOffsets: LongArray, newMdatStart: Long): ByteArray {
            val raw = original.raw(input)
            val stco = findStcoOrCo64(original) ?: return raw
            val relOffset = stco.offset - original.offset
            val useCo64 = stco.type == "co64" || relativeOffsets.any { it + newMdatStart > 0xffffffffL }
            val newOffsets = relativeOffsets.map { it + newMdatStart }.toLongArray()
            val payload = if (useCo64) {
                val p = ByteArray(8 + newOffsets.size * 8)
                putU32(p, 4, newOffsets.size.toLong())
                newOffsets.forEachIndexed { i, value -> putU64(p, 8 + i * 8, value) }
                box("co64", p)
            } else {
                val p = ByteArray(8 + newOffsets.size * 4)
                putU32(p, 4, newOffsets.size.toLong())
                newOffsets.forEachIndexed { i, value -> putU32(p, 8 + i * 4, value) }
                box("stco", p)
            }
            return concat(raw.copyOfRange(0, relOffset), payload, raw.copyOfRange(relOffset + stco.size, raw.size))
        }

        var moovBytes: ByteArray? = null
        var final: ByteArray? = null
        repeat(3) {
            // Match StreamShield 2.4.2 exactly: first pass estimates moov as +1024 bytes;
            // subsequent passes use the previous rebuilt moov length.
            val estMoovLen = moovBytes?.size ?: (moov.size + 1024)
            val newMdatContentStart = ftypBytes.size.toLong() + estMoovLen + 8L
            val fakeOffset = newMdatContentStart + origMdatPayload.size
            val newVideoTrack = rebuildTrack(videoTrak, videoRel, newMdatContentStart)
            val newAudioTrack = audioTrak?.let { rebuildTrack(it, audioRel, newMdatContentStart) }
            val t3 = buildTrack3(fakeOffset)
            moovBytes = box("moov", concat(makeMvhdV1(), newVideoTrack, newAudioTrack, t3))
            if (it == 2) final = concat(ftypBytes, moovBytes!!, box("mdat", origMdatPayload), trapPayload)
        }

        val out = final ?: error("StreamShield finalization failed.")
        onLog("StreamShield 2.4.2: ${out.size} bytes; source mdat preserved.")
        return EngineResult(out)
    }

    /**
     * F R Y 2.4.0 native port: replace mvhd with version-1 unknown duration
     * sentinel and recalibrate all chunk offsets when moov precedes mdat.
     */
    fun patchFry(input: ByteArray, onLog: (String) -> Unit = {}): EngineResult {
        val top = parseBoxes(input, 0, input.size)
        val moov = findTop(top, "moov") ?: error("MP4 tidak memiliki moov.")
        val mdat = findTop(top, "mdat") ?: error("MP4 tidak memiliki mdat.")
        val children = parseBoxes(input, moov.contentStart, moov.end)
        val mvhd = children.firstOrNull { it.type == "mvhd" } ?: error("mvhd hilang.")
        val sentinelMvhd = buildMvhdSentinel(input, mvhd)
        var newMoov = concat(
            input.copyOfRange(moov.offset, mvhd.offset),
            sentinelMvhd,
            input.copyOfRange(mvhd.end, moov.end)
        )

        val oldMoovSize = moov.size
        val delta = newMoov.size - oldMoovSize
        if (moov.offset < mdat.offset && delta != 0) {
            // Shift every stco/co64 entry inside moov by the same moov-size delta.
            newMoov = shiftChunkOffsetsInMoov(newMoov, delta)
        }

        val out = ByteArray(input.size + delta)
        var p = 0
        for (b in top) {
            when {
                b.offset == moov.offset -> {
                    newMoov.copyInto(out, p)
                    p += newMoov.size
                }
                else -> {
                    b.raw(input).copyInto(out, p)
                    p += b.size
                }
            }
        }
        require(p == out.size) { "F R Y rebuild size mismatch." }
        onLog("F R Y 2.4.0: mvhd unknown-duration sentinel applied; mdat payload preserved.")
        return EngineResult(out)
    }

    private fun shiftChunkOffsetsInMoov(moovBytes: ByteArray, delta: Int): ByteArray {
        val oldTop = parseBoxes(moovBytes, 8, moovBytes.size)
        fun rewriteRange(start: Int, end: Int): ByteArray {
            val children = parseBoxes(moovBytes, start, end)
            val chunks = ArrayList<ByteArray>()
            var changed = false
            for (child in children) {
                val raw = child.raw(moovBytes)
                when (child.type) {
                    "stco" -> {
                        val count = u32(moovBytes, child.contentStart + 4).toInt()
                        val p = ByteArray(8 + count * 4)
                        putU32(p, 4, count.toLong())
                        var overflow = false
                        for (i in 0 until count) {
                            val old = u32(moovBytes, child.contentStart + 8 + i * 4)
                            val next = old + delta
                            if (next > 0xffffffffL) overflow = true
                            putU32(p, 8 + i * 4, next)
                        }
                        if (overflow) {
                            val q = ByteArray(8 + count * 8)
                            putU32(q, 4, count.toLong())
                            for (i in 0 until count) {
                                val old = u32(moovBytes, child.contentStart + 8 + i * 4)
                                putU64(q, 8 + i * 8, old + delta)
                            }
                            chunks += box("co64", q)
                        } else chunks += box("stco", p)
                        changed = true
                    }
                    "co64" -> {
                        val count = u32(moovBytes, child.contentStart + 4).toInt()
                        val p = ByteArray(8 + count * 8)
                        putU32(p, 4, count.toLong())
                        for (i in 0 until count) {
                            val old = u64(moovBytes, child.contentStart + 8 + i * 8)
                            putU64(p, 8 + i * 8, old + delta)
                        }
                        chunks += box("co64", p)
                        changed = true
                    }
                    else -> chunks += raw
                }
            }
            return if (changed) concat(*chunks.toTypedArray()) else moovBytes.copyOfRange(start, end)
        }

        fun rewriteBox(box: Box): ByteArray {
            if (!CONTAINERS.contains(box.type) || box.type == "meta") return box.raw(moovBytes)
            val childBytes = rewriteRange(box.contentStart, box.end)
            return box(box.type, childBytes)
        }

        // Rebuild recursively while preserving box payloads.
        val rebuiltChildren = oldTop.map { child ->
            if (CONTAINERS.contains(child.type) && child.type != "meta") {
                val childBody = parseBoxes(moovBytes, child.contentStart, child.end)
                val newChildren = childBody.map { grand ->
                    if (CONTAINERS.contains(grand.type) && grand.type != "meta") {
                        val nested = shiftChunkOffsetsInContainer(moovBytes, grand, delta)
                        nested
                    } else if (grand.type == "stco" || grand.type == "co64") {
                        shiftOffsetBox(moovBytes, grand, delta)
                    } else grand.raw(moovBytes)
                }
                box(child.type, concat(*newChildren.toTypedArray()))
            } else if (child.type == "stco" || child.type == "co64") {
                shiftOffsetBox(moovBytes, child, delta)
            } else child.raw(moovBytes)
        }
        val rebuilt = concat(*rebuiltChildren.toTypedArray())
        return box("moov", rebuilt)
    }

    private fun shiftChunkOffsetsInContainer(bytes: ByteArray, container: Box, delta: Int): ByteArray {
        val kids = parseBoxes(bytes, container.contentStart, container.end)
        val out = kids.map { c ->
            when {
                c.type == "stco" || c.type == "co64" -> shiftOffsetBox(bytes, c, delta)
                CONTAINERS.contains(c.type) && c.type != "meta" -> shiftChunkOffsetsInContainer(bytes, c, delta)
                else -> c.raw(bytes)
            }
        }
        return box(container.type, concat(*out.toTypedArray()))
    }

    private fun shiftOffsetBox(bytes: ByteArray, child: Box, delta: Int): ByteArray {
        val count = u32(bytes, child.contentStart + 4).toInt()
        return if (child.type == "stco") {
            val q = ByteArray(8 + count * 4)
            var overflow = false
            val vals = LongArray(count)
            for (i in 0 until count) {
                vals[i] = u32(bytes, child.contentStart + 8 + i * 4) + delta
                if (vals[i] > 0xffffffffL) overflow = true
            }
            if (overflow) {
                val r = ByteArray(8 + count * 8)
                putU32(r, 4, count.toLong())
                vals.forEachIndexed { i, value -> putU64(r, 8 + i * 8, value) }
                box("co64", r)
            } else {
                putU32(q, 4, count.toLong())
                vals.forEachIndexed { i, value -> putU32(q, 8 + i * 4, value) }
                box("stco", q)
            }
        } else {
            val q = ByteArray(8 + count * 8)
            putU32(q, 4, count.toLong())
            for (i in 0 until count) {
                val old = u64(bytes, child.contentStart + 8 + i * 8)
                putU64(q, 8 + i * 8, old + delta)
            }
            box("co64", q)
        }
    }

    /** Ensure the exact metadata marker expected by the companion userscript. */
    fun ensureCutefishMetadata(input: ByteArray): ByteArray {
        if (containsAscii(input, "cutefish.my.id")) return input
        val top = parseBoxes(input, 0, input.size)
        val moov = findTop(top, "moov") ?: return input
        val mdat = findTop(top, "mdat")
        val moovRaw = moov.raw(input)

        val commentText = "cutefish.my.id".toByteArray(Charsets.UTF_8)
        val dataPayload = concat(
            byteArrayOf(0, 0, 0, 1),
            byteArrayOf(0, 0, 0, 0),
            commentText
        )
        val commentData = box("data", dataPayload)
        val commentItem = makeRawItem(byteArrayOf(0xa9.toByte(), 0x63, 0x6d, 0x74), commentData)
        val ilst = box("ilst", commentItem)
        val hdlr = ByteArray(33).apply {
            putU32(this, 0, 33)
            typeBytes("hdlr").copyInto(this, 4)
            typeBytes("mdir").copyInto(this, 12)
        }
        val metaPayload = concat(byteArrayOf(0, 0, 0, 0), hdlr, ilst)
        val meta = box("meta", metaPayload)
        val udta = box("udta", meta)

        val moovChildren = parseBoxes(input, moov.contentStart, moov.end)
        val existingUdta = moovChildren.firstOrNull { it.type == "udta" }
        val newMoov = if (existingUdta == null) {
            box("moov", concat(moovRaw.copyOfRange(8, moovRaw.size), udta))
        } else {
            val rel = existingUdta.offset - moov.offset
            box(
                "moov",
                concat(
                    moovRaw.copyOfRange(8, rel),
                    udta,
                    moovRaw.copyOfRange(rel + existingUdta.size, moovRaw.size)
                )
            )
        }

        val delta = newMoov.size - moov.size
        val out = ByteArray(input.size + delta)
        var dst = 0
        for (b in top) {
            if (b.offset == moov.offset) {
                newMoov.copyInto(out, dst)
                dst += newMoov.size
            } else {
                b.raw(input).copyInto(out, dst)
                dst += b.size
            }
        }

        if (delta != 0 && mdat != null && moov.offset < mdat.offset) {
            val outTop = parseBoxes(out, 0, out.size)
            val outMoov = findTop(outTop, "moov") ?: return out
            val end = outMoov.end
            var p = outMoov.offset + 8
            while (p + 8 <= end) {
                val t = type(out, p + 4)
                val declared = u32(out, p)
                if (t == "stco" && declared >= 16 && p + declared <= end) {
                    val count = u32(out, p + 12).toInt()
                    val tableEnd = p + 16 + count * 4
                    if (count >= 0 && tableEnd <= end) {
                        for (i in 0 until count) {
                            val off = p + 16 + i * 4
                            putU32(out, off, u32(out, off) + delta)
                        }
                    }
                } else if (t == "co64" && declared >= 16 && p + declared <= end) {
                    val count = u32(out, p + 12).toInt()
                    val tableEnd = p + 16 + count * 8
                    if (count >= 0 && tableEnd <= end) {
                        for (i in 0 until count) {
                            val off = p + 16 + i * 8
                            putU64(out, off, u64(out, off) + delta)
                        }
                    }
                }
                p += 1
            }
        }
        return out
    }

    private fun makeRawItem(typeBytes: ByteArray, payload: ByteArray): ByteArray {
        require(typeBytes.size == 4)
        val total = 8 + payload.size
        val out = ByteArray(total)
        putU32(out, 0, total.toLong())
        typeBytes.copyInto(out, 4)
        payload.copyInto(out, 8)
        return out
    }

    private fun containsAscii(bytes: ByteArray, text: String): Boolean {
        val needle = text.toByteArray(Charsets.UTF_8)
        if (needle.isEmpty() || needle.size > bytes.size) return false
        outer@ for (i in 0..bytes.size - needle.size) {
            for (j in needle.indices) if (bytes[i + j] != needle[j]) continue@outer
            return true
        }
        return false
    }

    private fun typeBytes(s: String): ByteArray = s.toByteArray(Charsets.ISO_8859_1)
}
