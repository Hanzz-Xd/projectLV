package com.baklava.projectlv.data.models

/**
 * Response terstruktur dari AM Finder (/api/comments).
 * Backend melakukan scanning caption, komentar, dan reply TikTok.
 */
data class AlightMotionFinderResult(
    val links: List<String>,
    val count: Int,
    val captionLinks: List<String>,
    val commentLinks: List<String>,
    val caption: String?,
    val captionFound: Boolean,
    val commentsChecked: Int,
    val repliesChecked: Int,
    val datasetItems: Int,
    val resolvedUrl: String?,
    val diagnostics: List<String>,
    val message: String
)
