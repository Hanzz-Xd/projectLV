const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue, Timestamp } = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();
const TELEGRAM_BOT_TOKEN = defineSecret("TELEGRAM_BOT_TOKEN");
const TELEGRAM_CHAT_ID = defineSecret("TELEGRAM_CHAT_ID");

const TRIAL_MS = 7 * 24 * 60 * 60 * 1000;
const BAN_MS = 7 * 24 * 60 * 60 * 1000;

function assertAuthenticated(request) {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Authentication diperlukan.");
  }
}

function validateDeviceHash(value) {
  if (typeof value !== "string" || !/^[a-f0-9]{64}$/i.test(value)) {
    throw new HttpsError("invalid-argument", "deviceIdHash tidak valid.");
  }
  return value.toLowerCase();
}

function millis(value) {
  if (!value) return null;
  if (value instanceof Timestamp) return value.toMillis();
  return Number(value) || null;
}

async function getOrCreateDevice(deviceIdHash, ownerUid) {
  const ref = db.collection("devices").doc(deviceIdHash);
  const snap = await ref.get();
  if (snap.exists) {
    const existing = snap.data();
    // Backfill ownerUid for devices created before this field existed, so the
    // Firestore rules (which key off ownerUid) can authorize the owning
    // client to read its own document in real time.
    if (!existing.ownerUid && ownerUid) {
      await ref.update({ ownerUid, updatedAt: FieldValue.serverTimestamp() });
      existing.ownerUid = ownerUid;
    }
    return { ref, data: existing };
  }

  const now = Date.now();
  const data = {
    deviceIdHash,
    ownerUid,
    trialStartedAt: Timestamp.fromMillis(now),
    trialExpiresAt: Timestamp.fromMillis(now + TRIAL_MS),
    banned: false,
    banStartedAt: null,
    banExpiresAt: null,
    violationCount: 0,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp()
  };
  await ref.set(data);
  return { ref, data };
}

function accessResponse(data) {
  const now = Date.now();
  const banExpiresAt = millis(data.banExpiresAt);
  const trialExpiresAt = millis(data.trialExpiresAt);
  // A ban with no expiry (set manually by an admin, e.g. from the Firebase
  // console) is treated as permanent rather than silently ignored. A ban
  // with an expiry is only active while that expiry is still in the future.
  const isTimedBanActive = Boolean(banExpiresAt) && banExpiresAt > now;
  const isPermanentBan = Boolean(data.banned) && !banExpiresAt;
  const banned = Boolean(data.banned) && (isTimedBanActive || isPermanentBan);
  const trialActive = Boolean(trialExpiresAt) && trialExpiresAt > now;

  if (banned) {
    return {
      allowed: false,
      banned: true,
      trialActive,
      trialExpiresAt,
      banExpiresAt,
      message: isPermanentBan
        ? "Perangkat diblokir permanen oleh admin karena pelanggaran keamanan."
        : "Perangkat diblokir selama 7 hari karena pelanggaran keamanan."
    };
  }

  if (!trialActive) {
    return {
      allowed: false,
      banned: false,
      trialActive: false,
      trialExpiresAt,
      banExpiresAt: null,
      message: "Masa trial 7 hari perangkat ini telah berakhir."
    };
  }

  return {
    allowed: true,
    banned: false,
    trialActive: true,
    trialExpiresAt,
    banExpiresAt: null,
    message: "Akses aktif."
  };
}

exports.checkDeviceAccess = onCall(
  { region: "us-central1", enforceAppCheck: true },
  async (request) => {
    assertAuthenticated(request);
    const deviceIdHash = validateDeviceHash(request.data?.deviceIdHash);
    const { ref, data } = await getOrCreateDevice(deviceIdHash, request.auth.uid);
    const response = accessResponse(data);

    // Only clear a TIMED ban that has expired. A permanent ban (banned=true,
    // banExpiresAt=null, e.g. set manually by an admin) must never be
    // auto-cleared here.
    const hadTimedBanExpiry = Boolean(data.banExpiresAt);
    if (!response.banned && data.banned && hadTimedBanExpiry) {
      await ref.update({ banned: false, banExpiresAt: null, updatedAt: FieldValue.serverTimestamp() });
    }
    return response;
  }
);

exports.reportSecurityViolation = onCall(
  {
    region: "us-central1",
    // Deliberately not enforced here: emulator/root/VPN findings must still be
    // reportable so the backend can create the 7-day ban. Authentication is required.
    secrets: [TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID]
  },
  async (request) => {
    assertAuthenticated(request);
    const deviceIdHash = validateDeviceHash(request.data?.deviceIdHash);
    const violations = Array.isArray(request.data?.violations) ? request.data.violations : [];
    if (violations.length === 0) {
      throw new HttpsError("invalid-argument", "Tidak ada security violation.");
    }

    const safeViolations = violations.slice(0, 10).map((v) => ({
      type: String(v?.type || "UNKNOWN").slice(0, 40),
      detail: String(v?.detail || "").slice(0, 200)
    }));

    const { ref, data } = await getOrCreateDevice(deviceIdHash, request.auth.uid);
    const now = Date.now();
    const banExpiresAt = now + BAN_MS;

    await ref.set({
      banned: true,
      banStartedAt: Timestamp.fromMillis(now),
      banExpiresAt: Timestamp.fromMillis(banExpiresAt),
      violationCount: Number(data.violationCount || 0) + 1,
      lastViolation: safeViolations[0].type,
      lastViolationAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp()
    }, { merge: true });

    const eventRef = ref.collection("securityEvents").doc();
    await eventRef.set({
      violations: safeViolations,
      appVersion: String(request.data?.appVersion || "unknown").slice(0, 40),
      versionCode: Number(request.data?.versionCode || 0),
      androidVersion: String(request.data?.androidVersion || "unknown").slice(0, 40),
      sdkInt: Number(request.data?.sdkInt || 0),
      manufacturer: String(request.data?.manufacturer || "unknown").slice(0, 80),
      model: String(request.data?.model || "unknown").slice(0, 120),
      createdAt: FieldValue.serverTimestamp()
    });

    await sendTelegramAlert({
      deviceIdHash,
      safeViolations,
      appVersion: request.data?.appVersion,
      androidVersion: request.data?.androidVersion,
      model: request.data?.model,
      banExpiresAt
    });

    return {
      allowed: false,
      banned: true,
      trialActive: true,
      trialExpiresAt: millis(data.trialExpiresAt),
      banExpiresAt,
      message: "Security violation terdeteksi. Perangkat diblokir selama 7 hari."
    };
  }
);

async function sendTelegramAlert(info) {
  const token = TELEGRAM_BOT_TOKEN.value();
  const chatId = TELEGRAM_CHAT_ID.value();
  if (!token || !chatId) return;

  const lines = [
    "🚨 PROJECT-LEVIATHAN SECURITY",
    "",
    `Device: ${info.deviceIdHash}`,
    `Model: ${info.model || "unknown"}`,
    `Android: ${info.androidVersion || "unknown"}`,
    `App: ${info.appVersion || "unknown"}`,
    "",
    "Violations:",
    ...info.safeViolations.map((v) => `• ${v.type}: ${v.detail}`),
    "",
    `Ban until: ${new Date(info.banExpiresAt).toISOString()}`
  ];

  await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text: lines.join("\n") })
  });
}
