package com.baklava.projectlv.data.streaming

import com.baklava.projectlv.data.network.HttpClientProvider
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.ResponseBody
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface Server2Api {
    @GET("api/popular")
    suspend fun getPopular(
        @Query("page") page: Int,
        @Query("count") count: Int = 20
    ): Server2ListResponse

    @GET("api/complete")
    suspend fun getComplete(
        @Query("page") page: Int,
        @Query("count") count: Int = 20
    ): Server2ListResponse

    @GET("api/latest")
    suspend fun getLatest(
        @Query("page") page: Int,
        @Query("count") count: Int = 20
    ): Server2ListResponse

    @GET("api/anime/{id}")
    suspend fun getAnimeDetail(@Path("id") id: String): ResponseBody

    @GET("api/anime/{id}/episodes")
    suspend fun getEpisodes(
        @Path("id") id: String,
        @Query("page") page: Int = 1,
        @Query("count") count: Int = 50
    ): Server2EpisodeListResponse

    @GET("api/episode/{id}")
    suspend fun getEpisode(@Path("id") id: String): Server2PostResponse
}

/**
 * Server 2 = backend proxy Vercel kamu sendiri (repo `anime-api-vercel`),
 * dipakai sebagai fallback kalau Server 1 (AnimeKita) gagal. Lihat
 * [Server2Mapper] untuk cara ID dari server ini "ditandai" supaya
 * [StreamingRepository] tahu ke server mana harus lanjut fetch detail/episode.
 */
object Server2ApiProvider {

    // TODO: ganti dengan domain deployment Vercel kamu, contoh:
    // "https://api-punya-kamu.vercel.app/". Harus diakhiri "/".
    private const val BASE_URL = "https://api-one-lemon-93.vercel.app"

    // Isi kalau kamu mengaktifkan APP_SHARED_SECRET di server.js (lihat
    // README backend). Biarkan kosong kalau endpoint-nya masih publik —
    // interceptor di bawah otomatis tidak menambahkan header apa pun.
    private const val APP_SHARED_SECRET = ""

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    val api: Server2Api by lazy {
        val client = HttpClientProvider.okHttpClient.newBuilder()
            .addInterceptor { chain ->
                val builder = chain.request().newBuilder()
                    .header("Accept", "application/json")
                if (APP_SHARED_SECRET.isNotBlank()) {
                    builder.header("x-app-key", APP_SHARED_SECRET)
                }
                chain.proceed(builder.build())
            }
            .build()
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi).asLenient())
            .build()
            .create(Server2Api::class.java)
    }
}
