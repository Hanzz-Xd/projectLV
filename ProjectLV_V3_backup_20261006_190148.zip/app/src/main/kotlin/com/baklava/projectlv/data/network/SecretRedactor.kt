package com.baklava.projectlv.data.network

import java.util.regex.Pattern

object SecretRedactor {

    private val HOST_ALIASES = mapOf(
        "restapidhan.vercel.app" to "API_HOST_1",
        "dapjimotionpro.my.id" to "API_HOST_2",
        "strom-ai.my.id" to "API_HOST_3",
        "www.view-page-source.com" to "API_HOST_4",
        "view-page-source.com" to "API_HOST_4",
        "api.products.aspose.app" to "API_HOST_5",
        "products.aspose.app" to "API_HOST_5",
        "bintangapi.my.id" to "API_HOST_6",
        "bintangtools.web.id" to "API_HOST_6",
        "api.siputzx.my.id" to "API_HOST_7",
        "satriam.satriadeveloperz.workers.dev" to "API_HOST_MAGICLINK_V2"
    )

    // Regex to match query parameters: (key|apikey|api_key|token)=...
    private val QUERY_PARAM_REGEX = Pattern.compile(
        "(?i)([?&])(apikey|api_key|key|token|secret)=([^&\\s]+)"
    )

    // Regex to match json fields: "apikey": "..."
    private val JSON_FIELD_REGEX = Pattern.compile(
        "(?i)\"(apikey|api_key|token|secret|password|sessionId|magicLink|refreshToken|idToken)\"\\s*:\\s*\"([^\"]+)\""
    )

    private val SENSITIVE_HEADER_NAMES = listOf(
        "authorization",
        "x-api-key",
        "apikey",
        "api-key",
        "token",
        "secret",
        "cookie"
    )

    fun isSensitiveHeader(name: String): Boolean {
        val lower = name.lowercase()
        return SENSITIVE_HEADER_NAMES.any { lower.contains(it) }
    }

    fun redactHeader(name: String, value: String): String {
        return if (isSensitiveHeader(name)) {
            "[REDACTED]"
        } else {
            value
        }
    }

    fun redactUrl(rawUrl: String): String {
        var result = rawUrl
        // Mask query params
        val matcher = QUERY_PARAM_REGEX.matcher(result)
        val sb = StringBuffer()
        while (matcher.find()) {
            val delimiter = matcher.group(1) ?: "?"
            val key = matcher.group(2) ?: "key"
            matcher.appendReplacement(sb, "$delimiter$key=[REDACTED]")
        }
        matcher.appendTail(sb)
        result = sb.toString()

        // Mask domain names to aliases for user-facing outputs
        for ((host, alias) in HOST_ALIASES) {
            result = result.replace(host, alias)
        }
        return result
    }

    fun redactBody(body: String): String {
        if (body.isBlank()) return body
        var result = body
        val matcher = JSON_FIELD_REGEX.matcher(result)
        val sb = StringBuffer()
        while (matcher.find()) {
            val field = matcher.group(1) ?: "field"
            matcher.appendReplacement(sb, "\"$field\":\"[REDACTED]\"")
        }
        matcher.appendTail(sb)
        result = sb.toString()

        // Also alias internal host names
        for ((host, alias) in HOST_ALIASES) {
            result = result.replace(host, alias)
        }
        return result
    }

    fun redactText(text: String): String {
        var out = text
        for ((host, alias) in HOST_ALIASES) {
            out = out.replace(host, alias)
        }
        val matcher = QUERY_PARAM_REGEX.matcher(out)
        val sb = StringBuffer()
        while (matcher.find()) {
            val delimiter = matcher.group(1) ?: "?"
            val key = matcher.group(2) ?: "key"
            matcher.appendReplacement(sb, "$delimiter$key=[REDACTED]")
        }
        matcher.appendTail(sb)
        out = sb.toString()

        val jsonMatcher = JSON_FIELD_REGEX.matcher(out)
        val sb2 = StringBuffer()
        while (jsonMatcher.find()) {
            val field = jsonMatcher.group(1) ?: "field"
            jsonMatcher.appendReplacement(sb2, "\"$field\":\"[REDACTED]\"")
        }
        jsonMatcher.appendTail(sb2)
        return sb2.toString()
    }

    fun sanitizeStackTrace(throwable: Throwable): String {
        val stackTraceString = throwable.stackTraceToString()
        return redactText(stackTraceString)
    }

    fun maskHost(host: String): String {
        return HOST_ALIASES[host.lowercase()] ?: host
    }
}
