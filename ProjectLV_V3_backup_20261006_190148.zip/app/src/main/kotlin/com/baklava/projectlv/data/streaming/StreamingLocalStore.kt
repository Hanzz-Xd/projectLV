package com.baklava.projectlv.data.streaming

import android.content.Context
import android.content.SharedPreferences
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Local cache/persistence for Streaming Mode.
 *
 * History + MyList are scoped per Firebase account UID so switching accounts on
 * the same device cannot leak streaming data between users. The legacy v1 keys
 * are migrated once into the first authenticated account that opens the app.
 */
class StreamingLocalStore(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val historyAdapter: JsonAdapter<List<WatchRecord>> = moshi.adapter(
        Types.newParameterizedType(List::class.java, WatchRecord::class.java)
    )
    private val myListAdapter: JsonAdapter<List<MyListEntry>> = moshi.adapter(
        Types.newParameterizedType(List::class.java, MyListEntry::class.java)
    )

    private val _history = MutableStateFlow(emptyList<WatchRecord>())
    private val _myList = MutableStateFlow(emptyList<MyListEntry>())

    /** Currently active authenticated Firebase UID, or null before authentication. */
    @Volatile
    var activeUserId: String? = null
        private set

    /** Called only for local mutations; cloud-sync code attaches its listener here. */
    @Volatile
    private var syncListener: ((StreamingLocalChange) -> Unit)? = null

    val history: StateFlow<List<WatchRecord>> = _history.asStateFlow()
    val myList: StateFlow<List<MyListEntry>> = _myList.asStateFlow()

    val preferredQuality: String
        get() = prefs.getString(KEY_QUALITY, "720p") ?: "720p"

    var autoPlayNext: Boolean
        get() = prefs.getBoolean(KEY_AUTO_NEXT, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_NEXT, value).apply()

    @Synchronized
    fun setSyncListener(listener: ((StreamingLocalChange) -> Unit)?) {
        syncListener = listener
    }

    /**
     * Activates one account. Every account gets its own local cache, while the
     * canonical copy lives in Firestore and survives an app uninstall.
     */
    @Synchronized
    fun activateUser(userId: String?) {
        if (activeUserId == userId) return
        activeUserId = userId

        if (userId == null) {
            _history.value = emptyList()
            _myList.value = emptyList()
            return
        }

        val historyKey = historyKey(userId)
        val myListKey = myListKey(userId)

        // One-time migration from the old device-only store. The app previously
        // had no account scoping, so those records belong to the first account
        // that activates the new account-aware store on this device.
        if (!prefs.contains(historyKey) && prefs.contains(LEGACY_HISTORY)) {
            prefs.edit()
                .putString(historyKey, prefs.getString(LEGACY_HISTORY, "[]"))
                .remove(LEGACY_HISTORY)
                .apply()
        }
        if (!prefs.contains(myListKey) && prefs.contains(LEGACY_MY_LIST)) {
            prefs.edit()
                .putString(myListKey, prefs.getString(LEGACY_MY_LIST, "[]"))
                .remove(LEGACY_MY_LIST)
                .apply()
        }

        _history.value = loadHistory(historyKey)
        _myList.value = loadMyList(myListKey)
    }

    @Synchronized
    fun saveProgress(record: WatchRecord) {
        val uid = activeUserId ?: return
        val merged = (_history.value.filterNot { it.key == record.key } + record)
            .sortedByDescending { it.lastWatchedAt }
            .take(MAX_HISTORY)
        _history.value = merged
        prefs.edit().putString(historyKey(uid), historyAdapter.toJson(merged)).apply()
        syncListener?.invoke(StreamingLocalChange.HistoryUpsert(record))
    }

    @Synchronized
    fun removeHistory(key: String) {
        val uid = activeUserId ?: return
        val updated = _history.value.filterNot { it.key == key }
        if (updated.size == _history.value.size) return
        _history.value = updated
        prefs.edit().putString(historyKey(uid), historyAdapter.toJson(updated)).apply()
        syncListener?.invoke(StreamingLocalChange.HistoryRemove(key))
    }

    @Synchronized
    fun clearHistory() {
        val uid = activeUserId ?: return
        if (_history.value.isEmpty()) return
        _history.value = emptyList()
        prefs.edit().remove(historyKey(uid)).apply()
        syncListener?.invoke(StreamingLocalChange.HistoryClear)
    }

    @Synchronized
    fun addToMyList(entry: MyListEntry) {
        val uid = activeUserId ?: return
        val now = System.currentTimeMillis()
        val existing = _myList.value.firstOrNull { it.seriesId == entry.seriesId }
        val effective = if (existing == null) {
            entry.copy(
                addedAt = entry.addedAt.takeIf { it > 0L } ?: now,
                updatedAt = now
            )
        } else {
            entry.copy(
                addedAt = existing.addedAt,
                updatedAt = now
            )
        }
        val updated = if (existing == null) {
            (_myList.value + effective).sortedByDescending { it.addedAt }
        } else {
            _myList.value.map { if (it.seriesId == entry.seriesId) effective else it }
        }
        _myList.value = updated
        prefs.edit().putString(myListKey(uid), myListAdapter.toJson(updated)).apply()
        syncListener?.invoke(StreamingLocalChange.MyListUpsert(effective))
    }

    @Synchronized
    fun removeFromMyList(seriesId: String) {
        val uid = activeUserId ?: return
        val updated = _myList.value.filterNot { it.seriesId == seriesId }
        if (updated.size == _myList.value.size) return
        _myList.value = updated
        prefs.edit().putString(myListKey(uid), myListAdapter.toJson(updated)).apply()
        syncListener?.invoke(StreamingLocalChange.MyListRemove(seriesId))
    }

    @Synchronized
    fun setMyListStatus(seriesId: String, status: String) {
        val uid = activeUserId ?: return
        val existing = _myList.value.firstOrNull { it.seriesId == seriesId } ?: return
        if (existing.status == status) return
        val updatedEntry = existing.copy(status = status, updatedAt = System.currentTimeMillis())
        val updated = _myList.value.map { if (it.seriesId == seriesId) updatedEntry else it }
        _myList.value = updated
        prefs.edit().putString(myListKey(uid), myListAdapter.toJson(updated)).apply()
        syncListener?.invoke(StreamingLocalChange.MyListUpsert(updatedEntry))
    }

    /** Used by cloud sync only; deliberately does not emit another sync event. */
    @Synchronized
    fun removeHistoryFromCloud(key: String) {
        if (_history.value.none { it.key == key }) return
        val updated = _history.value.filterNot { it.key == key }
        _history.value = updated
        activeUserId?.let { uid ->
            prefs.edit().putString(historyKey(uid), historyAdapter.toJson(updated)).apply()
        }
    }

    /** Used by cloud sync only; deliberately does not emit another sync event. */
    @Synchronized
    fun replaceHistoryFromCloud(records: List<WatchRecord>) {
        val normalized = records
            .sortedByDescending { it.lastWatchedAt }
            .take(MAX_HISTORY)
        _history.value = normalized
        activeUserId?.let { uid ->
            prefs.edit().putString(historyKey(uid), historyAdapter.toJson(normalized)).apply()
        }
    }

    /** Used by cloud sync only; deliberately does not emit another sync event. */
    @Synchronized
    fun removeMyListFromCloud(seriesId: String) {
        if (_myList.value.none { it.seriesId == seriesId }) return
        val updated = _myList.value.filterNot { it.seriesId == seriesId }
        _myList.value = updated
        activeUserId?.let { uid ->
            prefs.edit().putString(myListKey(uid), myListAdapter.toJson(updated)).apply()
        }
    }

    /** Used by cloud sync only; deliberately does not emit another sync event. */
    @Synchronized
    fun replaceMyListFromCloud(entries: List<MyListEntry>) {
        val normalized = entries.sortedByDescending { it.addedAt }
        _myList.value = normalized
        activeUserId?.let { uid ->
            prefs.edit().putString(myListKey(uid), myListAdapter.toJson(normalized)).apply()
        }
    }

    fun isInMyList(seriesId: String): Boolean = _myList.value.any { it.seriesId == seriesId }

    fun progressFor(seriesId: String, episodeId: Long): WatchRecord? =
        _history.value.firstOrNull { it.seriesId == seriesId && it.episodeId == episodeId }

    fun latestProgressForSeries(seriesId: String): WatchRecord? =
        _history.value.firstOrNull { it.seriesId == seriesId }

    fun saveQuality(quality: String) {
        prefs.edit().putString(KEY_QUALITY, quality).apply()
    }

    private fun loadHistory(key: String): List<WatchRecord> = runCatching {
        historyAdapter.fromJson(prefs.getString(key, "[]").orEmpty()).orEmpty()
            .sortedByDescending { it.lastWatchedAt }
            .take(MAX_HISTORY)
    }.getOrDefault(emptyList())

    private fun loadMyList(key: String): List<MyListEntry> = runCatching {
        myListAdapter.fromJson(prefs.getString(key, "[]").orEmpty()).orEmpty()
            .map { it.copy(updatedAt = it.updatedAt.takeIf { ts -> ts > 0L } ?: it.addedAt) }
            .sortedByDescending { it.addedAt }
    }.getOrDefault(emptyList())

    private fun historyKey(uid: String) = "watch_history_v2_$uid"
    private fun myListKey(uid: String) = "my_list_v2_$uid"

    companion object {
        private const val FILE_NAME = "project_lv_streaming"
        private const val LEGACY_HISTORY = "watch_history_v1"
        private const val LEGACY_MY_LIST = "my_list_v1"
        private const val KEY_QUALITY = "preferred_quality_v1"
        private const val KEY_AUTO_NEXT = "auto_next_v1"
        private const val MAX_HISTORY = 80
    }
}

sealed interface StreamingLocalChange {
    val syncKey: String

    data class HistoryUpsert(val record: WatchRecord) : StreamingLocalChange {
        override val syncKey: String = "history:${record.key}"
    }

    data class HistoryRemove(val key: String) : StreamingLocalChange {
        override val syncKey: String = "history:$key"
    }

    data object HistoryClear : StreamingLocalChange {
        override val syncKey: String = "history:__clear__"
    }

    data class MyListUpsert(val entry: MyListEntry) : StreamingLocalChange {
        override val syncKey: String = "mylist:${entry.seriesId}"
    }

    data class MyListRemove(val seriesId: String) : StreamingLocalChange {
        override val syncKey: String = "mylist:$seriesId"
    }
}
