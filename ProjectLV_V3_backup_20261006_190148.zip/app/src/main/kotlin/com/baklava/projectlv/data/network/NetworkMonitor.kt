package com.baklava.projectlv.data.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL

sealed interface NetworkStatus {
    data class Connected(
        val isWifi: Boolean,
        val isCellular: Boolean,
        val latencyMs: Long? = null,
        val realInternet: Boolean = true
    ) : NetworkStatus

    object Disconnected : NetworkStatus
}

class NetworkMonitor(private val context: Context) {

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    private val _status = MutableStateFlow<NetworkStatus>(NetworkStatus.Disconnected)
    val status: StateFlow<NetworkStatus> = _status.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            updateNetworkStatus()
        }

        override fun onLost(network: Network) {
            updateNetworkStatus()
        }

        override fun onCapabilitiesChanged(
            network: Network,
            networkCapabilities: NetworkCapabilities
        ) {
            updateNetworkStatus()
        }
    }

    init {
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        connectivityManager?.registerNetworkCallback(request, networkCallback)
        updateNetworkStatus()
    }

    fun isCurrentlyOnline(): Boolean {
        return _status.value is NetworkStatus.Connected
    }

    private fun updateNetworkStatus() {
        val cm = connectivityManager ?: run {
            _status.value = NetworkStatus.Disconnected
            return
        }
        val activeNetwork = cm.activeNetwork
        if (activeNetwork == null) {
            _status.value = NetworkStatus.Disconnected
            return
        }

        val caps = cm.getNetworkCapabilities(activeNetwork)
        if (caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
            _status.value = NetworkStatus.Disconnected
            return
        }

        val isWifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        val isCellular = caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)

        _status.value = NetworkStatus.Connected(isWifi = isWifi, isCellular = isCellular)

        // Async lightweight check
        scope.launch {
            val latency = measureRealPing()
            _status.value = NetworkStatus.Connected(
                isWifi = isWifi,
                isCellular = isCellular,
                latencyMs = latency,
                realInternet = latency != null
            )
        }
    }

    /**
     * Real active test to verify internet connectivity (HEAD / GET request to neutral host)
     * and DNS latency check.
     */
    suspend fun checkRealConnectivity(): ConnectivityCheckResult = withContext(Dispatchers.IO) {
        val cm = connectivityManager
        val activeNetwork = cm?.activeNetwork
        val caps = activeNetwork?.let { cm.getNetworkCapabilities(it) }

        val hasNetwork = caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        if (!hasNetwork) {
            return@withContext ConnectivityCheckResult(
                isConnected = false,
                latencyMs = -1,
                dnsResolved = false,
                message = "Internet: Tidak terdeteksi"
            )
        }

        // Test real HTTP connection
        var latencyMs: Long = -1
        var dnsResolved = false

        try {
            // DNS resolution check on neutral host & API hosts
            val dnsStart = System.currentTimeMillis()
            val address = InetAddress.getByName("cloudflare.com")
            dnsResolved = address.hostAddress?.isNotEmpty() == true

            val start = System.currentTimeMillis()
            val url = URL("https://www.google.com/generate_204")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 3000
            conn.readTimeout = 3000
            conn.requestMethod = "HEAD"
            conn.instanceFollowRedirects = false
            conn.useCaches = false
            val code = conn.responseCode
            latencyMs = System.currentTimeMillis() - start
            conn.disconnect()

            val isOk = code in 200..399
            if (isOk) {
                ConnectivityCheckResult(
                    isConnected = true,
                    latencyMs = latencyMs,
                    dnsResolved = dnsResolved,
                    message = "Internet: Terhubung ($latencyMs ms)"
                )
            } else {
                ConnectivityCheckResult(
                    isConnected = false,
                    latencyMs = latencyMs,
                    dnsResolved = dnsResolved,
                    message = "Internet: Terbatas ($code)"
                )
            }
        } catch (e: Exception) {
            ConnectivityCheckResult(
                isConnected = false,
                latencyMs = -1,
                dnsResolved = dnsResolved,
                message = "Internet: Tidak terdeteksi"
            )
        }
    }

    private fun measureRealPing(): Long? {
        return try {
            val start = System.currentTimeMillis()
            val url = URL("https://www.google.com/generate_204")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 2500
            conn.readTimeout = 2500
            conn.requestMethod = "HEAD"
            val code = conn.responseCode
            val took = System.currentTimeMillis() - start
            conn.disconnect()
            if (code in 200..399) took else null
        } catch (_: Exception) {
            null
        }
    }
}

data class ConnectivityCheckResult(
    val isConnected: Boolean,
    val latencyMs: Long,
    val dnsResolved: Boolean,
    val message: String
)
