package com.baklava.projectlv.ui.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import com.baklava.projectlv.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import com.baklava.projectlv.ui.components.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import com.baklava.projectlv.ui.components.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.data.models.ErrorReport
import com.baklava.projectlv.data.security.FirebaseUserAuthManager
import com.baklava.projectlv.data.network.ConnectivityCheckResult
import com.baklava.projectlv.data.network.NetworkMonitor
import com.baklava.projectlv.data.repository.ErrorReportManager
import com.baklava.projectlv.ui.components.AppWindowSize
import com.baklava.projectlv.ui.components.ModuleHeaderCard
import com.baklava.projectlv.ui.components.staggeredEntrance
import com.baklava.projectlv.ui.theme.BrightAmber
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.BrightMagenta
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    errorReportManager: ErrorReportManager,
    authManager: FirebaseUserAuthManager,
    networkMonitor: NetworkMonitor,
    windowSize: AppWindowSize,
    onShowSnackbar: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val reports by errorReportManager.reportsHistory.collectAsState()

    var isCheckingSystem by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<ConnectivityCheckResult?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        ModuleHeaderCard(
            icon = Icons.Default.Settings,
            title = "SETELAN & DIAGNOSTIK",
            subtitle = "Akun, keamanan, laporan error, dan uji jaringan"
        )

        // 0. Lihat Akun (nama, email, password + ganti)
        AccountCard(
            authManager = authManager,
            onShowSnackbar = onShowSnackbar,
            modifier = Modifier.staggeredEntrance(index = 1)
        )

        // 1. Session & Security
        Card(
            modifier = Modifier.fillMaxWidth().staggeredEntrance(index = 2),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Settings, contentDescription = null, tint = BrightCyan)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Keamanan Sesi",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
                    )
                }
                Text(
                    authManager.currentUser?.displayName.orEmpty().ifBlank { authManager.currentUser?.email.orEmpty().ifBlank { "Akun Firebase" } },
                    style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, fontWeight = FontWeight.SemiBold),
                    maxLines = 1
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecurityPill("EMAIL AUTH", BrightCyan)
                    SecurityPill("FIREBASE", BrightGreen)
                }
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            try {
                                authManager.signOut()
                                onShowSnackbar("Berhasil keluar dari akun.")
                            } catch (t: Throwable) {
                                onShowSnackbar(t.message ?: "Gagal keluar dari akun.")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BrightRed.copy(alpha = 0.55f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BrightRed),
                    shape = RoundedCornerShape(9.dp)
                ) {
                    Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(7.dp))
                    Text("LOG OUT", fontWeight = FontWeight.Bold)
                }
            }
        }

        // 2. Network & System On-Demand Diagnostic
        Card(
            modifier = Modifier.fillMaxWidth().staggeredEntrance(index = 3),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Speed, contentDescription = null, tint = Color(0xFFE5E7EB))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Diagnostik Jaringan Real-Time",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }

                Text(
                    text = "Uji resolusi DNS, probe konektivitas HTTP netral, dan periksa respon latency.",
                    style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey)
                )

                Button(
                    onClick = {
                        scope.launch {
                            isCheckingSystem = true
                            testResult = networkMonitor.checkRealConnectivity()
                            isCheckingSystem = false
                            onShowSnackbar("Uji diagnostik jaringan selesai.")
                        }
                    },
                    enabled = !isCheckingSystem,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("btn_run_system_diagnostic"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5E7EB), contentColor = Color(0xFF0C0D10))
                ) {
                    if (isCheckingSystem) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color(0xFF0C0D10))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Menguji Konektivitas...")
                    } else {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Jalankan Uji Sistem", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                    }
                }

                if (testResult != null) {
                    val r = testResult!!
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .staggeredEntrance(index = 0, offsetY = 10.dp, durationMs = 320, startScale = 0.98f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberBlack)
                            .border(1.dp, if (r.isConnected) Color(0xFFE5E7EB).copy(alpha = 0.4f) else BrightRed.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = r.message,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (r.isConnected) Color(0xFFE5E7EB) else BrightRed
                                )
                            )
                            Text(
                                text = "DNS Resolution: ${if (r.dnsResolved) "SUKSES" else "GAGAL"}",
                                style = MaterialTheme.typography.labelSmall.copy(color = MutedGrey, fontFamily = FontFamily.Default)
                            )
                            if (r.latencyMs > 0) {
                                Text(
                                    text = "Round-trip Latency: ${r.latencyMs} ms",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFCBD5E1), fontFamily = FontFamily.Default)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Error Reports Log History
        Card(
            modifier = Modifier.fillMaxWidth().staggeredEntrance(index = 4),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.BugReport, contentDescription = null, tint = BrightRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Riwayat Laporan Error (${reports.size})",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }
                }

                Text(
                    text = "Semua error yang terekam telah disanitasi oleh SecretRedactor",
                    style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey)
                )

                if (reports.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberBlack)
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Tidak ada laporan error. Sistem berjalan optimal.",
                            style = MaterialTheme.typography.bodySmall.copy(color = BrightGreen)
                        )
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        reports.take(10).forEachIndexed { index, report ->
                            Box(Modifier.staggeredEntrance(index = index, offsetY = 12.dp, durationMs = 340)) {
                                ReportItemCard(report = report)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportItemCard(report: ErrorReport) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CyberBlack)
            .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = report.moduleContext,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color(0xFFE5E7EB),
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Default
                    )
                )
                Text(
                    text = report.formattedDate(),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MutedGrey,
                        fontSize = 10.sp
                    )
                )
            }
            Text(
                text = "Detail teknis disembunyikan dari client dan dikirim secara tersanitasi ke panel admin.",
                style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey)
            )
        }
    }
}

@Composable
private fun SecurityPill(label: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 9.dp, vertical = 5.dp)
    ) {
        Text(label, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}
