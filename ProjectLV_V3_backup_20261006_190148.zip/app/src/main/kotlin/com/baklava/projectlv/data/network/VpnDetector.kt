package com.baklava.projectlv.data.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.LinkProperties

/**
 * Deteksi VPN aktif di perangkat.
 *
 * Prioritas utama menggunakan TRANSPORT_VPN dari ConnectivityManager.
 * Fallback memeriksa nama interface yang umum dipakai oleh VPN/tunnel.
 */
class VpnDetector(context: Context) {

    private val appContext = context.applicationContext
    private val connectivityManager =
        appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    fun isVpnActive(): Boolean {
        val cm = connectivityManager ?: return false

        // Android resmi: cari network yang memakai transport VPN.
        try {
            val activeNetwork = cm.activeNetwork
            val activeCaps = activeNetwork?.let(cm::getNetworkCapabilities)
            if (activeCaps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) {
                return true
            }

            // Beberapa konfigurasi dapat membuat VPN bukan sebagai activeNetwork utama.
            cm.allNetworks.forEach { network ->
                val caps = cm.getNetworkCapabilities(network)
                if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) {
                    return true
                }
            }
        } catch (_: SecurityException) {
            // Lanjut ke fallback interface check.
        } catch (_: RuntimeException) {
            // Hindari membuat aplikasi gagal hanya karena API jaringan bermasalah.
        }

        return hasVpnLikeInterface()
    }

    private fun hasVpnLikeInterface(): Boolean {
        return try {
            val interfaces = java.net.NetworkInterface.getNetworkInterfaces() ?: return false
            while (interfaces.hasMoreElements()) {
                val name = interfaces.nextElement().name.lowercase()
                if (VPN_INTERFACE_NAMES.any { name == it || name.startsWith(it) }) {
                    return true
                }
            }
            false
        } catch (_: Exception) {
            false
        }
    }

    companion object {
        private val VPN_INTERFACE_NAMES = setOf(
            "tun0",
            "tun1",
            "tun2",
            "tun3",
            "ppp0",
            "wg0",
            "wg1",
            "ipsec0",
            "ipsec1"
        )
    }
}
