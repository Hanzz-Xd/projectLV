package com.baklava.projectlv.ui.modules.tiktokquality

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.floor
import kotlin.math.roundToInt

/**
 * Port of the original uploaded Pure-JS MP4 binary patch.
 * Constants and structural decisions intentionally mirror Quality.txt.
 */
object Mp4QualityPatch {
    private val FAKE_SAMPLE_BYTES = byteArrayOf(0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00)
    private const val FAKE_SAMPLE_SIZE = 8

    private val CONTAINER_BOXES = setOf(
        "moov", "trak", "mdia", "minf", "stbl",
        "edts", "dinf", "udta", "meta", "ilst"
    )

    data class Resolution(val width: Int, val height: Int, val rotated: Boolean)
    data class VideoProcessingOptions(val width: Int, val height: Int, val vfString: String)
    data class PatchStats(
        val output: ByteArray,
        val realSamples: Int,
        val fakeSamples: Int,
        val timescale: Long,
        val sampleDelta: Long,
        val duration: Long,
        val chunkCount: Int,
        val inputFps: Int,
        val patchedFps: Int,
        val audioFix: Boolean = false
    )

    private data class Mp4Box(
        val type: String,
        val offset: Int,
        val size: Long,
        val headerSize: Int,
        val contentStart: Int,
        val end: Int,
        val path: String,
        val data: ByteArray,
        val prefixStart: Int,
        val prefixEnd: Int,
        var children: MutableList<Mp4Box> = mutableListOf()
    ) {
        fun bytes(): ByteArray = data.copyOfRange(offset, end)
    }

    private class ParseTree(val boxes: MutableList<Mp4Box>)

    private fun getBoxType(data: ByteArray, offset: Int): String {
        if (offset + 4 > data.size) return ""
        return data.copyOfRange(offset, offset + 4).toString(Charsets.ISO_8859_1)
    }

    private fun readU32BE(data: ByteArray, offset: Int): Long {
        require(offset + 4 <= data.size) { "uint32 read out of bounds" }
        return ByteBuffer.wrap(data, offset, 4).order(ByteOrder.BIG_ENDIAN).int.toLong() and 0xffffffffL
    }

    private fun writeU32BE(data: ByteArray, offset: Int, value: Long) {
        require(offset + 4 <= data.size) { "uint32 write out of bounds" }
        ByteBuffer.wrap(data, offset, 4).order(ByteOrder.BIG_ENDIAN).putInt(value.toInt())
    }

    private fun readBox(data: ByteArray, offset: Int, end: Int, parentPath: String): Mp4Box? {
        if (offset + 8 > end) return null
        val smallSize = readU32BE(data, offset).toInt()
        val type = getBoxType(data, offset + 4)
        var size = smallSize.toLong()
        var headerSize = 8
        if (smallSize == 1) {
            if (offset + 16 > end) return null
            val high = readU32BE(data, offset + 8)
            val low = readU32BE(data, offset + 12)
            size = high * 4_294_967_296L + low
            headerSize = 16
        } else if (smallSize == 0) {
            size = (end - offset).toLong()
        }
        if (size < headerSize || offset.toLong() + size > end.toLong()) return null
        val boxEnd = (offset.toLong() + size).toInt()
        val path = if (parentPath.isNotEmpty()) "$parentPath/$type" else type
        return Mp4Box(
            type = type,
            offset = offset,
            size = size,
            headerSize = headerSize,
            contentStart = offset + headerSize,
            end = boxEnd,
            path = path,
            data = data,
            prefixStart = offset + headerSize,
            prefixEnd = offset + headerSize
        )
    }

    private fun childStartForBox(box: Mp4Box): Int = if (box.type == "meta") box.contentStart + 4 else box.contentStart

    private fun parseTree(data: ByteArray): ParseTree {
        fun recurse(start: Int, end: Int, parent: String): MutableList<Mp4Box> {
            val out = mutableListOf<Mp4Box>()
            var off = start
            while (off + 8 <= end) {
                val raw = readBox(data, off, end, parent) ?: break
                var box = raw
                if (CONTAINER_BOXES.contains(box.type)) {
                    val childStart = childStartForBox(box)
                    if (childStart <= box.end) {
                        box = box.copy(
                            prefixStart = box.contentStart,
                            prefixEnd = childStart,
                            children = recurse(childStart, box.end, box.path)
                        )
                    }
                }
                out += box
                off = box.end
            }
            return out
        }
        return ParseTree(recurse(0, data.size, ""))
    }

    private fun findChild(box: Mp4Box?, type: String): Mp4Box? = box?.children?.firstOrNull { it.type == type }
    private fun findDescendant(box: Mp4Box?, path: List<String>): Mp4Box? {
        var cur = box
        for (type in path) {
            cur = findChild(cur, type) ?: return null
        }
        return cur
    }
    private fun findTopLevel(boxes: List<Mp4Box>, type: String): Mp4Box? = boxes.firstOrNull { it.type == type }

    private fun handlerTypeForTrak(trak: Mp4Box): String? {
        val hdlr = findDescendant(trak, listOf("mdia", "hdlr")) ?: return null
        if (hdlr.offset + 20 > hdlr.end) return null
        return getBoxType(hdlr.data, hdlr.offset + 16)
    }

    private fun getTimescale(trak: Mp4Box): Long {
        val mdhd = findDescendant(trak, listOf("mdia", "mdhd")) ?: return 90_000L
        val version = mdhd.data[mdhd.offset + 8].toInt() and 0xff
        return if (version == 0) readU32BE(mdhd.data, mdhd.offset + 20)
        else readU32BE(mdhd.data, mdhd.offset + 28)
    }

    private fun parseStsz(stsz: Mp4Box): LongArray {
        val sampleSize = readU32BE(stsz.data, stsz.offset + 12)
        val count = readU32BE(stsz.data, stsz.offset + 16).toInt()
        if (sampleSize != 0L) return LongArray(count) { sampleSize }
        val tableStart = stsz.offset + 20
        require(tableStart + count * 4 <= stsz.end) { "stsz too small for declared sample count." }
        return LongArray(count) { i -> readU32BE(stsz.data, tableStart + i * 4) }
    }

    private fun parseStco(box: Mp4Box): LongArray {
        val count = readU32BE(box.data, box.offset + 12).toInt()
        val tableStart = box.offset + 16
        val itemSize = if (box.type == "co64") 8 else 4
        require(tableStart + count * itemSize <= box.end) { "${box.type} too small for declared chunk count." }
        val offsets = LongArray(count)
        for (i in 0 until count) {
            offsets[i] = if (box.type == "co64") {
                val high = readU32BE(box.data, tableStart + i * 8)
                val low = readU32BE(box.data, tableStart + i * 8 + 4)
                high * 4_294_967_296L + low
            } else readU32BE(box.data, tableStart + i * 4)
        }
        return offsets
    }

    private fun parseStsc(stsc: Mp4Box): List<LongArray> {
        val count = readU32BE(stsc.data, stsc.offset + 12).toInt()
        val tableStart = stsc.offset + 16
        require(tableStart + count * 12 <= stsc.end) { "stsc too small for declared entry count." }
        return List(count) { i ->
            val off = tableStart + i * 12
            longArrayOf(
                readU32BE(stsc.data, off),
                readU32BE(stsc.data, off + 4),
                readU32BE(stsc.data, off + 8)
            )
        }
    }

    private fun parseStts(stts: Mp4Box): List<LongArray> {
        val count = readU32BE(stts.data, stts.offset + 12).toInt()
        val tableStart = stts.offset + 16
        return List(count) { i ->
            val off = tableStart + i * 8
            longArrayOf(readU32BE(stts.data, off), readU32BE(stts.data, off + 4))
        }
    }

    private fun makeBox(type: String, payload: ByteArray): ByteArray {
        require(type.length == 4) { "MP4 box type must be 4 bytes" }
        val size = 8L + payload.size
        require(size <= 0xffffffffL) { "$type.size out of uint32 range: $size" }
        val box = ByteArray(size.toInt())
        writeU32BE(box, 0, size)
        type.toByteArray(Charsets.ISO_8859_1).copyInto(box, 4)
        payload.copyInto(box, 8)
        return box
    }

    private fun concatBytes(parts: Iterable<ByteArray?>): ByteArray {
        val total = parts.sumOf { it?.size ?: 0 }
        val out = ByteArray(total)
        var off = 0
        parts.forEach { part ->
            if (part != null) {
                part.copyInto(out, off)
                off += part.size
            }
        }
        return out
    }

    private fun buildStco(offsets: LongArray): ByteArray {
        val payload = ByteArray(8 + offsets.size * 4)
        writeU32BE(payload, 4, offsets.size.toLong())
        offsets.forEachIndexed { index, value ->
            require(value in 0..0xffffffffL) { "stco.chunk_offset out of uint32 range: $value" }
            writeU32BE(payload, 8 + index * 4, value)
        }
        return makeBox("stco", payload)
    }

    private fun buildStsc(rows: List<LongArray>): ByteArray {
        val payload = ByteArray(8 + rows.size * 12)
        writeU32BE(payload, 4, rows.size.toLong())
        rows.forEachIndexed { i, row ->
            writeU32BE(payload, 8 + i * 12, row[0])
            writeU32BE(payload, 12 + i * 12, row[1])
            writeU32BE(payload, 16 + i * 12, row[2])
        }
        return makeBox("stsc", payload)
    }

    private fun buildStsz(sizes: LongArray): ByteArray {
        val payload = ByteArray(12 + sizes.size * 4)
        writeU32BE(payload, 8, sizes.size.toLong())
        sizes.forEachIndexed { i, size -> writeU32BE(payload, 12 + i * 4, size) }
        return makeBox("stsz", payload)
    }

    private fun buildStts(entries: List<LongArray>): ByteArray {
        val payload = ByteArray(8 + entries.size * 8)
        writeU32BE(payload, 4, entries.size.toLong())
        entries.forEachIndexed { i, entry ->
            writeU32BE(payload, 8 + i * 8, entry[0])
            writeU32BE(payload, 12 + i * 8, entry[1])
        }
        return makeBox("stts", payload)
    }

    private fun buildCommentItem(comment: String): ByteArray {
        val text = comment.toByteArray(Charsets.UTF_8)
        val dataPayload = ByteArray(8 + text.size)
        text.copyInto(dataPayload, 8)
        return makeBox("\u00A9cmt", makeBox("data", dataPayload))
    }

    private fun buildCommentMetadata(): ByteArray {
        val item = buildCommentItem("Patch by cutefish.my.id")
        return makeBox("meta", concatBytes(listOf(ByteArray(4), makeBox("ilst", item))))
    }

    private fun addCommentMetadata(moov: Mp4Box, replacements: MutableMap<Mp4Box, ByteArray?>) {
        val udta = findChild(moov, "udta")
        if (udta == null) {
            val moovBytes = rebuildBox(moov, replacements) ?: return
            val rebuiltMoov = makeBox("moov", concatBytes(listOf(moovBytes.copyOfRange(8, moovBytes.size), makeBox("udta", buildCommentMetadata()))))
            replacements[moov] = rebuiltMoov
            return
        }

        val meta = findChild(udta, "meta")
        if (meta == null) {
            val udtaPrefix = udta.data.copyOfRange(udta.offset + 8, udta.prefixEnd)
            val udtaChildren = udta.children.map { box -> box.bytes() }
            replacements[udta] = makeBox("udta", concatBytes(listOf(udtaPrefix) + udtaChildren + buildCommentMetadata()))
            return
        }

        val ilst = findChild(meta, "ilst")
        if (ilst != null) {
            val items = ilst.children.filter { it.type != "\u00A9cmt" }.map { it.bytes() }
            replacements[ilst] = makeBox("ilst", concatBytes(items + buildCommentItem("Patch by cutefish.my.id")))
            return
        }

        val metaPrefix = meta.data.copyOfRange(meta.offset + 8, meta.prefixEnd)
        val metaChildren = meta.children.map { it.bytes() }
        replacements[meta] = makeBox("meta", concatBytes(listOf(metaPrefix) + metaChildren + makeBox("ilst", buildCommentItem("Patch by cutefish.my.id"))))
    }

    private fun rebuildBox(box: Mp4Box, replacements: Map<Mp4Box, ByteArray?>): ByteArray? {
        if (replacements.containsKey(box)) return replacements[box]
        if (box.children.isEmpty()) return box.bytes()
        val prefix = box.data.copyOfRange(box.prefixStart, box.prefixEnd)
        val parts = mutableListOf<ByteArray?>().apply { add(prefix) }
        box.children.forEach { child -> parts += rebuildBox(child, replacements) }
        return makeBox(box.type, concatBytes(parts))
    }

    private fun getTrackId(trak: Mp4Box): Long {
        val tkhd = findChild(trak, "tkhd") ?: return 0
        val d = tkhd.bytes()
        val isV1 = (d[8].toInt() and 0xff) == 1
        val idOff = 8 + if (isV1) 20 else 12
        return readU32BE(d, idOff)
    }

    private fun withTrackId(trak: Mp4Box, newId: Long): ByteArray? {
        val tkhd = findChild(trak, "tkhd") ?: return null
        val d = tkhd.bytes()
        val isV1 = (d[8].toInt() and 0xff) == 1
        val idOff = 8 + if (isV1) 20 else 12
        writeU32BE(d, idOff, newId)
        return d
    }

    private fun buildFixedAudioClone(audioTrak: Mp4Box, ctx: AudioCloneContext): ByteArray {
        val cloneReplacements = mutableMapOf<Mp4Box, ByteArray?>()
        findChild(audioTrak, "edts")?.let { cloneReplacements[it] = null }
        findChild(audioTrak, "udta")?.let { cloneReplacements[it] = null }
        findChild(audioTrak, "tkhd")?.let { tkhd ->
            withTrackId(audioTrak, ctx.newTrackId)?.let { cloneReplacements[tkhd] = it }
        }
        cloneReplacements[ctx.aStcoBox] = buildStco(ctx.aRelOffsets.map { it + ctx.newMdatContentStart }.toLongArray() + longArrayOf(ctx.fakeChunkOffset))
        cloneReplacements[ctx.aStszBox] = buildStsz(ctx.aOrigSizes + LongArray(ctx.fakeCount) { FAKE_SAMPLE_SIZE.toLong() })
        cloneReplacements[ctx.aStscBox] = buildStsc(ctx.aOrigStsc + listOf(longArrayOf(ctx.aRelOffsets.size.toLong() + 1, ctx.fakeCount.toLong(), 1)))
        cloneReplacements[ctx.aSttsBox] = buildStts(ctx.aOrigStts + listOf(longArrayOf(ctx.fakeCount.toLong(), 1)))
        return rebuildBox(audioTrak, cloneReplacements) ?: error("Failed to clone audio track")
    }

    private data class AudioCloneContext(
        val newTrackId: Long,
        val newMdatContentStart: Long,
        val origMdatPayload: ByteArray,
        val aRelOffsets: LongArray,
        val aOrigSizes: LongArray,
        val aOrigStsc: List<LongArray>,
        val aOrigStts: List<LongArray>,
        val aStcoBox: Mp4Box,
        val aStszBox: Mp4Box,
        val aStscBox: Mp4Box,
        val aSttsBox: Mp4Box,
        val fakeCount: Int
    ) {
        val fakeChunkOffset: Long get() = newMdatContentStart + origMdatPayload.size
    }

    fun patchMp4(inputData: ByteArray, fixAudio: Boolean, onLog: (String) -> Unit = {}): PatchStats {
        val data = inputData.copyOf()
        onLog("Input buffer size: ${data.size} bytes (${formatMb(data.size.toLong())} MB)")
        val tree = parseTree(data)
        val ftyp = findTopLevel(tree.boxes, "ftyp") ?: error("Missing required MP4 boxes.")
        val moov = findTopLevel(tree.boxes, "moov") ?: error("Missing required MP4 boxes.")
        val mdat = findTopLevel(tree.boxes, "mdat") ?: error("Missing required MP4 boxes.")
        @Suppress("UNUSED_VARIABLE") val ignoredFtyp = ftyp

        val ftypPayload = byteArrayOf(
            0x69, 0x73, 0x6f, 0x6d,
            0x00, 0x00, 0x02, 0x00,
            0x69, 0x73, 0x6f, 0x6d,
            0x69, 0x73, 0x6f, 0x32,
            0x61, 0x76, 0x63, 0x31,
            0x6d, 0x70, 0x34, 0x31
        )
        val ftypBytes = makeBox("ftyp", ftypPayload)

        val origMdatPayload = data.copyOfRange(mdat.contentStart, mdat.end)
        val origMdatContentStart = mdat.contentStart.toLong()
        val traks = moov.children.filter { it.type == "trak" }.toMutableList()
        val videoTrak = traks.firstOrNull { handlerTypeForTrak(it) == "vide" } ?: error("Video track not found.")
        val audioTrak = traks.firstOrNull { handlerTypeForTrak(it) == "soun" }

        val vStbl = findDescendant(videoTrak, listOf("mdia", "minf", "stbl")) ?: error("Video sample table not found.")
        val vStcoBox = findChild(vStbl, "stco") ?: findChild(vStbl, "co64") ?: error("Video chunk offsets not found.")
        val vSttsBox = findChild(vStbl, "stts") ?: error("Video timing table not found.")
        val vStszBox = findChild(vStbl, "stsz") ?: error("Video sample sizes not found.")
        val vOrigOffsets = parseStco(vStcoBox)
        val vRelOffsets = vOrigOffsets.map { it - origMdatContentStart }.toLongArray()
        val vStsz = parseStsz(vStszBox)
        val vStts = parseStts(vSttsBox)

        var fakeCount = 0
        var aRelOffsets = LongArray(0)
        var aOrigSizes = LongArray(0)
        var aOrigStsc = emptyList<LongArray>()
        var aOrigStts = emptyList<LongArray>()
        var aStbl: Mp4Box? = null
        var aStszBox: Mp4Box? = null
        var aStcoBox: Mp4Box? = null
        var aStscBox: Mp4Box? = null
        var aSttsBox: Mp4Box? = null

        if (audioTrak != null) {
            aStbl = findDescendant(audioTrak, listOf("mdia", "minf", "stbl"))
            aStszBox = aStbl?.let { findChild(it, "stsz") }
            aStcoBox = aStbl?.let { findChild(it, "stco") ?: findChild(it, "co64") }
            aStscBox = aStbl?.let { findChild(it, "stsc") }
            aSttsBox = aStbl?.let { findChild(it, "stts") }
            if (aStbl != null && aStszBox != null && aStcoBox != null && aStscBox != null && aSttsBox != null) {
                aOrigSizes = parseStsz(aStszBox!!)
                fakeCount = aOrigSizes.size * 9
                val aOrigOffsets = parseStco(aStcoBox!!)
                aRelOffsets = aOrigOffsets.map { it - origMdatContentStart }.toLongArray()
                aOrigStsc = parseStsc(aStscBox!!)
                aOrigStts = parseStts(aSttsBox!!)
            }
        } else {
            fakeCount = vStsz.size * 9
        }

        val fakePayload = ByteArray(fakeCount * FAKE_SAMPLE_SIZE)
        repeat(fakeCount) { i -> FAKE_SAMPLE_BYTES.copyInto(fakePayload, i * FAKE_SAMPLE_SIZE) }

        var fixTrakStub: Mp4Box? = null
        var fixNewTrackId = 0L
        if (audioTrak != null && fixAudio) {
            fixNewTrackId = traks.maxOfOrNull { getTrackId(it) }?.plus(1) ?: 1
            fixTrakStub = Mp4Box("trak", -1, 8, 8, -1, -1, "moov/trak#stub", ByteArray(0), 0, 0, mutableListOf())
            moov.children.add(fixTrakStub)
            onLog("Fix unidentified audio: ON — original audio kept clean, padded clone added as track #$fixNewTrackId.")
        }

        var moovHeaderLen = moov.size
        var finalOutput: ByteArray? = null
        var patchResultStats: PatchStats? = null

        repeat(3) { pass ->
            val newMdatContentStart = ftypBytes.size.toLong() + moovHeaderLen + 8
            val replacements = mutableMapOf<Mp4Box, ByteArray?>()

            if (fixTrakStub != null && audioTrak != null && aStbl != null && aStszBox != null && aStcoBox != null && aStscBox != null && aSttsBox != null) {
                val clone = buildFixedAudioClone(
                    audioTrak,
                    AudioCloneContext(
                        newTrackId = fixNewTrackId,
                        newMdatContentStart = newMdatContentStart,
                        origMdatPayload = origMdatPayload,
                        aRelOffsets = aRelOffsets,
                        aOrigSizes = aOrigSizes,
                        aOrigStsc = aOrigStsc,
                        aOrigStts = aOrigStts,
                        aStcoBox = aStcoBox!!,
                        aStszBox = aStszBox!!,
                        aStscBox = aStscBox!!,
                        aSttsBox = aSttsBox!!,
                        fakeCount = fakeCount
                    )
                )
                replacements[fixTrakStub] = clone
            }

            findChild(videoTrak, "edts")?.let { replacements[it] = null }
            replacements[vStcoBox] = buildStco(vRelOffsets.map { it + newMdatContentStart }.toLongArray())

            if (audioTrak != null && !fixAudio && aStcoBox != null && aStszBox != null && aStscBox != null && aSttsBox != null) {
                findChild(audioTrak, "edts")?.let { replacements[it] = null }
                findChild(audioTrak, "udta")?.let { replacements[it] = null }
                val fakeChunkOffset = newMdatContentStart + origMdatPayload.size
                val newAOffsets = aRelOffsets.map { it + newMdatContentStart }.toLongArray() + longArrayOf(fakeChunkOffset)
                replacements[aStcoBox!!] = buildStco(newAOffsets)
                replacements[aStszBox!!] = buildStsz(aOrigSizes + LongArray(fakeCount) { FAKE_SAMPLE_SIZE.toLong() })
                replacements[aStscBox!!] = buildStsc(aOrigStsc + listOf(longArrayOf(aRelOffsets.size.toLong() + 1, fakeCount.toLong(), 1)))
                replacements[aSttsBox!!] = buildStts(aOrigStts + listOf(longArrayOf(fakeCount.toLong(), 1)))
            } else if (audioTrak != null && fixAudio && aStcoBox != null) {
                findChild(audioTrak, "edts")?.let { replacements[it] = null }
                findChild(audioTrak, "udta")?.let { replacements[it] = null }
                replacements[aStcoBox!!] = buildStco(aRelOffsets.map { it + newMdatContentStart }.toLongArray())
            }

            if (fixTrakStub != null) {
                val mvhd = findChild(moov, "mvhd")
                if (mvhd != null) {
                    val mvhdData = mvhd.bytes()
                    writeU32BE(mvhdData, mvhdData.size - 4, fixNewTrackId + 1)
                    replacements[mvhd] = mvhdData
                }
            }

            addCommentMetadata(moov, replacements)
            val moovFinal = rebuildBox(moov, replacements) ?: error("Failed to rebuild moov")
            moovHeaderLen = moovFinal.size.toLong()

            if (pass == 2) {
                val newMdatBox = makeBox("mdat", origMdatPayload)
                finalOutput = concatBytes(listOf(ftypBytes, moovFinal, newMdatBox, fakePayload))
                val vTimescale = getTimescale(videoTrak)
                val inputFps = ((vTimescale.toDouble()) / (vStts.firstOrNull()?.get(1) ?: 1000L).toDouble()).roundToInt()
                patchResultStats = PatchStats(
                    output = finalOutput!!,
                    realSamples = vStsz.size,
                    fakeSamples = fakeCount,
                    timescale = vTimescale,
                    sampleDelta = vStts.firstOrNull()?.get(1) ?: 1000L,
                    duration = vStsz.size * (vStts.firstOrNull()?.get(1) ?: 1000L),
                    chunkCount = vRelOffsets.size,
                    inputFps = inputFps,
                    patchedFps = inputFps,
                    audioFix = fixTrakStub != null
                )
            }
        }

        onLog("V3 MP4 patch completed successfully. Total output: ${finalOutput!!.size} bytes.")
        return patchResultStats!!
    }

    fun patchMp4Fps(inputData: ByteArray, onLog: (String) -> Unit = {}): PatchStats {
        val data = inputData.copyOf()
        onLog("Input buffer size: ${data.size} bytes")
        val tree = parseTree(data)
        val ftyp = findTopLevel(tree.boxes, "ftyp") ?: error("Missing required MP4 boxes.")
        val moov = findTopLevel(tree.boxes, "moov") ?: error("Missing required MP4 boxes.")
        val mdat = findTopLevel(tree.boxes, "mdat") ?: error("Missing required MP4 boxes.")
        @Suppress("UNUSED_VARIABLE") val ignored = ftyp

        val ftypPayload = byteArrayOf(
            0x69, 0x73, 0x6f, 0x6d,
            0x00, 0x00, 0x02, 0x00,
            0x69, 0x73, 0x6f, 0x6d,
            0x69, 0x73, 0x6f, 0x32,
            0x61, 0x76, 0x63, 0x31,
            0x6d, 0x70, 0x34, 0x31
        )
        val ftypBytes = makeBox("ftyp", ftypPayload)
        val origMdatPayload = data.copyOfRange(mdat.contentStart, mdat.end)
        val origMdatContentStart = mdat.contentStart.toLong()
        val traks = moov.children.filter { it.type == "trak" }
        val videoTrak = traks.firstOrNull { handlerTypeForTrak(it) == "vide" } ?: error("Video track not found.")
        val audioTrak = traks.firstOrNull { handlerTypeForTrak(it) == "soun" }

        val vStbl = findDescendant(videoTrak, listOf("mdia", "minf", "stbl")) ?: error("Video sample table not found.")
        val vStcoBox = findChild(vStbl, "stco") ?: findChild(vStbl, "co64") ?: error("Video chunk offsets not found.")
        val vSttsBox = findChild(vStbl, "stts") ?: error("Video timing table not found.")
        val vStszBox = findChild(vStbl, "stsz") ?: error("Video sample sizes not found.")
        val vOrigOffsets = parseStco(vStcoBox)
        val vRelOffsets = vOrigOffsets.map { it - origMdatContentStart }.toLongArray()
        val vStsz = parseStsz(vStszBox)
        val vStts = parseStts(vSttsBox)
        val vTimescale = getTimescale(videoTrak)
        val vSampleCount = vStsz.size
        val vBaseDelta = vStts.firstOrNull()?.get(1) ?: 1500L
        val newVStts = listOf(longArrayOf((vSampleCount - 1).toLong(), vBaseDelta * 2), longArrayOf(1, vBaseDelta))
        val vMdhdDur = (vSampleCount - 1L) * (vBaseDelta * 2) + vBaseDelta
        val vMvhdDur = vMdhdDur * 1000 / vTimescale

        var aRelOffsets = LongArray(0)
        var aStcoBox: Mp4Box? = null
        var newAStts = emptyList<LongArray>()
        var aMdhdDur = 0L
        var aMvhdDur = 0L

        if (audioTrak != null) {
            val aTimescale = getTimescale(audioTrak)
            val aStbl = findDescendant(audioTrak, listOf("mdia", "minf", "stbl")) ?: error("Audio sample table not found.")
            aStcoBox = findChild(aStbl, "stco") ?: findChild(aStbl, "co64") ?: error("Audio chunk offsets not found.")
            val aStszBox = findChild(aStbl, "stsz") ?: error("Audio sample sizes not found.")
            val aSttsBox = findChild(aStbl, "stts") ?: error("Audio timing table not found.")
            val aOrigSizes = parseStsz(aStszBox)
            val aOrigOffsets = parseStco(aStcoBox!!)
            aRelOffsets = aOrigOffsets.map { it - origMdatContentStart }.toLongArray()
            val aOrigStts = parseStts(aSttsBox)
            val aBaseDelta = aOrigStts.firstOrNull()?.get(1) ?: 1024L
            val aSampleCount = aOrigSizes.size
            val lastDelta = if (aOrigStts.size > 1) aOrigStts[aOrigStts.size - 1][1] else 992L
            newAStts = listOf(longArrayOf((aSampleCount - 1).toLong(), aBaseDelta * 2), longArrayOf(1, lastDelta))
            aMdhdDur = (aSampleCount - 1L) * (aBaseDelta * 2) + lastDelta
            aMvhdDur = aMdhdDur * 1000 / aTimescale
        }

        var moovHeaderLen = moov.size.toLong()
        var finalOutput: ByteArray? = null
        repeat(3) { pass ->
            val newMdatContentStart = ftypBytes.size.toLong() + moovHeaderLen + 8
            val replacements = mutableMapOf<Mp4Box, ByteArray?>()
            replacements[vStcoBox] = buildStco(vRelOffsets.map { it + newMdatContentStart }.toLongArray())
            replacements[vSttsBox] = buildStts(newVStts)

            val vMdhd = findDescendant(videoTrak, listOf("mdia", "mdhd"))
            if (vMdhd != null) {
                val vMdhdData = vMdhd.bytes()
                val isV1 = (vMdhdData[8].toInt() and 0xff) == 1
                val durOff = if (isV1) 32 else 24
                writeU32BE(vMdhdData, durOff, vMdhdDur)
                replacements[vMdhd] = vMdhdData
            }
            val vTkhd = findChild(videoTrak, "tkhd")
            if (vTkhd != null) {
                val vTkhdData = vTkhd.bytes()
                val isV1 = (vTkhdData[8].toInt() and 0xff) == 1
                val durOff = if (isV1) 32 else 28
                writeU32BE(vTkhdData, durOff, vMvhdDur)
                replacements[vTkhd] = vTkhdData
            }
            val vElst = findDescendant(videoTrak, listOf("edts", "elst"))
            if (vElst != null) {
                val vElstData = vElst.bytes()
                val isV1 = (vElstData[8].toInt() and 0xff) == 1
                val durOff = if (isV1) 20 else 16
                writeU32BE(vElstData, durOff, vMvhdDur)
                replacements[vElst] = vElstData
            }

            if (audioTrak != null && aStcoBox != null) {
                replacements[aStcoBox!!] = buildStco(aRelOffsets.map { it + newMdatContentStart }.toLongArray())
                val aSttsBox = findDescendant(audioTrak, listOf("mdia", "minf", "stbl", "stts"))
                if (aSttsBox != null) replacements[aSttsBox] = buildStts(newAStts)
                val aMdhd = findDescendant(audioTrak, listOf("mdia", "mdhd"))
                if (aMdhd != null) {
                    val aMdhdData = aMdhd.bytes()
                    val isV1 = (aMdhdData[8].toInt() and 0xff) == 1
                    val durOff = if (isV1) 32 else 24
                    writeU32BE(aMdhdData, durOff, aMdhdDur)
                    replacements[aMdhd] = aMdhdData
                }
                val aTkhd = findChild(audioTrak, "tkhd")
                if (aTkhd != null) {
                    val aTkhdData = aTkhd.bytes()
                    val isV1 = (aTkhdData[8].toInt() and 0xff) == 1
                    val durOff = if (isV1) 32 else 28
                    writeU32BE(aTkhdData, durOff, aMvhdDur)
                    replacements[aTkhd] = aTkhdData
                }
                val aElst = findDescendant(audioTrak, listOf("edts", "elst"))
                if (aElst != null) {
                    val aElstData = aElst.bytes()
                    val isV1 = (aElstData[8].toInt() and 0xff) == 1
                    val durOff = if (isV1) 20 else 16
                    writeU32BE(aElstData, durOff, aMvhdDur)
                    replacements[aElst] = aElstData
                }
            }

            val mvhd = findChild(moov, "mvhd")
            if (mvhd != null) {
                val mvhdData = mvhd.bytes()
                val isV1 = (mvhdData[8].toInt() and 0xff) == 1
                val durOff = if (isV1) 32 else 24
                val maxMvhdDur = maxOf(vMvhdDur, aMvhdDur)
                writeU32BE(mvhdData, durOff, maxMvhdDur)
                replacements[mvhd] = mvhdData
            }

            addCommentMetadata(moov, replacements)
            val moovFinal = rebuildBox(moov, replacements) ?: error("Failed to rebuild moov")
            moovHeaderLen = moovFinal.size.toLong()
            if (pass == 2) {
                val newMdatBox = makeBox("mdat", origMdatPayload)
                finalOutput = concatBytes(listOf(ftypBytes, moovFinal, newMdatBox))
            }
        }

        val inputFps = ((vTimescale.toDouble()) / vBaseDelta.toDouble()).roundToInt()
        val patchedFps = ((vTimescale.toDouble()) / (vBaseDelta * 2).toDouble()).roundToInt()
        val result = PatchStats(
            output = finalOutput!!,
            realSamples = vStsz.size,
            fakeSamples = 0,
            timescale = vTimescale,
            sampleDelta = vBaseDelta * 2,
            duration = vMdhdDur,
            chunkCount = vRelOffsets.size,
            inputFps = inputFps,
            patchedFps = patchedFps
        )
        onLog("FPS MP4 patch completed successfully. Total output: ${result.output.size} bytes.")
        return result
    }

    fun parseFpsFromMp4(buffer: ByteArray): Int {
        return try {
            val data = buffer
            var timescale = 0L
            var sampleDelta = 0L
            for (i in 0..data.size - 9) {
                if (data[i].toInt() == 0x6d && data[i + 1].toInt() == 0x64 && data[i + 2].toInt() == 0x68 && data[i + 3].toInt() == 0x64) {
                    val version = data[i + 4].toInt() and 0xff
                    timescale = if (version == 1) readU32BE(data, i + 24) else readU32BE(data, i + 16)
                }
                if (data[i].toInt() == 0x73 && data[i + 1].toInt() == 0x74 && data[i + 2].toInt() == 0x74 && data[i + 3].toInt() == 0x73) {
                    val entryCount = readU32BE(data, i + 8)
                    if (entryCount > 0) sampleDelta = readU32BE(data, i + 16)
                }
                if (timescale > 0 && sampleDelta > 0) {
                    val fps = (timescale / sampleDelta.toDouble()).roundToInt()
                    if (fps > 0 && fps < 300) return fps
                }
            }
            60
        } catch (_: Exception) {
            60
        }
    }

    fun parseResolutionFromMp4(buffer: ByteArray): Resolution {
        return try {
            val data = buffer
            for (i in 0..data.size - 9) {
                if (data[i].toInt() == 0x74 && data[i + 1].toInt() == 0x6b && data[i + 2].toInt() == 0x68 && data[i + 3].toInt() == 0x64) {
                    val version = data[i + 4].toInt() and 0xff
                    val wOffset = if (version == 1) i + 92 else i + 80
                    val hOffset = if (version == 1) i + 96 else i + 84
                    if (wOffset + 4 <= data.size && hOffset + 4 <= data.size) {
                        var width = (readU32BE(data, wOffset).toDouble() / 65536.0).roundToInt()
                        var height = (readU32BE(data, hOffset).toDouble() / 65536.0).roundToInt()
                        val matrixOffset = if (version == 1) (i - 4) + 60 else (i - 4) + 48
                        if (matrixOffset >= 0 && matrixOffset + 36 <= data.size && width > 0 && height > 0) {
                            val m0 = readS32BE(data, matrixOffset) / 65536f
                            val m4 = readS32BE(data, matrixOffset + 16) / 65536f
                            if (kotlin.math.abs(m0) < 0.5 && kotlin.math.abs(m4) < 0.5) {
                                val temp = width
                                width = height
                                height = temp
                            }
                        }
                        if (width > 0 && height > 0 && width < 16000 && height < 16000) {
                            return Resolution(width, height, false)
                        }
                    }
                }
            }
            Resolution(1080, 1920, false)
        } catch (_: Exception) {
            Resolution(1080, 1920, false)
        }
    }

    fun computeVideoProcessingOptions(w: Int, h: Int, fps: Int?, fileMB: Double, qualityShortSide: Int?): VideoProcessingOptions {
        var targetW = if (w > 0) w else 1080
        var targetH = if (h > 0) h else 1920
        if (qualityShortSide != null) {
            val shortSide = minOf(targetW, targetH)
            if (shortSide > 0) {
                val ratio = qualityShortSide.toDouble() / shortSide.toDouble()
                targetW = (targetW * ratio).roundToInt()
                targetH = (targetH * ratio).roundToInt()
            }
        }
        targetW = floor(targetW / 2.0).toInt() * 2
        targetH = floor(targetH / 2.0).toInt() * 2
        return VideoProcessingOptions(
            width = targetW,
            height = targetH,
            vfString = "scale=$targetW:$targetH:force_original_aspect_ratio=decrease,pad=$targetW:$targetH:(ow-iw)/2:(oh-ih)/2,format=yuv420p"
        )
    }

    private fun readS32BE(data: ByteArray, offset: Int): Int = ByteBuffer.wrap(data, offset, 4).order(ByteOrder.BIG_ENDIAN).int

    private fun formatMb(bytes: Long): String = "%.3f".format(bytes / (1024.0 * 1024.0))
}
