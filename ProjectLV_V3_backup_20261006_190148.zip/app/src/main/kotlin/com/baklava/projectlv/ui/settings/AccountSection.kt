package com.baklava.projectlv.ui.settings

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.data.security.FirebaseUserAuthManager
import com.baklava.projectlv.ui.components.Button
import com.baklava.projectlv.ui.components.Card
import com.baklava.projectlv.ui.components.IconButton
import com.baklava.projectlv.ui.components.TextButton
import com.baklava.projectlv.ui.components.clickable
import com.baklava.projectlv.ui.theme.BrightAmber
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private enum class AccountDialogType { NAME, PASSWORD, EMAIL }

/**
 * Kartu "Lihat Akun" di halaman Setelan: menampilkan nama, email, dan password akun,
 * serta menyediakan aksi ganti nama, ganti password, dan ganti email.
 */
@Composable
fun AccountCard(
    authManager: FirebaseUserAuthManager,
    onShowSnackbar: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    var expanded by rememberSaveable { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<AccountDialogType?>(null) }
    var displayName by remember { mutableStateOf(authManager.currentUser?.displayName.orEmpty()) }
    var email by remember { mutableStateOf(authManager.currentUser?.email.orEmpty()) }
    var knownPassword by remember { mutableStateOf(authManager.knownPassword()) }
    var passwordVisible by remember { mutableStateOf(false) }
    var pendingEmail by remember { mutableStateOf<String?>(null) }
    var refreshing by remember { mutableStateOf(false) }

    val arrowRotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = tween(320),
        label = "account_arrow"
    )

    fun refreshAccount() {
        if (refreshing) return
        refreshing = true
        scope.launch {
            try {
                authManager.reloadUser()
                val user = authManager.currentUser
                displayName = user?.displayName.orEmpty()
                email = user?.email.orEmpty()
                if (pendingEmail != null && email.equals(pendingEmail, ignoreCase = true)) pendingEmail = null
                onShowSnackbar("Data akun diperbarui.")
            } catch (t: Throwable) {
                onShowSnackbar(friendlyAccountError(t))
            } finally {
                refreshing = false
            }
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { expanded = !expanded },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Person, contentDescription = null, tint = BrightCyan)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "Lihat Akun",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Text(
                        "Nama, email, dan password akun",
                        style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey)
                    )
                }
                Icon(
                    Icons.Default.ExpandMore,
                    contentDescription = if (expanded) "Tutup" else "Buka",
                    tint = MutedGrey,
                    modifier = Modifier.rotate(arrowRotation)
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = fadeIn(tween(300)) + expandVertically(tween(340)),
                exit = fadeOut(tween(200)) + shrinkVertically(tween(260))
            ) {
                Column(
                    modifier = Modifier.padding(top = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AccountHero(name = displayName, email = email)

                    AccountInfoRow(
                        icon = Icons.Default.Person,
                        label = "Nama",
                        onEdit = { dialog = AccountDialogType.NAME }
                    ) {
                        Text(
                            displayName.ifBlank { "Belum diatur" },
                            color = if (displayName.isBlank()) MutedGrey else Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    AccountInfoRow(
                        icon = Icons.Default.Email,
                        label = "Email",
                        onEdit = { dialog = AccountDialogType.EMAIL }
                    ) {
                        Text(
                            email.ifBlank { "-" },
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        AnimatedVisibility(visible = pendingEmail != null) {
                            Text(
                                "Menunggu verifikasi: ${pendingEmail.orEmpty()}",
                                color = BrightAmber,
                                fontSize = 10.sp,
                                lineHeight = 13.sp
                            )
                        }
                    }

                    AccountInfoRow(
                        icon = Icons.Default.Lock,
                        label = "Password",
                        onEdit = { dialog = AccountDialogType.PASSWORD },
                        extraAction = {
                            if (knownPassword != null) {
                                IconButton(
                                    onClick = { passwordVisible = !passwordVisible },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (passwordVisible) "Sembunyikan password" else "Tampilkan password",
                                        tint = MutedGrey,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    ) {
                        val shown = passwordVisible && knownPassword != null
                        AnimatedContent(
                            targetState = shown,
                            transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(150)) },
                            label = "account_password"
                        ) { reveal ->
                            Text(
                                if (reveal) knownPassword.orEmpty()
                                else "•".repeat((knownPassword?.length ?: 8).coerceIn(6, 20)),
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (knownPassword == null) {
                            Text(
                                "Tidak tersedia di sesi ini. Password tidak disimpan di perangkat maupun server " +
                                    "dalam bentuk yang bisa dibaca — masuk ulang atau ubah password agar bisa dilihat.",
                                color = MutedGrey,
                                fontSize = 10.sp,
                                lineHeight = 13.sp
                            )
                        }
                    }

                    val createdAt = authManager.currentUser?.metadata?.creationTimestamp ?: 0L
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (createdAt > 0L) {
                                "Terdaftar sejak " + DateFormat
                                    .getDateInstance(DateFormat.MEDIUM, Locale.forLanguageTag("id-ID"))
                                    .format(Date(createdAt))
                            } else {
                                "Akun Firebase"
                            },
                            color = MutedGrey,
                            fontSize = 10.sp,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = ::refreshAccount, enabled = !refreshing) {
                            if (refreshing) {
                                CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp, color = BrightCyan)
                            } else {
                                Icon(Icons.Default.Refresh, null, modifier = Modifier.size(14.dp), tint = BrightCyan)
                            }
                            Spacer(Modifier.width(5.dp))
                            Text("Muat ulang", color = BrightCyan, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }

    when (dialog) {
        AccountDialogType.NAME -> EditNameDialog(
            current = displayName,
            onDismiss = { dialog = null },
            onSave = { newName ->
                displayName = authManager.updateDisplayName(newName)
                dialog = null
                onShowSnackbar("Nama berhasil diubah.")
            }
        )

        AccountDialogType.PASSWORD -> ChangePasswordDialog(
            onDismiss = { dialog = null },
            onSave = { current, new ->
                authManager.changePassword(current, new)
                knownPassword = authManager.knownPassword()
                passwordVisible = false
                dialog = null
                onShowSnackbar("Password berhasil diubah.")
            }
        )

        AccountDialogType.EMAIL -> ChangeEmailDialog(
            onDismiss = { dialog = null },
            onSave = { current, newEmail ->
                authManager.requestEmailChange(current, newEmail)
                pendingEmail = newEmail.trim().lowercase()
                dialog = null
                onShowSnackbar("Link verifikasi dikirim ke email baru. Buka link tersebut untuk menyelesaikan perubahan.")
            }
        )

        null -> Unit
    }
}

@Composable
private fun AccountHero(name: String, email: String) {
    val initial = name.ifBlank { email }.firstOrNull()?.uppercaseChar()?.toString() ?: "?"
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(BrightCyan.copy(alpha = 0.06f))
            .border(1.dp, BrightCyan.copy(alpha = 0.18f), RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(CyberSurfaceVariant)
                .border(1.dp, BrightCyan.copy(alpha = 0.4f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(initial, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                name.ifBlank { "Pengguna" },
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(email, color = MutedGrey, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .background(BrightGreen.copy(alpha = 0.12f))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.VerifiedUser, null, tint = BrightGreen, modifier = Modifier.size(11.dp))
            Spacer(Modifier.width(4.dp))
            Text("TERVERIFIKASI", color = BrightGreen, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AccountInfoRow(
    icon: ImageVector,
    label: String,
    onEdit: () -> Unit,
    extraAction: (@Composable () -> Unit)? = null,
    value: @Composable () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(CyberBlack)
            .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp))
            .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MutedGrey, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(label.uppercase(), color = MutedGrey, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp)
            value()
        }
        extraAction?.invoke()
        TextButton(onClick = onEdit) {
            Icon(Icons.Default.Edit, null, modifier = Modifier.size(13.dp), tint = BrightCyan)
            Spacer(Modifier.width(4.dp))
            Text("Ubah", color = BrightCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// ----------------------------------------------------------------------
// Dialog
// ----------------------------------------------------------------------

@Composable
private fun EditNameDialog(
    current: String,
    onDismiss: () -> Unit,
    onSave: suspend (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(current) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AccountDialogFrame(
        title = "Ubah Nama",
        confirmLabel = "SIMPAN",
        loading = loading,
        error = error,
        onDismiss = onDismiss,
        onConfirm = {
            loading = true
            error = null
            scope.launch {
                try {
                    onSave(name)
                } catch (t: Throwable) {
                    error = friendlyAccountError(t)
                } finally {
                    loading = false
                }
            }
        }
    ) {
        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(40); error = null },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Nama") },
            leadingIcon = { Icon(Icons.Default.Person, null, tint = MutedGrey) },
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
            singleLine = true,
            enabled = !loading
        )
    }
}

@Composable
private fun ChangePasswordDialog(
    onDismiss: () -> Unit,
    onSave: suspend (current: String, new: String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var showPasswords by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val transformation = if (showPasswords) VisualTransformation.None else PasswordVisualTransformation()

    AccountDialogFrame(
        title = "Ubah Password",
        confirmLabel = "GANTI",
        loading = loading,
        error = error,
        onDismiss = onDismiss,
        onConfirm = {
            when {
                currentPassword.isEmpty() -> error = "Password saat ini wajib diisi."
                newPassword.length < 8 || !newPassword.any(Char::isUpperCase) || !newPassword.any(Char::isDigit) ->
                    error = "Password baru minimal 8 karakter, 1 huruf kapital, dan 1 angka."
                newPassword != confirmPassword -> error = "Konfirmasi password tidak cocok."
                else -> {
                    loading = true
                    error = null
                    scope.launch {
                        try {
                            onSave(currentPassword, newPassword)
                        } catch (t: Throwable) {
                            error = friendlyAccountError(t)
                        } finally {
                            loading = false
                        }
                    }
                }
            }
        }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = currentPassword,
                onValueChange = { currentPassword = it.take(128); error = null },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Password saat ini") },
                visualTransformation = transformation,
                singleLine = true,
                enabled = !loading
            )
            OutlinedTextField(
                value = newPassword,
                onValueChange = { newPassword = it.take(128); error = null },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Password baru") },
                visualTransformation = transformation,
                singleLine = true,
                enabled = !loading
            )
            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it.take(128); error = null },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Konfirmasi password baru") },
                trailingIcon = {
                    IconButton(onClick = { showPasswords = !showPasswords }) {
                        Icon(
                            if (showPasswords) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (showPasswords) "Sembunyikan" else "Tampilkan",
                            tint = MutedGrey
                        )
                    }
                },
                visualTransformation = transformation,
                singleLine = true,
                enabled = !loading
            )
        }
    }
}

@Composable
private fun ChangeEmailDialog(
    onDismiss: () -> Unit,
    onSave: suspend (current: String, newEmail: String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var currentPassword by remember { mutableStateOf("") }
    var newEmail by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AccountDialogFrame(
        title = "Ubah Email",
        confirmLabel = "KIRIM LINK",
        loading = loading,
        error = error,
        onDismiss = onDismiss,
        onConfirm = {
            loading = true
            error = null
            scope.launch {
                try {
                    onSave(currentPassword, newEmail)
                } catch (t: Throwable) {
                    error = friendlyAccountError(t)
                } finally {
                    loading = false
                }
            }
        }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                "Link verifikasi akan dikirim ke email baru. Email baru berlaku setelah link dibuka, " +
                    "dan kamu mungkin perlu masuk ulang.",
                color = MutedGrey,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
            OutlinedTextField(
                value = newEmail,
                onValueChange = { newEmail = it.take(320); error = null },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Email baru") },
                leadingIcon = { Icon(Icons.Default.Email, null, tint = MutedGrey) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                singleLine = true,
                enabled = !loading
            )
            OutlinedTextField(
                value = currentPassword,
                onValueChange = { currentPassword = it.take(128); error = null },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Password saat ini") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                enabled = !loading
            )
        }
    }
}

@Composable
private fun AccountDialogFrame(
    title: String,
    confirmLabel: String,
    loading: Boolean,
    error: String?,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    content: @Composable () -> Unit
) {
    AlertDialog(
        onDismissRequest = { if (!loading) onDismiss() },
        containerColor = CyberDarkNavy,
        shape = RoundedCornerShape(18.dp),
        title = { Text(title, color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                content()
                AnimatedVisibility(
                    visible = error != null,
                    enter = fadeIn(tween(220)) + expandVertically(tween(220)),
                    exit = fadeOut(tween(150)) + shrinkVertically(tween(150))
                ) {
                    Text(
                        error.orEmpty(),
                        color = BrightRed,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                enabled = !loading,
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                    containerColor = BrightCyan,
                    contentColor = CyberBlack
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                if (loading) {
                    CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = CyberBlack)
                } else {
                    Text(confirmLabel, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !loading) {
                Text("Batal", color = MutedGrey)
            }
        }
    )
}

private fun friendlyAccountError(t: Throwable): String {
    val raw = t.message.orEmpty()
    return when {
        t is IllegalArgumentException && raw.isNotBlank() -> raw
        raw.contains("password is invalid", true) ||
            raw.contains("INVALID_LOGIN_CREDENTIALS", true) ||
            raw.contains("credential is incorrect", true) ||
            raw.contains("malformed or has expired", true) -> "Password saat ini salah."
        raw.contains("already in use", true) -> "Email tersebut sudah dipakai akun lain."
        raw.contains("badly formatted", true) -> "Format email tidak valid."
        raw.contains("recent login", true) -> "Sesi sudah lama. Keluar lalu masuk kembali, kemudian coba lagi."
        raw.contains("network", true) -> "Tidak dapat terhubung ke Firebase. Periksa koneksi internet."
        raw.contains("too many requests", true) -> "Terlalu banyak percobaan. Coba lagi beberapa saat."
        raw.isBlank() -> "Terjadi kesalahan. Coba lagi."
        else -> raw
    }
}
