package com.baklava.projectlv.ui.splash

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import com.baklava.projectlv.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import com.baklava.projectlv.ui.components.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.BuildConfig
import com.baklava.projectlv.R
import com.baklava.projectlv.data.network.EnvironmentCheckResult
import com.baklava.projectlv.ui.components.SystemReadyPill
import com.baklava.projectlv.ui.theme.BrightAmber
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.BrightMagenta
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey

private val MonoFont = FontFamily.Monospace

@Composable
fun SplashScreen(
    diagnosticsManager: BootDiagnosticsManager,
    onReady: () -> Unit
) {
    val state by diagnosticsManager.state.collectAsState()

    LaunchedEffect(Unit) {
        diagnosticsManager.start()
    }

    LaunchedEffect(state.isFinished, state.isOfflineMode) {
        if (state.isFinished) {
            onReady()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            BrandingCrest()

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "PROJECT-LEVIATHAN",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = BrightCyan,
                    letterSpacing = 1.5.sp
                )
            )

            Text(
                text = "Advanced Modular Terminal Toolkit · v${BuildConfig.VERSION_NAME}",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = MutedGrey,
                    letterSpacing = 0.5.sp
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            DiagnosticsPanel(state = state)

            Spacer(modifier = Modifier.height(20.dp))

            if (state.isOfflineMode && !state.isFinished) {
                OfflineBanner(
                    onRetry = { diagnosticsManager.start() }
                )
            } else if (!state.hasFatalError) {
                SystemReadyPill(
                    isReady = state.isFinished,
                    isOfflineMode = state.isOfflineMode
                )
            } else {
                Text(
                    text = state.fatalErrorMessage.ifBlank { "Gagal memverifikasi akses Firebase." },
                    style = MaterialTheme.typography.bodyMedium.copy(color = BrightRed),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(onClick = { diagnosticsManager.start() }) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Coba Lagi")
                }
            }
        }
    }
}

@Composable
private fun BrandingCrest() {
    val infiniteTransition = rememberInfiniteTransition(label = "crest_pulse")
    val borderAlpha by infiniteTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "crest_border_alpha"
    )

    Box(
        modifier = Modifier
            .size(96.dp)
            .clip(RoundedCornerShape(20.dp))
            .border(
                2.dp,
                Brush.linearGradient(
                    listOf(
                        BrightCyan.copy(alpha = borderAlpha),
                        BrightMagenta.copy(alpha = borderAlpha)
                    )
                ),
                RoundedCornerShape(20.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.splash_logo),
            contentDescription = "Project Leviathan",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
    }
}

@Composable
private fun DiagnosticsPanel(state: BootDiagnosticsState) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CyberDarkNavy)
            .border(1.dp, CyberCardBorder, RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            PanelHeader(state = state)

            Column(verticalArrangement = Arrangement.spacedBy(11.dp)) {
                state.steps.forEachIndexed { index, stepState ->
                    DiagnosticStepRow(index = index, stepState = stepState)
                }
            }

            // API endpoint sub-readout — only shown once the endpoint test step has data.
            AnimatedVisibility(visible = state.apiEndpointResults.isNotEmpty()) {
                ApiEndpointReadout(results = state.apiEndpointResults)
            }

            // Environment / security sub-readout.
            state.environmentCheckResult?.let { env ->
                EnvironmentReadout(env = env)
            }

            Spacer(modifier = Modifier.height(2.dp))

            val progress = (state.currentStepIndex + 1f) / state.totalSteps.toFloat()
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = if (state.isOfflineMode) BrightAmber else BrightCyan,
                trackColor = CyberSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "STEP ${(state.currentStepIndex + 1).coerceAtMost(state.totalSteps)}/${state.totalSteps}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MutedGrey,
                        fontFamily = MonoFont,
                        fontSize = 10.sp,
                        letterSpacing = 0.5.sp
                    )
                )
                Text(
                    text = "${state.totalElapsedMs} ms",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MutedGrey,
                        fontFamily = MonoFont,
                        fontSize = 10.sp
                    )
                )
            }
        }
    }
}

@Composable
private fun PanelHeader(state: BootDiagnosticsState) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(if (state.hasFatalError) BrightRed else BrightCyan)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "STARTUP SEQUENCE DIAGNOSTICS",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = Color(0xFFE5E7EB),
                    fontWeight = FontWeight.Bold,
                    fontFamily = MonoFont,
                    letterSpacing = 0.8.sp,
                    fontSize = 12.sp
                )
            )
        }
        Text(
            text = "v${BuildConfig.VERSION_NAME}",
            style = MaterialTheme.typography.labelSmall.copy(
                color = MutedGrey,
                fontFamily = MonoFont,
                fontSize = 10.sp
            )
        )
    }
}

@Composable
private fun DiagnosticStepRow(index: Int, stepState: BootStepState) {
    Row(
        verticalAlignment = Alignment.Top,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "%02d".format(index + 1),
            style = MaterialTheme.typography.labelSmall.copy(
                color = MutedGrey.copy(alpha = 0.5f),
                fontFamily = MonoFont,
                fontSize = 10.sp
            ),
            modifier = Modifier.padding(top = 2.dp, end = 8.dp)
        )

        Box(modifier = Modifier.padding(top = 1.dp)) {
            when {
                stepState.isRunning -> {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = Color(0xFFE5E7EB)
                    )
                }
                stepState.isWarning -> {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Warning",
                        tint = BrightAmber,
                        modifier = Modifier.size(18.dp)
                    )
                }
                stepState.isSuccess -> {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = BrightGreen,
                        modifier = Modifier.size(18.dp)
                    )
                }
                else -> {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(MutedGrey.copy(alpha = 0.3f))
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = stepState.step.label,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = if (stepState.isRunning) FontWeight.Bold else FontWeight.Normal,
                        color = when {
                            stepState.isRunning -> Color(0xFFE5E7EB)
                            stepState.isWarning -> BrightAmber
                            stepState.isSuccess -> Color.White
                            else -> MutedGrey.copy(alpha = 0.6f)
                        },
                        fontSize = 13.sp
                    )
                )
                if (stepState.elapsedMs > 0 && !stepState.isRunning) {
                    Text(
                        text = "${stepState.elapsedMs}ms",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MutedGrey.copy(alpha = 0.5f),
                            fontFamily = MonoFont,
                            fontSize = 9.sp
                        )
                    )
                }
            }
            if (stepState.detailMessage.isNotBlank()) {
                Text(
                    text = stepState.detailMessage,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = when {
                            stepState.isWarning -> BrightAmber
                            stepState.isSuccess -> Color(0xFFCBD5E1)
                            else -> MutedGrey
                        },
                        fontFamily = MonoFont,
                        fontSize = 10.sp
                    )
                )
            }
        }
    }
}

@Composable
private fun ApiEndpointReadout(results: List<ApiEndpointResult>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CyberSurfaceVariant.copy(alpha = 0.5f))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = "ENDPOINT PROBE",
            style = MaterialTheme.typography.labelSmall.copy(
                color = MutedGrey,
                fontFamily = MonoFont,
                fontSize = 9.sp,
                letterSpacing = 0.6.sp
            )
        )
        results.forEach { endpoint ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (endpoint.isReachable) BrightGreen else BrightRed)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = endpoint.label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFFCBD5E1),
                            fontFamily = MonoFont,
                            fontSize = 10.sp
                        )
                    )
                }
                Text(
                    text = if (endpoint.isReachable) {
                        "${endpoint.statusCode} · ${endpoint.latencyMs}ms"
                    } else {
                        "unreachable"
                    },
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (endpoint.isReachable) MutedGrey else BrightRed,
                        fontFamily = MonoFont,
                        fontSize = 9.sp
                    )
                )
            }
        }
    }
}

@Composable
private fun EnvironmentReadout(env: EnvironmentCheckResult) {
    val hasFlags = env.vpnActive || env.rootIndicatorsFound > 0 || env.debuggerAttached || env.isProbableEmulator
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CyberSurfaceVariant.copy(alpha = 0.5f))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = "ENVIRONMENT SCAN",
            style = MaterialTheme.typography.labelSmall.copy(
                color = MutedGrey,
                fontFamily = MonoFont,
                fontSize = 9.sp,
                letterSpacing = 0.6.sp
            )
        )
        EnvironmentFlagRow("VPN", env.vpnActive)
        EnvironmentFlagRow("Root indicators", env.rootIndicatorsFound > 0, extra = if (env.rootIndicatorsFound > 0) "${env.rootIndicatorsFound} found" else null)
        EnvironmentFlagRow("Debugger", env.debuggerAttached)
        EnvironmentFlagRow("Emulator heuristic", env.isProbableEmulator)
        if (!hasFlags) {
            Text(
                text = "Semua pemeriksaan bersih",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = BrightGreen,
                    fontFamily = MonoFont,
                    fontSize = 9.sp
                )
            )
        }
    }
}

@Composable
private fun EnvironmentFlagRow(label: String, flagged: Boolean, extra: String? = null) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = Color(0xFFCBD5E1),
                fontFamily = MonoFont,
                fontSize = 10.sp
            )
        )
        Text(
            text = extra ?: if (flagged) "detected" else "clear",
            style = MaterialTheme.typography.labelSmall.copy(
                color = if (flagged) BrightAmber else MutedGrey,
                fontFamily = MonoFont,
                fontSize = 9.sp
            )
        )
    }
}

@Composable
private fun OfflineBanner(
    onRetry: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(BrightAmber.copy(alpha = 0.12f))
            .border(1.dp, BrightAmber.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
            .padding(14.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            SystemReadyPill(isReady = false, isOfflineMode = true)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Tidak ada koneksi internet, Gagal Menyambungkan ke Server",
                style = MaterialTheme.typography.bodySmall.copy(color = Color.White),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedButton(
                onClick = onRetry,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_splash_retry"),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = BrightCyan),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Coba Lagi")
            }
        }
    }
}
