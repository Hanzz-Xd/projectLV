package com.baklava.projectlv.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import com.baklava.projectlv.ui.components.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.outlined.AutoFixHigh
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.HighQuality
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.DarkGrey
import com.baklava.projectlv.ui.theme.MutedGrey

enum class LeviathanDestination(
    val title: String,
    val filledIcon: ImageVector,
    val outlinedIcon: ImageVector,
    val requiresInternet: Boolean = false
) {
    DASHBOARD(
        "Beranda",
        Icons.Filled.Dashboard,
        Icons.Outlined.Dashboard
    ),

    BASE64_LAB(
        "Base64",
        Icons.Filled.Code,
        Icons.Outlined.Code,
        requiresInternet = false
    ),

    MAGIC_LINK(
        "Magic Link",
        Icons.Filled.AutoFixHigh,
        Icons.Outlined.AutoFixHigh,
        requiresInternet = true
    ),

    WEB_TOOLS(
        "Web Tools",
        Icons.Filled.Language,
        Icons.Outlined.Language,
        requiresInternet = true
    ),

    STROM_AI(
        "Strom AI",
        Icons.Filled.Psychology,
        Icons.Outlined.Psychology,
        requiresInternet = true
    ),

    DOWNLOADER(
        "Download",
        Icons.Filled.Download,
        Icons.Outlined.Download,
        requiresInternet = true
    ),

    MEDIA(
        "Media",
        Icons.Filled.Image,
        Icons.Filled.Image,
        requiresInternet = true
    ),

    TIKTOK_QUALITY(
        "Quality",
        Icons.Filled.HighQuality,
        Icons.Outlined.HighQuality,
        requiresInternet = false
    ),

    PY_OBFUSCATOR(
        "Py Obfuscator",
        Icons.Filled.Terminal,
        Icons.Outlined.Terminal,
        requiresInternet = true
    ),

    PTERODACTYL_WHATSAPP(
        "Panel WhatsApp",
        Icons.Filled.Cloud,
        Icons.Outlined.Cloud,
        requiresInternet = true
    ),

    STREAMING_ANIME(
        "Streaming Anime",
        Icons.Filled.PlayArrow,
        Icons.Outlined.PlayArrow,
        requiresInternet = true
    ),

    ALIGHT_MOTION_FINDER(
        "Preset Finder",
        Icons.Filled.Search,
        Icons.Outlined.Search,
        requiresInternet = true
    ),

    SFL_BYPASS(
        "SFL Bypass",
        Icons.Filled.Search,
        Icons.Outlined.Search,
        requiresInternet = true
    ),

    SETTINGS(
        "Pengaturan",
        Icons.Filled.Settings,
        Icons.Outlined.Settings
    )
}

/**
 * Kerangka navigasi global.
 *
 * PENTING (bug "klik episode -> balik ke Beranda"):
 * Versi sebelumnya memakai dua cabang `if (windowSize.isCompact) Scaffold{...} else Scaffold{...}`
 * dan memanggil `content()` di masing-masing cabang. Saat player memaksa layar landscape,
 * lebar layar >= 600dp sehingga `isCompact` berubah -> Compose menganggap `content()` berada di
 * tempat lain, membuang seluruh composable anak (termasuk StreamingScreen beserta state `route`-nya)
 * lalu membuatnya ulang dengan route = Home. Akibatnya video tidak pernah diputar.
 *
 * Sekarang hanya ada SATU Scaffold dan SATU posisi pemanggilan `content()`. Bottom bar / rail hanya
 * ditampilkan atau disembunyikan lewat `if` di slot-nya masing-masing sehingga state `content()`
 * tidak pernah hilang ketika orientasi berubah.
 *
 * @param immersive true saat player layar penuh aktif: nav global, rail, dan padding sistem
 *                  disembunyikan sepenuhnya supaya video benar-benar fullscreen.
 */
@Composable
fun LeviathanScaffold(
    currentDestination: LeviathanDestination,
    onNavigateTo: (LeviathanDestination) -> Unit,
    snackbarHostState: SnackbarHostState,
    windowSize: AppWindowSize,
    isOnline: Boolean,
    onOfflineModuleBlocked: (String) -> Unit,
    immersive: Boolean = false,
    content: @Composable () -> Unit
) {

    // Global app navigation is intentionally limited to three destinations.
    // Individual tools are launched from the Beranda dashboard, while the
    // Streaming screen owns only its internal content routes.
    val items = listOf(
        LeviathanDestination.DASHBOARD,
        LeviathanDestination.STREAMING_ANIME,
        LeviathanDestination.SETTINGS
    )

    // Streaming Anime memakai navigasi internalnya sendiri pada layar compact.
    // Sembunyikan nav global agar kedua bottom bar tidak bertumpuk.
    val showBottomBar = windowSize.isCompact &&
        !immersive &&
        currentDestination != LeviathanDestination.STREAMING_ANIME
    val showRail = !windowSize.isCompact && !immersive

    Scaffold(
        containerColor = CyberBlack,
        // Setiap screen module (mis. StromAiScreen) sudah menangani imePadding()
        // sendiri secara presisi di komponen yang tepat (input bar saja, bukan
        // seluruh layar). Jika Scaffold JUGA memasukkan WindowInsets.ime ke
        // innerPadding, ruang keyboard akan dihitung dua kali dan muncul
        // sebagai celah kosong besar di atas keyboard. Maka IME dikecualikan
        // di sini dan navigationBars tetap dihitung agar bottomBar tidak
        // tertutup gesture bar. Pada mode immersive (player) semua inset dibuang.
        contentWindowInsets = if (immersive) WindowInsets(0, 0, 0, 0) else WindowInsets.navigationBars,
        snackbarHost = {
            SnackbarHost(snackbarHostState)
        },
        bottomBar = {
            if (showBottomBar) {
                CompactBottomBar(
                    items = items,
                    currentDestination = currentDestination,
                    isOnline = isOnline,
                    onNavigateTo = onNavigateTo,
                    onOfflineModuleBlocked = onOfflineModuleBlocked
                )
            }
        }
    ) { innerPadding ->

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (showRail) {
                ExpandedNavigationRail(
                    items = items,
                    currentDestination = currentDestination,
                    isOnline = isOnline,
                    onNavigateTo = onNavigateTo,
                    onOfflineModuleBlocked = onOfflineModuleBlocked
                )
            }

            // Satu-satunya tempat content() dipanggil. Jangan dipindah / diduplikasi.
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                content()
            }
        }
    }
}

/*
 * ============================================
 * COMPACT / HP
 * CUSTOM BOTTOM NAVIGATION
 * ============================================
 */
@Composable
private fun CompactBottomBar(
    items: List<LeviathanDestination>,
    currentDestination: LeviathanDestination,
    isOnline: Boolean,
    onNavigateTo: (LeviathanDestination) -> Unit,
    onOfflineModuleBlocked: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberDarkNavy)
            .border(
                width = 1.dp,
                color = CyberCardBorder
            )
            .windowInsetsPadding(
                WindowInsets.navigationBars
            )
            .padding(
                horizontal = 8.dp,
                vertical = 5.dp
            ),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {

        items.forEach { dest ->

            val selected = dest == currentDestination
            val enabled = !dest.requiresInternet || isOnline

            val tint by animateColorAsState(
                targetValue = when {
                    selected -> Color(0xFFFFFFFF)
                    !enabled -> DarkGrey.copy(alpha = 0.5f)
                    else -> MutedGrey
                },
                animationSpec = tween(260),
                label = "nav_tint_${dest.name}"
            )
            val iconScale by animateFloatAsState(
                targetValue = if (selected) 1.16f else 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMedium
                ),
                label = "nav_scale_${dest.name}"
            )
            val indicatorWidth by animateDpAsState(
                targetValue = if (selected) 18.dp else 0.dp,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMediumLow
                ),
                label = "nav_indicator_${dest.name}"
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickable {
                        if (dest.requiresInternet && !isOnline) {
                            onOfflineModuleBlocked(dest.title)
                        } else {
                            onNavigateTo(dest)
                        }
                    }
                    .padding(vertical = 2.dp)
                    .testTag("nav_${dest.name.lowercase()}"),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {

                // Indikator geser di atas ikon yang aktif
                Box(
                    modifier = Modifier
                        .width(indicatorWidth)
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color.White)
                )

                Icon(
                    imageVector = if (selected) dest.filledIcon else dest.outlinedIcon,
                    contentDescription = dest.title,
                    modifier = Modifier
                        .padding(top = 1.dp)
                        .size(22.dp)
                        .graphicsLayer {
                            scaleX = iconScale
                            scaleY = iconScale
                        },
                    tint = tint
                )

                Text(
                    text = dest.title,
                    maxLines = 1,
                    softWrap = false,
                    fontSize = 9.sp,
                    lineHeight = 10.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    color = tint
                )
            }
        }
    }
}

/*
 * ============================================
 * MEDIUM / EXPANDED
 * NAVIGATION RAIL
 * ============================================
 */
@Composable
private fun ExpandedNavigationRail(
    items: List<LeviathanDestination>,
    currentDestination: LeviathanDestination,
    isOnline: Boolean,
    onNavigateTo: (LeviathanDestination) -> Unit,
    onOfflineModuleBlocked: (String) -> Unit
) {
    NavigationRail(
        containerColor = CyberDarkNavy,
        header = {
            Text(
                text = "LEVIATHAN",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = Color.White,
                    letterSpacing = 0.5.sp,
                    fontWeight = FontWeight.Bold
                ),
                modifier = Modifier.padding(vertical = 16.dp)
            )
        },
        modifier = Modifier
            .fillMaxHeight()
            .border(1.dp, CyberCardBorder)
    ) {

        items.forEach { dest ->

            val selected = dest == currentDestination
            val blocked = dest.requiresInternet && !isOnline

            NavigationRailItem(
                selected = selected,
                onClick = {
                    if (blocked) {
                        onOfflineModuleBlocked(dest.title)
                    } else {
                        onNavigateTo(dest)
                    }
                },
                icon = {
                    Icon(
                        imageVector = if (selected) dest.filledIcon else dest.outlinedIcon,
                        contentDescription = dest.title,
                        modifier = Modifier.size(24.dp)
                    )
                },
                label = {
                    Text(
                        text = dest.title,
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                        maxLines = 1
                    )
                },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = Color(0xFF0C0D10),
                    selectedTextColor = Color.White,
                    indicatorColor = Color(0xFFE5E7EB),
                    unselectedIconColor = if (blocked) DarkGrey.copy(alpha = 0.5f) else MutedGrey,
                    unselectedTextColor = if (blocked) DarkGrey.copy(alpha = 0.5f) else MutedGrey
                ),
                modifier = Modifier.testTag("rail_${dest.name.lowercase()}")
            )
        }
    }
}
