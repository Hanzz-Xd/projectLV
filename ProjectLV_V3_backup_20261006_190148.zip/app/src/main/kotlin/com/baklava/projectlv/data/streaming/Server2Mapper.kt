package com.baklava.projectlv.data.streaming

/**
 * Menjembatani respons Server 2 (backend Vercel kamu) ke model domain yang
 * sudah dipakai di seluruh app ([AnimeListItem], [AnimeDetail], [Episode],
 * [EpisodeStreamData]) — supaya ViewModel & UI (StreamingScreen dkk) tetap
 * jalan tanpa perubahan sama sekali, tidak peduli item itu datang dari
 * Server 1 (AnimeKita) atau Server 2.
 *
 * Skema ID lintas-server: karena Server 1 pakai slug (mis. "one-piece") dan
 * Server 2 pakai category_id numerik dari sumber yang beda, dua ID itu TIDAK
 * bisa dipertukarkan begitu saja. Setiap ID yang berasal dari Server 2 diberi
 * prefix "s2:" (lihat [tag]) sehingga [StreamingRepository] tahu harus
 * memanggil [Server2Api] (bukan [AnimeKitaApi]) saat user membuka detail
 * anime/episode itu, lalu prefix-nya dilepas sebelum dikirim ke jaringan.
 *
 * PENTING soal pemetaan kategori: server.js tidak punya konsep "ongoing" /
 * "semua anime" yang identik dengan AnimeKita. Pemetaan di [StreamingRepository]
 * memakai `get_category_popular` sebagai pengganti "ongoing" dan
 * `get_category_complete` sebagai pengganti "semua anime" — ini heuristik,
 * cek lagi hasilnya setelah deploy dan sesuaikan kalau kategorinya kurang pas.
 */
object Server2Mapper {
    private const val TAG = "s2:"

    fun tag(id: String): String = "$TAG$id"
    fun isServer2Id(id: String): Boolean = id.startsWith(TAG)
    fun stripTag(id: String): String = id.removePrefix(TAG)

    fun toAnimeList(response: Server2ListResponse): List<AnimeListItem> =
        response.items.mapNotNull(::toAnimeListItem)

    private fun toAnimeListItem(item: Server2AnimeItem): AnimeListItem? {
        val id = item.category_id ?: item.anime_id ?: return null
        val title = item.title ?: item.judul ?: return null
        return AnimeListItem(
            url = tag(id),
            judul = title,
            cover = item.thumbnail ?: item.poster,
            lastch = item.latest_episode ?: item.lastch,
            genre = item.genre,
            sinopsis = item.synopsis ?: item.sinopsis,
            status = item.status,
            score = item.rating ?: item.score
        )
    }

    fun toAnimeDetail(response: Server2AnimeDetailResponse): AnimeDetail {
        val d = response.data ?: error("Data anime (server 2) tidak ditemukan")
        val id = d.category_id ?: d.anime_id ?: error("ID anime (server 2) tidak valid")
        return AnimeDetail(
            series_id = tag(id),
            judul = d.title ?: d.judul ?: "Tanpa judul",
            cover = d.thumbnail ?: d.poster,
            status = d.status,
            rating = d.rating ?: d.score,
            genre = d.genre,
            sinopsis = d.synopsis ?: d.sinopsis,
            chapter = response.episodes.mapNotNull(::toEpisode)
        )
    }

    private fun toEpisode(ep: Server2Episode): Episode? {
        val rawId = ep.video_id ?: ep.episode_id ?: ep.post_id ?: ep.id ?: return null
        val label = ep.episode ?: ep.episode_number ?: ep.title ?: rawId
        return Episode(
            // Episode.id di model domain bertipe Long, sedangkan Server 2
            // mengirim id sebagai String (bisa non-numerik). hashCode dipakai
            // sebagai pengganti Long yang stabil untuk keperluan
            // key/pengurutan lokal (histori tonton dll) — bukan untuk
            // dikirim balik ke jaringan, jadi tabrakan hash tidak berisiko
            // salah ambil episode.
            id = rawId.hashCode().toLong(),
            ch = label,
            url = tag(rawId),
            date = ep.date
        )
    }

    fun toStreamData(response: Server2PostResponse): EpisodeStreamData {
        val s = response.streams ?: error("Link streaming (server 2) tidak tersedia")
        return EpisodeStreamData(
            episode_id = s.episode_id?.toLongOrNull(),
            reso = s.reso,
            streams = s.streams.mapValues { (_, candidates) ->
                candidates
                    .filter { !it.link.isNullOrBlank() }
                    .map { c ->
                        StreamCandidate(
                            link = c.link.orEmpty(),
                            provide = c.provide,
                            id = c.id,
                            reso = c.reso,
                            size_kb = c.size_kb
                        )
                    }
            }
        )
    }
}
