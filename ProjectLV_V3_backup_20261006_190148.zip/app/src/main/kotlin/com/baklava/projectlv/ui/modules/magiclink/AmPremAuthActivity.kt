package com.baklava.projectlv.ui.modules.magiclink

import android.app.Activity
import android.os.Bundle

/**
 * Legacy placeholder kept so an older local checkout that still contains
 * AmPremAuthActivity.kt does not fail compilation.
 *
 * Magic Link V2 no longer uses the AM-Prem WebView/session flow.
 */
@Deprecated("AM-Prem WebView authentication is no longer used by Magic Link V2.")
class AmPremAuthActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        finish()
    }
}
