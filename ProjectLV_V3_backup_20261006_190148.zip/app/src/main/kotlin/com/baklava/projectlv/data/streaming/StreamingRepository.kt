package com.baklava.projectlv.data.streaming

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import org.json.JSONArray
import org.json.JSONObject

/** Hasil satu halaman fetch yang membawa info "masih ada halaman lagi atau tidak". */
data class PagedCatalog(
    val items: List<AnimeListItem>,
    val hasMore: Boolean
)

/**
 * Server 1 = AnimeKita (default, seperti sebelumnya).
 * Server 2 = backend Vercel kamu sendiri ([Server2Api]) — dipakai otomatis
 * sebagai fallback tiap kali Server 1 gagal (timeout, error upstream, dll).
 *
 * Untuk detail anime & episode, routing-nya STRICT berdasarkan tag di ID
 * (lihat [Server2Mapper]) — repository ini sengaja TIDAK mencoba "server
 * lain" pakai ID yang sama untuk detail/episode, karena skema ID Server 1
 * dan Server 2 berasal dari sumber berbeda dan tidak bisa dipertukarkan;
 * memaksakannya berisiko menampilkan anime yang salah.
 */
class StreamingRepository(
    private val api: AnimeKitaApi = AnimeKitaApiProvider.api,
    private val api2: Server2Api = Server2ApiProvider.api
) {
    private val animeMoshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    suspend fun getOngoing(page: Int = 1): Result<List<AnimeListItem>> = withContext(Dispatchers.IO) {
        // server.js tidak punya kategori "ongoing" yang persis sama; dipakai
        // get_category_popular sebagai padanan terdekat saat fallback.
        runCatching { api.getOngoing(page) }
            .recoverCatching { Server2Mapper.toAnimeList(api2.getPopular(page)) }
    }

    suspend fun getLatest(page: Int = 1): Result<List<AnimeListItem>> = withContext(Dispatchers.IO) {
        runCatching { api.getLatest(page) }
            .recoverCatching { Server2Mapper.toAnimeList(api2.getLatest(page)) }
    }

    /**
     * Catalog paging uses the same paginated catalog feed seen in the captured app
     * traffic. We first try the more semantically named all-anime endpoint and
     * gracefully fall back to baruupload.php when that endpoint is unavailable,
     * and finally to Server 2's `get_category_complete` (padanan terdekat untuk
     * "semua anime" di backend itu) kalau Server 1 gagal total.
     */
    suspend fun getAllAnimePage(page: Int): Result<List<AnimeListItem>> = withContext(Dispatchers.IO) {
        runCatching { api.getAllAnime(page) }
            .recoverCatching { api.getLatest(page) }
            .recoverCatching { Server2Mapper.toAnimeList(api2.getComplete(page)) }
    }

    suspend fun getSeries(slug: String, titleHint: String? = null): Result<AnimeDetail> = withContext(Dispatchers.IO) {
        val normalizedSlug = normalizeExternalId(slug)
        if (Server2Mapper.isServer2Id(normalizedSlug)) {
            runCatching {
                Server2Mapper.toAnimeDetail(
                    parseServer2Detail(api2.getAnimeDetail(Server2Mapper.stripTag(normalizedSlug)))
                )
            }
        } else {
            runCatching { fetchSeriesServer1(normalizedSlug) }
                .recoverCatching { firstError ->
                    if (firstError is CancellationException) throw firstError
                    // Slug di MyList bisa sudah usang (anime diganti slug / dihapus di
                    // AnimeKita). Server membalas peringatan PHP + data kosong (id 0).
                    // Coba cari slug terbaru lewat search.php, lalu ambil ulang.
                    val alternative = findAlternativeSlug(normalizedSlug, titleHint)
                    if (alternative != null && alternative != normalizedSlug) {
                        fetchSeriesServer1(alternative)
                    } else {
                        throw firstError
                    }
                }
        }
    }

    private suspend fun fetchSeriesServer1(slug: String): AnimeDetail {
        val detail = parseSeriesResponse(
            api.getSeries(slug, AnimeKitaApiProvider.seriesBody(SeriesRequest(post_id = slug)))
        ).data.firstOrNull() ?: error("Data anime tidak ditemukan")
        if (isEmptyStub(detail)) {
            error(
                "Anime ini tidak tersedia di server AnimeKita saat ini (data kosong). " +
                    "Coba cari judulnya lewat Search, atau hapus dari MyList."
            )
        }
        return detail
    }

    /** Server mengembalikan record kosong (id 0, tanpa episode) untuk slug yang tidak valid. */
    private fun isEmptyStub(detail: AnimeDetail): Boolean =
        detail.chapter.isEmpty() &&
            (detail.id == 0L || (detail.id == null && detail.judul.isBlank()))

    private val slugNoise = setOf("sub", "indo", "subtitle", "indonesia")

    private fun slugTokens(slug: String): Set<String> =
        slug.lowercase().split('-', ' ', '_').filter { it.isNotBlank() && it !in slugNoise }.toSet()

    private fun titleKey(value: String): String = value.lowercase().filter { it.isLetterOrDigit() }

    private fun titleWords(value: String): Set<String> =
        value.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 1 }.toSet()

    private fun jaccard(a: Set<String>, b: Set<String>): Float {
        val union = (a + b).size
        return if (union == 0) 0f else a.intersect(b).size.toFloat() / union
    }

    private suspend fun searchItems(keyword: String): List<AnimeListItem> = try {
        api.search(keyword, 1, 20).data.firstOrNull()?.result.orEmpty()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        emptyList()
    }

    /**
     * Cari slug yang valid berdasarkan judul tersimpan (MyList/History) atau token slug.
     * Hasil yang slug-nya sama dengan yang sudah gagal diabaikan.
     */
    private suspend fun findAlternativeSlug(slug: String, titleHint: String?): String? {
        val slugWords = slugTokens(slug)
        val title = titleHint?.trim().orEmpty()
        val keywords = mutableListOf<String>()
        if (title.isNotBlank()) {
            keywords += title
            val short = title.split(Regex("\\s+")).take(4).joinToString(" ")
            if (short != title) keywords += short
        }
        if (slugWords.isNotEmpty()) keywords += slugWords.joinToString(" ")

        for (keyword in keywords.filter { it.length >= 3 }.distinct()) {
            val results = searchItems(keyword).filter { it.url != slug }
            if (results.isEmpty()) continue

            if (title.isNotBlank()) {
                val key = titleKey(title)
                results.firstOrNull { titleKey(it.judul) == key }?.let { return it.url }
            }
            if (slugWords.isNotEmpty()) {
                results.firstOrNull { slugTokens(it.url) == slugWords }?.let { return it.url }
            }
            val titleWordSet = titleWords(title)
            val best = results
                .map { item ->
                    val byTitle = if (titleWordSet.isNotEmpty()) jaccard(titleWordSet, titleWords(item.judul)) else 0f
                    val bySlug = jaccard(slugWords, slugTokens(item.url))
                    item to maxOf(byTitle, bySlug)
                }
                .filter { it.second >= 0.6f }
                .maxByOrNull { it.second }
            if (best != null) return best.first.url
        }
        return null
    }

    suspend fun getEpisodeStreams(
        series: AnimeDetail,
        episode: Episode
    ): Result<EpisodeStreamData> = withContext(Dispatchers.IO) {
        if (Server2Mapper.isServer2Id(episode.url)) {
            runCatching {
                Server2Mapper.toStreamData(api2.getEpisode(Server2Mapper.stripTag(episode.url)))
            }
        } else {
            runCatching {
                api.getEpisodeStreams(
                    url = episode.url,
                    request = AnimeKitaApiProvider.episodeBody(
                        EpisodeRequest(
                            post_id = episode.url,
                            series_id = series.series_id,
                            series_url = series.series_id,
                            episode = episode.ch.replace(Regex("[^0-9].*$"), "").ifBlank { "0" }
                        )
                    )
                ).data.firstOrNull() ?: error("Link streaming tidak tersedia")
            }
        }
    }

    /** movie.php tidak dimiliki Server 2, jadi tidak ada fallback di sini. */
    suspend fun getMovies(): Result<List<AnimeListItem>> = withContext(Dispatchers.IO) {
        runCatching { api.getMovies() }
    }

    /**
     * "Donghua" bukan field/kategori asli di AnimeKita — tidak ada endpoint
     * khusus donghua yang kita tahu. Ini pendekatan terbaik yang bisa
     * dibuktikan dari data HAR: search.php?keyword=donghua memang
     * mengembalikan katalog donghua yang relevan (terverifikasi ~417 judul).
     * Kalau ternyata ada endpoint kategori donghua yang lebih akurat,
     * gampang diganti di sini saja.
     */
    suspend fun getDonghuaPage(page: Int): Result<PagedCatalog> = withContext(Dispatchers.IO) {
        runCatching {
            val response = api.search("donghua", page, 20)
            val pageData = response.data.firstOrNull()
            PagedCatalog(
                items = pageData?.result.orEmpty(),
                hasMore = pageData?.pagination?.has_next ?: false
            )
        }
    }

    /**
     * Search terhadap dua katalog upstream yang BERBEDA. Server 1 (AnimeKita)
     * punya endpoint search asli (search.php) yang mencari ke SELURUH
     * katalog — jadi dipakai sebagai sumber utama, dengan auto-fetch
     * beberapa halaman pertama biar hasil langsung banyak tanpa harus tap
     * "muat lagi" berkali-kali. Server 2 tidak punya search asli, jadi tetap
     * dibantu scan halaman get_category_complete sebagai pelengkap (bisa
     * saja ada judul yang cuma ada di Server 2).
     */
    suspend fun searchAnime(
        query: String,
        maxServer1Pages: Int = 5,
        maxServer2Pages: Int = 5
    ): Result<List<AnimeListItem>> = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.isBlank()) return@withContext Result.success(emptyList())

        val matches = LinkedHashMap<String, AnimeListItem>()
        var anySourceReachable = false

        // Server 1: page 1 dulu buat tahu total_pages, baru sisanya paralel.
        val firstPage = try {
            val response = api.search(trimmed, 1, 20)
            anySourceReachable = true
            response.data.firstOrNull()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
        firstPage?.result?.forEach { matches.putIfAbsent(it.url, it) }

        val totalPages = firstPage?.pagination?.total_pages ?: 0
        val extraPages = (2..minOf(totalPages, maxServer1Pages))
        if (!extraPages.isEmpty()) {
            extraPages.map { page ->
                async {
                    try {
                        Result.success(api.search(trimmed, page, 20).data.firstOrNull()?.result.orEmpty())
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Result.failure(e)
                    }
                }
            }.awaitAll().forEach { pageResult ->
                pageResult.getOrNull()?.forEach { matches.putIfAbsent(it.url, it) }
            }
        }

        // Server 2: belum punya search asli, tetap scan terbatas sebagai pelengkap.
        fun isMatch(item: AnimeListItem): Boolean =
            item.judul.contains(trimmed, true) ||
                item.genre.any { it.contains(trimmed, true) } ||
                item.studio.orEmpty().contains(trimmed, true)

        val server2Results = (1..maxServer2Pages).map { page ->
            async {
                try {
                    Result.success(Server2Mapper.toAnimeList(api2.getComplete(page, 40)))
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Result.failure(e)
                }
            }
        }.awaitAll()
        server2Results.forEach { pageResult ->
            if (pageResult.isSuccess) anySourceReachable = true
            pageResult.getOrNull()?.filter(::isMatch)?.forEach { matches.putIfAbsent(it.url, it) }
        }

        if (anySourceReachable) {
            Result.success(matches.values.toList())
        } else {
            Result.failure(IllegalStateException("Tidak bisa terhubung ke server 1 maupun server 2"))
        }
    }

    private fun normalizeExternalId(value: String): String {
        var current = value.trim()
        repeat(2) {
            if (current.length >= 2 && current.first() == '"' && current.last() == '"') {
                current = AnimeKitaApiProvider.unwrapJsonString(current).trim()
            }
        }
        return current.trimEnd('/')
    }

    /**
     * Server AnimeKita kadang menaruh peringatan PHP (HTML) di depan JSON, mis.
     * `<br /><b>Warning</b>: Invalid argument supplied for foreach() ... <br />{"data":[...]}`.
     * Buang bagian HTML itu supaya JSON-nya tetap bisa dibaca.
     */
    private fun stripPhpNoise(raw: String): String {
        var text = raw.trim()
        text = text.replace(
            Regex("(?is)<br\\s*/?>\\s*<b>(?:Warning|Notice|Deprecated|Strict Standards)</b>:.*?<br\\s*/?>"),
            ""
        ).trim()
        if (text.isNotEmpty() && text.first() != '{' && text.first() != '[' && text.first() != '"') {
            val idx = text.indexOf("{\"data\"").takeIf { it >= 0 }
                ?: text.indexOfFirst { it == '{' || it == '[' }
            if (idx > 0) text = text.substring(idx).trim()
        }
        return text
    }

    private fun parseSeriesResponse(body: okhttp3.ResponseBody): SeriesResponse {
        val raw = body.string().trim()
        if (raw.isBlank()) error("Respons detail anime kosong")

        // Upstream AnimeKita pernah mengembalikan beberapa bentuk payload:
        // 1) {"data":[...]}
        // 2) [{...}]
        // 3) "{\"data\":[...]}" / "[{...}]"
        // Jangan memaksa root selalu BEGIN_OBJECT karena bentuk (2) dan (3)
        // menghasilkan error Moshi: Expected BEGIN_OBJECT/ARRAY ... at path $.
        var current = stripPhpNoise(raw)
        repeat(3) {
            current = if (current.startsWith("\"") && current.endsWith("\"")) {
                AnimeKitaApiProvider.unwrapJsonString(current).trim()
            } else current
        }

        val objectAdapter = animeMoshi.adapter(SeriesResponse::class.java)
        val listAdapter = animeMoshi.adapter<List<AnimeDetail>>(Types.newParameterizedType(List::class.java, AnimeDetail::class.java))

        // Root object: normal response { data: [...] }.
        runCatching { objectAdapter.fromJson(current) }
            .getOrNull()
            ?.let { response ->
                if (response.data.isNotEmpty()) return response
            }

        // Root array: [{...}] — bentuk yang juga dipakai oleh beberapa versi
        // endpoint detail.
        runCatching { listAdapter.fromJson(current) }
            .getOrNull()
            ?.let { list ->
                if (list.isNotEmpty()) return SeriesResponse(data = list)
            }

        // Root object tunggal: {...}. Coba langsung sebagai AnimeDetail untuk
        // menghindari kegagalan jika server menghilangkan wrapper `data`.
        runCatching { animeMoshi.adapter(AnimeDetail::class.java).fromJson(current) }
            .getOrNull()
            ?.let { detail ->
                if (detail.series_id.isNotBlank() || detail.judul.isNotBlank()) {
                    return SeriesResponse(data = listOf(detail))
                }
            }

        // Beberapa proxy mengembalikan {data: "[...]"}. Ambil field data dan
        // lakukan satu tahap parsing tambahan bila nilainya berupa string.
        runCatching {
            val root = org.json.JSONObject(current)
            root.opt("data")
        }.getOrNull()?.let { dataValue ->
            val nested = dataValue.toString().trim()
            val nestedJson = if (nested.startsWith("\"") && nested.endsWith("\"")) {
                AnimeKitaApiProvider.unwrapJsonString(nested).trim()
            } else nested
            runCatching { listAdapter.fromJson(nestedJson) }.getOrNull()?.let { list ->
                if (list.isNotEmpty()) return SeriesResponse(data = list)
            }
            runCatching { animeMoshi.adapter(AnimeDetail::class.java).fromJson(nestedJson) }
                .getOrNull()?.let { detail -> return SeriesResponse(data = listOf(detail)) }
        }

        // Fallback terakhir: parser longgar (org.json) yang toleran terhadap
        // field null / hilang, supaya satu field aneh tidak menggagalkan semuanya.
        parseSeriesLenient(current)?.let { return SeriesResponse(data = listOf(it)) }

        val preview = current.replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").trim().take(180)
        error("Format detail anime tidak dikenali. Respons: $preview")
    }

    private fun JSONObject.optStr(key: String): String? =
        if (isNull(key)) null else optString(key).takeIf { it.isNotBlank() && it != "null" }

    private fun JSONObject.optStrList(key: String): List<String> {
        val arr = optJSONArray(key) ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            if (arr.isNull(i)) null else arr.optString(i).takeIf { it.isNotBlank() && it != "null" }
        }
    }

    private fun JSONObject.optLongList(key: String): List<Long> {
        val arr = optJSONArray(key) ?: return emptyList()
        return (0 until arr.length()).map { i -> arr.optLong(i) }
    }

    private fun JSONObject.optLongOrNull(key: String): Long? =
        if (isNull(key)) null else optLong(key)

    private fun parseSeriesLenient(json: String): AnimeDetail? {
        val first: JSONObject = runCatching {
            val trimmed = json.trim()
            when {
                trimmed.startsWith("[") -> JSONArray(trimmed).optJSONObject(0)
                else -> {
                    val root = JSONObject(trimmed)
                    when (val data = root.opt("data")) {
                        is JSONArray -> data.optJSONObject(0)
                        is JSONObject -> data
                        else -> root
                    }
                }
            }
        }.getOrNull() ?: return null

        val chapters = first.optJSONArray("chapter")?.let { arr ->
            (0 until arr.length()).mapNotNull { i ->
                val c = arr.optJSONObject(i) ?: return@mapNotNull null
                val url = c.optStr("url") ?: return@mapNotNull null
                Episode(
                    id = c.optLong("id"),
                    ch = c.optStr("ch") ?: "",
                    url = url,
                    date = c.optStr("date"),
                    history = c.optStr("history"),
                    views = c.optLongOrNull("views"),
                    lastDurasi = c.optLongOrNull("lastDurasi"),
                    fullDurasi = c.optLongOrNull("fullDurasi")
                )
            }
        }.orEmpty()

        return AnimeDetail(
            id = first.optLongOrNull("id"),
            series_id = first.optStr("series_id") ?: "",
            cover = first.optStr("cover"),
            judul = first.optStr("judul") ?: "",
            type = first.optStr("type"),
            status = first.optStr("status"),
            rating = first.optStr("rating"),
            published = first.optStr("published"),
            author = first.optStr("author"),
            genre = first.optStrList("genre"),
            genreurl = first.optStrList("genreurl"),
            sinopsis = first.optStr("sinopsis"),
            history = first.optStrList("history"),
            historyDurasi = first.optLongList("historyDurasi"),
            historyDurasiFull = first.optLongList("historyDurasiFull"),
            chapter = chapters
        )
    }

    private fun parseServer2Detail(body: okhttp3.ResponseBody): Server2AnimeDetailResponse {
        val raw = body.string().trim()
        if (raw.isBlank()) error("Respons detail anime server 2 kosong")
        val unwrapped = if (raw.startsWith("\"") && raw.endsWith("\"")) {
            AnimeKitaApiProvider.unwrapJsonString(raw)
        } else raw
        return animeMoshi.adapter(Server2AnimeDetailResponse::class.java).fromJson(unwrapped)
            ?: error("Format detail anime server 2 tidak sesuai")
    }

    fun streamsForQuality(data: EpisodeStreamData, quality: String): List<StreamCandidate> =
        data.streams[quality].orEmpty().filter { it.link.isNotBlank() }

    fun preferredStream(data: EpisodeStreamData, quality: String): StreamCandidate? =
        streamsForQuality(data, quality).firstOrNull { it.provide == 871 }
            ?: streamsForQuality(data, quality).firstOrNull { it.provide == 99 }
            ?: streamsForQuality(data, quality).firstOrNull()
}
