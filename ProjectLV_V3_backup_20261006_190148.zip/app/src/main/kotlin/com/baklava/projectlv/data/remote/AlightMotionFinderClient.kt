package com.baklava.projectlv.data.remote

import com.baklava.projectlv.data.models.AlightMotionFinderResult
import com.baklava.projectlv.data.network.HttpClientProvider
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class AlightMotionFinderClient {
    companion object {
        private const val BASE_URL = "https://dapjimotionpro.my.id"
        private const val COMMENTS_PATH = "/api/comments"
    }

    private val client = HttpClientProvider.okHttpClient

    fun find(url: String): AlightMotionFinderResult {
        val postResult = runCatching { requestPost(url) }.getOrNull()
        if (postResult != null && postResult.links.isNotEmpty()) return postResult

        val getResult = runCatching { requestGet(url) }.getOrNull()
        return getResult ?: postResult ?: throw IllegalStateException("Finder API tidak dapat dihubungi.")
    }

    private fun requestPost(target: String): AlightMotionFinderResult {
        val payload = JSONObject().apply {
            put("url", target)
            put("link", target)
            put("videoUrl", target)
        }
        val request = Request.Builder()
            .url(BASE_URL + COMMENTS_PATH)
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .header("Accept", "application/json")
            .header("Content-Type", "application/json")
            .build()
        return execute(request)
    }

    private fun requestGet(target: String): AlightMotionFinderResult {
        val url = (BASE_URL + COMMENTS_PATH).toHttpUrl().newBuilder()
            .addQueryParameter("url", target)
            .build()
        val request = Request.Builder()
            .url(url)
            .get()
            .header("Accept", "application/json")
            .build()
        return execute(request)
    }

    private fun execute(request: Request): AlightMotionFinderResult {
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IllegalStateException(
                    parseMessage(body).ifBlank { "HTTP ${response.code}" }
                )
            }
            val json = JSONObject(body)
            return parseResult(json)
        }
    }

    private fun parseResult(json: JSONObject): AlightMotionFinderResult {
        fun stringList(vararg keys: String): List<String> {
            for (key in keys) {
                val value = json.opt(key)
                when (value) {
                    is JSONArray -> return buildList {
                        for (i in 0 until value.length()) {
                            value.optString(i).trim().takeIf { it.isNotEmpty() }?.let(::add)
                        }
                    }
                    is String -> return value.split("\\n", ",").map(String::trim).filter(String::isNotEmpty)
                }
            }
            return emptyList()
        }

        val links = stringList("links", "results", "presets", "presetLinks")
            .filter { it.startsWith("http://") || it.startsWith("https://") }
            .distinct()
        val captionLinks = stringList("captionLinks")
        val commentLinks = stringList("commentLinks")
        val diagnostics = stringList("diagnostics", "logs")
        val caption = json.optString("caption").takeIf { it.isNotBlank() }
        val resolvedUrl = json.optString("resolvedUrl", json.optString("url")).takeIf { it.isNotBlank() }
        val message = json.optString("message").ifBlank {
            if (links.isEmpty()) "Tidak ada link preset ditemukan." else "Preset ditemukan."
        }

        return AlightMotionFinderResult(
            links = links,
            count = json.optInt("count", links.size),
            captionLinks = captionLinks,
            commentLinks = commentLinks,
            caption = caption,
            captionFound = json.optBoolean("captionFound", caption != null),
            commentsChecked = json.optInt("commentsChecked", 0),
            repliesChecked = json.optInt("repliesChecked", 0),
            datasetItems = json.optInt("datasetItems", 0),
            resolvedUrl = resolvedUrl,
            diagnostics = diagnostics,
            message = message
        )
    }

    private fun parseMessage(body: String): String {
        if (body.isBlank()) return ""
        return runCatching {
            val json = JSONObject(body)
            json.optString("message").ifBlank { json.optString("error") }
        }.getOrDefault(body.take(300))
    }
}
