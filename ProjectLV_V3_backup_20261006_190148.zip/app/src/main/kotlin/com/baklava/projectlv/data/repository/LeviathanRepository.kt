package com.baklava.projectlv.data.repository

import android.content.Context
import android.net.Uri
import android.util.Base64
import android.webkit.MimeTypeMap
import com.baklava.projectlv.data.models.PageSourceResult
import com.baklava.projectlv.data.models.MediaUploadResult
import com.baklava.projectlv.data.models.UpscaleResult
import com.baklava.projectlv.data.models.ShortUrlResult
import com.baklava.projectlv.data.models.TikTokMediaInfo
import com.baklava.projectlv.data.models.DriveMediaInfo
import com.baklava.projectlv.data.models.YoutubeFormatOption
import com.baklava.projectlv.data.models.YoutubeMediaInfo
import com.baklava.projectlv.data.models.Web2ApkBuildRequest
import com.baklava.projectlv.data.models.Web2ApkBuildResult
import com.baklava.projectlv.data.models.WebToZipResult
import com.baklava.projectlv.data.network.HttpClientProvider
import com.baklava.projectlv.data.storage.LocalWorkspaceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.concurrent.TimeUnit
import java.util.zip.ZipOutputStream

sealed class ResultState<out T> {
    data class Success<T>(val data: T) : ResultState<T>()
    data class Error(val message: String, val throwable: Throwable? = null) : ResultState<Nothing>()
}

data class TikTokHdResolveResult(
    /** Best video URL selected exactly like the supplied web downloader: hdplay first, then play. */
    val hdPlayUrl: String,
    val proxyDownloadUrl: String,
    /** True only when the resolver actually returned a non-empty hdplay URL. */
    val hasNativeHd: Boolean = false,
    val fallbackPlayUrl: String? = null,
    val coverUrl: String? = null,
    val authorNickname: String? = null,
    val authorUniqueId: String? = null,
    val title: String? = null
)

data class MagicLinkResult(
    val isSuccess: Boolean,
    val message: String,
    val codeOrder: String? = null,
    val email: String? = null,
    val uid: String? = null,
    val displayName: String? = null,
    val membershipStatus: String? = null,
    val planName: String? = null,
    val orderId: String? = null,
    val validUntil: String? = null,
    val features: List<String> = emptyList(),
    val premium: Boolean? = null
)

data class StromAiResponse(
    val text: String,
    val sessionId: String?,
    val model: StromAiModel,
    val creator: String? = null,
    val reasoning: String? = null
)

private class UpstreamHttpException(val httpCode: Int, message: String) : RuntimeException(message)

class LeviathanRepository(
    private val context: Context,
    private val errorReportManager: ErrorReportManager,
    val workspaceManager: LocalWorkspaceManager
) {
    private val client = HttpClientProvider.okHttpClient

    // ----------------------------------------------------
    // 1. MAGIC LINK
    // ----------------------------------------------------

    /**
     * Kotlin equivalent of the reference Python AlightClient.
     *
     * Important:
     * - Keeps a session cookie jar, including visitor_id.
     * - Fetches a fresh CSRF token before every POST.
     * - Uses the new Alight API directly.
     */
    // ----------------------------------------------------
    // 1. MAGIC LINK
    // ----------------------------------------------------

    /**
     * Magic Link V2 client untuk API Satria.
     *
     * Send:
     * POST https://satriam.satriadeveloperz.workers.dev/api/satriam/send-link
     * {"email":"..."}
     *
     * Verify:
     * POST https://satriam.satriadeveloperz.workers.dev/api/satriam/verify-link
     * {"email":"...","magicLink":"..."}
     *
     * Secret token yang dikembalikan API tidak disimpan ke model/UI.
     */
    private class SatriaMagicLinkClient {
        companion object {
            private const val BASE_URL =
                "https://satriam.satriadeveloperz.workers.dev/api/satriam"
            private const val SEND_URL = "$BASE_URL/send-link"
            private const val VERIFY_URL = "$BASE_URL/verify-link"
        }

        private fun post(url: String, payload: JSONObject): JSONObject {
            val request = Request.Builder()
                .url(url)
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .build()

            HttpClientProvider.okHttpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                val json = try {
                    JSONObject(body)
                } catch (_: Exception) {
                    null
                }

                if (!response.isSuccessful) {
                    val message = json?.optString("message").orEmpty()
                        .ifBlank { json?.optString("error").orEmpty() }
                        .ifBlank { body.take(500) }
                        .ifBlank { "HTTP ${response.code}" }
                    throw RuntimeException("HTTP ${response.code}: $message")
                }

                return json ?: throw RuntimeException(
                    "API Magic Link V2 mengembalikan respons non-JSON."
                )
            }
        }

        fun sendLink(email: String): JSONObject =
            post(
                SEND_URL,
                JSONObject().apply {
                    put("email", email)
                }
            )

        fun verifyLink(email: String, magicLink: String): JSONObject =
            post(
                VERIFY_URL,
                JSONObject().apply {
                    put("email", email)
                    put("magicLink", magicLink)
                }
            )
    }

    private fun satriaSuccess(json: JSONObject): Boolean =
        json.optBoolean("success", false)

    private fun satriaMessage(json: JSONObject, fallback: String): String =
        json.optString("message", fallback).ifBlank { fallback }

    private suspend fun executeSendV2(email: String): String {
        val result = SatriaMagicLinkClient().sendLink(email)

        if (!satriaSuccess(result)) {
            throw RuntimeException(
                satriaMessage(result, "Gagal mengirim magic link V2.")
            )
        }

        return satriaMessage(
            result,
            "Magic link berhasil dikirim. Silakan cek inbox/spam email."
        )
    }

    private suspend fun executeVerifyV2(
        email: String,
        rawLink: String
    ): MagicLinkResult {
        val result = SatriaMagicLinkClient().verifyLink(email, rawLink)

        val success = satriaSuccess(result)
        if (!success) {
            return MagicLinkResult(
                isSuccess = false,
                message = satriaMessage(result, "Verifikasi gagal.")
            )
        }

        val features = mutableListOf<String>()
        val featureArray = result.optJSONArray("features")
        if (featureArray != null) {
            for (i in 0 until featureArray.length()) {
                val item = featureArray.optString(i).trim()
                if (item.isNotBlank()) features += item
            }
        }

        val orderId = result.optString("orderId").ifBlank { null }
        val premium = if (result.has("premium")) {
            result.optBoolean("premium", false)
        } else {
            null
        }

        return MagicLinkResult(
            isSuccess = true,
            message = satriaMessage(result, "Verifikasi berhasil."),
            codeOrder = orderId,
            email = result.optString("email").ifBlank { email },
            uid = result.optString("uid").ifBlank { null },
            displayName = result.optString("displayName").ifBlank { null },
            membershipStatus = result.optString("membershipStatus").ifBlank { null },
            planName = result.optString("planName").ifBlank { null },
            orderId = orderId,
            validUntil = result.optString("validUntil").ifBlank { null },
            features = features,
            premium = premium
        )
    }

    suspend fun sendMagicLink(version: String, email: String): ResultState<String> =
        withContext(Dispatchers.IO) {
            val moduleCtx = "MAGIC_LINK / SEND ($version)"
            try {
                if (version.lowercase() == "v1") {
                    try {
                        val url =
                            "https://restapidhan.vercel.app/api/am?action=send&apikey=freeapikeydhan26&email=${
                                URLEncoder.encode(email, "UTF-8")
                            }"
                        val request = Request.Builder()
                            .url(url)
                            .get()
                            .build()

                        val responseText = client.newCall(request).execute().use { resp ->
                            if (!resp.isSuccessful) {
                                val body = resp.body?.string().orEmpty()
                                throw RuntimeException("HTTP ${resp.code}: $body")
                            }
                            resp.body?.string().orEmpty()
                        }

                        val parsedMsg = try {
                            val json = JSONObject(responseText)
                            json.optString(
                                "message",
                                json.optString(
                                    "msg",
                                    "Magic link berhasil diproses. Periksa inbox/spam email Anda."
                                )
                            )
                        } catch (_: Exception) {
                            "Magic link berhasil diproses. Periksa inbox/spam email Anda."
                        }

                        ResultState.Success(parsedMsg)
                    } catch (_: Exception) {
                        val v2Msg = executeSendV2(email)
                        ResultState.Success("Terkirim via Engine V2: $v2Msg")
                    }
                } else {
                    val msg = executeSendV2(email)
                    ResultState.Success(msg)
                }
            } catch (e: Exception) {
                errorReportManager.capture(
                    e,
                    moduleCtx,
                    rawHost = if (version.lowercase() == "v1") {
                        "restapidhan.vercel.app"
                    } else {
                        "satriam.satriadeveloperz.workers.dev"
                    }
                )

                ResultState.Error(
                    e.message ?: "Gagal mengirim magic link.",
                    e
                )
            }
        }

    suspend fun verifyMagicLink(
        version: String,
        email: String,
        link: String
    ): ResultState<MagicLinkResult> = withContext(Dispatchers.IO) {
        val moduleCtx = "MAGIC_LINK / VERIFY ($version)"
        try {
            if (version.lowercase() == "v1") {
                try {
                    val url =
                        "https://restapidhan.vercel.app/api/am?action=verif&apikey=freeapikeydhan26&email=${
                            URLEncoder.encode(email, "UTF-8")
                        }&url=${URLEncoder.encode(link, "UTF-8")}"

                    val request = Request.Builder()
                        .url(url)
                        .get()
                        .build()

                    val responseText = client.newCall(request).execute().use { resp ->
                        if (!resp.isSuccessful) {
                            val body = resp.body?.string().orEmpty()
                            throw RuntimeException("HTTP ${resp.code}: $body")
                        }
                        resp.body?.string().orEmpty()
                    }

                    var success = false
                    var codeOrder: String? = null
                    var message = "Verifikasi selesai."

                    try {
                        val json = JSONObject(responseText)
                        success = json.optBoolean(
                            "status",
                            json.optBoolean(
                                "success",
                                json.optBoolean("verified", false)
                            )
                        )

                        if (!success) {
                            val statusStr = json.optString("status", "").lowercase()
                            if (statusStr in listOf(
                                    "true",
                                    "success",
                                    "ok",
                                    "verified",
                                    "1"
                                )
                            ) {
                                success = true
                            }
                        }

                        message = json.optString(
                            "message",
                            json.optString("msg", message)
                        )

                        for (k in listOf(
                            "codeorder",
                            "code_order",
                            "codeOrder",
                            "order_code",
                            "orderCode",
                            "code"
                        )) {
                            if (json.has(k)) {
                                codeOrder = json.optString(k)
                                break
                            }
                        }

                        if (codeOrder == null && json.has("data")) {
                            val dataObj = json.optJSONObject("data")
                            if (dataObj != null) {
                                for (k in listOf(
                                    "codeorder",
                                    "code_order",
                                    "codeOrder",
                                    "order_code",
                                    "orderCode",
                                    "code"
                                )) {
                                    if (dataObj.has(k)) {
                                        codeOrder = dataObj.optString(k)
                                        break
                                    }
                                }
                            }
                        }
                    } catch (_: Exception) {
                        if (
                            responseText.contains("success", ignoreCase = true) ||
                            responseText.contains("berhasil", ignoreCase = true)
                        ) {
                            success = true
                        }
                    }

                    ResultState.Success(
                        MagicLinkResult(
                            isSuccess = success,
                            message = message,
                            codeOrder = codeOrder
                        )
                    )
                } catch (_: Exception) {
                    val v2Result = executeVerifyV2(email, link)
                    ResultState.Success(
                        v2Result.copy(
                            message = "Verifikasi dialihkan ke Engine V2: ${v2Result.message}"
                        )
                    )
                }
            } else {
                ResultState.Success(executeVerifyV2(email, link))
            }
        } catch (e: Exception) {
            errorReportManager.capture(
                e,
                moduleCtx,
                rawHost = if (version.lowercase() == "v1") {
                    "restapidhan.vercel.app"
                } else {
                    "satriam.satriadeveloperz.workers.dev"
                }
            )

            ResultState.Error(
                e.message ?: "Verifikasi gagal.",
                e
            )
        }
    }


    // ----------------------------------------------------
    // 2. WEB TOOLS
    // ----------------------------------------------------

    /** Pulls a field from the top-level JSON and common wrapper objects. */
    private fun extractField(json: JSONObject, keys: List<String>): String? {
        val candidates = buildList {
            add(json)
            for (wrapper in listOf("data", "result", "response")) {
                json.optJSONObject(wrapper)?.let { add(it) }
            }
        }
        for (obj in candidates) {
            for (key in keys) {
                val value = obj.optString(key, "")
                if (value.isNotBlank()) return value
            }
        }
        return null
    }

    /**
     * Forge an installable APK locally using the supplied SDKForge API resources.
     *
     * The app fetches the public template and signing material, downloads an optional icon,
     * patches the compiled APK on-device, then saves the final APK into app cache.
     */
    suspend fun forgeWeb2Apk(
        req: Web2ApkBuildRequest,
        onStep: (step: Int) -> Unit = {}
    ): ResultState<Web2ApkBuildResult> = withContext(Dispatchers.IO) {
        val moduleCtx = "WEB_TOOLS / WEB_TO_APK_LOCAL_FORGE"
        try {
            val apiBase = "https://code-v-compiler-sr.vercel.app/api/public/apk"
            require(req.appName.trim().isNotBlank()) { "Nama aplikasi wajib diisi" }
            require(req.websiteUrl.trim().startsWith("http://", ignoreCase = true) || req.websiteUrl.trim().startsWith("https://", ignoreCase = true)) {
                "URL website tidak valid"
            }
            require(Web2ApkForge.validatePackage(req.packageName.trim())) { "Package name tidak valid: ${req.packageName}" }
            require(req.versionName.trim().isNotBlank()) { "Version wajib diisi" }
            require(req.versionCode.toIntOrNull()?.let { it > 0 } == true) { "Version code harus berupa angka positif" }

            onStep(0)
            val template = client.newCall(
                Request.Builder()
                    .url("$apiBase/template")
                    .get()
                    .header("Accept", "application/vnd.android.package-archive")
                    .build()
            ).execute().use { response ->
                if (!response.isSuccessful) throw IOException("Template API HTTP ${response.code}")
                response.body?.bytes() ?: throw IOException("Template APK kosong")
            }

            onStep(1)
            val signJson = client.newCall(
                Request.Builder()
                    .url("$apiBase/signkey")
                    .get()
                    .header("Accept", "application/json")
                    .build()
            ).execute().use { response ->
                if (!response.isSuccessful) throw IOException("Signing API HTTP ${response.code}")
                JSONObject(response.body?.string().orEmpty())
            }

            // Keep the supplied forge.js endpoint in the same feature contract. The native forge
            // below is a direct Kotlin port because Android WebView/JS support is not guaranteed
            // to expose the browser-only DecompressionStream API on every supported device.
            client.newCall(
                Request.Builder()
                    .url("$apiBase/forge.js")
                    .get()
                    .header("Accept", "text/javascript")
                    .build()
            ).execute().use { response ->
                if (!response.isSuccessful) throw IOException("Forge API HTTP ${response.code}")
                val forgeSource = response.body?.string().orEmpty()
                if (!forgeSource.contains("forgeApk") || !forgeSource.contains("signV1")) {
                    throw IOException("SDKForge engine response tidak valid")
                }
            }

            val signKey = Web2ApkForge.SignKey(
                pkcs8 = signJson.optString("pkcs8"),
                certRsa = signJson.optString("certRsa"),
                sigOffset = signJson.optInt("sigOffset", -1)
            )
            require(signKey.pkcs8.isNotBlank() && signKey.certRsa.isNotBlank() && signKey.sigOffset >= 0) {
                "Response signing key tidak lengkap"
            }

            val iconBytes = if (req.iconPng != null) {
                req.iconPng
            } else if (req.appIconUrl.isNotBlank()) {
                client.newCall(
                    Request.Builder()
                        .url(req.appIconUrl.trim())
                        .get()
                        .header("Accept", "image/png,image/*;q=0.8,*/*;q=0.5")
                        .build()
                ).execute().use { response ->
                    if (!response.isSuccessful) throw IOException("Download icon HTTP ${response.code}")
                    val data = response.body?.bytes() ?: throw IOException("Icon kosong")
                    require(data.size <= 4 * 1024 * 1024) { "Ukuran icon terlalu besar (maks. 4 MB)" }
                    require(data.size >= 8 && data.copyOfRange(0, 8).contentEquals(byteArrayOf(
                        0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A
                    ))) { "Icon dari URL harus berupa PNG" }
                    data
                }
            } else null

            onStep(2)
            val apk = Web2ApkForge.forge(
                template = template,
                signKey = signKey,
                packageName = req.packageName.trim(),
                appName = req.appName.trim(),
                versionName = req.versionName.trim(),
                versionCode = req.versionCode.toInt(),
                iconPng = iconBytes,
                permissions = req.permissions,
                config = req.config,
                onStep = onStep
            )

            val dir = File(context.cacheDir, "web2apk").apply { mkdirs() }
            val safeName = req.appName.trim()
                .replace(Regex("[^A-Za-z0-9._-]+"), "_")
                .trim('_')
                .ifBlank { "Web2APK" }
            val file = File(dir, "$safeName-${System.currentTimeMillis()}.apk")
            file.writeBytes(apk)

            onStep(5)
            ResultState.Success(
                Web2ApkBuildResult(
                    filePath = file.absolutePath,
                    fileName = file.name,
                    sizeBytes = file.length(),
                    websiteUrl = req.websiteUrl.trim(),
                    packageName = req.packageName.trim()
                )
            )
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx, rawHost = "code-v-compiler-sr.vercel.app")
            ResultState.Error(e.message ?: "Gagal membuat APK.", e)
        }
    }

    suspend fun fetchPageSource(url: String): ResultState<PageSourceResult> = withContext(Dispatchers.IO) {
        val moduleCtx = "WEB_TOOLS / PAGE_SOURCE"
        try {
            // Step 1: Token
            val tokenReq = Request.Builder()
                .url("https://www.view-page-source.com/api/token")
                .get()
                .header("Origin", "https://www.view-page-source.com")
                .header("Referer", "https://www.view-page-source.com/")
                .build()

            val token = client.newCall(tokenReq).execute().use { resp ->
                if (!resp.isSuccessful) throw RuntimeException("Token error: HTTP ${resp.code}")
                val json = JSONObject(resp.body?.string().orEmpty())
                json.getString("token")
            }

            // Step 2: Fetch HTML
            val bodyJson = JSONObject().apply {
                put("url", url)
                put("token", token)
                put("stylize", true)
            }
            val fetchReq = Request.Builder()
                .url("https://www.view-page-source.com/api/fetch")
                .post(bodyJson.toString().toRequestBody("application/json".toMediaType()))
                .header("Origin", "https://www.view-page-source.com")
                .header("Referer", "https://www.view-page-source.com/")
                .build()

            val respString = client.newCall(fetchReq).execute().use { resp ->
                if (!resp.isSuccessful) throw RuntimeException("Fetch error: HTTP ${resp.code}")
                resp.body?.string().orEmpty()
            }

            val json = JSONObject(respString)
            val html = json.optString("html", "")
            val pageInfo = json.optJSONObject("pageInfo")
            val metrics = json.optJSONObject("metrics")
            val serverInfo = json.optJSONObject("serverInfo")

            ResultState.Success(
                PageSourceResult(
                    url = url,
                    html = html,
                    totalSize = pageInfo?.optString("totalSize"),
                    totalChars = pageInfo?.optString("totalChars"),
                    totalWords = pageInfo?.optString("totalWords"),
                    totalLines = pageInfo?.optString("totalLines"),
                    timingMs = metrics?.optString("totalTime"),
                    server = serverInfo?.optString("server"),
                    httpCode = serverInfo?.optString("httpCode")
                )
            )
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx, rawHost = "view-page-source.com")
            ResultState.Error(e.message ?: "Gagal mengambil page source.", e)
        }
    }

    suspend fun webToZip(url: String): ResultState<WebToZipResult> = withContext(Dispatchers.IO) {
        val moduleCtx = "WEB_TOOLS / WEB_TO_ZIP"
        val cleanUrl = url.trim().let {
            if (!it.startsWith("http://", ignoreCase = true) && !it.startsWith("https://", ignoreCase = true)) {
                "https://$it"
            } else {
                it
            }
        }
        val uri = Uri.parse(cleanUrl)
        val host = uri.host?.takeIf { it.isNotBlank() } ?: "website"

        // 1. Try Aspose Online Converter
        try {
            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("link_303108836", cleanUrl)
                .build()

            val request = Request.Builder()
                .url("https://api.products.aspose.app/cells/converter/api/ConverterApi/WebConverter?outputType=ZIP")
                .post(body)
                .header("Origin", "https://products.aspose.app")
                .header("Referer", "https://products.aspose.app/")
                .build()

            val respString = client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) throw RuntimeException("Aspose HTTP ${resp.code}")
                resp.body?.string().orEmpty()
            }

            val json = JSONObject(respString)
            val isSuccess = json.optBoolean("IsSuccess", false) || json.optString("IsSuccess").equals("true", true)
            if (isSuccess && json.has("FolderName") && json.has("FileName")) {
                val folderName = json.getString("FolderName")
                val fileName = json.getString("FileName")
                val downloadUrl = "https://api.products.aspose.app/cells/converter/api/Download/${URLEncoder.encode(folderName, "UTF-8")}?file=${URLEncoder.encode(fileName, "UTF-8")}"

                return@withContext ResultState.Success(
                    WebToZipResult(
                        isSuccess = true,
                        fileName = fileName,
                        downloadUrl = downloadUrl,
                        isLocalArchive = false,
                        note = "Dikonversi via Aspose Cloud Engine"
                    )
                )
            }
        } catch (_: Exception) {
            // Aspose service unavailable or form signature expired -> proceed to Native In-App Web Archiver
        }

        // 2. Resilient Native Web Archiver Engine
        try {
            val req = Request.Builder()
                .url(cleanUrl)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .get()
                .build()

            val htmlContent: String
            val httpCode: Int
            client.newCall(req).execute().use { resp ->
                htmlContent = resp.body?.string().orEmpty()
                httpCode = resp.code
            }

            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val readableDate = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            val safeHost = host.replace(Regex("[^a-zA-Z0-9.-]"), "_")
            val zipFileName = "${safeHost}_archive_$timeStamp.zip"

            val baos = ByteArrayOutputStream()
            ZipOutputStream(BufferedOutputStream(baos)).use { zos ->
                // Entry 1: index.html
                val htmlEntry = ZipEntry("index.html")
                zos.putNextEntry(htmlEntry)
                zos.write(htmlContent.toByteArray(Charsets.UTF_8))
                zos.closeEntry()

                // Entry 2: manifest.json
                val manifestJson = JSONObject().apply {
                    put("url", cleanUrl)
                    put("host", host)
                    put("httpCode", httpCode)
                    put("htmlSizeBytes", htmlContent.toByteArray(Charsets.UTF_8).size)
                    put("archivedAt", readableDate)
                    put("tool", "PROJECT-LEVIATHAN Web Archiver v2.0")
                }
                val manifestEntry = ZipEntry("manifest.json")
                zos.putNextEntry(manifestEntry)
                zos.write(manifestJson.toString(2).toByteArray(Charsets.UTF_8))
                zos.closeEntry()

                // Entry 3: README.txt
                val readme = "=== ARSIP WEB OFFLINE ===\nURL: $cleanUrl\nTanggal Simpan: $readableDate\nStatus HTTP: $httpCode\nUkuran Dokumen: ${htmlContent.length} karakter\n\nBuka 'index.html' di browser mana saja untuk melihat halaman web secara offline."
                val readmeEntry = ZipEntry("README.txt")
                zos.putNextEntry(readmeEntry)
                zos.write(readme.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }

            val zipBytes = baos.toByteArray()
            val savedUri = workspaceManager.saveToDownloads(zipFileName, "application/zip", zipBytes)

            if (savedUri != null) {
                ResultState.Success(
                    WebToZipResult(
                        isSuccess = true,
                        fileName = zipFileName,
                        downloadUrl = savedUri.toString(),
                        sizeBytes = zipBytes.size.toLong(),
                        isLocalArchive = true,
                        localUri = savedUri.toString(),
                        note = "Arsip ZIP offline berhasil dibuat dan disimpan di Download/Leviathan."
                    )
                )
            } else {
                throw RuntimeException("Gagal menyimpan file ZIP ke memori perangkat.")
            }
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx, rawHost = host)
            ResultState.Error("Konversi Web to ZIP gagal: ${e.message}", e)
        }
    }

    // ----------------------------------------------------
    // 3. STROM AI / SOURCE.GATEWAY
    // ----------------------------------------------------

    private val sourceAiClient = client.newBuilder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun chatStromAi(
        prompt: String,
        sessionId: String? = null,
        model: StromAiModel = StromAiModel.CLAUDE,
        system: String? = null
    ): ResultState<StromAiResponse> = withContext(Dispatchers.IO) {
        val moduleCtx = "STROM_AI / ${model.name}"
        try {
            val baseUrl = when (model) {
                // source.txt does not define a separate STROM endpoint.
                // Keep STROM functional by using the existing project AI gateway.
                StromAiModel.STROM, StromAiModel.CLAUDE -> "https://api.alfisy.my.id/api/ai/claude-chat"
                StromAiModel.CHATGPT -> "https://api.alfisy.my.id/api/ai/chatgpt"
                StromAiModel.DEEPSEEK_FLASH, StromAiModel.DEEPSEEK_PRO ->
                    "https://api.alfisy.my.id/api/ai/deepseek-chat"
            }.toHttpUrlOrNull() ?: throw IllegalArgumentException("URL AI tidak valid")

            val modelId = when (model) {
                StromAiModel.STROM, StromAiModel.CLAUDE -> "anthropic/claude-opus-4.8"
                StromAiModel.CHATGPT -> "openai/gpt-oss-20b"
                StromAiModel.DEEPSEEK_FLASH -> "DeepSeek-V4-Flash"
                StromAiModel.DEEPSEEK_PRO -> "DeepSeek-V4-Pro"
            }

            val urlBuilder = baseUrl.newBuilder()
            when (model) {
                StromAiModel.CHATGPT -> urlBuilder.addQueryParameter("q", prompt)
                else -> urlBuilder.addQueryParameter("prompt", prompt)
            }
            urlBuilder.addQueryParameter("model", modelId)
            if (!system.isNullOrBlank()) urlBuilder.addQueryParameter("system", system)
            if (!sessionId.isNullOrBlank()) urlBuilder.addQueryParameter("session", sessionId)

            val request = Request.Builder()
                .url(urlBuilder.build())
                .get()
                .header("Accept", "application/json")
                .build()

            val responseBody = sourceAiClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw RuntimeException("HTTP ${response.code}: ${body.take(300)}")
                }
                if (body.isBlank()) throw RuntimeException("Response API kosong")
                body
            }

            val json = JSONObject(responseBody)
            if (!json.optBoolean("status", false)) {
                throw RuntimeException("API status = false")
            }

            val result = json.optJSONObject("result")
                ?: throw RuntimeException("Object result tidak ditemukan")

            val text = result.optString("text", "")
            val newSession = json.optString("session", "").ifBlank { null }
            val creator = json.optString("creator", "").ifBlank { null }
            val reasoning = result.optString("reasoning", "").ifBlank { null }

            ResultState.Success(
                StromAiResponse(
                    text = text.ifBlank { "AI tidak mengembalikan teks jawaban." },
                    sessionId = newSession,
                    model = model,
                    creator = creator,
                    reasoning = reasoning
                )
            )
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx, rawHost = "api.alfisy.my.id")
            ResultState.Error(e.message ?: "AI request gagal.", e)
        }
    }

    suspend fun uploadFileForAi(uri: Uri): ResultState<String> = withContext(Dispatchers.IO) {
        val moduleCtx = "STROM_AI / FILE_UPLOAD"
        var tempFile: File? = null
        try {
            val resolver = context.contentResolver
            val mimeType = resolver.getType(uri) ?: "image/jpeg"
            // The uploader from source.txt is multipart-based. Keep it generic here so
            // STROM can attach files, while the UI decides when the attachment action is shown.
            if (mimeType.isBlank()) throw IllegalArgumentException("Tipe file tidak diketahui.")

            val extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType) ?: "bin"
            tempFile = File.createTempFile("strom_ai_upload_", ".$extension", context.cacheDir)
            resolver.openInputStream(uri)?.use { input ->
                tempFile.outputStream().use { output -> input.copyTo(output) }
            } ?: throw IOException("Tidak dapat membaca gambar yang dipilih.")

            val fileBody = tempFile.asRequestBody(mimeType.toMediaType())
            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", tempFile.name, fileBody)
                .build()

            val request = Request.Builder()
                .url("https://bintangapi.my.id/api/uploader/uguu")
                .post(body)
                .header("Accept", "application/json")
                .build()

            val responseText = client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw RuntimeException("HTTP ${response.code}: ${text.take(300)}")
                }
                text
            }

            val json = JSONObject(responseText)
            val status = json.optString("status", "").lowercase()
            val url = json.optString("url", "").trim()
            if (url.isBlank() || (status.isNotBlank() && status !in setOf("true", "success", "ok", "1"))) {
                val message = json.optString("pesan", json.optString("message", "Upload gambar gagal."))
                throw RuntimeException(message)
            }
            ResultState.Success(url)
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx, rawHost = "bintangapi.my.id")
            ResultState.Error(e.message ?: "Upload gambar gagal.", e)
        } finally {
            tempFile?.delete()
        }
    }

    // ----------------------------------------------------
    // 3B. WEB TOOLS — SHORT URL
    // ----------------------------------------------------

    suspend fun shortenUrl(url: String): ResultState<ShortUrlResult> = withContext(Dispatchers.IO) {
        val moduleCtx = "WEB_TOOLS / SHORT_URL"
        try {
            val encodedUrl = URLEncoder.encode(url, "UTF-8")
            val targetUrl = "https://api.alfisy.my.id/api/tools/shorturl?url=$encodedUrl&service=tinyurl"
            val request = Request.Builder()
                .url(targetUrl)
                .get()
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36")
                .build()

            val respString = client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) throw RuntimeException("HTTP ${resp.code}")
                resp.body?.string().orEmpty()
            }

            val json = JSONObject(respString)
            if (!json.optBoolean("status", false)) {
                throw RuntimeException(json.optString("message", "Gagal memperpendek URL."))
            }

            val shortUrl = json.optString("short_url").ifBlank { null }
                ?: throw RuntimeException("API tidak mengembalikan short URL.")

            ResultState.Success(
                ShortUrlResult(
                    originalUrl = json.optString("original_url", url),
                    shortUrl = shortUrl,
                    service = json.optString("service").ifBlank { null }
                )
            )
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx, rawHost = "api.alfisy.my.id")
            ResultState.Error(e.message ?: "Gagal memperpendek URL.", e)
        }
    }

    // ----------------------------------------------------
    // 4. DOWNLOADER (TIKTOK)
    // ----------------------------------------------------

    suspend fun getTikTokInfo(url: String): ResultState<TikTokMediaInfo> = withContext(Dispatchers.IO) {
        val moduleCtx = "DOWNLOADER / TIKTOK_INFO"
        try {
            val targetUrl = "https://api.siputzx.my.id/api/d/tiktok/v2?url=${URLEncoder.encode(url, "UTF-8")}"
            val request = Request.Builder()
                .url(targetUrl)
                .get()
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36")
                .header("Referer", "https://api.siputzx.my.id/")
                .build()

            val respString = client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) throw RuntimeException("HTTP ${resp.code}")
                resp.body?.string().orEmpty()
            }

            val json = JSONObject(respString)
            val data = json.optJSONObject("data") ?: throw RuntimeException(json.optString("message", "API TikTok tidak mengembalikan data video."))

            // API siputzx mengembalikan "duration" dalam milidetik (mis. "25844" = ~26 detik),
            // bukan detik. Dikonversi di sini agar seluruh app konsisten menyimpan durasi dalam detik.
            val durationSeconds = data.optString("duration").toLongOrNull()?.let { ms -> ms / 1000 }

            val info = TikTokMediaInfo(
                author = data.optString("author_nickname").ifBlank { null },
                caption = data.optString("text").ifBlank { null },
                duration = durationSeconds?.toString(),
                likeCount = data.optString("like_count").ifBlank { null },
                commentCount = data.optString("comment_count").ifBlank { null },
                shareCount = data.optString("share_count").ifBlank { null },
                playCount = data.optString("play_count").ifBlank { null },
                videoUrl = data.optString("no_watermark_link").ifBlank { null },
                videoHdUrl = data.optString("no_watermark_link_hd").ifBlank { null },
                mp3Url = data.optString("music_link").ifBlank { null },
                itemId = data.optString("itemId").ifBlank { null },
                coverUrl = data.optString("cover_link").ifBlank { null }
            )

            if (info.videoUrl == null && info.videoHdUrl == null && info.mp3Url == null) {
                throw RuntimeException("Link download video tidak ditemukan.")
            }

            ResultState.Success(info)
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx, rawHost = "api.siputzx.my.id")
            ResultState.Error(e.message ?: "API TikTok gagal memproses link.", e)
        }
    }

    /**
     * Resolves the dedicated HD TikTok downloader used by the supplied web tool.
     *
     * This is intentionally separate from [getTikTokInfo]: the existing API remains
     * the source for standard no-watermark video + MP3, while this resolver is used
     * only for the HD stream and its proxy download URL.
     */
    suspend fun getTikTokHdInfo(url: String): ResultState<TikTokHdResolveResult> = withContext(Dispatchers.IO) {
        val moduleCtx = "DOWNLOADER / TIKTOK_HD_RESOLVE"
        try {
            val encodedUrl = URLEncoder.encode(url, "UTF-8")
            val resolverUrl = "https://www.cutefish.my.id/api/tiktok-resolve?url=$encodedUrl&nocache=1"
            val request = Request.Builder()
                .url(resolverUrl)
                .get()
                .header("Accept", "application/json")
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36")
                .header("Referer", "https://www.cutefish.my.id/")
                .build()

            val responseBody = client.newCall(request).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    val json = runCatching { JSONObject(body) }.getOrNull()
                    val message = json?.optString("error")?.takeIf { it.isNotBlank() }
                        ?: json?.optString("details")?.takeIf { it.isNotBlank() }
                        ?: "HTTP ${resp.code}"
                    throw RuntimeException("TikTok HD resolver gagal: $message")
                }
                body
            }

            val json = JSONObject(responseBody)
            val hdPlay = json.optString("hdplay").trim().ifBlank { null }
            val normalPlay = json.optString("play").trim().ifBlank { null }

            // The supplied web JS does NOT require hdplay to exist. Its exact selection is:
            //   hdplay (when it is a valid http URL) -> play -> hdplay.
            // Some valid TikTok posts return hdplay="" (as in the reported response), while
            // play contains a working no-watermark stream. Treating empty hdplay as a hard error
            // was the reason the Android UI showed "HD tidak tersedia".
            val selectedVideo = hdPlay?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
                ?: normalPlay?.takeIf { it.startsWith("http://") || it.startsWith("https://") }

            if (selectedVideo.isNullOrBlank()) {
                throw RuntimeException("Resolver tidak mengembalikan link video yang dapat diputar.")
            }

            val proxyUrl = "https://www.cutefish.my.id/api/proxy?url=${URLEncoder.encode(selectedVideo, "UTF-8")}"

            ResultState.Success(
    TikTokHdResolveResult(
        hdPlayUrl = selectedVideo,
        proxyDownloadUrl = proxyUrl,
        hasNativeHd = hdPlay?.startsWith("http://") == true ||
            hdPlay?.startsWith("https://") == true,
        fallbackPlayUrl = normalPlay,
        coverUrl = json.optString("cover").trim().ifBlank { null },
        authorNickname = json.optString("author_nickname").trim().ifBlank { null },
        authorUniqueId = json.optString("author_unique_id").trim().ifBlank { null },
        title = json.optString("title").trim().ifBlank { null }
    )
)
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx, rawHost = "www.cutefish.my.id")
            ResultState.Error(e.message ?: "TikTok HD resolver gagal.", e)
        }
    }

    /**
     * Reads YouTube metadata from the same oEmbed endpoint used by the supplied HAR,
     * then exposes the same format choices shown by the y2meta frame.
     *
     * IMPORTANT: format URLs are intentionally left empty. The HAR shows that the actual
     * download URL is generated on demand through cnv.cx/v2/sanity/key + /v2/converter.
     */
    suspend fun getYoutubeInfo(url: String): ResultState<YoutubeMediaInfo> = withContext(Dispatchers.IO) {
        val moduleCtx = "DOWNLOADER / YOUTUBE_INFO"
        try {
            val cleanUrl = url.trim()
            if (cleanUrl.isBlank()) throw RuntimeException("URL YouTube kosong.")

            val videoId = extractYoutubeVideoId(cleanUrl)
                ?: throw RuntimeException("URL YouTube tidak valid atau video ID tidak ditemukan.")

            val watchUrl = "https://www.youtube.com/watch?v=$videoId"
            var title: String? = null
            var thumbnail: String? = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg"

            // Matches the HAR: GET YouTube oEmbed for title + thumbnail.
            try {
                val oEmbedUrl = "https://www.youtube.com/oembed?url=${URLEncoder.encode(watchUrl, "UTF-8")}&format=json"
                val request = Request.Builder()
                    .url(oEmbedUrl)
                    .get()
                    .header(
                        "User-Agent",
                        "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 " +
                            "(KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36"
                    )
                    .header("Accept", "*/*")
                    .header("Origin", "https://frame.y2meta-uk.com")
                    .header("Referer", "https://frame.y2meta-uk.com/")
                    .build()

                client.newCall(request).execute().use { response ->
                    val text = response.body?.string().orEmpty()
                    if (response.isSuccessful && text.isNotBlank()) {
                        val json = JSONObject(text)
                        title = json.optString("title").trim().ifBlank { null }
                        thumbnail = json.optString("thumbnail_url").trim().ifBlank { thumbnail }
                    }
                }
            } catch (_: Exception) {
                // The source page also treats oEmbed as best-effort. Keep the YouTube
                // downloader usable with the local video ID/thumbnail fallback.
            }

            // Exact format set exposed by the supplied frame HAR.
            val formats = buildList {
                add(YoutubeFormatOption(1080, "1080p MP4", "", false))
                add(YoutubeFormatOption(720, "720p MP4", "", false))
                add(YoutubeFormatOption(360, "360p MP4", "", false))
                add(YoutubeFormatOption(240, "240p MP4", "", false))
                add(YoutubeFormatOption(144, "144p MP4", "", false))
                add(YoutubeFormatOption(320, "320kbps MP3", "", true))
                add(YoutubeFormatOption(256, "256kbps MP3", "", true))
                add(YoutubeFormatOption(128, "128kbps MP3", "", true))
            }

            ResultState.Success(
                YoutubeMediaInfo(
                    title = title ?: "YouTube Video",
                    sourceUrl = cleanUrl,
                    duration = null,
                    thumbnailUrl = thumbnail,
                    formats = formats
                )
            )
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx, rawHost = "www.youtube.com")
            ResultState.Error(e.message ?: "Gagal memproses link YouTube.", e)
        }
    }

    /**
     * Generates a fresh converter URL using the exact request flow found in frame.y2meta-uk.com HAR:
     *   1) GET /v2/sanity/key?id=<videoId>
     *   2) POST /v2/converter with the returned `key` header
     */
    suspend fun resolveYoutubeDownloadUrl(
        sourceUrl: String,
        quality: Int,
        isAudioOnly: Boolean
    ): ResultState<String> = withContext(Dispatchers.IO) {
        val moduleCtx = "DOWNLOADER / YOUTUBE_RESOLVE"
        try {
            val videoId = extractYoutubeVideoId(sourceUrl)
                ?: throw RuntimeException("URL YouTube tidak valid atau video ID tidak ditemukan.")

            val framePageUrl = "https://frame.y2meta-uk.com/test.php?videoId=$videoId"
            val sanityUrl = "https://cnv.cx/v2/sanity/key?id=${URLEncoder.encode(videoId, "UTF-8")}"
            val sanityRequest = Request.Builder()
                .url(sanityUrl)
                .get()
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36"
                )
                // Mirror the browser fetch from the supplied y2meta iframe HAR.
                // The important difference is that the Referer is the exact iframe
                // document, not just the frame origin.
                .header("Accept", "*/*")
                .header("Accept-Language", "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7")
                .header("Content-Type", "application/json")
                .header("Origin", "https://frame.y2meta-uk.com")
                .header("Referer", framePageUrl)
                .header("Sec-Fetch-Site", "cross-site")
                .header("Sec-Fetch-Mode", "cors")
                .header("Sec-Fetch-Dest", "empty")
                .header("sec-ch-ua", "\"Chromium\";v=\"152\", \"Not?A_Brand\";v=\"24\", \"Google Chrome\";v=\"152\"")
                .header("sec-ch-ua-mobile", "?1")
                .header("sec-ch-ua-platform", "\"Android\"")
                .header("Cache-Control", "no-cache")
                .build()

            val sanityText = client.newCall(sanityRequest).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw RuntimeException("Converter sanity HTTP ${response.code}: ${text.take(200)}")
                }
                text
            }

            val validateKey = JSONObject(sanityText).optString("key").trim()
            if (validateKey.isBlank()) {
                throw RuntimeException("Converter tidak mengembalikan validation key.")
            }

            // HAR behavior:
            // mp4 => audioBitrate=128, videoQuality=<selected>
            // mp3 => audioBitrate=<selected>, videoQuality=720
            val format = if (isAudioOnly) "mp3" else "mp4"
            val audioBitrate = if (isAudioOnly) quality else 128
            val videoQuality = if (isAudioOnly) 720 else quality

            val formBody = FormBody.Builder()
                .add("link", "https://youtu.be/$videoId")
                .add("format", format)
                .add("audioBitrate", audioBitrate.toString())
                .add("videoQuality", videoQuality.toString())
                .add("filenameStyle", "pretty")
                .add("vCodec", "h264")
                .build()

            val converterRequest = Request.Builder()
                .url("https://cnv.cx/v2/converter")
                .post(formBody)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 Chrome/152.0.0.0 Mobile Safari/537.36")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .header("Accept", "*/*")
                .header("Accept-Language", "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7")
                .header("key", validateKey)
                .header("Origin", "https://frame.y2meta-uk.com")
                .header("Referer", framePageUrl)
                .header("Sec-Fetch-Site", "cross-site")
                .header("Sec-Fetch-Mode", "cors")
                .header("Sec-Fetch-Dest", "empty")
                .header("sec-ch-ua", "\"Chromium\";v=\"152\", \"Not?A_Brand\";v=\"24\", \"Google Chrome\";v=\"152\"")
                .header("sec-ch-ua-mobile", "?1")
                .header("sec-ch-ua-platform", "\"Android\"")
                .build()

            val converterText = client.newCall(converterRequest).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw RuntimeException("Converter HTTP ${response.code}: ${text.take(300)}")
                }
                text
            }

            val converterJson = JSONObject(converterText)
            val rawUrl = converterJson.optString("url").trim()
                .ifBlank { converterJson.optString("downloadUrl").trim() }
                .ifBlank { converterJson.optString("download").trim() }
                .ifBlank {
                    converterJson.optJSONObject("data")?.optString("url")?.trim().orEmpty()
                }

            // This fallback is the one explicitly embedded in the supplied frame HAR.
            val selectedUrl = if (rawUrl.isNotBlank()) {
                normalizeY2MetaConverterUrl(rawUrl)
            } else {
                "https://conv.mp3youtube.cc/download/$videoId"
            }

            if (selectedUrl.isBlank()) {
                throw RuntimeException("Converter tidak mengembalikan URL download.")
            }

            ResultState.Success(selectedUrl)
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx, rawHost = "cnv.cx")
            ResultState.Error(e.message ?: "Gagal membuat link download YouTube.", e)
        }
    }

    private fun extractYoutubeVideoId(sourceUrl: String): String? {
        val uri = runCatching { Uri.parse(sourceUrl.trim()) }.getOrNull() ?: return null
        val host = uri.host?.lowercase(Locale.US) ?: return null

        if (host == "youtu.be" || host == "www.youtu.be") {
            return uri.pathSegments.firstOrNull()?.takeIf { it.isNotBlank() }
        }

        if (host == "youtube.com" || host.endsWith(".youtube.com")) {
            uri.getQueryParameter("v")?.takeIf { it.isNotBlank() }?.let { return it }
            val segments = uri.pathSegments.filter { it.isNotBlank() }
            val markerIndex = segments.indexOfFirst { it == "shorts" || it == "embed" || it == "live" }
            if (markerIndex >= 0) {
                return segments.getOrNull(markerIndex + 1)?.takeIf { it.isNotBlank() }
            }
        }

        // Last-resort fallback for plain video IDs embedded in a pasted link.
        return Regex("(?:v=|youtu\\.be/|shorts/|embed/|live/)([A-Za-z0-9_-]{6,})")
            .find(sourceUrl)
            ?.groupValues
            ?.getOrNull(1)
    }

    /**
     * The frame page converts a returned URL such as `https://host/path?id=XYZ`
     * into `https://host/path/?id=XYZ` before opening it. Reproduce that behavior here
     * so Android follows the same final endpoint instead of storing the intermediate URL.
     */
    private fun normalizeY2MetaConverterUrl(rawUrl: String): String {
        if (rawUrl.startsWith("https://conv.mp3youtube.cc/download/") ||
            rawUrl.startsWith("http://conv.mp3youtube.cc/download/")) {
            return rawUrl
        }

        val parsed = rawUrl.toHttpUrlOrNull() ?: return rawUrl

        // Reproduce the exact URL transformation in frame.y2meta-uk.com HAR:
        //   let parsed = new URL(dwn_url);
        //   let base = parsed.origin + parsed.pathname;
        //   let query = parsed.search.substring(1);
        //   if (query.startsWith("id=")) query = query.substring(3);
        //   final = base + '/?id=' + query;
        // Keep every query parameter after `id=`; tokens/signatures must not be lost.
        val base = "${parsed.scheme}://${parsed.host}${parsed.encodedPath}"
        var query = parsed.encodedQuery.orEmpty()
        if (query.startsWith("id=")) {
            query = query.removePrefix("id=")
        }
        if (query.isBlank()) return rawUrl

        return "$base/?id=$query"
    }

    suspend fun getDriveInfo(url: String): ResultState<DriveMediaInfo> = withContext(Dispatchers.IO) {
        val moduleCtx = "DOWNLOADER / DRIVE_INFO"
        try {
            val targetUrl = "https://api.alfisy.my.id/api/download/drive?url=${URLEncoder.encode(url, "UTF-8")}"
            val request = Request.Builder()
                .url(targetUrl)
                .get()
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36")
                .build()

            val respString = client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) throw RuntimeException("HTTP ${resp.code}")
                resp.body?.string().orEmpty()
            }

            val json = JSONObject(respString)
            if (!json.optBoolean("success", false)) {
                throw RuntimeException(json.optString("message", "API Google Drive tidak mengembalikan data file."))
            }

            val result = json.optJSONObject("result")
                ?: throw RuntimeException("API Google Drive tidak mengembalikan data file.")

            val info = DriveMediaInfo(
                name = result.optString("name").ifBlank { null },
                downloadUrl = result.optString("download").ifBlank { null },
                sourceLink = result.optString("link").ifBlank { null }
            )

            if (info.downloadUrl == null) {
                throw RuntimeException("Link download file tidak ditemukan.")
            }

            ResultState.Success(info)
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx, rawHost = "api.alfisy.my.id")
            ResultState.Error(e.message ?: "API Google Drive gagal memproses link.", e)
        }
    }

    /**
     * Generates a fresh converter URL immediately before downloading, so no expired ydl.ymcdn.org
     * URL is persisted or reused between actions.
     */
    suspend fun downloadYoutubeFormatToStorage(
        sourceUrl: String,
        quality: Int,
        isAudioOnly: Boolean,
        fileName: String,
        mimeType: String,
        onProgress: (Float) -> Unit = {}
    ): ResultState<Uri> = withContext(Dispatchers.IO) {
        val moduleCtx = "DOWNLOADER / YOUTUBE_DOWNLOAD"
        try {
            val resolveResult = resolveYoutubeDownloadUrl(sourceUrl, quality, isAudioOnly)
            val downloadUrl = when (resolveResult) {
                is ResultState.Success -> resolveResult.data
                is ResultState.Error -> throw RuntimeException(resolveResult.message, resolveResult.throwable)
            }

            var result = downloadFileToStorage(
                downloadUrl = downloadUrl,
                fileName = fileName,
                mimeType = mimeType,
                onProgress = onProgress,
                referer = "https://frame.y2meta-uk.com/test.php?videoId=${extractYoutubeVideoId(sourceUrl) ?: ""}",
                origin = "https://frame.y2meta-uk.com"
            )

            // Converter/CDN URLs can expire between generation and the first byte.
            // Re-run the exact HAR converter flow once when that happens.
            if (result is ResultState.Error &&
                (result.message.contains("HTTP 400", ignoreCase = true) ||
                 result.message.contains("HTTP 410", ignoreCase = true) ||
                 result.message.contains("HTTP 404", ignoreCase = true))) {
                val retryResolve = resolveYoutubeDownloadUrl(sourceUrl, quality, isAudioOnly)
                if (retryResolve is ResultState.Success) {
                    result = downloadFileToStorage(
                        downloadUrl = retryResolve.data,
                        fileName = fileName,
                        mimeType = mimeType,
                        onProgress = onProgress,
                        referer = "https://frame.y2meta-uk.com/test.php?videoId=${extractYoutubeVideoId(sourceUrl) ?: ""}",
                        origin = "https://frame.y2meta-uk.com"
                    )
                }
            }

            result
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx, rawHost = "cnv.cx")
            ResultState.Error(e.message ?: "Gagal mengunduh video YouTube.", e)
        }
    }

    suspend fun downloadFileToStorage(
        downloadUrl: String,
        fileName: String,
        mimeType: String,
        onProgress: (Float) -> Unit = {},
        referer: String? = null,
        origin: String? = null
    ): ResultState<Uri> = withContext(Dispatchers.IO) {
        val moduleCtx = "DOWNLOADER / DOWNLOAD_FILE"
        try {
            val requestBuilder = Request.Builder()
                .url(downloadUrl)
                .get()
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 16; K) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/140.0.7339.101 Mobile Safari/537.36"
                )
                .header("Accept", "*/*")
            // The supplied HAR opens the converter result as a normal browser
            // navigation. It does not send an Origin header on that final GET.
            // Let OkHttp manage compression rather than forcing br/zstd manually.
            if (!referer.isNullOrBlank()) {
                requestBuilder.header("Referer", referer)
            }
            val request = requestBuilder.build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                val errorBody = response.body?.string().orEmpty().take(500)
                throw RuntimeException(
                    "Download failed: HTTP ${response.code}" +
                        if (errorBody.isNotBlank()) ": $errorBody" else ""
                )
            }

            val body = response.body ?: throw RuntimeException("Empty response body")
            val savedUri = workspaceManager.saveStreamToDownloads(fileName, mimeType, body.byteStream())
                ?: throw RuntimeException("Gagal menyimpan file ke Download.")

            ResultState.Success(savedUri)
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx)
            ResultState.Error(e.message ?: "Gagal mengunduh file.", e)
        }
    }

    // ----------------------------------------------------
    // 6. MEDIA TOOLS (UPLOAD / UPSCALE / REMOVE BACKGROUND)
    // ----------------------------------------------------

    /**
     * Upload file publik (image/pdf/doc/xls/ppt) ke endpoint alfisy.
     * Membaca seluruh konten [uri] via ContentResolver (dibutuhkan karena multipart body
     * butuh Content-Length yang diketahui di muka), lalu mengirimkannya sebagai multipart
     * form-data dengan field "file". Dijalankan di Dispatchers.IO agar tidak memblokir UI thread.
     */
    suspend fun uploadMediaFile(uri: Uri, fileName: String, mimeType: String): ResultState<MediaUploadResult> =
        withContext(Dispatchers.IO) {
            val moduleCtx = "MEDIA / UPLOAD"
            try {
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IOException("Tidak dapat membaca file yang dipilih.")

                if (bytes.isEmpty()) {
                    throw IOException("File yang dipilih kosong.")
                }

                val mediaType = mimeType.toMediaType()
                val fileBody = bytes.toRequestBody(mediaType)

                val requestBody = MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("file", fileName, fileBody)
                    .build()

                val request = Request.Builder()
                    .url("https://api.alfisy.my.id/api/tools/upload")
                    .post(requestBody)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36")
                    .build()

                val respString = client.newCall(request).execute().use { resp ->
                    val body = resp.body?.string()
                    if (!resp.isSuccessful) {
                        throw UpstreamHttpException(resp.code, "Upload gagal (${resp.code}): ${body.orEmpty()}")
                    }
                    body ?: throw IOException("Response kosong dari server upload.")
                }

                val json = JSONObject(respString)
                if (!json.optBoolean("status", false)) {
                    throw RuntimeException("Server upload mengembalikan status gagal.")
                }
                val urls = json.optJSONObject("urls")
                    ?: throw RuntimeException("Response upload tidak berisi data URL.")
                val directUrl = urls.optString("direct").ifBlank { null }
                    ?: throw RuntimeException("Response upload tidak berisi directUrl.")

                ResultState.Success(
                    MediaUploadResult(
                        directUrl = directUrl,
                        originalName = json.optString("originalName").ifBlank { fileName },
                        size = json.optLong("size", bytes.size.toLong()),
                        mimetype = json.optString("mimetype").ifBlank { mimeType }
                    )
                )
            } catch (e: UpstreamHttpException) {
                errorReportManager.capture(e, moduleCtx, httpStatusCode = e.httpCode, rawHost = "api.alfisy.my.id")
                ResultState.Error(e.message ?: "Upload gagal.", e)
            } catch (e: Exception) {
                errorReportManager.capture(e, moduleCtx, rawHost = "api.alfisy.my.id")
                ResultState.Error(e.message ?: "Upload gagal.", e)
            }
        }

    /**
     * Upscale gambar publik (hasil upload) via api/tools/upscale.
     * Response berupa binary PNG langsung, ditulis ke cache dir memakai buffered stream
     * (bukan dibaca penuh ke ByteArray) agar aman untuk gambar hasil upscale berukuran besar.
     */
    suspend fun upscaleImage(imageUrl: String, scale: Int): ResultState<UpscaleResult> = withContext(Dispatchers.IO) {
        val moduleCtx = "MEDIA / UPSCALE"
        try {
            require(scale == 2 || scale == 4 || scale == 8) { "Scale harus 2, 4, atau 8." }

            val encodedUrl = URLEncoder.encode(imageUrl, "UTF-8")
            val targetUrl = "https://api.alfisy.my.id/api/tools/upscale?image_url=$encodedUrl&scale=$scale"

            val request = Request.Builder()
                .url(targetUrl)
                .get()
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36")
                .header("Accept", "image/png,*/*")
                .build()

            val outputFile = File(context.cacheDir, "upscaled_${System.currentTimeMillis()}.png")

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw UpstreamHttpException(response.code, "Upscale gagal: HTTP ${response.code}")
                }
                val body = response.body ?: throw IOException("Response upscale kosong.")

                BufferedOutputStream(java.io.FileOutputStream(outputFile)).use { out ->
                    val buffer = ByteArray(64 * 1024)
                    var bytesRead: Int
                    var totalRead = 0L
                    body.byteStream().use { input ->
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            out.write(buffer, 0, bytesRead)
                            totalRead += bytesRead
                        }
                    }
                    if (totalRead == 0L) {
                        throw IOException("Response gambar upscale kosong.")
                    }
                }
            }

            ResultState.Success(UpscaleResult(localFilePath = outputFile.absolutePath, scale = scale))
        } catch (e: UpstreamHttpException) {
            errorReportManager.capture(e, moduleCtx, httpStatusCode = e.httpCode, rawHost = "api.alfisy.my.id")
            ResultState.Error(e.message ?: "Upscale gagal.", e)
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx, rawHost = "api.alfisy.my.id")
            ResultState.Error(e.message ?: "Upscale gagal.", e)
        }
    }

    /**
     * Hapus background gambar via api/tools/removebg (multipart, field "file").
     * Gambar sumber dibaca dari [uri], response binary (PNG dengan alpha channel)
     * ditulis langsung ke cache dir via buffered stream.
     */
    suspend fun removeBackground(uri: Uri): ResultState<UpscaleResult> = withContext(Dispatchers.IO) {
        val moduleCtx = "MEDIA / REMOVEBG"
        try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IOException("Tidak dapat membaca gambar yang dipilih.")

            if (bytes.isEmpty()) {
                throw IOException("Gambar yang dipilih kosong.")
            }

            val mimeType = context.contentResolver.getType(uri) ?: "image/png"
            val mediaType = mimeType.toMediaType()
            val imageBody = bytes.toRequestBody(mediaType)

            val requestBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", "image.png", imageBody)
                .build()

            val request = Request.Builder()
                .url("https://api.alfisy.my.id/api/tools/removebg")
                .post(requestBody)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36")
                .header("Accept", "*/*")
                .build()

            val outputFile = File(context.cacheDir, "removebg_${System.currentTimeMillis()}.png")

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw UpstreamHttpException(response.code, "RemoveBG gagal: HTTP ${response.code}")
                }
                val body = response.body ?: throw IOException("Response RemoveBG kosong.")

                BufferedOutputStream(java.io.FileOutputStream(outputFile)).use { out ->
                    val buffer = ByteArray(64 * 1024)
                    var bytesRead: Int
                    var totalRead = 0L
                    body.byteStream().use { input ->
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            out.write(buffer, 0, bytesRead)
                            totalRead += bytesRead
                        }
                    }
                    if (totalRead == 0L) {
                        throw IOException("Response gambar RemoveBG kosong.")
                    }
                }
            }

            ResultState.Success(UpscaleResult(localFilePath = outputFile.absolutePath, scale = 1))
        } catch (e: UpstreamHttpException) {
            errorReportManager.capture(e, moduleCtx, httpStatusCode = e.httpCode, rawHost = "api.alfisy.my.id")
            ResultState.Error(e.message ?: "RemoveBG gagal.", e)
        } catch (e: Exception) {
            errorReportManager.capture(e, moduleCtx, rawHost = "api.alfisy.my.id")
            ResultState.Error(e.message ?: "RemoveBG gagal.", e)
        }
    }

    // ----------------------------------------------------
    // 5. BASE64 LAB (OFFLINE LOCAL ENGINE)
    // ----------------------------------------------------

    fun encodeTextBase64(text: String): String {
        return Base64.encodeToString(text.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    }

    fun decodeTextBase64(base64: String): String {
        val cleaned = cleanBase64(base64)
        val bytes = Base64.decode(cleaned, Base64.DEFAULT)
        return String(bytes, Charsets.UTF_8)
    }

    fun decodeBytesBase64(base64: String): ByteArray {
        val cleaned = cleanBase64(base64)
        return Base64.decode(cleaned, Base64.DEFAULT)
    }

    private fun cleanBase64(input: String): String {
        var value = input.trim()
        if (value.startsWith("data:", ignoreCase = true)) {
            val comma = value.indexOf(',')
            if (comma != -1) {
                value = value.substring(comma + 1)
            }
        }
        return value.replace("\\s".toRegex(), "")
    }
}
