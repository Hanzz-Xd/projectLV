package com.baklava.projectlv.ui.components

/**
 * Satu-satunya sumber data untuk pengelompokan fitur (kategori) dan susunan navigasi.
 * Dashboard, bottom navigation (HP) dan navigation rail (tablet) semua membaca dari sini,
 * jadi mengubah urutan / kategori cukup dilakukan di satu tempat.
 */
enum class ToolCategory(val label: String, val caption: String) {
    AI_AUTOMATION("AI & OTOMASI", "Asisten cerdas dan alat otomatis"),
    MEDIA_DOWNLOAD("MEDIA & DOWNLOAD", "Unduh, edit, dan tingkatkan kualitas media"),
    WEB_DEV("WEB & DEVELOPER", "Alat bantu web, kode, dan konversi data");

    /** Modul di dalam kategori, urut dari yang paling sering dipakai. */
    val destinations: List<LeviathanDestination>
        get() = when (this) {
            AI_AUTOMATION -> listOf(
                LeviathanDestination.STROM_AI,
                LeviathanDestination.MAGIC_LINK
            )
            MEDIA_DOWNLOAD -> listOf(
                LeviathanDestination.DOWNLOADER,
                LeviathanDestination.MEDIA,
                LeviathanDestination.TIKTOK_QUALITY
            )
            WEB_DEV -> listOf(
                LeviathanDestination.WEB_TOOLS,
                LeviathanDestination.PY_OBFUSCATOR,
                LeviathanDestination.BASE64_LAB,
                LeviathanDestination.ALIGHT_MOTION_FINDER,
                LeviathanDestination.SFL_BYPASS
            )
        }
}

object ToolCatalog {

    /** Urutan kategori di Dashboard. */
    val categories: List<ToolCategory> = ToolCategory.entries

    /**
     * Tab bottom navigation (HP): hanya jalan pintas yang paling sering dipakai,
     * supaya label terbaca jelas dan mudah disentuh. Modul lain dibuka lewat Beranda.
     */
    val bottomTabs: List<LeviathanDestination> = listOf(
        LeviathanDestination.DASHBOARD,
        LeviathanDestination.STROM_AI,
        LeviathanDestination.DOWNLOADER,
        LeviathanDestination.MEDIA,
        LeviathanDestination.SETTINGS
    )

    /** Navigation rail (tablet / layar lebar): semua modul, dikelompokkan per kategori. */
    val railItems: List<LeviathanDestination> =
        listOf(LeviathanDestination.DASHBOARD) +
            categories.flatMap { it.destinations } +
            LeviathanDestination.SETTINGS

    /** Modul yang bukan tab akan menandai "Beranda" sebagai induknya. */
    fun bottomTabFor(destination: LeviathanDestination): LeviathanDestination =
        if (destination in bottomTabs) destination else LeviathanDestination.DASHBOARD
}
