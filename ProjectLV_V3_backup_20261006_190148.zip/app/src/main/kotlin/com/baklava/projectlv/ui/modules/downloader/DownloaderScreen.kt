package com.baklava.projectlv.ui.modules.downloader

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import com.baklava.projectlv.ui.components.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Hd
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Repeat
import com.baklava.projectlv.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import com.baklava.projectlv.ui.components.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import com.baklava.projectlv.ui.components.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.baklava.projectlv.data.models.DriveMediaInfo
import com.baklava.projectlv.data.models.TikTokMediaInfo
import com.baklava.projectlv.data.models.YoutubeFormatOption
import com.baklava.projectlv.data.models.YoutubeMediaInfo
import com.baklava.projectlv.data.repository.LeviathanRepository
import com.baklava.projectlv.data.repository.ResultState
import com.baklava.projectlv.ui.components.AppWindowSize
import com.baklava.projectlv.ui.components.ModuleHeaderCard
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.BrightMagenta
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.launch

/*
 * CATATAN IMPLEMENTASI:
 * - Preview thumbnail (cover) memakai Coil. Tambahkan di build.gradle.kts (module app)
 *   bila belum ada:
 *       implementation("io.coil-kt:coil-compose:2.6.0")
 * - Preview VIDEO (play-on-tap) memakai Media3 ExoPlayer. Tambahkan:
 *       implementation("androidx.media3:media3-exoplayer:1.4.1")
 *       implementation("androidx.media3:media3-ui:1.4.1")
 *   Alur TikTok: cover ditampilkan dulu (hemat kuota) -> tombol play ditekan -> video HD
 *   dari resolver khusus dimuat & diputar inline via ExoPlayer; video standar menjadi fallback.
 *   Alur YouTube: thumbnail ditampilkan dulu -> tombol play ditekan -> video kualitas
 *   TERTINGGI (info.previewVideoUrl, hasil pilih otomatis dari daftar format HD) diputar inline.
 */

@Composable
fun DownloaderScreen(
    repository: LeviathanRepository,
    windowSize: AppWindowSize,
    onShowSnackbar: (String) -> Unit
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("TikTok", "YouTube", "Google Drive")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
    ) {
        ModuleHeaderCard(
            icon = Icons.Default.Download,
            title = "DOWNLOADER",
            subtitle = "TikTok, YouTube & Google Drive Downloader (No Watermark)",
            modifier = Modifier.padding(16.dp)
        )

        ScrollableTabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = CyberDarkNavy,
            contentColor = BrightCyan,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = BrightCyan
                )
            },
            divider = { Box(modifier = Modifier.height(1.dp).background(CyberCardBorder)) }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) BrightCyan else MutedGrey
                            )
                        )
                    },
                    modifier = Modifier.testTag("tab_downloader_$index")
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            when (selectedTabIndex) {
                0 -> TikTokTab(repository, onShowSnackbar)
                1 -> YoutubeTab(repository, onShowSnackbar)
                2 -> DriveTab(repository, onShowSnackbar)
            }
        }
    }
}

// ----------------------------------------------------------------
// 1. TIKTOK TAB
// ----------------------------------------------------------------
@Composable
private fun TikTokTab(
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit
) {
    val scope = rememberCoroutineScope()

    var tiktokUrl by remember { mutableStateOf("") }
    var isProcessing by remember { mutableStateOf(false) }
    var mediaInfo by remember { mutableStateOf<TikTokMediaInfo?>(null) }
    var captionExpanded by remember { mutableStateOf(false) }

    var isDownloading by remember { mutableStateOf(false) }
    var downloadStatusText by remember { mutableStateOf("") }
    var lastDownloadedUri by remember { mutableStateOf<Uri?>(null) }
    var lastDownloadedMime by remember { mutableStateOf("video/mp4") }

    fun downloadMedia(url: String, fileName: String, mime: String, referer: String? = null) {
        isDownloading = true
        downloadStatusText = "Mengunduh $fileName..."
        lastDownloadedMime = mime
        scope.launch {
            when (val res = repository.downloadFileToStorage(url, fileName, mime, referer = referer)) {
                is ResultState.Success -> {
                    lastDownloadedUri = res.data
                    downloadStatusText = "File berhasil disimpan ke folder Download."
                }
                is ResultState.Error -> {
                    downloadStatusText = "Gagal mengunduh: ${res.message}"
                    onShowSnackbar("Gagal: ${res.message}")
                }
            }
            isDownloading = false
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Input Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = tiktokUrl,
                    onValueChange = { tiktokUrl = it },
                    label = { Text("URL Video TikTok") },
                    placeholder = { Text("https://vt.tiktok.com/... atau https://www.tiktok.com/@...") },
                    leadingIcon = { Icon(Icons.Default.Link, contentDescription = null, tint = MutedGrey) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_tiktok_url"),
                    colors = downloaderFieldColors(BrightMagenta),
                    shape = RoundedCornerShape(8.dp)
                )

                Button(
                    onClick = {
                        val url = tiktokUrl.trim()
                        if (url.isBlank()) {
                            onShowSnackbar("Masukkan URL TikTok terlebih dahulu.")
                            return@Button
                        }
                        scope.launch {
    isProcessing = true
    mediaInfo = null
    captionExpanded = false
    lastDownloadedUri = null

    // Resolve both sources independently:
    // API lama = standard video + MP3
    // Resolver baru = HD video
    val standardRes = repository.getTikTokInfo(url)
    val hdRes = repository.getTikTokHdInfo(url)

    var mergedInfo: TikTokMediaInfo? = when (standardRes) {
        is ResultState.Success -> standardRes.data.copy(
            // Never use the legacy API's HD URL in the player or HD button.
            videoHdUrl = null,
            videoHdDownloadUrl = null
        )
        is ResultState.Error -> null
    }

    when (hdRes) {
        is ResultState.Success -> {
            val hd = hdRes.data
            val base = mergedInfo ?: TikTokMediaInfo()

            mergedInfo = base.copy(
                videoHdUrl = hd.hdPlayUrl,
                videoHdDownloadUrl = hd.proxyDownloadUrl,
                hasNativeHd = hd.hasNativeHd,
                coverUrl = base.coverUrl ?: hd.coverUrl,
                author = base.author ?: hd.authorNickname,
                caption = base.caption ?: hd.title
            )
        }

        is ResultState.Error -> Unit
    }

    if (mergedInfo == null) {
        val standardMessage = (standardRes as? ResultState.Error)?.message
        val hdMessage = (hdRes as? ResultState.Error)?.message

        onShowSnackbar(
            "TikTok gagal diproses. " +
                "${standardMessage ?: hdMessage ?: "Tidak ada sumber yang tersedia."}"
        )
    } else {
        // Tidak ada Snackbar saat video berhasil diproses.
        mediaInfo = mergedInfo
    }

    isProcessing = false
}
                    },
                    enabled = tiktokUrl.isNotBlank() && !isProcessing,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("btn_process_tiktok_link"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightMagenta, contentColor = Color.White)
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Memproses Link...")
                    } else {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Proses Link", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        }

        // Parsed Media Info Card & Format Options
        AnimatedVisibility(
            visible = mediaInfo != null,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            val info = mediaInfo
            if (info != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BrightMagenta.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {

                        // --- VIDEO PREVIEW ---
                        VideoPreviewPlayer(
                            coverUrl = info.coverUrl,
                            // TikTok preview must use the NEW HD resolver stream first.
                            playableUrl = info.videoHdUrl ?: info.videoUrl,
                            fallbackPlayableUrl = if (info.videoHdUrl != null) info.videoHdDownloadUrl else null,
                            durationText = info.duration?.let { "${it}s" },
                            accentColor = BrightMagenta,
                            preferredAspectRatio = 9f / 16f,
                            badgeText = when {
                                info.hasNativeHd -> "HD PREVIEW"
                                info.videoHdUrl != null -> "BEST AVAILABLE"
                                else -> "NO WATERMARK"
                            }
                        )

                        // Author & Caption
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(BrightCyan.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = BrightCyan)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = info.author ?: "TikTok Creator",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Durasi: ${info.duration ?: "-"}s",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MutedGrey)
                                )
                            }
                        }

                        if (!info.caption.isNullOrBlank()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { captionExpanded = !captionExpanded }
                            ) {
                                Text(
                                    text = info.caption,
                                    style = MaterialTheme.typography.bodyMedium.copy(color = Color.White, lineHeight = 20.sp),
                                    maxLines = if (captionExpanded) Int.MAX_VALUE else 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (info.caption.length > 90) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(top = 2.dp)
                                    ) {
                                        Text(
                                            text = if (captionExpanded) "Lebih sedikit" else "Selengkapnya",
                                            style = MaterialTheme.typography.labelSmall.copy(color = BrightCyan, fontWeight = FontWeight.SemiBold)
                                        )
                                        Icon(
                                            imageVector = if (captionExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                            contentDescription = null,
                                            tint = BrightCyan,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Metrics
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberBlack)
                                .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
                                .padding(vertical = 10.dp, horizontal = 6.dp),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            MetricItem(
                                icon = Icons.Default.FavoriteBorder,
                                value = info.likeCount?.toString() ?: "0",
                                tint = BrightMagenta
                            )
                            MetricItem(
                                icon = Icons.Default.ChatBubbleOutline,
                                value = info.commentCount?.toString() ?: "0",
                                tint = BrightCyan
                            )
                            MetricItem(
                                icon = Icons.Default.Repeat,
                                value = info.shareCount?.toString() ?: "0",
                                tint = BrightGreen
                            )
                        }

                        Text(
                            text = "PILIH FORMAT UNDUHAN:",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        )

                        // Download Action Buttons
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (!info.videoUrl.isNullOrBlank()) {
                                DownloadFormatRow(
                                    title = "MP4 Video (No Watermark)",
                                    subtitle = "Kualitas standar jernih tanpa watermark",
                                    icon = Icons.Default.Movie,
                                    color = BrightCyan,
                                    enabled = !isDownloading,
                                    onDownload = {
                                        downloadMedia(
                                            info.videoUrl,
                                            "tiktok_${info.itemId ?: System.currentTimeMillis()}.mp4",
                                            "video/mp4"
                                        )
                                    }
                                )
                            }

                            if (!info.videoHdDownloadUrl.isNullOrBlank() && !info.videoHdUrl.isNullOrBlank()) {
                                DownloadFormatRow(
                                    title = "MP4 HD Video (High Quality)",
                                    subtitle = if (info.hasNativeHd) {
                                        "Resolver HD khusus • tanpa watermark"
                                    } else {
                                        "Resolver HD • kualitas terbaik yang tersedia"
                                    },
                                    icon = Icons.Default.Hd,
                                    color = BrightMagenta,
                                    enabled = !isDownloading,
                                    onDownload = {
                                        downloadMedia(
                                            info.videoHdDownloadUrl,
                                            "tiktok_hd_${info.itemId ?: System.currentTimeMillis()}.mp4",
                                            "video/mp4",
                                            referer = "https://www.cutefish.my.id/"
                                        )
                                    }
                                )
                            }

                            if (!info.mp3Url.isNullOrBlank()) {
                                DownloadFormatRow(
                                    title = "MP3 Audio Saja",
                                    subtitle = "Ekstrak musik / suara latar video",
                                    icon = Icons.Default.Audiotrack,
                                    color = BrightGreen,
                                    enabled = !isDownloading,
                                    onDownload = {
                                        downloadMedia(
                                            info.mp3Url,
                                            "tiktok_audio_${info.itemId ?: System.currentTimeMillis()}.mp3",
                                            "audio/mpeg"
                                        )
                                    }
                                )
                            }
                        }

                        DownloadProgressAndActions(
                            repository = repository,
                            isDownloading = isDownloading,
                            downloadStatusText = downloadStatusText,
                            lastDownloadedUri = lastDownloadedUri,
                            lastDownloadedMime = lastDownloadedMime
                        )
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------
// 2. YOUTUBE TAB
// ----------------------------------------------------------------
@Composable
private fun YoutubeTab(
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit
) {
    val scope = rememberCoroutineScope()

    var youtubeUrl by remember { mutableStateOf("") }
    var isProcessing by remember { mutableStateOf(false) }
    var mediaInfo by remember { mutableStateOf<YoutubeMediaInfo?>(null) }

    var isDownloading by remember { mutableStateOf(false) }
    var downloadStatusText by remember { mutableStateOf("") }
    var lastDownloadedUri by remember { mutableStateOf<Uri?>(null) }
    var lastDownloadedMime by remember { mutableStateOf("video/mp4") }

    fun downloadMedia(format: YoutubeFormatOption, fileName: String, mime: String) {
        isDownloading = true
        downloadStatusText = "Mengambil link download terbaru..."
        lastDownloadedMime = mime
        val sourceUrl = mediaInfo?.sourceUrl
        scope.launch {
            val res = if (!sourceUrl.isNullOrBlank()) {
                repository.downloadYoutubeFormatToStorage(
                    sourceUrl = sourceUrl,
                    quality = format.quality,
                    isAudioOnly = format.isAudioOnly,
                    fileName = fileName,
                    mimeType = mime
                )
            } else {
                repository.downloadFileToStorage(
                    format.url, fileName, mime, referer = "https://api.alfisy.my.id/"
                )
            }
            when (res) {
                is ResultState.Success -> {
                    lastDownloadedUri = res.data
                    downloadStatusText = "File berhasil disimpan ke folder Download."
                }
                is ResultState.Error -> {
                    downloadStatusText = "Gagal mengunduh: ${res.message}"
                    onShowSnackbar("Gagal: ${res.message}")
                }
            }
            isDownloading = false
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = youtubeUrl,
                    onValueChange = { youtubeUrl = it },
                    label = { Text("URL Video YouTube") },
                    placeholder = { Text("https://youtu.be/... atau https://www.youtube.com/watch?v=...") },
                    leadingIcon = { Icon(Icons.Default.Link, contentDescription = null, tint = MutedGrey) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_youtube_url"),
                    colors = downloaderFieldColors(BrightRed),
                    shape = RoundedCornerShape(8.dp)
                )

                Button(
                    onClick = {
                        val url = youtubeUrl.trim()
                        if (url.isBlank()) {
                            onShowSnackbar("Masukkan URL YouTube terlebih dahulu.")
                            return@Button
                        }
                        scope.launch {
                            isProcessing = true
                            mediaInfo = null
                            lastDownloadedUri = null
                            when (val res = repository.getYoutubeInfo(url)) {
                                is ResultState.Success -> {
                                    mediaInfo = res.data
                                }
                                is ResultState.Error -> {
                                    onShowSnackbar("Gagal: ${res.message}")
                                }
                            }
                            isProcessing = false
                        }
                    },
                    enabled = youtubeUrl.isNotBlank() && !isProcessing,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("btn_process_youtube_link"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightRed, contentColor = Color.White)
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Memproses Link...")
                    } else {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Proses Link", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = mediaInfo != null,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            val info = mediaInfo
            if (info != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BrightRed.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {

                        // --- VIDEO PREVIEW ---
                        // Preview memutar kualitas HD tertinggi (info.previewVideoUrl), bukan
                        // kualitas terendah, sesuai permintaan: preview memakai link video HD.
                        VideoPreviewPlayer(
                            coverUrl = info.thumbnailUrl,
                            playableUrl = null,
                            durationText = info.duration,
                            accentColor = BrightRed,
                            badgeText = "HD PREVIEW",
                            preferredAspectRatio = 16f / 9f,
                            requestReferer = "https://frame.y2meta-uk.com/",
                            requestOrigin = "https://frame.y2meta-uk.com",
                            refreshPlayableUrl = {
                                val source = info.sourceUrl
                                if (source.isNullOrBlank()) null
                                else when (val resolved = repository.resolveYoutubeDownloadUrl(
                                    sourceUrl = source,
                                    quality = 720,
                                    isAudioOnly = false
                                )) {
                                    is ResultState.Success -> resolved.data
                                    is ResultState.Error -> null
                                }
                            }
                        )

                        Text(
                            text = info.title ?: "Video YouTube",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            ),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        if (!info.duration.isNullOrBlank()) {
                            Text(
                                text = "Durasi: ${info.duration}",
                                style = MaterialTheme.typography.labelSmall.copy(color = MutedGrey)
                            )
                        }

                        Text(
                            text = "PILIH FORMAT UNDUHAN:",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            info.formats.forEach { format ->
                                val isAudio = format.isAudioOnly
                                DownloadFormatRow(
                                    title = format.label,
                                    subtitle = if (isAudio) "Ekstrak audio saja" else "Kualitas ${format.quality}p",
                                    icon = if (isAudio) Icons.Default.Audiotrack else Icons.Default.Movie,
                                    color = if (isAudio) BrightGreen else if (format.quality >= 720) BrightMagenta else BrightCyan,
                                    enabled = !isDownloading,
                                    onDownload = {
                                        val safeTitle = (info.title ?: "youtube_video")
                                            .replace(Regex("[^a-zA-Z0-9]+"), "_")
                                            .take(40)
                                        val extension = if (isAudio) "mp3" else "mp4"
                                        val mime = if (isAudio) "audio/mpeg" else "video/mp4"
                                        downloadMedia(
                                            format,
                                            "${safeTitle}_${format.quality}.$extension",
                                            mime
                                        )
                                    }
                                )
                            }
                        }

                        DownloadProgressAndActions(
                            repository = repository,
                            isDownloading = isDownloading,
                            downloadStatusText = downloadStatusText,
                            lastDownloadedUri = lastDownloadedUri,
                            lastDownloadedMime = lastDownloadedMime
                        )
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------
// 3. GOOGLE DRIVE TAB
// ----------------------------------------------------------------
@Composable
private fun DriveTab(
    repository: LeviathanRepository,
    onShowSnackbar: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var driveUrl by remember { mutableStateOf("") }
    var isProcessing by remember { mutableStateOf(false) }
    var mediaInfo by remember { mutableStateOf<DriveMediaInfo?>(null) }

    var isDownloading by remember { mutableStateOf(false) }
    var downloadStatusText by remember { mutableStateOf("") }
    var lastDownloadedUri by remember { mutableStateOf<Uri?>(null) }
    var lastDownloadedMime by remember { mutableStateOf("application/octet-stream") }

    fun downloadMedia(url: String, fileName: String, mime: String) {
        isDownloading = true
        downloadStatusText = "Mengunduh $fileName..."
        lastDownloadedMime = mime
        scope.launch {
            when (val res = repository.downloadFileToStorage(url, fileName, mime)) {
                is ResultState.Success -> {
                    lastDownloadedUri = res.data
                    downloadStatusText = "File berhasil disimpan ke folder Download."
                }
                is ResultState.Error -> {
                    downloadStatusText = "Gagal mengunduh: ${res.message}"
                    onShowSnackbar("Gagal: ${res.message}")
                }
            }
            isDownloading = false
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = driveUrl,
                    onValueChange = { driveUrl = it },
                    label = { Text("URL File Google Drive") },
                    placeholder = { Text("https://drive.google.com/file/d/.../view") },
                    leadingIcon = { Icon(Icons.Default.Link, contentDescription = null, tint = MutedGrey) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_drive_url"),
                    colors = downloaderFieldColors(BrightGreen),
                    shape = RoundedCornerShape(8.dp)
                )

                Button(
                    onClick = {
                        val url = driveUrl.trim()
                        if (url.isBlank()) {
                            onShowSnackbar("Masukkan URL Google Drive terlebih dahulu.")
                            return@Button
                        }
                        scope.launch {
                            isProcessing = true
                            mediaInfo = null
                            lastDownloadedUri = null
                            when (val res = repository.getDriveInfo(url)) {
                                is ResultState.Success -> {
                                    mediaInfo = res.data
                                }
                                is ResultState.Error -> {
                                    onShowSnackbar("Gagal: ${res.message}")
                                }
                            }
                            isProcessing = false
                        }
                    },
                    enabled = driveUrl.isNotBlank() && !isProcessing,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("btn_process_drive_link"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightGreen, contentColor = CyberBlack)
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = CyberBlack, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Memproses Link...")
                    } else {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Proses Link", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = mediaInfo != null,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            val info = mediaInfo
            if (info != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BrightGreen.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(BrightGreen.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderZip,
                                    contentDescription = null,
                                    tint = BrightGreen,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = info.name ?: "File Google Drive",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    ),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "File publik siap diunduh",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MutedGrey)
                                )
                            }
                        }

                        if (!info.downloadUrl.isNullOrBlank()) {
                            DownloadFormatRow(
                                title = "Unduh File Asli",
                                subtitle = "Mengunduh langsung dari Google Drive",
                                icon = Icons.Default.FolderZip,
                                color = BrightGreen,
                                enabled = !isDownloading,
                                onDownload = {
                                    val safeName = (info.name ?: "drive_file_${System.currentTimeMillis()}")
                                        .replace(Regex("[\\\\/:*?\"<>|]+"), "_")
                                    downloadMedia(info.downloadUrl, safeName, "application/octet-stream")
                                }
                            )
                        }

                        DownloadProgressAndActions(
                            repository = repository,
                            isDownloading = isDownloading,
                            downloadStatusText = downloadStatusText,
                            lastDownloadedUri = lastDownloadedUri,
                            lastDownloadedMime = lastDownloadedMime
                        )
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------
// SHARED: PROGRESS BAR + OPEN/SHARE BUTTONS (dipakai ketiga tab)
// ----------------------------------------------------------------
@Composable
private fun DownloadProgressAndActions(
    repository: LeviathanRepository,
    isDownloading: Boolean,
    downloadStatusText: String,
    lastDownloadedUri: Uri?,
    lastDownloadedMime: String
) {
    AnimatedVisibility(visible = isDownloading) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = downloadStatusText,
                style = MaterialTheme.typography.bodySmall.copy(color = BrightCyan)
            )
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = BrightCyan,
                trackColor = CyberSurfaceVariant
            )
        }
    }

    AnimatedVisibility(visible = lastDownloadedUri != null && !isDownloading) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    lastDownloadedUri?.let { repository.workspaceManager.openFileUri(it, lastDownloadedMime) }
                },
                modifier = Modifier.weight(1f).testTag("btn_open_downloaded_media"),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrightGreen, contentColor = CyberBlack)
            ) {
                Text("Buka File", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            }

            OutlinedButton(
                onClick = {
                    lastDownloadedUri?.let { repository.workspaceManager.shareFileUri(it, lastDownloadedMime, "Bagikan File") }
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = BrightCyan)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Bagikan")
            }
        }
    }
}

/**
 * Preview video: menampilkan cover/thumbnail secara default (hemat kuota),
 * lalu memuat dan memutar video asli inline saat tombol play ditekan.
 * Rasio 9:16 mengikuti aspek video vertikal pada umumnya (TikTok/Shorts).
 * Dipakai bersama oleh tab TikTok (playableUrl = link HD resolver) dan
 * tab YouTube (playableUrl = link kualitas HD tertinggi).
 */
@Composable
private fun VideoPreviewPlayer(
    coverUrl: String?,
    playableUrl: String?,
    fallbackPlayableUrl: String? = null,
    durationText: String?,
    accentColor: Color,
    badgeText: String = "NO WATERMARK",
    preferredAspectRatio: Float = 16f / 9f,
    refreshPlayableUrl: (suspend () -> String?)? = null,
    requestReferer: String? = "https://api.alfisy.my.id/",
    requestOrigin: String? = "https://api.alfisy.my.id"
) {
    var activePlayableUrl by remember(playableUrl) { mutableStateOf(playableUrl) }
    var isPlaying by remember(playableUrl) { mutableStateOf(false) }
    var isRefreshingUrl by remember(playableUrl) { mutableStateOf(false) }
    val previewScope = rememberCoroutineScope()
    var isBuffering by remember(playableUrl) { mutableStateOf(false) }
    var playbackError by remember(playableUrl) { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(preferredAspectRatio)
            .clip(RoundedCornerShape(10.dp))
            .background(
                Brush.verticalGradient(
                    listOf(CyberSurfaceVariant, CyberBlack)
                )
            )
            .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp))
    ) {
        if (isPlaying && !activePlayableUrl.isNullOrBlank()) {
            // --- MODE PLAYER: video asli diputar inline ---
            InlineExoPlayer(
                url = activePlayableUrl!!,
                fallbackUrl = fallbackPlayableUrl,
                requestReferer = requestReferer,
                requestOrigin = requestOrigin,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(10.dp)),
                onBufferingChange = { isBuffering = it },
                onError = { msg ->
                    playbackError = msg
                    isPlaying = false
                },
                refreshUrl = refreshPlayableUrl
            )

            if (isBuffering) {
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center).size(32.dp),
                    color = accentColor,
                    strokeWidth = 2.dp
                )
            }
        } else {
            // --- MODE THUMBNAIL: cover statis + tombol play ---
            if (!coverUrl.isNullOrBlank()) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(coverUrl)
                        .crossfade(true)
                        .build(),
                    contentDescription = "Preview video",
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(10.dp)),
                    contentScale = ContentScale.Crop
                )

                // Gradient overlay agar badge/play button tetap kontras
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f)),
                                startY = 300f
                            )
                        )
                )
            } else {
                // Fallback saat cover tidak tersedia
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Movie,
                        contentDescription = null,
                        tint = MutedGrey,
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Preview tidak tersedia",
                        style = MaterialTheme.typography.labelSmall.copy(color = MutedGrey)
                    )
                }
            }

            // Tombol play di tengah — menekan ini memuat & memutar video asli
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.45f))
                    .border(1.dp, Color.White.copy(alpha = 0.6f), CircleShape)
                    .clickable(enabled = !isRefreshingUrl && (!playableUrl.isNullOrBlank() || refreshPlayableUrl != null)) {
                        playbackError = null
                        if (refreshPlayableUrl != null) {
                            isRefreshingUrl = true
                            previewScope.launch {
                                val freshUrl = refreshPlayableUrl.invoke()
                                isRefreshingUrl = false
                                if (!freshUrl.isNullOrBlank()) {
                                    activePlayableUrl = freshUrl
                                    isPlaying = true
                                } else {
                                    playbackError = "Link preview sudah tidak valid dan gagal diperbarui."
                                }
                            }
                        } else {
                            activePlayableUrl = playableUrl
                            isPlaying = true
                        }
                    }
                    .testTag("btn_play_video_preview"),
                contentAlignment = Alignment.Center
            ) {
                if (isRefreshingUrl) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(26.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                } else Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Putar preview",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }

            if (playbackError != null) {
                Text(
                    text = "Gagal memutar preview: $playbackError",
                    style = MaterialTheme.typography.labelSmall.copy(color = accentColor),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 8.dp)
                )
            }

            // Badge durasi di pojok kanan bawah
            if (!durationText.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.Black.copy(alpha = 0.65f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = durationText,
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.SemiBold)
                    )
                }
            }

            // Badge label di pojok kiri atas — penegasan value prop fitur
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(accentColor.copy(alpha = 0.85f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = badgeText,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        letterSpacing = 0.5.sp
                    )
                )
            }
        }
    }
}

/**
 * Wrapper ExoPlayer (Media3) sebagai AndroidView untuk memutar video dari URL langsung.
 * Player dibuat dan dirilis mengikuti lifecycle composable ini (DisposableEffect),
 * agar tidak bocor resource saat preview ditutup/dibongkar dari layar.
 */
@Composable
private fun InlineExoPlayer(
    url: String,
    fallbackUrl: String? = null,
    requestReferer: String? = null,
    requestOrigin: String? = null,
    modifier: Modifier = Modifier,
    onBufferingChange: (Boolean) -> Unit,
    onError: (String) -> Unit,
    refreshUrl: (suspend () -> String?)? = null
) {
    val context = LocalContext.current

    val exoPlayer = remember(url, fallbackUrl) {
        val requestHeaders = buildMap {
            put("Accept", "*/*")
            if (!requestReferer.isNullOrBlank()) put("Referer", requestReferer)
            // Final converter URL is a browser navigation; do not synthesize Origin.
        }
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 16; K) AppleWebKit/537.36 Chrome/140.0.7339.101 Mobile Safari/537.36")
            .setDefaultRequestProperties(requestHeaders)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(androidx.media3.exoplayer.source.DefaultMediaSourceFactory(httpFactory))
            .build().apply {
                setMediaItem(MediaItem.fromUri(Uri.parse(url)))
                playWhenReady = true
                prepare()
            }
    }

    var fallbackTried by remember(url, fallbackUrl) { mutableStateOf(false) }
    var refreshTried by remember(url, refreshUrl) { mutableStateOf(false) }
    val playerScope = rememberCoroutineScope()

    DisposableEffect(exoPlayer, fallbackUrl, refreshUrl) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                onBufferingChange(playbackState == Player.STATE_BUFFERING)
            }

            override fun onPlayerError(error: PlaybackException) {
                // First try the explicitly provided fallback stream (used by TikTok).
                if (!fallbackTried && !fallbackUrl.isNullOrBlank() && fallbackUrl != url) {
                    fallbackTried = true
                    exoPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(fallbackUrl)))
                    exoPlayer.prepare()
                    exoPlayer.playWhenReady = true
                    return
                }

                // YouTube converter links can expire while the player is opening them.
                // Generate one fresh URL using the same converter/key flow, then retry once.
                if (!refreshTried && refreshUrl != null) {
                    refreshTried = true
                    playerScope.launch {
                        val freshUrl = refreshUrl.invoke()
                        if (!freshUrl.isNullOrBlank() && freshUrl != url) {
                            exoPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(freshUrl)))
                            exoPlayer.prepare()
                            exoPlayer.playWhenReady = true
                        } else {
                            onError(error.message ?: "Terjadi kesalahan saat memutar video.")
                        }
                    }
                    return
                }

                onError(error.message ?: "Terjadi kesalahan saat memutar video.")
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    AndroidView(
        modifier = modifier,
        factory = {
            PlayerView(context).apply {
                player = exoPlayer
                useController = true
                setShowNextButton(false)
                setShowPreviousButton(false)
                // FIT keeps the entire frame visible. The old ZOOM mode cropped video content.
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                setKeepContentOnPlayerReset(true)
                setShutterBackgroundColor(android.graphics.Color.BLACK)
            }
        }
    )
}

@Composable
private fun MetricItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: String,
    tint: Color
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFE5E7EB), fontFamily = FontFamily.Default)
        )
    }
}

@Composable
private fun DownloadFormatRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    enabled: Boolean,
    onDownload: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CyberBlack)
            .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Color.White),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall.copy(color = MutedGrey, fontSize = 11.sp),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onDownload,
                enabled = enabled,
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = CyberBlack),
                modifier = Modifier.testTag("btn_dl_${title.take(3).lowercase()}")
            ) {
                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Unduh", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
            }
        }
    }
}

@Composable
private fun downloaderFieldColors(accent: Color) = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = accent,
    unfocusedBorderColor = CyberCardBorder,
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedContainerColor = CyberBlack,
    unfocusedContainerColor = CyberBlack,
    cursorColor = accent
)
