package com.baklava.projectlv.data.streaming

/**
 * DTO untuk Server 2 (backend proxy Vercel kamu, lihat repo `anime-api-vercel`
 * / `server.js`). Nama field di sini sengaja mengikuti persis nama field yang
 * dikembalikan oleh `canonicalAnime()` / `canonicalEpisode()` /
 * `normalizeStreamPayload()` di server.js — bukan nama field AnimeKita.
 *
 * Semua field bertipe nullable + default supaya Moshi (reflection adapter)
 * tetap bisa parse walau upstream Server 2 berubah / ada field yang hilang.
 */

data class Server2AnimeItem(
    val category_id: String? = null,
    val anime_id: String? = null,
    val title: String? = null,
    val judul: String? = null,
    val thumbnail: String? = null,
    val poster: String? = null,
    val genre: List<String> = emptyList(),
    val synopsis: String? = null,
    val sinopsis: String? = null,
    val rating: String? = null,
    val score: String? = null,
    val status: String? = null,
    val latest_episode: String? = null,
    val lastch: String? = null
)

data class Server2ListResponse(
    val status: String? = null,
    val items: List<Server2AnimeItem> = emptyList(),
    val count: Int? = null
)

data class Server2Episode(
    val id: String? = null,
    val video_id: String? = null,
    val episode_id: String? = null,
    val post_id: String? = null,
    val episode: String? = null,
    val episode_number: String? = null,
    val title: String? = null,
    val url: String? = null,
    val date: String? = null
)

data class Server2EpisodeListResponse(
    val status: String? = null,
    val items: List<Server2Episode> = emptyList(),
    val count: Int? = null
)

data class Server2AnimeDetailResponse(
    val status: String? = null,
    val data: Server2AnimeItem? = null,
    val episodes: List<Server2Episode> = emptyList()
)

data class Server2StreamCandidate(
    val link: String? = null,
    val provide: Int? = null,
    val id: Long? = null,
    val reso: String? = null,
    val size_kb: Long? = null
)

data class Server2Streams(
    val episode_id: String? = null,
    val reso: List<String> = emptyList(),
    val streams: Map<String, List<Server2StreamCandidate>> = emptyMap()
)

data class Server2PostResponse(
    val status: String? = null,
    val streams: Server2Streams? = null
)

/** Bentuk error generik yang dikirim server.js (`{ status: 'error', ... }`). */
data class Server2ErrorResponse(
    val status: String? = null,
    val error: String? = null,
    val message: String? = null
)
