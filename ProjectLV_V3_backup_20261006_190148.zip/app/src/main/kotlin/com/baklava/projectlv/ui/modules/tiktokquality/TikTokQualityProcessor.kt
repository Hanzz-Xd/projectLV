package com.baklava.projectlv.ui.modules.tiktokquality

import android.content.Context
import android.net.Uri
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.LogCallback
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.Statistics
import com.arthenica.ffmpegkit.StatisticsCallback
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max
import kotlin.math.min

/**
 * ProjectLV native implementation of the source-provided TikTok Quality Method
 * 2.4.x family.
 *
 * Method mapping from the source:
 * - FISH  -> tbt / StreamShield 2.4.2
 * - BINARY -> binary patch 2.4.0
 * - F R Y -> FRY 2.4.0
 * - FPS -> FPS timing patch 2.4.0
 * - WMV -> V1 WMV fallback 2.4.0
 *
 * All MP4 methods run the shared Cutefish metadata finalizer so the companion
 * userscript can detect the output marker.
 */
object TikTokQualityProcessor {

    enum class Version {
        FISH_STREAMSHIELD,
        BINARY,
        FRY,
        FPS,
        V1_WMV
    }

    enum class CompressMode { OFF, P720, P1080 }

    data class Options(
        val version: Version = Version.FISH_STREAMSHIELD,
        val compressMode: CompressMode = CompressMode.OFF,
        val fixAudio: Boolean = false
    )

    data class Result(
        val file: File,
        val inputName: String,
        val method: Version,
        val compressMode: CompressMode,
        val inputBytes: Long,
        val outputBytes: Long,
        val inputFps: Int? = null,
        val patchedFps: Int? = null,
        val realSamples: Int? = null,
        val fakeSamples: Int? = null
    )

    suspend fun process(
        context: Context,
        sourceUri: Uri,
        inputName: String,
        options: Options,
        onProgress: (Int) -> Unit = {},
        onLog: (String) -> Unit = {}
    ): Result = withContext(Dispatchers.IO) {
        val workDir = File(context.cacheDir, "quality_method").apply { mkdirs() }
        val input = File(workDir, "input_${System.currentTimeMillis()}.mp4")
        val output = File(workDir, "result_${System.currentTimeMillis()}.${if (options.version == Version.V1_WMV) "wmv" else "mp4"}")
        val compressed = File(workDir, "compressed_${System.currentTimeMillis()}.mp4")

        try {
            copyUriToFile(context, sourceUri, input)
            val inputBytes = input.length()
            require(inputBytes >= 1024) { "Video sumber kosong atau terlalu kecil." }
            onLog("Input: ${formatMb(inputBytes)} MB")

            val originalBytes = if (needsInMemoryInput(options)) input.readBytes() else null
            val inputFps = originalBytes?.let { runCatching { Mp4QualityPatch.parseFpsFromMp4(it) }.getOrNull() }
            val resolution = originalBytes?.let { runCatching { Mp4QualityPatch.parseResolutionFromMp4(it) }.getOrNull() }
            if (resolution != null) onLog("Resolution: ${resolution.width}x${resolution.height}")
            if (inputFps != null) onLog("FPS: $inputFps")

            var baseFile = input
            var effectiveCompress = options.compressMode
            if (resolution != null && isOver1080p(resolution) && effectiveCompress == CompressMode.OFF) {
                effectiveCompress = CompressMode.P1080
                onLog("Source > 1080-class detected; compression forced to 1080P to match source dispatcher.")
            }

            if (options.version == Version.V1_WMV && effectiveCompress == CompressMode.OFF) {
                // Source WMV defaults to the 1080-class scaling path.
                effectiveCompress = CompressMode.P1080
            }

            val workingBytes: ByteArray
            val stats: Mp4QualityPatch.PatchStats?
            when (options.version) {
                Version.FISH_STREAMSHIELD -> {
                    baseFile = maybeCompress(context, input, compressed, effectiveCompress, inputFps, resolution, onProgress, onLog)
                    val baseBytes = baseFile.readBytes()
                    val emergencyBytes = applyEmergencyIfNeeded(baseBytes, inputFps, onLog)
                    if (effectiveCompress == CompressMode.OFF) {
                        onLog("FISH: StreamShield direct/lossless path.")
                    } else {
                        onLog("FISH: ${effectiveCompress.label} compression + StreamShield.")
                    }
                    workingBytes = TikTokQualityNativeEngines.patchStreamShield(emergencyBytes, onLog).output
                    stats = null
                }

                Version.BINARY -> {
                    baseFile = maybeCompress(context, input, compressed, effectiveCompress, inputFps, resolution, onProgress, onLog)
                    val baseBytes = baseFile.readBytes()
                    val emergencyBytes = applyEmergencyIfNeeded(baseBytes, inputFps, onLog)
                    val patched = Mp4QualityPatch.patchMp4(emergencyBytes, fixAudio = options.fixAudio, onLog = onLog)
                    workingBytes = patched.output
                    stats = patched
                }

                Version.FRY -> {
                    baseFile = maybeCompress(context, input, compressed, effectiveCompress, inputFps, resolution, onProgress, onLog)
                    val baseBytes = baseFile.readBytes()
                    val emergencyBytes = applyEmergencyIfNeeded(baseBytes, inputFps, onLog)
                    workingBytes = TikTokQualityNativeEngines.patchFry(emergencyBytes, onLog).output
                    stats = null
                }

                Version.FPS -> {
                    baseFile = maybeCompress(context, input, compressed, effectiveCompress, inputFps, resolution, onProgress, onLog)
                    val baseBytes = baseFile.readBytes()
                    val patched = Mp4QualityPatch.patchMp4Fps(baseBytes, onLog)
                    workingBytes = patched.output
                    stats = patched
                }

                Version.V1_WMV -> {
                    val baseBytes = input.readBytes()
                    val emergencyBytes = applyEmergencyIfNeeded(baseBytes, inputFps, onLog)
                    File(workDir, "wmv_source_${System.currentTimeMillis()}.mp4").apply { writeBytes(emergencyBytes) }.also { baseFile = it }
                    val command = buildWmvCommand(baseFile, output, effectiveCompress, inputFps)
                    onLog("WMV command: ffmpeg ${command.joinToString(" ")}")
                    executeFfmpeg(command, onProgress, onLog, 0, 98)
                    require(output.length() >= 1024) { "WMV processing menghasilkan file kosong." }
                    val finalName = baseName(inputName) + "_hd.wmv"
                    val renamed = moveToFinal(output, finalName)
                    onProgress(100)
                    return@withContext Result(
                        file = renamed,
                        inputName = inputName,
                        method = options.version,
                        compressMode = effectiveCompress,
                        inputBytes = inputBytes,
                        outputBytes = renamed.length(),
                        inputFps = inputFps
                    )
                }
            }

            onProgress(97)
            var finalBytes = workingBytes
            if (options.version != Version.V1_WMV) {
                runCatching { finalBytes = TikTokQualityNativeEngines.ensureCutefishMetadata(finalBytes) }
                    .onFailure { onLog("[Notice] Metadata finalizer skipped: ${it.message}") }
            }
            output.writeBytes(finalBytes)
            require(output.length() >= 1024) { "Output terlalu kecil." }
            val finalName = baseName(inputName) + "_hd.mp4"
            val renamed = moveToFinal(output, finalName)
            onProgress(100)

            Result(
                file = renamed,
                inputName = inputName,
                method = options.version,
                compressMode = effectiveCompress,
                inputBytes = inputBytes,
                outputBytes = renamed.length(),
                inputFps = stats?.inputFps ?: inputFps,
                patchedFps = stats?.patchedFps,
                realSamples = stats?.realSamples,
                fakeSamples = stats?.fakeSamples
            )
        } finally {
            input.delete()
            compressed.delete()
            output.delete()
        }
    }

    private fun isOver1080p(resolution: Mp4QualityPatch.Resolution): Boolean =
        min(resolution.width, resolution.height) > 1080 || max(resolution.width, resolution.height) > 1920

    private suspend fun maybeCompress(
        context: Context,
        input: File,
        compressed: File,
        mode: CompressMode,
        fps: Int?,
        resolution: Mp4QualityPatch.Resolution?,
        onProgress: (Int) -> Unit,
        onLog: (String) -> Unit
    ): File {
        if (mode == CompressMode.OFF) return input
        val proc = Mp4QualityPatch.computeVideoProcessingOptions(
            resolution?.width ?: 1080,
            resolution?.height ?: 1920,
            fps,
            input.length() / (1024.0 * 1024.0),
            mode.targetShortSide
        )
        onLog("Compression: ${mode.label} -> ${proc.width}x${proc.height}")
        val command = listOf(
            "-y", "-i", input.absolutePath,
            "-threads", "1",
            "-map", "0:v:0",
            "-map", "0:a:0?",
            "-dn",
            "-map_metadata", "-1",
            "-map_chapters", "-1",
            "-vf", proc.vfString.replace("format=yuv420p", "format=yuv420p"),
            "-c:v", "libx264",
            "-preset", "medium",
            "-crf", "20",
            "-maxrate", "12.5M",
            "-bufsize", "18M",
            "-pix_fmt", "yuv420p",
            "-c:a", "aac",
            "-b:a", "128k",
            "-movflags", "+faststart",
            compressed.absolutePath
        )
        executeFfmpeg(command, onProgress, onLog, 0, 90)
        require(compressed.length() >= 1024) { "Compression gagal menghasilkan output." }
        return compressed
    }

    private fun applyEmergencyIfNeeded(input: ByteArray, fps: Int?, onLog: (String) -> Unit): ByteArray {
        val detected = fps ?: runCatching { Mp4QualityPatch.parseFpsFromMp4(input) }.getOrNull() ?: return input
        if (detected <= 60) return input
        onLog("Emergency FPS: ${detected} FPS -> 60 FPS presentation patch before method.")
        return runCatching { Mp4QualityPatch.patchMp4Fps(input, onLog).output }
            .onFailure { onLog("[Notice] Emergency FPS patch failed; continuing with source bytes: ${it.message}") }
            .getOrDefault(input)
    }

    private fun buildWmvCommand(input: File, output: File, mode: CompressMode, fps: Int?): List<String> {
        val maxDim = when (mode) {
            CompressMode.P720 -> 720
            CompressMode.P1080, CompressMode.OFF -> 1080
        }
        val threads = min(4, Runtime.getRuntime().availableProcessors().coerceAtLeast(1))
        return listOf(
            "-y", "-i", input.absolutePath,
            "-threads", threads.toString(),
            "-map_metadata", "-1",
            "-map_chapters", "-1",
            "-vf", "scale='if(lt(iw,ih),trunc(min(iw,$maxDim)/2)*2,-2)':'if(lt(iw,ih),-2,trunc(min(ih,$maxDim)/2)*2)'",
            "-c:v", "wmv2",
            "-qscale:v", "1",
            "-c:a", "wmav2",
            "-b:a", "320k",
            output.absolutePath
        )
    }

    private suspend fun executeFfmpeg(
        args: List<String>,
        onProgress: (Int) -> Unit,
        onLog: (String) -> Unit,
        phaseStart: Int,
        phaseEnd: Int
    ) = suspendCancellableCoroutine<Unit> { continuation ->
        val command = args.joinToString(" ") { quoteCommandArg(it) }
        val completeCallback = { session: FFmpegSession ->
            if (ReturnCode.isSuccess(session.returnCode)) {
                onProgress(phaseEnd)
                continuation.resume(Unit)
            } else {
                val message = session.failStackTrace?.takeIf { it.isNotBlank() }
                    ?: session.output?.takeLast(1600)
                    ?: "FFmpeg gagal: ${session.returnCode}"
                continuation.resumeWithException(IllegalStateException(message))
            }
        }
        val logCallback = object : LogCallback {
            override fun apply(log: com.arthenica.ffmpegkit.Log) {
                val message = log.message
                onLog(message)
            }
        }
        val statisticsCallback = object : StatisticsCallback {
            override fun apply(statistics: Statistics) {
                val time = statistics.time
                if (time > 0) {
                    val pulse = ((time / 1000L) % max(1, (phaseEnd - phaseStart - 2)).toLong()).toInt()
                    onProgress(min(phaseEnd - 2, phaseStart + pulse))
                }
            }
        }
        val session = try {
            FFmpegKit.executeAsync(command, completeCallback, logCallback, statisticsCallback)
        } catch (e: Throwable) {
            continuation.resumeWithException(e)
            return@suspendCancellableCoroutine
        }
        continuation.invokeOnCancellation {
            runCatching { FFmpegKit.cancel(session.sessionId) }
        }
    }

    private fun quoteCommandArg(arg: String): String {
        if (arg.isEmpty()) return "''"
        return if (arg.any { it.isWhitespace() || it == '\'' || it == '"' }) {
            "'${arg.replace("'", "'\\''")}'"
        } else arg
    }

    private fun copyUriToFile(context: Context, uri: Uri, target: File) {
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(target).use { output ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val n = input.read(buffer)
                    if (n <= 0) break
                    output.write(buffer, 0, n)
                }
            }
        } ?: error("Tidak dapat membaca file sumber.")
    }

    private fun moveToFinal(source: File, finalName: String): File {
        val target = File(source.parentFile, finalName).apply { delete() }
        if (!source.renameTo(target)) {
            source.copyTo(target, overwrite = true)
            source.delete()
        }
        return target
    }

    private fun baseName(name: String): String = name.substringBeforeLast('.', name)

    private fun needsInMemoryInput(options: Options): Boolean = options.version != Version.V1_WMV

    private val CompressMode.targetShortSide: Int?
        get() = when (this) {
            CompressMode.OFF -> null
            CompressMode.P720 -> 720
            CompressMode.P1080 -> 1080
        }

    private val CompressMode.label: String
        get() = when (this) {
            CompressMode.OFF -> "OFF"
            CompressMode.P720 -> "720P"
            CompressMode.P1080 -> "1080P"
        }

    private fun formatMb(bytes: Long): String = "%.2f".format(bytes / (1024.0 * 1024.0))
}
