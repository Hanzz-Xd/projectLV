package com.baklava.projectlv.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFE5E7EB),
    onPrimary = Color(0xFF0C0D10),
    primaryContainer = Color(0xFF22252C),
    onPrimaryContainer = Color(0xFFF3F4F6),
    secondary = Color(0xFFCBD5E1),
    onSecondary = Color(0xFF0C0D10),
    secondaryContainer = Color(0xFF1E2128),
    onSecondaryContainer = Color(0xFFE5E7EB),
    tertiary = Color(0xFF9AA0A6),
    onTertiary = Color(0xFF0C0D10),
    error = BrightRed,
    onError = Color(0xFF0C0D10),
    errorContainer = BrightRedContainer,
    onErrorContainer = Color(0xFFFCA5A5),
    background = CyberBlack,
    onBackground = Color(0xFFF3F4F6),
    surface = CyberDarkNavy,
    onSurface = Color(0xFFF3F4F6),
    surfaceVariant = CyberSurfaceVariant,
    onSurfaceVariant = MutedGrey,
    outline = CyberCardBorder
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF1F2328),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8EAEE),
    onPrimaryContainer = Color(0xFF181B1F),
    secondary = Color(0xFF57606A),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF0F2F5),
    onSecondaryContainer = Color(0xFF24292F),
    tertiary = Color(0xFF6E7781),
    onTertiary = Color.White,
    error = Color(0xFFDC2626),
    onError = Color.White,
    background = LightBg,
    onBackground = Color(0xFF1F2328),
    surface = LightSurface,
    onSurface = Color(0xFF1F2328),
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = Color(0xFF57606A),
    outline = LightBorder
)

@Composable
fun LeviathanTheme(
    darkTheme: Boolean = true, // Dark-first default
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = Color.Transparent.toArgb()
            window.navigationBarColor = Color.Transparent.toArgb()
            val windowInsetsController = WindowCompat.getInsetsController(window, view)
            windowInsetsController.isAppearanceLightStatusBars = !darkTheme
            windowInsetsController.isAppearanceLightNavigationBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Keep backwards-compat alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    LeviathanTheme(darkTheme = darkTheme, content = content)
}

