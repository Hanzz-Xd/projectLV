package com.baklava.projectlv.data.models

import com.baklava.projectlv.data.repository.StromAiModel
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class PersistedChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val isUser: Boolean,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class ChatSessionHistory(
    val id: String = UUID.randomUUID().toString(),
    val model: StromAiModel,
    val title: String,
    val sessionId: String? = null,
    val systemPrompt: String = "",
    val messages: List<PersistedChatMessage> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

fun ChatSessionHistory.toJson(): JSONObject = JSONObject().apply {
    put("id", id)
    put("model", model.name)
    put("title", title)
    put("sessionId", sessionId ?: "")
    put("systemPrompt", systemPrompt)
    put("createdAt", createdAt)
    put("updatedAt", updatedAt)
    put("messages", JSONArray().apply {
        messages.forEach { message ->
            put(JSONObject().apply {
                put("id", message.id)
                put("isUser", message.isUser)
                put("text", message.text)
                put("timestamp", message.timestamp)
            })
        }
    })
}

fun JSONObject.toChatSessionHistory(): ChatSessionHistory {
    val messageArray = optJSONArray("messages") ?: JSONArray()
    val messages = buildList {
        for (i in 0 until messageArray.length()) {
            val message = messageArray.optJSONObject(i) ?: continue
            add(
                PersistedChatMessage(
                    id = message.optString("id", UUID.randomUUID().toString()),
                    isUser = message.optBoolean("isUser", false),
                    text = message.optString("text", ""),
                    timestamp = message.optLong("timestamp", System.currentTimeMillis())
                )
            )
        }
    }

    return ChatSessionHistory(
        id = optString("id", UUID.randomUUID().toString()),
        model = runCatching { StromAiModel.valueOf(optString("model")) }
            .getOrDefault(StromAiModel.STROM),
        title = optString("title", "Chat baru"),
        sessionId = optString("sessionId", "").ifBlank { null },
        systemPrompt = optString("systemPrompt", ""),
        messages = messages,
        createdAt = optLong("createdAt", System.currentTimeMillis()),
        updatedAt = optLong("updatedAt", System.currentTimeMillis())
    )
}
