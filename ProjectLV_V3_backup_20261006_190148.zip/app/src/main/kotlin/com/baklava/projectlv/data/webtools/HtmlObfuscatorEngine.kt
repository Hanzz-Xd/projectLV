package com.baklava.projectlv.data.webtools

import java.io.BufferedWriter
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.time.Instant
import java.util.zip.Deflater
import java.util.zip.Inflater

/**
 * Android-native port of the supplied w.py HTML/CSS/JavaScript obfuscator.
 *
 * Pipeline kept compatible with w.py:
 * UTF-8 -> zlib(level 9) -> XOR(SHA-512(seed*777))
 * -> nibble swap -> hex -> special Unicode characters.
 *
 * Important performance design:
 * - Encoding is intended to run off the UI thread.
 * - The protected HTML is streamed directly to a file.
 * - The huge payload is never retained as a second giant String.
 * - Verification is performed from the compressed bytes without building a
 *   second full recovered HTML String.
 */
object HtmlObfuscatorEngine {
    const val SCRIPT_VERSION = "2.0.0"
    const val MAX_PAD_REPEAT = 5000
    const val MAX_PAD_LINES = 100

    private const val IO_BUFFER_SIZE = 64 * 1024

    private val HEX_TO_SPECIAL = linkedMapOf(
        "0" to "E͐",
        "1" to "͙",
        "2" to "͏",
        "3" to "͂",
        "4" to "͆",
        "5" to "͕",
        "6" to "͓",
        "7" to "̓",
        "8" to "́",
        "9" to "͔",
        "a" to "ͅ",
        "b" to "̝",
        "c" to "̈",
        "d" to "͌",
        "e" to "͍",
        "f" to "̈́"
    )

    private val SPECIAL_TO_HEX = HEX_TO_SPECIAL.entries.associate { (key, value) -> value to key }
    private val HEX_CHARS = "0123456789abcdef"

    data class Config(
        val keySeed: String,
        val paddingRepeat: Int = 2500,
        val paddingLines: Int = 20
    )

    data class Result(
        val outputFile: File,
        val sourceSha256: String,
        val payloadChars: Int,
        val outputBytes: Int,
        val version: String = SCRIPT_VERSION
    )

    fun validateConfig(config: Config) {
        require(config.keySeed.isNotEmpty()) {
            "Key seed harus berupa string dan tidak boleh kosong."
        }
        require(config.paddingRepeat in 0..MAX_PAD_REPEAT) {
            "Padding repeat harus 0-$MAX_PAD_REPEAT."
        }
        require(config.paddingLines in 0..MAX_PAD_LINES) {
            "Padding lines harus 0-$MAX_PAD_LINES."
        }
    }

    fun buildFinalHtml(
        htmlSource: String,
        cssSource: String = "",
        jsSource: String = ""
    ): String {
        require(htmlSource.isNotBlank()) { "HTML source tidak boleh kosong." }

        var result = htmlSource
        if (cssSource.isNotBlank()) {
            val cssBlock = "\n<!-- Protected CSS -->\n<style>\n$cssSource\n</style>\n<!-- /Protected CSS -->\n"
            result = injectBeforeClosingTag(result, "head", cssBlock)
        }

        if (jsSource.isNotBlank()) {
            val jsBlock = "\n<!-- Protected JavaScript -->\n<script>\n$jsSource\n</script>\n<!-- /Protected JavaScript -->\n"
            result = injectBeforeClosingTag(result, "body", jsBlock)
        }

        return result
    }

    /**
     * Main production path. Writes directly to [outputFile] to avoid retaining
     * a giant encrypted HTML String in Compose state.
     */
    fun obfuscateToFile(
        htmlSource: String,
        cssSource: String = "",
        jsSource: String = "",
        config: Config,
        outputFile: File
    ): Result {
        validateConfig(config)

        val finalHtml = buildFinalHtml(htmlSource, cssSource, jsSource)
        val sourceBytes = finalHtml.toByteArray(StandardCharsets.UTF_8)
        val sourceSha256 = sha256(sourceBytes)
        val generatedAt = Instant.now().toString()
        val compressed = zlibCompress(sourceBytes)
        val key = buildMasterKey(config.keySeed)

        outputFile.parentFile?.mkdirs()
        val metadataComment = buildMetadataComment(sourceSha256, generatedAt)

        try {
            // Transform in-place: this avoids allocating a second encrypted ByteArray.
            transformInPlace(compressed, key)

            var payloadChars = 0
            BufferedWriter(
                OutputStreamWriter(FileOutputStream(outputFile), StandardCharsets.UTF_8),
                IO_BUFFER_SIZE
            ).use { writer ->
                writer.write("<!doctype html>\n<html><head><meta charset=\"utf-8\"></head><body>\n")
                writer.write(metadataComment)
                writer.write("\n")
                writePadding(writer, config.paddingRepeat, config.paddingLines)

                writer.write("<!-- ===== JAVASIAENC24 ENCRYPTED LOADER ===== -->\n")
                payloadChars = writeLoaderWithPayload(writer, config.keySeed, compressed)
                writer.write("\n<!-- ===== /JAVASIAENC24 ENCRYPTED LOADER ===== -->\n")
                writePadding(writer, config.paddingRepeat, config.paddingLines)
                writer.write("\n</body></html>\n")
            }

            // Reverse the transformation in-place and verify the actual compressed
            // payload by decompressing into a digest buffer, without creating the
            // recovered HTML String.
            reverseTransformInPlace(compressed, key)
            val recoveredSha256 = sha256ZlibDecompressed(compressed)
            check(recoveredSha256 == sourceSha256) {
                "Round-trip verification gagal."
            }

            return Result(
                outputFile = outputFile,
                sourceSha256 = sourceSha256,
                payloadChars = payloadChars,
                outputBytes = outputFile.length().coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            )
        } catch (e: Exception) {
            outputFile.delete()
            throw e
        }
    }

    /**
     * Compatibility helper for callers that explicitly need the whole output
     * as a String. The Web Tools UI intentionally does not use this path.
     */
    fun obfuscate(
        htmlSource: String,
        cssSource: String = "",
        jsSource: String = "",
        config: Config
    ): Result {
        val temp = File.createTempFile("projectlv-obf-", ".html")
        return try {
            obfuscateToFile(htmlSource, cssSource, jsSource, config, temp)
        } catch (e: Exception) {
            temp.delete()
            throw e
        }
    }

    private fun injectBeforeClosingTag(html: String, tagName: String, block: String): String {
        val marker = "</$tagName>"
        val index = html.lowercase().lastIndexOf(marker.lowercase())
        return if (index >= 0) {
            html.substring(0, index) + block + "\n" + html.substring(index)
        } else {
            html.trimEnd() + "\n" + block + "\n"
        }
    }

    private fun buildMetadataComment(sourceSha256: String, generatedAt: String): String {
        return """
            <!-- JAVASIAENC24 BUILD METADATA -->
            <!-- Version: $SCRIPT_VERSION -->
            <!-- Generated: $generatedAt -->
            <!-- Source-SHA256: $sourceSha256 -->
            <!-- NOTE: Metadata is diagnostic only; it provides no protection. -->
            <!-- /JAVASIAENC24 BUILD METADATA -->
        """.trimIndent()
    }

    private fun writePadding(writer: BufferedWriter, paddingRepeat: Int, paddingLines: Int) {
        if (paddingRepeat <= 0 || paddingLines <= 0) return
        val specialText = "JavasiaEnc24".repeat(paddingRepeat)
        repeat(paddingLines) {
            writer.write("<!-- ")
            writer.write(specialText)
            writer.write(" -->\n")
        }
    }

    private fun loaderTemplate(keySeed: String): String {
        val keyLiteral = jsonQuote(keySeed)
        val reverseMapLines = SPECIAL_TO_HEX.entries.joinToString(",\n") { (special, hex) ->
            "                [${jsonQuote(special)}, ${jsonQuote(hex)}]"
        }
        return """
            <script>
            (() => {
                "use strict";

                const _key_seed_ = $keyLiteral;
                const _enc_special_ = "__PROJECTLV_PAYLOAD__";

                const _special_to_hex_dict_ = new Map([
$reverseMapLines
                ]);

                function _special_to_hex_(text) {
                    const chars = [];
                    let i = 0;

                    while (i < text.length) {
                        let found = false;

                        for (const [_special_char_, _hex_char_] of _special_to_hex_dict_) {
                            if (text.startsWith(_special_char_, i)) {
                                chars.push(_hex_char_);
                                i += _special_char_.length;
                                found = true;
                                break;
                            }
                        }

                        if (!found) i += 1;
                    }

                    return chars.join("");
                }

                function _hex_to_bytes_(hex) {
                    if ((hex.length & 1) !== 0) {
                        throw new Error("Encrypted payload memiliki panjang hex ganjil.");
                    }

                    const bytes = new Uint8Array(hex.length / 2);
                    for (let i = 0; i < hex.length; i += 2) {
                        bytes[i / 2] = parseInt(hex.slice(i, i + 2), 16);
                    }
                    return bytes;
                }

                async function _sha512_key_(seed) {
                    const seedBytes = new TextEncoder().encode(seed.repeat(777));
                    const digest = await crypto.subtle.digest("SHA-512", seedBytes);
                    return new Uint8Array(digest);
                }

                function _reverse_nibble_swap_(bytes) {
                    const result = new Uint8Array(bytes.length);
                    for (let i = 0; i < bytes.length; i++) {
                        const byte = bytes[i];
                        result[i] = ((byte >>> 4) | ((byte << 4) & 0xFF)) & 0xFF;
                    }
                    return result;
                }

                function _reverse_xor_(bytes, key) {
                    const result = new Uint8Array(bytes.length);
                    for (let i = 0; i < bytes.length; i++) {
                        result[i] = bytes[i] ^ key[i % key.length];
                    }
                    return result;
                }

                async function _zlib_decompress_(bytes) {
                    if (typeof DecompressionStream === "undefined") {
                        throw new Error(
                            "Browser tidak mendukung DecompressionStream('deflate'). " +
                            "Gunakan browser Chromium/Android modern."
                        );
                    }

                    const stream = new Blob([bytes])
                        .stream()
                        .pipeThrough(new DecompressionStream("deflate"));
                    const arrayBuffer = await new Response(stream).arrayBuffer();
                    return new Uint8Array(arrayBuffer);
                }

                function _show_error_(error) {
                    document.documentElement.innerHTML =
                        '<body style="margin:0;padding:24px;background:#111;color:#eee;font-family:system-ui,sans-serif;">' +
                        '<h2>JavasiaEnc24 Loader Error</h2>' +
                        '<pre id="error" style="white-space:pre-wrap;color:#ff8080;"></pre>' +
                        '</body>';
                    const errorNode = document.getElementById("error");
                    if (errorNode) errorNode.textContent = String(error);
                }

                async function _decrypt_and_run_() {
                    const _enc_hex_ = _special_to_hex_(_enc_special_);
                    const _enc_bytes_ = _hex_to_bytes_(_enc_hex_);
                    const _key_ = await _sha512_key_(_key_seed_);

                    const _unrotated_ = _reverse_nibble_swap_(_enc_bytes_);
                    const _decrypted_ = _reverse_xor_(_unrotated_, _key_);
                    const _final_bytes_ = await _zlib_decompress_(_decrypted_);
                    const _final_html_ = new TextDecoder("utf-8", { fatal: true }).decode(_final_bytes_);

                    document.open();
                    document.write(_final_html_);
                    document.close();
                }

                _decrypt_and_run_().catch(_show_error_);
            })();
            </script>
        """.trimIndent()
    }

    private fun writeLoaderWithPayload(writer: BufferedWriter, keySeed: String, compressed: ByteArray): Int {
        val marker = "__PROJECTLV_PAYLOAD__"
        val template = loaderTemplate(keySeed)
        val markerIndex = template.indexOf(marker)
        check(markerIndex >= 0) { "Loader payload marker tidak ditemukan." }
        writer.write(template, 0, markerIndex)

        var payloadChars = 0
        for (byte in compressed) {
            val value = byte.toInt() and 0xFF
            val first = HEX_TO_SPECIAL[HEX_CHARS[value ushr 4].toString()]!!
            val second = HEX_TO_SPECIAL[HEX_CHARS[value and 0x0F].toString()]!!
            writer.write(first)
            writer.write(second)
            payloadChars += first.length + second.length
        }

        val suffixStart = markerIndex + marker.length
        writer.write(template, suffixStart, template.length - suffixStart)
        return payloadChars
    }

    private fun transformInPlace(data: ByteArray, key: ByteArray) {
        for (i in data.indices) {
            val input = data[i].toInt() and 0xFF
            val xored = input xor (key[i % key.size].toInt() and 0xFF)
            data[i] = (((xored shl 4) or (xored ushr 4)) and 0xFF).toByte()
        }
    }

    private fun reverseTransformInPlace(data: ByteArray, key: ByteArray) {
        for (i in data.indices) {
            val input = data[i].toInt() and 0xFF
            val unrotated = ((input ushr 4) or ((input shl 4) and 0xFF)) and 0xFF
            data[i] = (unrotated xor (key[i % key.size].toInt() and 0xFF)).toByte()
        }
    }

    private fun buildMasterKey(keySeed: String): ByteArray {
        val seedBytes = keySeed.toByteArray(StandardCharsets.UTF_8)
        require(seedBytes.isNotEmpty()) { "Key seed harus berupa string dan tidak boleh kosong." }
        val repeated = ByteArray(seedBytes.size * 777)
        for (i in repeated.indices) repeated[i] = seedBytes[i % seedBytes.size]
        return MessageDigest.getInstance("SHA-512").digest(repeated)
    }

    private fun zlibCompress(data: ByteArray): ByteArray {
        val deflater = Deflater(9, false)
        return try {
            deflater.setInput(data)
            deflater.finish()
            val buffer = ByteArray(IO_BUFFER_SIZE)
            val out = ByteArrayOutputStream(maxOf(1024, data.size / 3))
            while (!deflater.finished()) {
                val count = deflater.deflate(buffer)
                if (count == 0 && !deflater.finished()) {
                    throw IllegalStateException("zlib compression stalled")
                }
                out.write(buffer, 0, count)
            }
            out.toByteArray()
        } finally {
            deflater.end()
        }
    }

    private fun sha256ZlibDecompressed(data: ByteArray): String {
        val inflater = Inflater(false)
        val digest = MessageDigest.getInstance("SHA-256")
        return try {
            inflater.setInput(data)
            val buffer = ByteArray(IO_BUFFER_SIZE)
            while (!inflater.finished()) {
                val count = inflater.inflate(buffer)
                if (count > 0) {
                    digest.update(buffer, 0, count)
                } else if (inflater.needsDictionary() || inflater.needsInput()) {
                    throw IllegalStateException("zlib decompression gagal: payload tidak lengkap atau format salah")
                }
            }
            digestToHex(digest.digest())
        } catch (e: Exception) {
            throw IllegalStateException("zlib decompression gagal: ${e.message}", e)
        } finally {
            inflater.end()
        }
    }

    private fun sha256(data: ByteArray): String =
        digestToHex(MessageDigest.getInstance("SHA-256").digest(data))

    private fun digestToHex(bytes: ByteArray): String = buildString(bytes.size * 2) {
        bytes.forEach { byte ->
            val value = byte.toInt() and 0xFF
            append(HEX_CHARS[value ushr 4])
            append(HEX_CHARS[value and 0x0F])
        }
    }

    private fun jsonQuote(value: String): String {
        val out = StringBuilder(value.length + 2)
        out.append('"')
        value.forEach { ch ->
            when (ch) {
                '"' -> out.append("\\\"")
                '\\' -> out.append("\\\\")
                '\b' -> out.append("\\b")
                '\u000C' -> out.append("\\f")
                '\n' -> out.append("\\n")
                '\r' -> out.append("\\r")
                '\t' -> out.append("\\t")
                else -> {
                    if (ch.code < 0x20) out.append("\\u%04x".format(ch.code))
                    else out.append(ch)
                }
            }
        }
        out.append('"')
        return out.toString()
    }
}
