package com.baklava.projectlv.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.BuildConfig
import com.baklava.projectlv.R
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightMagenta
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurface
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LeviathanHeaderCard(
    isOnline: Boolean,
    modifier: Modifier = Modifier,
    showHeroImage: Boolean = true,
    onSecretAdminGesture: () -> Unit = {}
) {
    val model = "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}".trim()
    val androidVer = "Android ${android.os.Build.VERSION.RELEASE}"
    var secretTapCount by remember { mutableIntStateOf(0) }
    var lastSecretTapMs by remember { mutableLongStateOf(0L) }
    val secretInteraction = remember { MutableInteractionSource() }

    Box(
        modifier = modifier
            .staggeredEntrance(index = 0, offsetY = 18.dp, durationMs = 520)
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CyberDarkNavy)
            .border(
                1.dp,
                CyberCardBorder,
                RoundedCornerShape(14.dp)
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Top branding with logo icon
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.combinedClickable(
                        interactionSource = secretInteraction,
                        indication = null,
                        onClick = {
                            val now = System.currentTimeMillis()
                            secretTapCount = if (now - lastSecretTapMs <= 2200L) {
                                secretTapCount + 1
                            } else {
                                1
                            }
                            lastSecretTapMs = now
                            if (secretTapCount >= 7) {
                                secretTapCount = 0
                                lastSecretTapMs = 0L
                                onSecretAdminGesture()
                            }
                        },
                        onLongClick = { onSecretAdminGesture() }
                    )
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.dashboard_logo),
                        contentDescription = "Leviathan Emblem",
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "PROJECT-LEVIATHAN",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    letterSpacing = 0.5.sp
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(CyberSurfaceVariant)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "v${BuildConfig.VERSION_NAME}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = MutedGrey,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                        }
                        Text(
                            text = "Terminal Toolkit",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MutedGrey,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Real-time Status Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SystemStatusPill(isOnline = isOnline)
                DeviceInfoPill(model = model, androidVersion = androidVer)
            }

            Spacer(modifier = Modifier.height(14.dp))

        }
    }
}
