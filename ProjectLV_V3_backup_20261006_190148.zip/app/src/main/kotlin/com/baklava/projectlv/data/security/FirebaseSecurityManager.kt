package com.baklava.projectlv.data.security

import android.content.Context
import android.os.Build
import android.provider.Settings
import com.baklava.projectlv.BuildConfig
import com.baklava.projectlv.data.network.EnvironmentCheckResult
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.Date

/**
 * Firebase access/security adapter for the Spark-compatible client + Firestore
 * Rules architecture.
 *
 * Normal users must be authenticated with Firebase Email/Password. Anonymous
 * Auth is deliberately unsupported and there is no fallback path.
 *
 * Device access is account-bound through devices/{deviceIdHash}. The document
 * contains operational telemetry and ban state only; per-device trial/expiry
 * fields are no longer created, read, or evaluated here.
 */
class FirebaseSecurityManager(context: Context) {
    companion object {
        private const val BAN_DURATION_MS = 7L * 24L * 60L * 60L * 1000L
    }

    private val appContext = context.applicationContext
    private val firestore by lazy { FirebaseFirestore.getInstance() }
    private val auth by lazy { FirebaseAuth.getInstance() }

    private val enabled: Boolean
        get() = FirebaseApp.getApps(appContext).isNotEmpty()

    data class AccessState(
        val allowed: Boolean,
        val banned: Boolean,
        val banExpiresAt: Long? = null,
        val banReason: String = "",
        val banWarning: String = "",
        val message: String = "",
        val verificationFailed: Boolean = false,
        val accountMismatch: Boolean = false
    )

    fun deviceIdHash(): String {
        val androidId = Settings.Secure.getString(
            appContext.contentResolver,
            Settings.Secure.ANDROID_ID
        ).orEmpty().ifBlank { "unknown-android-id" }

        val stableMaterial = listOf(
            appContext.packageName,
            androidId,
            Build.BRAND,
            Build.DEVICE
        ).joinToString("|")

        return sha256(stableMaterial)
    }

    suspend fun checkAccess(): AccessState {
        if (!enabled) {
            return AccessState(
                allowed = false,
                banned = false,
                message = "Firebase belum dikonfigurasi.",
                verificationFailed = true
            )
        }

        val user = auth.currentUser
        if (user == null || !isPasswordUser(user)) {
            return AccessState(
                allowed = false,
                banned = false,
                message = "Login diperlukan sebelum memverifikasi akses.",
                verificationFailed = true
            )
        }

        return try {
            // Firebase can keep the locally cached User object/token after the
            // email has just been verified. Firestore Rules evaluate the ID
            // token claims, so refresh both the User object and token before the
            // first protected Firestore request.
            user.reload().await()
            val freshUser = auth.currentUser
                ?: return AccessState(
                    allowed = false,
                    banned = false,
                    message = "Sesi Firebase berakhir. Silakan login kembali.",
                    verificationFailed = true
                )

            if (!isPasswordUser(freshUser)) {
                return AccessState(
                    allowed = false,
                    banned = false,
                    message = "Sesi bukan Firebase Email/Password.",
                    verificationFailed = true
                )
            }

            if (!freshUser.isEmailVerified) {
                return AccessState(
                    allowed = false,
                    banned = false,
                    message = "Email belum terverifikasi. Verifikasi email lalu login kembali.",
                    verificationFailed = true
                )
            }

            freshUser.getIdToken(true).await()

            val deviceIdHash = deviceIdHash()
            val ref = firestore.collection("devices").document(deviceIdHash)
            val snapshot = ref.get().await()

            if (!snapshot.exists()) {
                val now = System.currentTimeMillis()
                ref.set(
                    mapOf(
                        "deviceIdHash" to deviceIdHash,
                        "ownerUid" to freshUser.uid,
                        "ownerEmail" to freshUser.email.orEmpty().take(320),
                        "banned" to false,
                        "banStartedAt" to null,
                        "banExpiresAt" to null,
                        "violationCount" to 0L,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                        "lastSeenAt" to FieldValue.serverTimestamp(),
                        "appVersion" to BuildConfig.VERSION_NAME,
                        "versionCode" to BuildConfig.VERSION_CODE,
                        "manufacturer" to Build.MANUFACTURER,
                        "brand" to Build.BRAND,
                        "model" to Build.MODEL,
                        "device" to Build.DEVICE,
                        "androidVersion" to Build.VERSION.RELEASE,
                        "sdkInt" to Build.VERSION.SDK_INT
                    )
                ).await()
                return AccessState(
                    allowed = true,
                    banned = false,
                    message = "Akses aktif."
                )
            }

            val ownerUid = snapshot.getString("ownerUid").orEmpty()
            if (ownerUid.isBlank()) {
                return AccessState(
                    allowed = false,
                    banned = false,
                    message = "Record perangkat lama belum memiliki pemilik akun. Bersihkan data legacy di Firebase sebelum memakai perangkat ini.",
                    accountMismatch = true
                )
            }
            if (ownerUid != freshUser.uid) {
                return AccessState(
                    allowed = false,
                    banned = false,
                    message = "Perangkat ini sudah terikat ke akun lain. Hubungi admin untuk migrasi perangkat.",
                    accountMismatch = true
                )
            }

            accessStateFromSnapshot(snapshot)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            AccessState(
                allowed = false,
                banned = false,
                message = "Gagal memverifikasi akses Firebase: ${e.describeForUser()}",
                verificationFailed = true
            )
        }
    }

    suspend fun reportSecurityViolation(environment: EnvironmentCheckResult): AccessState {
        if (!enabled) {
            return AccessState(
                allowed = false,
                banned = false,
                message = "Firebase belum dikonfigurasi.",
                verificationFailed = true
            )
        }

        val user = auth.currentUser
        if (user == null || !isPasswordUser(user)) {
            return AccessState(
                allowed = false,
                banned = false,
                message = "Login diperlukan sebelum memverifikasi keamanan.",
                verificationFailed = true
            )
        }

        try {
            user.reload().await()
            val freshUser = auth.currentUser
                ?: return AccessState(false, false, message = "Sesi Firebase berakhir. Silakan login kembali.", verificationFailed = true)
            if (!isPasswordUser(freshUser) || !freshUser.isEmailVerified) {
                return AccessState(false, false, message = "Email belum terverifikasi. Verifikasi email lalu login kembali.", verificationFailed = true)
            }
            freshUser.getIdToken(true).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return AccessState(false, false, message = "Gagal memperbarui sesi Firebase: ${e.describeForUser()}", verificationFailed = true)
        }

        val evaluation = SecurityEvaluation.from(environment)
        if (!evaluation.hasViolation) return checkAccess()

        return try {
            val deviceIdHash = deviceIdHash()
            val ref = firestore.collection("devices").document(deviceIdHash)
            val snapshot = ref.get().await()

            val ownerUid = snapshot.getString("ownerUid").orEmpty()
            if (snapshot.exists() && ownerUid.isBlank()) {
                return AccessState(
                    allowed = false,
                    banned = false,
                    message = "Record perangkat lama belum memiliki pemilik akun. Bersihkan data legacy di Firebase sebelum memakai perangkat ini.",
                    accountMismatch = true
                )
            }
            if (snapshot.exists() && ownerUid != auth.currentUser?.uid) {
                return AccessState(
                    allowed = false,
                    banned = false,
                    message = "Perangkat ini sudah terikat ke akun lain. Hubungi admin untuk migrasi perangkat.",
                    accountMismatch = true
                )
            }

            val now = System.currentTimeMillis()
            val banExpiresAt = now + BAN_DURATION_MS
            val previousViolationCount = snapshot.getLong("violationCount") ?: 0L

            ref.set(
                mapOf(
                    "deviceIdHash" to deviceIdHash,
                    "ownerUid" to auth.currentUser?.uid.orEmpty(),
                    "ownerEmail" to auth.currentUser?.email.orEmpty().take(320),
                    "banned" to true,
                    "banStartedAt" to Date(now),
                    "banExpiresAt" to Date(banExpiresAt),
                    "violationCount" to previousViolationCount + 1L,
                    "lastViolation" to evaluation.violations.firstOrNull()?.type?.name.orEmpty(),
                    "lastViolationAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()

            AccessState(
                allowed = false,
                banned = true,
                banExpiresAt = banExpiresAt,
                message = "Security violation terdeteksi. Perangkat diblokir selama 7 hari."
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            AccessState(
                allowed = false,
                banned = false,
                message = "Pelaporan keamanan gagal: ${e.describeForUser()}",
                verificationFailed = true
            )
        }
    }

    fun observeAccess(): Flow<AccessState> = callbackFlow {
        if (!enabled) {
            trySend(
                AccessState(
                    allowed = false,
                    banned = false,
                    message = "Firebase belum dikonfigurasi.",
                    verificationFailed = true
                )
            )
            awaitClose { }
            return@callbackFlow
        }

        val user = auth.currentUser
        if (user == null || !isPasswordUser(user)) {
            trySend(
                AccessState(
                    allowed = false,
                    banned = false,
                    message = "Login diperlukan sebelum memverifikasi akses.",
                    verificationFailed = true
                )
            )
            awaitClose { }
            return@callbackFlow
        }

        try {
            user.reload().await()
            val freshUser = auth.currentUser
            if (freshUser == null || !isPasswordUser(freshUser)) {
                trySend(AccessState(false, false, message = "Sesi Firebase berakhir. Silakan login kembali.", verificationFailed = true))
                awaitClose { }
                return@callbackFlow
            }
            if (!freshUser.isEmailVerified) {
                trySend(AccessState(false, false, message = "Email belum terverifikasi.", verificationFailed = true))
                awaitClose { }
                return@callbackFlow
            }
            freshUser.getIdToken(true).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            trySend(AccessState(false, false, message = "Gagal memperbarui sesi Firebase: ${e.describeForUser()}", verificationFailed = true))
            awaitClose { }
            return@callbackFlow
        }

        val deviceIdHash = deviceIdHash()
        val ref = firestore.collection("devices").document(deviceIdHash)
        val registration: ListenerRegistration = ref.addSnapshotListener { snapshot, error ->
            if (error != null) {
                val isPermissionIssue = error.code == FirebaseFirestoreException.Code.PERMISSION_DENIED
                trySend(
                    AccessState(
                        allowed = false,
                        banned = false,
                        message = if (isPermissionIssue) {
                            "Verifikasi perangkat gagal: akses Firestore ditolak."
                        } else {
                            "Gagal memantau status akses: ${error.message ?: error.code.name}"
                        },
                        verificationFailed = true
                    )
                )
                return@addSnapshotListener
            }

            if (snapshot == null || !snapshot.exists()) {
                trySend(
                    AccessState(
                        allowed = false,
                        banned = false,
                        message = "Menunggu verifikasi perangkat.",
                        verificationFailed = true
                    )
                )
                return@addSnapshotListener
            }

            val ownerUid = snapshot.getString("ownerUid").orEmpty()
            if (ownerUid.isBlank()) {
                trySend(
                    AccessState(
                        allowed = false,
                        banned = false,
                        message = "Record perangkat lama belum memiliki pemilik akun. Bersihkan data legacy di Firebase sebelum memakai perangkat ini.",
                        accountMismatch = true
                    )
                )
                return@addSnapshotListener
            }
            if (ownerUid != user.uid) {
                trySend(
                    AccessState(
                        allowed = false,
                        banned = false,
                        message = "Perangkat ini sudah terikat ke akun lain. Hubungi admin untuk migrasi perangkat.",
                        accountMismatch = true
                    )
                )
                return@addSnapshotListener
            }

            trySend(accessStateFromSnapshot(snapshot))
        }

        awaitClose { registration.remove() }
    }

    private fun isPasswordUser(user: FirebaseUser): Boolean =
        user.providerData.any { it.providerId == EmailAuthProvider.PROVIDER_ID }

    private fun accessStateFromSnapshot(snapshot: DocumentSnapshot): AccessState {
        val now = System.currentTimeMillis()
        val banExpiresAt = snapshot.getTimestamp("banExpiresAt")?.toDate()?.time
        val bannedFlag = snapshot.getBoolean("banned") == true
        val isTimedBanActive = banExpiresAt != null && banExpiresAt > now
        val isPermanentBan = bannedFlag && banExpiresAt == null
        val banned = bannedFlag && (isTimedBanActive || isPermanentBan)
        val banReason = snapshot.getString("banReason").orEmpty()
        val banWarning = snapshot.getString("banWarning").orEmpty()

        if (banned) {
            return AccessState(
                allowed = false,
                banned = true,
                banExpiresAt = banExpiresAt,
                banReason = banReason,
                banWarning = banWarning,
                message = when {
                    banWarning.isNotBlank() && banReason.isNotBlank() ->
                        "${banWarning.trim()}\n\nAlasan: ${banReason.trim()}"
                    banWarning.isNotBlank() -> banWarning.trim()
                    isPermanentBan -> "Perangkat diblokir permanen oleh admin karena pelanggaran keamanan."
                    else -> "Perangkat diblokir sementara oleh admin."
                }
            )
        }

        return AccessState(
            allowed = true,
            banned = false,
            message = "Akses aktif."
        )
    }

    private fun sha256(value: String): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        return digest.digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    private fun Exception.safeMessage(): String =
        message?.take(180) ?: javaClass.simpleName

    private fun Exception.describeForUser(): String {
        val isPermissionDenied = this is FirebaseFirestoreException &&
            this.code == FirebaseFirestoreException.Code.PERMISSION_DENIED
        return if (isPermissionDenied) {
            "PERMISSION_DENIED. Cek: (1) firestore.rules sudah di-deploy, " +
                "(2) Email/Password Auth aktif di Firebase Console, " +
                "(3) App Check tidak menolak request (Play Integrity/Debug token)."
        } else {
            safeMessage()
        }
    }
}
