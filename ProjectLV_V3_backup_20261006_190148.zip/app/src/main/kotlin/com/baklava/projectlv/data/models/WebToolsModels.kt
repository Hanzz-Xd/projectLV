package com.baklava.projectlv.data.models

data class Web2ApkBuildRequest(
    val appName: String,
    val websiteUrl: String,
    val packageName: String,
    val versionName: String,
    val versionCode: String,
    val appIconUrl: String = "",
    val iconPng: ByteArray? = null,
    val permissions: List<String> = emptyList(),
    val config: Map<String, Any?> = emptyMap()
)

data class Web2ApkBuildResult(
    val filePath: String,
    val fileName: String,
    val sizeBytes: Long,
    val websiteUrl: String,
    val packageName: String,
    val signingLabel: String = "SDKForge Web2APK"
)

data class PageSourceResult(
    val url: String,
    val html: String,
    val totalSize: String? = null,
    val totalChars: String? = null,
    val totalWords: String? = null,
    val totalLines: String? = null,
    val timingMs: String? = null,
    val server: String? = null,
    val httpCode: String? = null
)

data class WebToZipResult(
    val isSuccess: Boolean,
    val fileName: String,
    val downloadUrl: String,
    val sizeBytes: Long = 0L,
    val isLocalArchive: Boolean = false,
    val localUri: String? = null,
    val note: String? = null
)

data class ShortUrlResult(
    val originalUrl: String,
    val shortUrl: String,
    val service: String? = null
)
