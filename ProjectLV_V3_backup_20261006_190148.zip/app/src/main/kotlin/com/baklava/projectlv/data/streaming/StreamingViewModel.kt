package com.baklava.projectlv.data.streaming

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class ContentType { ANIME, DONGHUA, MOVIE }

private enum class CatalogStop { CONTINUE, END_OF_CATALOG, ERROR }

class StreamingViewModel(
    private val repository: StreamingRepository = StreamingRepository(),
    val localStore: StreamingLocalStore
) : ViewModel() {
    private val _ongoing = MutableStateFlow<List<AnimeListItem>>(emptyList())
    private val _latest = MutableStateFlow<List<AnimeListItem>>(emptyList())
    private val _allAnime = MutableStateFlow<List<AnimeListItem>>(emptyList())
    private val _allLoading = MutableStateFlow(false)
    private val _allHasMore = MutableStateFlow(true)
    private val _allPage = MutableStateFlow(0)
    private val _loading = MutableStateFlow(false)
    private val _error = MutableStateFlow<String?>(null)
    private val _allError = MutableStateFlow<String?>(null)
    private val _selectedAnime = MutableStateFlow<AnimeDetail?>(null)
    private val _streams = MutableStateFlow<EpisodeStreamData?>(null)
    private val _searchResults = MutableStateFlow<List<AnimeListItem>>(emptyList())
    private val _searchLoading = MutableStateFlow(false)
    private val _searchError = MutableStateFlow<String?>(null)
    private val _contentType = MutableStateFlow(ContentType.ANIME)
    private val _movies = MutableStateFlow<List<AnimeListItem>>(emptyList())
    private val _movieLoading = MutableStateFlow(false)
    private val _movieError = MutableStateFlow<String?>(null)
    private val _donghua = MutableStateFlow<List<AnimeListItem>>(emptyList())
    private val _donghuaLoading = MutableStateFlow(false)
    private val _donghuaHasMore = MutableStateFlow(true)
    private val _donghuaPage = MutableStateFlow(0)
    private val _donghuaError = MutableStateFlow<String?>(null)

    // Set persisten, BUKAN dihitung ulang dari _allAnime.value tiap kali (itu
    // bug lama yang bikin lag: rebuild HashSet dari seluruh list yang terus
    // membesar di tiap halaman = O(n^2) begitu katalog di-auto-load penuh).
    private val knownCatalogUrls = HashSet<String>()
    private val knownDonghuaUrls = HashSet<String>()

    val ongoing: StateFlow<List<AnimeListItem>> = _ongoing.asStateFlow()
    val latest: StateFlow<List<AnimeListItem>> = _latest.asStateFlow()
    val allAnime: StateFlow<List<AnimeListItem>> = _allAnime.asStateFlow()
    val allLoading: StateFlow<Boolean> = _allLoading.asStateFlow()
    val allHasMore: StateFlow<Boolean> = _allHasMore.asStateFlow()
    val allPage: StateFlow<Int> = _allPage.asStateFlow()
    val loading: StateFlow<Boolean> = _loading.asStateFlow()
    val error: StateFlow<String?> = _error.asStateFlow()
    val allError: StateFlow<String?> = _allError.asStateFlow()
    val selectedAnime: StateFlow<AnimeDetail?> = _selectedAnime.asStateFlow()
    val streams: StateFlow<EpisodeStreamData?> = _streams.asStateFlow()
    val searchResults: StateFlow<List<AnimeListItem>> = _searchResults.asStateFlow()
    val searchLoading: StateFlow<Boolean> = _searchLoading.asStateFlow()
    val searchError: StateFlow<String?> = _searchError.asStateFlow()
    val contentType: StateFlow<ContentType> = _contentType.asStateFlow()
    val movies: StateFlow<List<AnimeListItem>> = _movies.asStateFlow()
    val movieLoading: StateFlow<Boolean> = _movieLoading.asStateFlow()
    val movieError: StateFlow<String?> = _movieError.asStateFlow()
    val donghua: StateFlow<List<AnimeListItem>> = _donghua.asStateFlow()
    val donghuaLoading: StateFlow<Boolean> = _donghuaLoading.asStateFlow()
    val donghuaHasMore: StateFlow<Boolean> = _donghuaHasMore.asStateFlow()
    val donghuaError: StateFlow<String?> = _donghuaError.asStateFlow()

    private var homeJob: Job? = null
    private var detailJob: Job? = null
    private var streamJob: Job? = null
    private var allLoadJob: Job? = null
    private var searchJob: Job? = null
    private var movieJob: Job? = null
    private var donghuaJob: Job? = null

    private companion object {
        // Semua request dijalankan konkuren per batch (bukan satu-satu
        // berurutan) supaya auto-load-all cepat, tapi update state (yang
        // memicu recomposition) cuma sekali per batch, bukan sekali per
        // halaman — ini yang mencegah "lag" waktu ratusan halaman ke-load.
        const val CATALOG_BATCH_SIZE = 4
        // Batas pengaman kalau-kalau pagination upstream tidak pernah
        // benar-benar berhenti (bug di server) — bukan estimasi ukuran katalog.
        const val CATALOG_PAGE_SAFETY_CAP = 400
        const val DONGHUA_PAGE_SAFETY_CAP = 60
    }

    init {
        refreshHome()
        // Auto-load SEMUA halaman katalog di background begitu masuk mode
        // streaming (bukan cuma halaman 1) — lihat dokumentasi loadNextAllPage().
        loadNextAllPage()
    }

    fun refreshHome() {
        homeJob?.cancel()
        homeJob = viewModelScope.launch {
            _loading.value = true
            _error.value = null
            val ongoingResult = repository.getOngoing(1)
            val latestResult = repository.getLatest(1)
            ongoingResult.onSuccess { _ongoing.value = it }
            latestResult.onSuccess { _latest.value = it }
            _error.value = listOfNotNull(
                ongoingResult.exceptionOrNull(),
                latestResult.exceptionOrNull()
            ).firstOrNull()?.message
            _loading.value = false
        }
    }

    /**
     * Dulu cuma memuat 1 halaman per panggilan (nunggu user scroll ke bawah
     * / tap "muat lagi"). Sekarang begitu dipanggil (termasuk otomatis dari
     * init{} saat masuk mode streaming), fungsi ini akan terus memuat
     * SEMUA halaman katalog di background sampai habis — supaya begitu
     * masuk mode streaming, hampir semua anime sudah tersedia untuk dicari
     * tanpa perlu scroll manual.
     *
     * Nama & signature-nya sengaja tetap sama seperti sebelumnya (dipanggil
     * dari onLoadMore/onRetry/pull-to-refresh di StreamingScreen) — karena
     * sudah auto-continue, panggilan-panggilan itu sekarang praktis jadi
     * "pastikan auto-load jalan/lanjut" saja, aman dipanggil berkali-kali.
     */
    fun loadNextAllPage() {
        if (_allLoading.value || !_allHasMore.value || allLoadJob?.isActive == true) return
        allLoadJob = viewModelScope.launch {
            _allLoading.value = true
            _allError.value = null
            try {
                while (_allHasMore.value && _allPage.value < CATALOG_PAGE_SAFETY_CAP) {
                    val startPage = _allPage.value + 1
                    val batch = (startPage until startPage + CATALOG_BATCH_SIZE).toList()
                    val results = batch
                        .map { page -> async { page to repository.getAllAnimePage(page) } }
                        .awaitAll()
                        .sortedBy { it.first }

                    var lastGoodPage = _allPage.value
                    val freshBatch = mutableListOf<AnimeListItem>()
                    var stop = CatalogStop.CONTINUE

                    for ((page, result) in results) {
                        val items = result.getOrNull()
                        if (result.isFailure) {
                            _allError.value = result.exceptionOrNull()?.message ?: "Gagal memuat katalog"
                            stop = CatalogStop.ERROR
                            break
                        }
                        if (items.isNullOrEmpty()) {
                            stop = CatalogStop.END_OF_CATALOG
                            break
                        }
                        lastGoodPage = page
                        items.forEach { if (it.url.isNotBlank() && knownCatalogUrls.add(it.url)) freshBatch += it }
                    }

                    if (freshBatch.isNotEmpty()) {
                        _allAnime.value = _allAnime.value + freshBatch
                    }
                    _allPage.value = lastGoodPage

                    when (stop) {
                        CatalogStop.END_OF_CATALOG -> {
                            _allHasMore.value = false
                            break
                        }
                        // Error jaringan sementara: berhenti untuk sesi ini tapi
                        // JANGAN set hasMore = false, supaya onRetry (yang
                        // manggil fungsi ini lagi) bisa lanjut dari halaman
                        // terakhir yang berhasil, bukan mulai dari 0 lagi.
                        CatalogStop.ERROR -> break
                        CatalogStop.CONTINUE -> delay(200) // jeda sopan, jangan bombardir server upstream
                    }
                }
            } finally {
                _allLoading.value = false
            }
        }
    }

    fun resetAllCatalog() {
        knownCatalogUrls.clear()
        _allAnime.value = emptyList()
        _allPage.value = 0
        _allHasMore.value = true
        _allError.value = null
        loadNextAllPage()
    }

    // Judul yang diingat per slug supaya "Coba lagi" tetap bisa pakai judul sebagai cadangan.
    private val titleHints = HashMap<String, String>()

    fun openAnime(slug: String, titleHint: String? = null) {
        titleHint?.takeIf { it.isNotBlank() }?.let { titleHints[slug] = it }
        detailJob?.cancel()
        detailJob = viewModelScope.launch {
            _selectedAnime.value = null
            _loading.value = true
            _error.value = null
            repository.getSeries(slug, titleHints[slug])
                .onSuccess { _selectedAnime.value = it }
                .onFailure { _error.value = it.message ?: "Gagal memuat anime" }
            _loading.value = false
        }
    }

    fun openEpisode(anime: AnimeDetail, episode: Episode, onReady: () -> Unit = {}) {
        streamJob?.cancel()
        streamJob = viewModelScope.launch {
            _loading.value = true
            _error.value = null
            repository.getEpisodeStreams(anime, episode)
                .onSuccess {
                    _streams.value = it
                    onReady()
                }
                .onFailure { _error.value = it.message ?: "Gagal mengambil link streaming" }
            _loading.value = false
        }
    }

    fun clearStreams() {
        _streams.value = null
    }

    /**
     * Beda dengan browsing (getOngoing/getLatest/getAllAnimePage) yang cuma
     * fallback ke Server 2 kalau Server 1 gagal, search SELALU memindai
     * kedua server sekaligus dan menggabungkan hasilnya — karena AnimeKita
     * (Server 1) dan backend Vercel (Server 2) adalah dua katalog upstream
     * yang berbeda, jadi sebuah judul bisa saja hanya ada di salah satunya.
     * Debounce 350ms supaya tidak menembak request di setiap ketukan huruf.
     */
    fun search(query: String) {
        searchJob?.cancel()
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            _searchLoading.value = false
            _searchError.value = null
            return
        }
        searchJob = viewModelScope.launch {
            delay(350)
            _searchLoading.value = true
            _searchError.value = null
            repository.searchAnime(query)
                .onSuccess { _searchResults.value = it }
                .onFailure { _searchError.value = it.message ?: "Gagal mencari anime" }
            _searchLoading.value = false
        }
    }

    fun clearSearch() {
        searchJob?.cancel()
        _searchResults.value = emptyList()
        _searchLoading.value = false
        _searchError.value = null
    }

    /**
     * Anime = katalog utama (allAnime, sudah jalan dari init). Donghua &
     * Movie sengaja lazy-load: baru mulai fetch pas pertama kali tab-nya
     * dibuka, bukan langsung ikut auto-load waktu init (biar tidak nambah
     * beban network di awal untuk user yang tidak pernah buka tab itu).
     */
    fun selectContentType(type: ContentType) {
        _contentType.value = type
        when (type) {
            ContentType.MOVIE -> if (_movies.value.isEmpty() && movieJob?.isActive != true) loadMovies()
            ContentType.DONGHUA -> if (_donghua.value.isEmpty() && donghuaJob?.isActive != true) loadAllDonghua()
            ContentType.ANIME -> Unit
        }
    }

    fun loadMovies() {
        if (_movieLoading.value || movieJob?.isActive == true) return
        movieJob = viewModelScope.launch {
            _movieLoading.value = true
            _movieError.value = null
            repository.getMovies()
                .onSuccess { _movies.value = it }
                .onFailure { _movieError.value = it.message ?: "Gagal memuat daftar movie" }
            _movieLoading.value = false
        }
    }

    /**
     * Donghua bukan kategori asli AnimeKita (lihat catatan di
     * StreamingRepository.getDonghuaPage) — dibangun dari search.php
     * ber-keyword "donghua", tapi karena search.php sudah kasih info
     * has_next/total_pages yang akurat, auto-load-nya jauh lebih murah &
     * pasti berhenti tepat waktu dibanding scan katalog utama.
     */
    fun loadAllDonghua() {
        if (_donghuaLoading.value || !_donghuaHasMore.value || donghuaJob?.isActive == true) return
        donghuaJob = viewModelScope.launch {
            _donghuaLoading.value = true
            _donghuaError.value = null
            try {
                while (_donghuaHasMore.value && _donghuaPage.value < DONGHUA_PAGE_SAFETY_CAP) {
                    val nextPage = _donghuaPage.value + 1
                    val result = repository.getDonghuaPage(nextPage)
                    val paged = result.getOrNull()
                    if (result.isFailure) {
                        _donghuaError.value = result.exceptionOrNull()?.message ?: "Gagal memuat donghua"
                        break
                    }
                    if (paged == null || paged.items.isEmpty()) {
                        _donghuaHasMore.value = false
                        break
                    }
                    val fresh = paged.items.filter { it.url.isNotBlank() && knownDonghuaUrls.add(it.url) }
                    if (fresh.isNotEmpty()) _donghua.value = _donghua.value + fresh
                    _donghuaPage.value = nextPage
                    if (!paged.hasMore) {
                        _donghuaHasMore.value = false
                        break
                    }
                    delay(120)
                }
            } finally {
                _donghuaLoading.value = false
            }
        }
    }
}

class StreamingViewModelFactory(
    private val localStore: StreamingLocalStore
) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StreamingViewModel::class.java)) {
            return StreamingViewModel(localStore = localStore) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
