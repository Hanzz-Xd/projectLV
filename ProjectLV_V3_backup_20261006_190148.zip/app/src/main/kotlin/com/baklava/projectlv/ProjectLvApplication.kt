package com.baklava.projectlv

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

class ProjectLvApplication : Application() {
    override fun onCreate() {
        super.onCreate()

        // google-services.json is processed by the Google Services Gradle plugin.
        // Firebase can therefore initialize from the generated resources without
        // duplicating API key / App ID / Project ID values in BuildConfig.
        if (FirebaseApp.getApps(this).isEmpty()) {
            FirebaseApp.initializeApp(this)
        }

        runCatching {
            val appCheck = FirebaseAppCheck.getInstance()
            if (BuildConfig.DEBUG) {
                // Play Integrity attestation expects the APK to be verifiable
                // through Google Play (installed via Play, signed with a cert
                // linked in Play Console). A debug/sideloaded build — installed
                // directly via AndroidIDE/adb/apk file — fails that check, so
                // every Firestore request gets rejected as PERMISSION_DENIED
                // even though the security rules and Firebase Auth are fine.
                // The Debug provider fixes this for development: on first run
                // it logs a debug token to Logcat — register that token once in
                // Firebase Console > App Check > Apps > (⋮) > "Manage debug
                // tokens" and it will be trusted from then on.
                appCheck.installAppCheckProviderFactory(
                    DebugAppCheckProviderFactory.getInstance()
                )
            } else {
                appCheck.installAppCheckProviderFactory(
                    PlayIntegrityAppCheckProviderFactory.getInstance()
                )
            }
        }
    }
}
