package com.baklava.projectlv.ui.admin

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import com.baklava.projectlv.ui.components.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import com.baklava.projectlv.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import com.baklava.projectlv.ui.components.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import com.baklava.projectlv.ui.components.IconButton
import com.baklava.projectlv.ui.components.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import com.baklava.projectlv.ui.components.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.BuildConfig
import com.baklava.projectlv.data.admin.AdminControlManager
import com.baklava.projectlv.data.admin.AnnouncementContext
import com.baklava.projectlv.data.admin.AnnouncementRecord
import com.baklava.projectlv.data.admin.ApiControlState
import com.baklava.projectlv.data.admin.BugReportRecord
import com.baklava.projectlv.data.admin.DeviceRecord
import com.baklava.projectlv.data.admin.GlobalControlState
import com.baklava.projectlv.data.admin.GlobalToolPolicy
import com.baklava.projectlv.ui.theme.BrightAmber
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private data class AdminTabSpec(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val AdminTabs = listOf(
    AdminTabSpec("Global", Icons.Default.Settings),
    AdminTabSpec("Device", Icons.Default.PhoneAndroid),
    AdminTabSpec("Bug", Icons.Default.BugReport),
    AdminTabSpec("Info", Icons.Default.Campaign)
)

/** Quick-pick durations offered everywhere a ban/expiry window is chosen. */
private data class DurationOption(val label: String, val millis: Long?)

private val DurationOptions = listOf(
    DurationOption("15 menit", 15L * 60L * 1000L),
    DurationOption("1 jam", 60L * 60L * 1000L),
    DurationOption("6 jam", 6L * 60L * 60L * 1000L),
    DurationOption("1 hari", 24L * 60L * 60L * 1000L),
    DurationOption("3 hari", 3L * 24L * 60L * 60L * 1000L),
    DurationOption("7 hari", 7L * 24L * 60L * 60L * 1000L),
    DurationOption("14 hari", 14L * 24L * 60L * 60L * 1000L),
    DurationOption("30 hari", 30L * 24L * 60L * 60L * 1000L),
    DurationOption("90 hari", 90L * 24L * 60L * 60L * 1000L),
    DurationOption("Permanen", null)
)

@Composable
fun AdminEntryScreen(
    manager: AdminControlManager,
    onClose: () -> Unit
) {
    val loggedIn by manager.observeAdminRecord().collectAsState(initial = false)
    if (loggedIn) {
        AdminPanelScreen(manager = manager, onClose = onClose)
    } else {
        AdminLoginScreen(manager, onClose) { }
    }
}

@Composable
private fun AdminLoginScreen(
    manager: AdminControlManager,
    onClose: () -> Unit,
    onLoggedIn: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Box(Modifier.fillMaxSize().background(CyberBlack), contentAlignment = Alignment.Center) {
        Card(
            modifier = Modifier.fillMaxWidth(0.94f).heightIn(max = 720.dp)
                .border(1.dp, CyberCardBorder, RoundedCornerShape(18.dp)),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(
                Modifier.padding(20.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(42.dp).background(BrightCyan.copy(alpha = 0.12f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.AdminPanelSettings, null, tint = BrightCyan, modifier = Modifier.size(24.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("ADMIN CONTROL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Realtime control plane • device-bound", color = MutedGrey, fontSize = 12.sp)
                    }
                }
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Email admin") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Password") },
                    singleLine = true
                )
                AnimatedVisibility(visible = error != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth()
                            .background(BrightRed.copy(alpha = 0.1f), RoundedCornerShape(10.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ErrorOutline, null, tint = BrightRed, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(error.orEmpty(), color = BrightRed, fontSize = 12.sp)
                    }
                }
                Text(
                    "Akun harus ada di Firebase Authentication + admins/{uid}. Device hash harus cocok dengan perangkat ini.",
                    color = MutedGrey,
                    fontSize = 11.sp
                )
                Card(colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant), shape = RoundedCornerShape(8.dp)) {
                    Text(
                        "Device hash provisioning:\n${manager.deviceIdHash()}",
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onClose, Modifier.weight(1f)) { Text("Tutup") }
                    Button(
                        onClick = {
                            loading = true
                            error = null
                            scope.launch {
                                val result = manager.signInAdmin(email, password)
                                loading = false
                                result.exceptionOrNull()?.let { error = it.message ?: "Login admin gagal." }
                                    ?: onLoggedIn()
                            }
                        },
                        enabled = !loading && email.isNotBlank() && password.isNotBlank(),
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
                    ) {
                        if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = CyberBlack)
                        else Text("Masuk")
                    }
                }
            }
        }
    }
}

/** Small floating status describing whether an admin action succeeded or failed. */
private data class OpStatus(val message: String, val isError: Boolean, val nonce: Long = System.currentTimeMillis())

@Composable
private fun AdminPanelScreen(manager: AdminControlManager, onClose: () -> Unit) {
    // IMPORTANT: remember the cold flows. Creating a new callbackFlow on every
    // recomposition causes listener churn, which was the main source of the
    // irregular blinking seen in the previous panel.
    val globalFlow = remember(manager) { manager.observeGlobalControl() }
    val devicesFlow = remember(manager) { manager.observeDevices() }
    val bugsFlow = remember(manager) { manager.observeBugReports() }
    val announcementsFlow = remember(manager) { manager.observeAnnouncements(includeDisabled = true) }

    val control by globalFlow.collectAsState(initial = GlobalControlState())
    val devices by devicesFlow.collectAsState(initial = emptyList())
    val bugs by bugsFlow.collectAsState(initial = emptyList())
    val announcements by announcementsFlow.collectAsState(initial = emptyList())

    var selectedTab by remember { mutableStateOf(0) }
    var opStatus by remember { mutableStateOf<OpStatus?>(null) }
    var refreshing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(manager) {
        try { manager.recordPresence("admin_panel") } catch (_: Exception) { }
    }

    // Auto-dismiss the toast after a few seconds instead of leaving stale
    // status text glued under the tab bar forever.
    LaunchedEffect(opStatus?.nonce) {
        if (opStatus != null) {
            kotlinx.coroutines.delay(3600L)
            opStatus = null
        }
    }

    fun report(message: String, isError: Boolean = message.startsWith("Gagal")) {
        opStatus = OpStatus(message, isError)
    }

    fun runAction(action: suspend () -> Unit, success: String) {
        scope.launch {
            try {
                action()
                report(success, isError = false)
            } catch (t: Throwable) {
                report("Gagal: ${t.message ?: "operasi tidak berhasil"}", isError = true)
            }
        }
    }

    Box(Modifier.fillMaxSize().background(CyberBlack)) {
        Column(Modifier.fillMaxSize()) {
            // ---------------------------------------------------------------
            // HEADER — kartu rounded bermargin, senada dengan gaya Dashboard
            // ---------------------------------------------------------------
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(CyberDarkNavy)
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(14.dp))
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyberSurfaceVariant)
                            .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Security, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("ADMIN PANEL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, letterSpacing = 0.5.sp)
                            Spacer(Modifier.width(8.dp))
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(CyberSurfaceVariant)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("v${BuildConfig.VERSION_NAME}", color = MutedGrey, fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LiveDot(active = control.enabled)
                            Spacer(Modifier.width(5.dp))
                            Text(
                                "${devices.size} device • ${bugs.count { it.status == "open" }} bug open",
                                color = MutedGrey,
                                fontSize = 10.sp
                            )
                        }
                    }
                    IconButton(onClick = {
                        refreshing = true
                        scope.launch {
                            try {
                                manager.recordPresence("admin_panel")
                                report("Presence admin disinkronkan.", isError = false)
                            } catch (t: Throwable) {
                                report("Gagal refresh: ${t.message}", isError = true)
                            }
                            refreshing = false
                        }
                    }) {
                        if (refreshing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = BrightCyan)
                        else Icon(Icons.Default.Refresh, "Refresh", tint = BrightCyan)
                    }
                    TextButton(onClick = { runAction({ manager.logoutAdmin() }, "Logout berhasil."); onClose() }) {
                        Text("Logout", color = BrightAmber, fontSize = 12.sp)
                    }
                    IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = Color.White) }
                }

                // ---------------------------------------------------------------
                // TAB BAR — pill-style segmented control instead of default
                // Material TabRow, with icon + label so each destination reads
                // instantly instead of requiring the user to remember tab order.
                // ---------------------------------------------------------------
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AdminTabs.forEachIndexed { index, tab ->
                        val selected = selectedTab == index
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selected) BrightCyan.copy(alpha = 0.14f) else CyberSurfaceVariant)
                                .border(1.dp, if (selected) BrightCyan.copy(alpha = 0.5f) else CyberCardBorder, RoundedCornerShape(10.dp))
                                .clickable { selectedTab = index }
                                .padding(vertical = 9.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                tab.icon, null,
                                tint = if (selected) BrightCyan else MutedGrey,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(
                                tab.label,
                                color = if (selected) BrightCyan else MutedGrey,
                                fontSize = 11.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            Box(Modifier.fillMaxSize().padding(10.dp)) {
                when (selectedTab) {
                    0 -> GlobalControlTab(manager, control) { report(it) }
                    1 -> DevicesTab(manager, devices) { report(it) }
                    2 -> BugsTab(manager, bugs) { report(it) }
                    3 -> AnnouncementsTab(manager, announcements) { report(it) }
                }
            }
        }

        // ---------------------------------------------------------------
        // FLOATING TOAST — replaces the old plain Text banner that pushed
        // content down and never went away on its own.
        // ---------------------------------------------------------------
        AnimatedVisibility(
            visible = opStatus != null,
            modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
            enter = fadeIn(tween(180)) + slideInVertically(tween(220)) { it / 2 },
            exit = fadeOut(tween(160)) + slideOutVertically(tween(180)) { it / 2 }
        ) {
            val status = opStatus
            if (status != null) {
                val accent = if (status.isError) BrightRed else BrightGreen
                Row(
                    modifier = Modifier
                        .background(CyberDarkNavy, RoundedCornerShape(12.dp))
                        .border(1.dp, accent.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (status.isError) Icons.Default.ErrorOutline else Icons.Default.CheckCircle,
                        null, tint = accent, modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(status.message, color = Color.White, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun LiveDot(active: Boolean) {
    Box(
        modifier = Modifier
            .size(6.dp)
            .background(if (active) BrightGreen else BrightRed, CircleShape)
    )
}

// =====================================================================
// GLOBAL CONTROL TAB
// =====================================================================

@Composable
private fun GlobalControlTab(manager: AdminControlManager, control: GlobalControlState, report: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var enabled by remember(control.enabled) { mutableStateOf(control.enabled) }
    var message by remember(control.message) { mutableStateOf(control.message) }
    var toolStates by remember(control.toolStates) { mutableStateOf(defaultTools(control.toolStates)) }
    var apiControls by remember(control.apiControls) { mutableStateOf(defaultApis(control.apiControls)) }
    var saving by remember { mutableStateOf(false) }
    var dirty by remember { mutableStateOf(false) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
        item {
            StatsStrip(
                active = if (enabled) "ACTIVE" else "OFF",
                activeColor = if (enabled) BrightGreen else BrightRed,
                tools = toolStates.count { it.value },
                apis = apiControls.count { it.value.enabled }
            )
        }
        item {
            SectionCard("AKSES GLOBAL", Icons.Default.Settings, subtitle = "Maintenance / kontrol utama seluruh toolkit") {
                ToggleRow(
                    title = "Sistem aktif",
                    subtitle = "Matikan untuk masuk maintenance mode; admin tetap dapat mengakses aplikasi.",
                    checked = enabled,
                    onCheckedChange = { enabled = it; dirty = true }
                )
                OutlinedTextField(
                    message,
                    { message = it.take(300); dirty = true },
                    Modifier.fillMaxWidth(),
                    label = { Text("Pesan global") },
                    supportingText = { Text("${message.length}/300", color = MutedGrey, fontSize = 10.sp) }
                )
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(CyberSurfaceVariant, RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Security, null, tint = BrightCyan, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Global Control mengatur maintenance, module gate, dan API kill-switch. Fitur expiry global sudah dihapus.",
                        color = MutedGrey,
                        fontSize = 10.sp,
                        lineHeight = 14.sp
                    )
                }
            }
        }
        item {
            SectionCard("TOOL GATES", Icons.Default.Settings, subtitle = "${toolStates.count { it.value }} dari ${toolStates.size} modul aktif") {
                toolStates.entries.forEach { (id, state) ->
                    val label = GlobalToolPolicy.label(id)
                    ToggleRow(label, "Realtime gate untuk modul $label", state) {
                        toolStates = toolStates.toMutableMap().apply { put(id, it) }
                        dirty = true
                    }
                }
            }
        }
        item {
            SectionCard("API CONTROL", Icons.Default.Security, subtitle = "${apiControls.count { it.value.enabled }} dari ${apiControls.size} API enabled") {
                apiControls.entries.forEach { (id, config) ->
                    val label = GlobalToolPolicy.label(id)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        ToggleRow(label, "Kill-switch + metadata revision", config.enabled) {
                            apiControls = apiControls.toMutableMap().apply { put(id, config.copy(enabled = it)) }
                            dirty = true
                        }
                        OutlinedTextField(
                            config.keyRevision,
                            { value ->
                                apiControls = apiControls.toMutableMap().apply { put(id, config.copy(keyRevision = value.take(32))) }
                                dirty = true
                            },
                            Modifier.fillMaxWidth(),
                            label = { Text("$id • key revision") },
                            singleLine = true
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth().background(BrightAmber.copy(alpha = 0.08f), RoundedCornerShape(8.dp)).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Warning, null, tint = BrightAmber, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("API key rahasia tidak disimpan di Firestore. Kill-switch/revision hanya metadata.", color = BrightAmber, fontSize = 10.sp)
                }
            }
        }
        item {
            Button(
                onClick = {
                    saving = true
                    scope.launch {
                        try {
                            manager.refreshAdminDeviceBinding().getOrThrow()
                            manager.setGlobalControl(enabled, message, toolStates, apiControls)
                            report("Global Control tersimpan dan tersinkron realtime.")
                            dirty = false
                        } catch (t: Throwable) {
                            val detail = t.message ?: "unknown"
                            report(
                                if (detail.contains("PERMISSION_DENIED", true)) {
                                    "Gagal menyimpan Global Control: Firebase menolak write. Pastikan admin aktif, email terverifikasi, device hash cocok, dan rules terbaru sudah deploy."
                                } else {
                                    "Gagal menyimpan Global Control: $detail"
                                }
                            )
                        }
                        saving = false
                    }
                },
                enabled = !saving,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (dirty) BrightCyan else BrightCyan.copy(alpha = 0.7f), contentColor = CyberBlack),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (saving) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = CyberBlack)
                else Text(if (dirty) "SIMPAN PERUBAHAN" else "SIMPAN GLOBAL CONTROL", fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * Horizontal row of quick-pick duration chips. Used for global expiry,
 * device ban duration, and device expiry override so the admin never has to
 * hand-type a timestamp for the common cases — only genuinely custom dates
 * fall back to the text field next to it.
 */
@Composable
private fun DurationPicker(selectedMillisFromNow: Long?, onPick: (Long?) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items(DurationOptions, key = { it.label }) { option ->
            val selected = option.millis == selectedMillisFromNow
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selected) BrightCyan.copy(alpha = 0.18f) else CyberSurfaceVariant)
                    .border(1.dp, if (selected) BrightCyan.copy(alpha = 0.6f) else CyberCardBorder, RoundedCornerShape(8.dp))
                    .clickable { onPick(option.millis) }
                    .padding(horizontal = 11.dp, vertical = 7.dp)
            ) {
                Text(
                    option.label,
                    color = if (selected) BrightCyan else Color(0xFFD1D5DB),
                    fontSize = 10.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

// =====================================================================
// DEVICES TAB
// =====================================================================

private enum class DeviceFilter(val label: String) { ALL("Semua"), ACTIVE("Aktif"), BANNED("Banned") }

@Composable
private fun DevicesTab(manager: AdminControlManager, devices: List<DeviceRecord>, report: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<DeviceRecord?>(null) }
    var selectedIds by remember { mutableStateOf(emptySet<String>()) }
    var filter by remember { mutableStateOf(DeviceFilter.ALL) }
    var bulkBusy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val filtered = devices.filter { device ->
        val q = query.trim().lowercase()
        val matchesQuery = q.isBlank() || listOf(
            device.model, device.manufacturer, device.lastIp, device.id, device.ownerUid, device.ownerEmail, device.lastTool
        ).any { value -> value.lowercase().contains(q) }
        val matchesFilter = when (filter) {
            DeviceFilter.ALL -> true
            DeviceFilter.ACTIVE -> !device.banned
            DeviceFilter.BANNED -> device.banned
        }
        matchesQuery && matchesFilter
    }

    val allVisibleSelected = filtered.isNotEmpty() && filtered.all { it.id in selectedIds }

    fun toggleAllVisible() {
        selectedIds = if (allVisibleSelected) {
            selectedIds - filtered.map { it.id }.toSet()
        } else {
            selectedIds + filtered.map { it.id }
        }
    }

    fun runBulk(name: String, action: suspend () -> Unit) {
        if (bulkBusy || selectedIds.isEmpty()) return
        bulkBusy = true
        scope.launch {
            try {
                action()
                report(name)
                selectedIds = emptySet()
            } catch (t: Throwable) {
                report("Gagal: ${t.message ?: "operasi tidak berhasil"}")
            } finally {
                bulkBusy = false
            }
        }
    }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            query, { query = it }, Modifier.fillMaxWidth(),
            label = { Text("Cari model / IP / hash / email / UID") },
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                if (query.isNotBlank()) {
                    IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, "Clear", tint = MutedGrey, modifier = Modifier.size(16.dp)) }
                }
            }
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(DeviceFilter.entries.toList(), key = { it.name }) { option ->
                val count = when (option) {
                    DeviceFilter.ALL -> devices.size
                    DeviceFilter.ACTIVE -> devices.count { !it.banned }
                    DeviceFilter.BANNED -> devices.count { it.banned }
                }
                FilterChipLike("${option.label} ($count)", filter == option) { filter = option }
            }
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = allVisibleSelected, onCheckedChange = { toggleAllVisible() })
            Text(
                if (selectedIds.isEmpty()) "Pilih device untuk aksi massal" else "${selectedIds.size} device dipilih",
                color = if (selectedIds.isEmpty()) MutedGrey else BrightCyan,
                fontSize = 11.sp,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { selectedIds = emptySet() }, enabled = selectedIds.isNotEmpty()) {
                Text("Clear", color = MutedGrey, fontSize = 10.sp)
            }
        }

        if (selectedIds.isNotEmpty()) {
            SectionCard("AKSI MASSAL", Icons.Default.Security, subtitle = "${selectedIds.size} akun/device terpilih") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = {
                            runBulk("Ban massal berhasil diterapkan.") {
                                manager.setDevicesBan(
                                    selectedIds.toList(),
                                    DurationOptions.first { it.label == "7 hari" }.millis,
                                    "Ban massal oleh admin",
                                    "Akses perangkat dikunci sementara oleh admin."
                                )
                            }
                        },
                        enabled = !bulkBusy,
                        modifier = Modifier.weight(1f)
                    ) { Text("Ban 7d", color = BrightRed, fontSize = 10.sp) }

                    OutlinedButton(
                        onClick = { runBulk("Device terpilih berhasil dihapus bersama securityEvents lama.") { manager.deleteDevices(selectedIds.toList()) } },
                        enabled = !bulkBusy,
                        modifier = Modifier.weight(1f)
                    ) { Text("Hapus", color = BrightRed, fontSize = 10.sp) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = {
                            val emails = filtered.filter { it.id in selectedIds }.map { it.ownerEmail }.filter { it.isNotBlank() }.distinct()
                            if (emails.isEmpty()) {
                                report("Tidak ada email user yang tersimpan pada selection ini.")
                            } else {
                                runBulk("Permintaan reset password dikirim ke ${emails.size} email.") {
                                    emails.forEach { manager.sendPasswordResetForAccount(it) }
                                }
                            }
                        },
                        enabled = !bulkBusy,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Reset password", color = BrightCyan, fontSize = 10.sp) }
                }
            }
        }

        if (filtered.isEmpty()) {
            EmptyState(Icons.Default.PhoneAndroid, "Tidak ada device yang cocok", "Coba ubah kata kunci atau filter di atas.")
        } else {
            LazyColumn(Modifier.fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered, key = { it.id }) { device ->
                    DeviceCard(
                        device = device,
                        selected = device.id in selectedIds,
                        onToggleSelected = {
                            selectedIds = if (device.id in selectedIds) selectedIds - device.id else selectedIds + device.id
                        },
                        onClick = { selected = device }
                    )
                }
            }
        }
    }

    selected?.let { device ->
        DeviceDetailDialog(
            manager = manager,
            device = device,
            onClose = { selected = null },
            report = report
        )
    }
}

@Composable
private fun DeviceDetailDialog(manager: AdminControlManager, device: DeviceRecord, onClose: () -> Unit, report: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var reason by remember(device.id) { mutableStateOf(device.banReason) }
    var warning by remember(device.id) { mutableStateOf(device.banWarning) }
    var banDurationMillis by remember(device.id) { mutableStateOf<Long?>(DurationOptions.first { it.label == "7 hari" }.millis) }
    var busyAction by remember { mutableStateOf<String?>(null) }
    var showResetConfirm by remember { mutableStateOf(false) }

    fun runDialogAction(name: String, action: suspend () -> Unit, success: String, closeAfter: Boolean = false) {
        busyAction = name
        scope.launch {
            try {
                action()
                report(success)
                if (closeAfter) onClose()
            } catch (t: Throwable) {
                report("Gagal: ${t.message ?: "operasi tidak berhasil"}")
            }
            busyAction = null
        }
    }

    AlertDialog(
        onDismissRequest = onClose,
        containerColor = CyberDarkNavy,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (device.banned) Icons.Default.Block else Icons.Default.CheckCircle,
                    null, tint = if (device.banned) BrightRed else BrightGreen, modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("${device.manufacturer} ${device.model}".trim().ifBlank { "Unknown device" }, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("${device.id.take(16)}…", color = MutedGrey, fontSize = 10.sp)
                }
                IconButton(onClick = {
                    clipboard.setText(AnnotatedString(device.id))
                    report("Device hash disalin ke clipboard.")
                }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.ContentCopy, "Copy device hash", tint = MutedGrey, modifier = Modifier.size(14.dp))
                }
            }
        },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                InfoGrid(
                    listOf(
                        "Android" to "${device.androidVersion} • SDK ${device.sdkInt}",
                        "App" to device.appVersion,
                        "Owner UID" to device.ownerUid.ifBlank { "-" },
                        "Email" to device.ownerEmail.ifBlank { "tidak tersimpan" },
                        "IP terakhir" to device.lastIp.ifBlank { "tidak tersedia" },
                        "Tool terakhir" to "${device.lastTool.ifBlank { "-" }} (${device.totalToolUses}x)",
                        "Last seen" to formatMillis(device.lastSeenAt).ifBlank { "-" }
                    )
                )
                StatusPillRow(device)
                if (device.violationCount > 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth().background(BrightAmber.copy(alpha = 0.08f), RoundedCornerShape(8.dp)).padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, null, tint = BrightAmber, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("${device.violationCount} violation • ${device.lastViolation}", color = BrightAmber, fontSize = 10.sp)
                    }
                }
                if (device.toolUsage.isNotEmpty()) {
                    Text(
                        "Usage: ${device.toolUsage.entries.sortedByDescending { it.value }.joinToString { "${it.key}=${it.value}" }}",
                        color = MutedGrey, fontSize = 10.sp
                    )
                }

                Divider()

                Text("BAN CONTROL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                OutlinedTextField(reason, { reason = it.take(500) }, Modifier.fillMaxWidth(), label = { Text("Reason ban custom") })
                OutlinedTextField(warning, { warning = it.take(500) }, Modifier.fillMaxWidth(), label = { Text("Peringatan custom") })
                Text("Durasi ban", color = MutedGrey, fontSize = 10.sp)
                DurationPicker(banDurationMillis) { banDurationMillis = it }

                Divider()

                OutlinedButton(
                    onClick = { showResetConfirm = true },
                    enabled = busyAction == null && device.ownerEmail.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Kirim reset password", color = BrightCyan, fontSize = 10.sp)
                }
                if (device.ownerEmail.isBlank()) {
                    Text("Email user belum tersimpan pada device lama; gunakan Firebase Console/Admin SDK untuk reset akun tersebut.", color = MutedGrey, fontSize = 9.sp)
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(
                    onClick = { runDialogAction("unban", { manager.unbanDevice(device.id) }, "Device berhasil di-unban.", closeAfter = true) },
                    enabled = busyAction == null
                ) { Text("Unban", color = BrightGreen) }
                TextButton(
                    onClick = {
                        runDialogAction("ban", { manager.setDeviceBan(device.id, banDurationMillis, reason, warning) }, "Ban device diterapkan realtime.", closeAfter = true)
                    },
                    enabled = busyAction == null
                ) { Text("Ban", color = BrightRed) }
                TextButton(
                    onClick = {
                        runDialogAction("delete", { manager.deleteDevices(listOf(device.id)) }, "Device dan securityEvents berhasil dihapus.", closeAfter = true)
                    },
                    enabled = busyAction == null
                ) { Text("Hapus", color = BrightRed) }
            }
        }
    )

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            containerColor = CyberDarkNavy,
            title = { Text("Kirim reset password?", color = Color.White) },
            text = { Text(device.ownerEmail, color = MutedGrey) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showResetConfirm = false
                        runDialogAction("reset", { manager.sendPasswordResetForAccount(device.ownerEmail) }, "Email reset password berhasil diminta.")
                    },
                    enabled = busyAction == null
                ) { Text("Kirim", color = BrightCyan) }
            },
            dismissButton = { TextButton(onClick = { showResetConfirm = false }) { Text("Batal", color = MutedGrey) } }
        )
    }
}

// =====================================================================
// BUGS TAB
// =====================================================================

private enum class BugFilter(val label: String) { OPEN("Open"), REVIEWING("Reviewing"), RESOLVED("Resolved"), IGNORED("Ignored"), ALL("Semua") }

@Composable
private fun BugsTab(manager: AdminControlManager, bugs: List<BugReportRecord>, report: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(BugFilter.OPEN) }
    var fatalOnly by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<BugReportRecord?>(null) }

    val filtered = bugs.filter { bug ->
        val q = query.trim().lowercase()
        val matchesQuery = q.isBlank() || listOf(bug.moduleContext, bug.message, bug.model, bug.publicIp, bug.deviceIdHash, bug.status)
            .any { value -> value.lowercase().contains(q) }
        val matchesFilter = filter == BugFilter.ALL || bug.status == filter.label.lowercase()
        val matchesSeverity = !fatalOnly || bug.severity == "fatal"
        matchesQuery && matchesFilter && matchesSeverity
    }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        StatsStripBugs(bugs)
        OutlinedTextField(
            query, { query = it }, Modifier.fillMaxWidth(),
            label = { Text("Cari bug / module / IP / device") },
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                if (query.isNotBlank()) {
                    IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, "Clear", tint = MutedGrey, modifier = Modifier.size(16.dp)) }
                }
            }
        )
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            LazyRow(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(BugFilter.entries.toList(), key = { it.name }) { option ->
                    val count = if (option == BugFilter.ALL) bugs.size else bugs.count { it.status == option.label.lowercase() }
                    FilterChipLike("${option.label} ($count)", filter == option) { filter = option }
                }
            }
            Spacer(Modifier.width(6.dp))
            FilterChipLike("Fatal", fatalOnly) { fatalOnly = !fatalOnly }
        }
        if (filtered.isEmpty()) {
            EmptyState(Icons.Default.BugReport, "Tidak ada bug report", "Semua bersih untuk filter ini — coba longgarkan pencarian.")
        } else {
            LazyColumn(Modifier.fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered, key = { it.id }) { bug -> BugCard(bug) { selected = bug } }
            }
        }
    }

    selected?.let { bug -> BugDetailDialog(manager, bug, { selected = null }, report) }
}

@Composable
private fun StatsStripBugs(bugs: List<BugReportRecord>) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        MiniStat("OPEN", "${bugs.count { it.status == "open" }}", BrightRed, Modifier.weight(1f))
        MiniStat("REVIEWING", "${bugs.count { it.status == "reviewing" }}", BrightAmber, Modifier.weight(1f))
        MiniStat("RESOLVED", "${bugs.count { it.status == "resolved" }}", BrightGreen, Modifier.weight(1f))
        MiniStat("FATAL", "${bugs.count { it.severity == "fatal" }}", BrightRed, Modifier.weight(1f))
    }
}

@Composable
private fun BugDetailDialog(manager: AdminControlManager, bug: BugReportRecord, onClose: () -> Unit, report: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var busyStatus by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onClose,
        containerColor = CyberDarkNavy,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.BugReport, null, tint = if (bug.severity == "fatal") BrightRed else BrightAmber, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("BUG DETAIL", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(bug.status.uppercase(), color = statusColor(bug.status), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 650.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(bug.moduleContext.ifBlank { "Unknown module" }, color = BrightCyan, fontWeight = FontWeight.Bold)
                Text(bug.message.ifBlank { "Tidak ada pesan" }, color = Color.White, fontSize = 13.sp)
                InfoGrid(
                    listOf(
                        "Severity" to bug.severity,
                        "HTTP" to (bug.httpStatusCode?.toString() ?: "-"),
                        "Model" to bug.model.ifBlank { "Unknown" },
                        "Android" to bug.androidVersion.ifBlank { "?" },
                        "App" to bug.appVersion,
                        "IP" to bug.publicIp.ifBlank { "tidak tersedia" }
                    )
                )
                Text("Device: ${bug.deviceIdHash}", color = MutedGrey, fontSize = 9.sp)
                if (bug.hostAlias.isNotBlank()) Text("Host: ${bug.hostAlias}", color = MutedGrey, fontSize = 10.sp)

                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text("STACK TRACE", color = BrightAmber, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(bug.stackTrace.ifBlank { bug.message }))
                        report("Stack trace disalin ke clipboard.")
                    }) {
                        Icon(Icons.Default.ContentCopy, null, tint = BrightCyan, modifier = Modifier.size(13.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Copy", color = BrightCyan, fontSize = 11.sp)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = CyberBlack), shape = RoundedCornerShape(8.dp)) {
                    Text(
                        bug.stackTrace.ifBlank { "(stack trace kosong)" },
                        Modifier.padding(10.dp).heightIn(max = 260.dp).verticalScroll(rememberScrollState()),
                        color = Color(0xFFD1D5DB),
                        fontSize = 9.sp
                    )
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("reviewing", "resolved", "ignored").forEach { status ->
                    TextButton(
                        onClick = {
                            busyStatus = status
                            scope.launch {
                                try {
                                    manager.setBugStatus(bug.id, status)
                                    report("Bug ditandai $status.")
                                    onClose()
                                } catch (t: Throwable) {
                                    report("Gagal update bug: ${t.message}")
                                }
                                busyStatus = null
                            }
                        },
                        enabled = busyStatus == null
                    ) {
                        if (busyStatus == status) CircularProgressIndicator(Modifier.size(12.dp), strokeWidth = 2.dp, color = statusColor(status))
                        else Text(status, color = statusColor(status), fontSize = 10.sp)
                    }
                }
            }
        }
    )
}

@Composable
private fun BugCard(bug: BugReportRecord, onOpen: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen).border(1.dp, CyberCardBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(26.dp)
                        .background((if (bug.severity == "fatal") BrightRed else BrightAmber).copy(alpha = 0.14f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.BugReport, null, tint = if (bug.severity == "fatal") BrightRed else BrightAmber, modifier = Modifier.size(14.dp))
                }
                Spacer(Modifier.width(8.dp))
                Text(bug.moduleContext.ifBlank { "Unknown module" }, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), fontSize = 13.sp)
                StatusBadge(bug.status.uppercase(), statusColor(bug.status))
            }
            Text(bug.message.ifBlank { "Tidak ada pesan" }, color = Color(0xFFE5E7EB), maxLines = 2, fontSize = 12.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PhoneAndroid, null, tint = MutedGrey, modifier = Modifier.size(11.dp))
                Spacer(Modifier.width(4.dp))
                Text("${bug.model.ifBlank { "Unknown" }} • Android ${bug.androidVersion.ifBlank { "?" }} • IP ${bug.publicIp.ifBlank { "-" }}", color = MutedGrey, fontSize = 10.sp)
            }
            Text("Device ${bug.deviceIdHash.take(16)}… • ${bug.appVersion}", color = Color(0xFF94A3B8), fontSize = 9.sp)
        }
    }
}

// =====================================================================
// ANNOUNCEMENTS TAB
// =====================================================================

@Composable
private fun AnnouncementsTab(manager: AdminControlManager, announcements: List<AnnouncementRecord>, report: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var editingId by remember { mutableStateOf<String?>(null) }
    var context by remember { mutableStateOf(AnnouncementContext.INFORMATION) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var enabled by remember { mutableStateOf(true) }
    var publishing by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    val filtered = announcements.filter {
        query.isBlank() || it.title.lowercase().contains(query.trim().lowercase()) || it.body.lowercase().contains(query.trim().lowercase())
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
        item {
            SectionCard(
                title = if (editingId == null) "PUBLISH PENGUMUMAN" else "EDIT PENGUMUMAN",
                icon = Icons.Default.Campaign,
                subtitle = "Muncul realtime sebagai overlay notifikasi di semua device"
            ) {
                Text("Tipe pengumuman", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    AnnouncementContext.entries.filter { it != AnnouncementContext.UPDATE }.forEach { type ->
                        FilterChipLike(type.label, context == type) { context = type }
                    }
                }
                Text(context.meaning, color = MutedGrey, fontSize = 10.sp)
                OutlinedTextField(
                    title, { title = it.take(120) }, Modifier.fillMaxWidth(),
                    label = { Text("Judul") }, singleLine = true,
                    supportingText = { Text("${title.length}/120", color = MutedGrey, fontSize = 9.sp) }
                )
                OutlinedTextField(
                    body, { body = it.take(4000) }, Modifier.fillMaxWidth(),
                    label = { Text("Isi pengumuman") }, minLines = 4,
                    supportingText = { Text("${body.length}/4000", color = MutedGrey, fontSize = 9.sp) }
                )
                ToggleRow("Aktif", "Announcement terlihat pada client", enabled) { enabled = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            publishing = true
                            scope.launch {
                                try {
                                    manager.publishAnnouncement(editingId, context, title, body, enabled)
                                    report(if (editingId == null) "Announcement dipublish realtime." else "Announcement disimpan realtime.")
                                    editingId = null; title = ""; body = ""; enabled = true; context = AnnouncementContext.INFORMATION
                                } catch (t: Throwable) {
                                    report("Gagal publish: ${t.message}")
                                }
                                publishing = false
                            }
                        },
                        enabled = !publishing && title.isNotBlank() && body.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
                    ) {
                        if (publishing) CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp, color = CyberBlack)
                        else Text(if (editingId == null) "Publish" else "Update")
                    }
                    OutlinedButton(onClick = { editingId = null; title = ""; body = ""; enabled = true; context = AnnouncementContext.INFORMATION }) { Text("Reset") }
                }
            }
        }
        if (announcements.isNotEmpty()) {
            item {
                OutlinedTextField(
                    query, { query = it }, Modifier.fillMaxWidth(),
                    label = { Text("Cari pengumuman") }, singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null, modifier = Modifier.size(16.dp)) }
                )
            }
        }
        if (announcements.isNotEmpty() && filtered.isEmpty()) {
            item { EmptyState(Icons.Default.Campaign, "Tidak ditemukan", "Coba kata kunci lain.") }
        }
        items(filtered, key = { it.id }) { item ->
            Card(Modifier.fillMaxWidth().border(1.dp, CyberCardBorder, RoundedCornerShape(12.dp)), colors = CardDefaults.cardColors(containerColor = CyberDarkNavy), shape = RoundedCornerShape(12.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusBadge(item.context.label.uppercase(), contextColor(item.context))
                        Spacer(Modifier.width(8.dp))
                        Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), fontSize = 13.sp)
                        StatusBadge(if (item.enabled) "ACTIVE" else "HIDDEN", if (item.enabled) BrightGreen else MutedGrey)
                    }
                    Text(item.body, color = Color(0xFFE5E7EB), maxLines = 4, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        TextButton(onClick = { editingId = item.id; context = item.context; title = item.title; body = item.body; enabled = item.enabled }) { Text("Edit") }
                        TextButton(onClick = {
                            scope.launch {
                                try {
                                    manager.publishAnnouncement(item.id, item.context, item.title, item.body, !item.enabled)
                                    report(if (item.enabled) "Announcement disembunyikan." else "Announcement diaktifkan.")
                                } catch (t: Throwable) { report("Gagal toggle announcement: ${t.message}") }
                            }
                        }) { Text(if (item.enabled) "Hide" else "Show", color = BrightAmber) }
                        TextButton(onClick = {
                            scope.launch {
                                try { manager.deleteAnnouncement(item.id); report("Announcement dihapus.") }
                                catch (t: Throwable) { report("Gagal delete: ${t.message}") }
                            }
                        }) { Text("Delete", color = BrightRed) }
                    }
                }
            }
        }
    }
}

// =====================================================================
// SHARED SMALL COMPONENTS
// =====================================================================

@Composable
private fun DeviceCard(device: DeviceRecord, selected: Boolean, onToggleSelected: () -> Unit, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).border(1.dp, CyberCardBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(26.dp)
                        .background((if (device.banned) BrightRed else BrightGreen).copy(alpha = 0.14f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(if (device.banned) Icons.Default.Block else Icons.Default.CheckCircle, null, tint = if (device.banned) BrightRed else BrightGreen, modifier = Modifier.size(14.dp))
                }
                Spacer(Modifier.width(8.dp))
                Text("${device.manufacturer} ${device.model}".trim().ifBlank { "Unknown device" }, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), fontSize = 13.sp)
                StatusBadge(if (device.banned) "BAN" else "AKTIF", if (device.banned) BrightRed else BrightGreen)
                Checkbox(checked = selected, onCheckedChange = { onToggleSelected() })
            }
            Text("IP: ${device.lastIp.ifBlank { "-" }} • ${device.androidVersion} • ${device.appVersion}", color = MutedGrey, fontSize = 10.sp)
            Text("Tool: ${device.lastTool.ifBlank { "-" }} • Uses: ${device.totalToolUses} • Violations: ${device.violationCount}", color = MutedGrey, fontSize = 10.sp)
            Text("ID: ${device.id.take(20)}… • ketuk untuk kontrol", color = Color(0xFF94A3B8), fontSize = 9.sp)
        }
    }
}

@Composable
private fun StatusBadge(label: String, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.16f), RoundedCornerShape(6.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp)
    ) {
        Text(label, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StatusPillRow(device: DeviceRecord) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        StatusBadge(if (device.banned) "BANNED" else "ACTIVE", if (device.banned) BrightRed else BrightGreen)
        if (device.banned) {
            StatusBadge(formatMillis(device.banExpiresAt).ifBlank { "PERMANEN" }, BrightRed)
        }
    }
}

@Composable
private fun InfoGrid(pairs: List<Pair<String, String>>) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        pairs.chunked(1).forEach { row ->
            row.forEach { (label, value) ->
                Row(Modifier.fillMaxWidth()) {
                    Text(label, color = MutedGrey, fontSize = 10.sp, modifier = Modifier.width(96.dp))
                    Text(value, color = Color(0xFFE5E7EB), fontSize = 11.sp, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun Divider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(CyberCardBorder))
}

@Composable
private fun EmptyState(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 36.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(icon, null, tint = MutedGrey, modifier = Modifier.size(30.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Text(subtitle, color = MutedGrey, fontSize = 11.sp)
    }
}

@Composable
private fun StatsStrip(active: String, activeColor: Color, tools: Int, apis: Int) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        MiniStat("SYSTEM", active, activeColor, Modifier.weight(1f))
        MiniStat("TOOLS", "$tools/6", BrightCyan, Modifier.weight(1f))
        MiniStat("APIS", "$apis/6", BrightGreen, Modifier.weight(1f))
    }
}

@Composable
private fun MiniStat(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = CyberDarkNavy), shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.padding(9.dp)) {
            Text(label, color = MutedGrey, fontSize = 8.sp)
            Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text(subtitle, color = MutedGrey, fontSize = 9.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = BrightCyan, checkedThumbColor = CyberBlack)
        )
    }
}

@Composable
private fun FilterChipLike(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) BrightCyan.copy(alpha = 0.16f) else CyberSurfaceVariant)
            .border(1.dp, if (selected) BrightCyan.copy(alpha = 0.55f) else CyberCardBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(label, color = if (selected) BrightCyan else Color(0xFFD1D5DB), fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun SectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    subtitle: String? = null,
    content: @Composable () -> Unit
) {
    Card(Modifier.fillMaxWidth().border(1.dp, CyberCardBorder, RoundedCornerShape(12.dp)), colors = CardDefaults.cardColors(containerColor = CyberDarkNavy), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(28.dp).background(BrightCyan.copy(alpha = 0.12f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, null, tint = BrightCyan, modifier = Modifier.size(15.dp))
                }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    if (subtitle != null) Text(subtitle, color = MutedGrey, fontSize = 9.sp)
                }
            }
            content()
        }
    }
}

private fun defaultTools(existing: Map<String, Boolean>): Map<String, Boolean> =
    GlobalToolPolicy.ALL_TOOL_IDS.associateWith { existing[it] ?: true }

private fun defaultApis(existing: Map<String, ApiControlState>): Map<String, ApiControlState> =
    GlobalToolPolicy.ALL_TOOL_IDS.associateWith { existing[it] ?: ApiControlState() }

private fun parseMillis(text: String): Long? = runCatching {
    if (text.isBlank()) null else LocalDateTime.parse(text.trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))
        .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
}.getOrNull()

private fun formatMillis(value: Long?): String = value?.let {
    LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))
}.orEmpty()

private fun contextColor(context: AnnouncementContext): Color = when (context) {
    AnnouncementContext.INFORMATION -> BrightCyan
    AnnouncementContext.WARNING -> BrightAmber
    AnnouncementContext.HARD_WARNING -> BrightRed
    AnnouncementContext.UPDATE -> BrightGreen
}

private fun statusColor(status: String): Color = when (status) {
    "open" -> BrightRed
    "reviewing" -> BrightAmber
    "resolved" -> BrightGreen
    else -> MutedGrey
}

