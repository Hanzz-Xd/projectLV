package com.baklava.projectlv.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp

enum class WindowType {
    Compact,   // Phones in portrait (< 600dp)
    Medium,    // Small tablets, foldables, large landscape phones (600dp - 840dp)
    Expanded   // Tablets, desktops, ultra-wide screens (> 840dp)
}

data class AppWindowSize(
    val widthType: WindowType,
    val heightType: WindowType,
    val screenWidthDp: Int,
    val screenHeightDp: Int
) {
    val isCompact: Boolean get() = widthType == WindowType.Compact
    val isMedium: Boolean get() = widthType == WindowType.Medium
    val isExpanded: Boolean get() = widthType == WindowType.Expanded
}

val LocalAppWindowSize = compositionLocalOf {
    AppWindowSize(WindowType.Compact, WindowType.Compact, 360, 640)
}

@Composable
fun rememberAppWindowSize(): AppWindowSize {
    val config = LocalConfiguration.current
    val widthDp = config.screenWidthDp.dp
    val heightDp = config.screenHeightDp.dp

    val widthType = when {
        widthDp < 600.dp -> WindowType.Compact
        widthDp < 840.dp -> WindowType.Medium
        else -> WindowType.Expanded
    }

    val heightType = when {
        heightDp < 480.dp -> WindowType.Compact
        heightDp < 900.dp -> WindowType.Medium
        else -> WindowType.Expanded
    }

    return AppWindowSize(
        widthType = widthType,
        heightType = heightType,
        screenWidthDp = config.screenWidthDp,
        screenHeightDp = config.screenHeightDp
    )
}
