package com.baklava.projectlv.data.network

import android.util.Log
import okhttp3.Interceptor
import okhttp3.Response
import okio.Buffer
import java.io.IOException

class RedactingLoggingInterceptor(
    private val tag: String = "LeviathanNetwork"
) : Interceptor {

    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val redactedUrl = SecretRedactor.redactUrl(request.url.toString())

        val requestHeadersSanitized = StringBuilder()
        for (i in 0 until request.headers.size) {
            val name = request.headers.name(i)
            val value = SecretRedactor.redactHeader(name, request.headers.value(i))
            requestHeadersSanitized.append("  ").append(name).append(": ").append(value).append("\n")
        }

        var requestBodyString = ""
        val requestBody = request.body
        if (requestBody != null) {
            val buffer = Buffer()
            requestBody.writeTo(buffer)
            val raw = buffer.readUtf8()
            requestBodyString = SecretRedactor.redactBody(raw)
        }

        Log.d(tag, "--> ${request.method} $redactedUrl\n$requestHeadersSanitized${if (requestBodyString.isNotBlank()) "Body: $requestBodyString\n" else ""}--> END ${request.method}")

        val startNs = System.nanoTime()
        val response: Response
        try {
            response = chain.proceed(request)
        } catch (e: Exception) {
            Log.e(tag, "<-- HTTP FAILED: ${SecretRedactor.redactText(e.message ?: "Unknown network error")}")
            throw e
        }

        val tookMs = (System.nanoTime() - startNs) / 1_000_000
        val responseHeadersSanitized = StringBuilder()
        for (i in 0 until response.headers.size) {
            val name = response.headers.name(i)
            val value = SecretRedactor.redactHeader(name, response.headers.value(i))
            responseHeadersSanitized.append("  ").append(name).append(": ").append(value).append("\n")
        }

        Log.d(tag, "<-- ${response.code} ${response.message} (${tookMs}ms) for $redactedUrl\n$responseHeadersSanitized<-- END HTTP")

        return response
    }
}
