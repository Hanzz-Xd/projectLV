package com.baklava.projectlv.ui.modules.pyobfuscator

/**
 * Diff baris sederhana berbasis Longest Common Subsequence (LCS), murni
 * Kotlin tanpa dependency eksternal. Cukup untuk highlight baris yang
 * ditambahkan/dihapus/sama antara kode Python asli dan hasil obfuscate,
 * tanpa perlu menambah library diff pihak ketiga ke project.
 */
object LineDiffer {

    enum class LineType { SAME, ADDED, REMOVED }

    data class DiffLine(
        val type: LineType,
        val originalLineNumber: Int?,
        val modifiedLineNumber: Int?,
        val text: String
    )

    /**
     * Menghasilkan diff unified (satu kolom, urut) antara [original] dan [modified].
     * Baris yang identik ditandai SAME, baris yang hanya ada di [original]
     * ditandai REMOVED, baris yang hanya ada di [modified] ditandai ADDED.
     */
    fun diffLines(original: String, modified: String): List<DiffLine> {
        val a = original.split("\n")
        val b = modified.split("\n")
        val n = a.size
        val m = b.size

        // Tabel LCS panjang, dibatasi ukurannya agar tidak meledak memori
        // untuk file yang sangat besar (fallback ke diff kasar bila terlalu besar).
        if (n.toLong() * m.toLong() > 4_000_000L) {
            return coarseDiff(a, b)
        }

        val dp = Array(n + 1) { IntArray(m + 1) }
        for (i in n - 1 downTo 0) {
            for (j in m - 1 downTo 0) {
                dp[i][j] = if (a[i] == b[j]) {
                    dp[i + 1][j + 1] + 1
                } else {
                    maxOf(dp[i + 1][j], dp[i][j + 1])
                }
            }
        }

        val result = ArrayList<DiffLine>(n + m)
        var i = 0
        var j = 0
        while (i < n && j < m) {
            when {
                a[i] == b[j] -> {
                    result += DiffLine(LineType.SAME, i + 1, j + 1, a[i])
                    i++; j++
                }
                dp[i + 1][j] >= dp[i][j + 1] -> {
                    result += DiffLine(LineType.REMOVED, i + 1, null, a[i])
                    i++
                }
                else -> {
                    result += DiffLine(LineType.ADDED, null, j + 1, b[j])
                    j++
                }
            }
        }
        while (i < n) { result += DiffLine(LineType.REMOVED, i + 1, null, a[i]); i++ }
        while (j < m) { result += DiffLine(LineType.ADDED, null, j + 1, b[j]); j++ }

        return result
    }

    /** Fallback murah untuk source sangat besar: tidak mencari LCS optimal, hanya bandingkan berurutan. */
    private fun coarseDiff(a: List<String>, b: List<String>): List<DiffLine> {
        val result = ArrayList<DiffLine>(a.size + b.size)
        val common = minOf(a.size, b.size)
        for (k in 0 until common) {
            if (a[k] == b[k]) {
                result += DiffLine(LineType.SAME, k + 1, k + 1, a[k])
            } else {
                result += DiffLine(LineType.REMOVED, k + 1, null, a[k])
                result += DiffLine(LineType.ADDED, null, k + 1, b[k])
            }
        }
        for (k in common until a.size) result += DiffLine(LineType.REMOVED, k + 1, null, a[k])
        for (k in common until b.size) result += DiffLine(LineType.ADDED, null, k + 1, b[k])
        return result
    }

    data class DiffStats(val added: Int, val removed: Int, val unchanged: Int)

    fun stats(diff: List<DiffLine>): DiffStats {
        var added = 0
        var removed = 0
        var same = 0
        for (line in diff) {
            when (line.type) {
                LineType.ADDED -> added++
                LineType.REMOVED -> removed++
                LineType.SAME -> same++
            }
        }
        return DiffStats(added, removed, same)
    }
}
