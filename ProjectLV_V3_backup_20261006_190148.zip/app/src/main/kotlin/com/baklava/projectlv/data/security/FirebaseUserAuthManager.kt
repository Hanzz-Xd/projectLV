package com.baklava.projectlv.data.security

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * Firebase Email/Password authentication for ProjectLV.
 * Anonymous Auth is intentionally not used.
 */
class FirebaseUserAuthManager(context: Context) {
    private val appContext = context.applicationContext
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val firestore by lazy { FirebaseFirestore.getInstance() }

    private val enabled: Boolean
        get() = FirebaseApp.getApps(appContext).isNotEmpty()

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    /**
     * Password yang diketik pengguna pada sesi aplikasi ini. Hanya disimpan di memori
     * (tidak pernah ditulis ke disk/Firestore) supaya bisa ditampilkan di halaman Akun.
     * Firebase sendiri tidak pernah bisa mengembalikan password, jadi setelah aplikasi
     * dibuka ulang dengan sesi tersimpan nilainya kosong sampai pengguna masuk ulang
     * atau mengganti password.
     */
    @Volatile
    private var sessionPassword: String? = null

    fun knownPassword(): String? = sessionPassword

    fun observeAuthState(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        trySend(auth.currentUser)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    suspend fun signIn(email: String, password: String) {
        require(enabled) { "Firebase belum dikonfigurasi." }
        val normalizedEmail = email.trim().lowercase()
        require(normalizedEmail.isNotBlank()) { "Email wajib diisi." }
        require(password.isNotEmpty()) { "Password wajib diisi." }
        auth.signInWithEmailAndPassword(normalizedEmail, password).await()
        val user = requireNotNull(auth.currentUser)
        user.reload().await()
        if (!user.isEmailVerified) {
            throw EmailVerificationRequiredException(user.email.orEmpty())
        }
        user.getIdToken(true).await()
        sessionPassword = password
        syncAccountEmail(user)
    }

    suspend fun register(email: String, password: String, name: String) {
        require(enabled) { "Firebase belum dikonfigurasi." }
        val normalizedEmail = email.trim().lowercase()
        val cleanName = validateName(name)
        require(normalizedEmail.isNotBlank()) { "Email wajib diisi." }
        require(password.length >= 8) { "Password minimal 8 karakter." }
        require(password.any(Char::isUpperCase)) { "Password harus memiliki minimal 1 huruf kapital." }
        require(password.any(Char::isDigit)) { "Password harus memiliki minimal 1 angka." }

        auth.createUserWithEmailAndPassword(normalizedEmail, password).await()
        val user = requireNotNull(auth.currentUser)
        user.updateProfile(profileRequest(cleanName)).await()
        user.reload().await()
        sessionPassword = password

        // Provision the account record before verification is completed. The
        // Firestore rules only allow this exact UID/email pair to create it.
        firestore.collection("accounts").document(user.uid).set(
            mapOf(
                "ownerUid" to user.uid,
                "email" to normalizedEmail,
                "name" to cleanName,
                "locked" to false,
                "lockReason" to "",
                "emailVerified" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        ).await()

        user.sendEmailVerification().await()
    }

    suspend fun resendVerification() {
        require(enabled) { "Firebase belum dikonfigurasi." }
        val user = auth.currentUser ?: error("Login terlebih dahulu.")
        user.reload().await()
        if (user.isEmailVerified) return
        user.sendEmailVerification().await()
    }

    suspend fun refreshVerificationState(): Boolean {
        val user = auth.currentUser ?: return false
        user.reload().await()
        if (user.isEmailVerified) {
            // Refresh the ID token so Firestore sees email_verified=true.
            // Verification state is trusted from Firebase Auth, not from a
            // client-controlled Firestore field.
            user.getIdToken(true).await()
        }
        return user.isEmailVerified
    }

    suspend fun signOut() {
        sessionPassword = null
        auth.signOut()
    }

    suspend fun sendPasswordResetEmail(email: String) {
        require(enabled) { "Firebase belum dikonfigurasi." }
        val normalizedEmail = email.trim().lowercase()
        require(normalizedEmail.isNotBlank()) { "Email wajib diisi." }
        auth.sendPasswordResetEmail(normalizedEmail).await()
    }

    // ------------------------------------------------------------------
    // Manajemen akun (halaman Setelan → Lihat Akun)
    // ------------------------------------------------------------------

    /** Mengganti nama tampilan. Nama disimpan di profil Firebase Auth dan (best effort) di Firestore. */
    suspend fun updateDisplayName(name: String): String {
        require(enabled) { "Firebase belum dikonfigurasi." }
        val user = auth.currentUser ?: error("Login terlebih dahulu.")
        val cleanName = validateName(name)
        user.updateProfile(profileRequest(cleanName)).await()
        user.reload().await()
        runCatching {
            firestore.collection("accounts").document(user.uid).set(
                mapOf(
                    "name" to cleanName,
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
        }
        return cleanName
    }

    /** Mengganti password. Wajib memasukkan password saat ini (re-autentikasi). */
    suspend fun changePassword(currentPassword: String, newPassword: String) {
        require(enabled) { "Firebase belum dikonfigurasi." }
        val user = auth.currentUser ?: error("Login terlebih dahulu.")
        val email = user.email.orEmpty()
        require(email.isNotBlank()) { "Akun tidak memiliki email." }
        require(currentPassword.isNotEmpty()) { "Password saat ini wajib diisi." }
        require(newPassword.length >= 8) { "Password baru minimal 8 karakter." }
        require(newPassword.any(Char::isUpperCase)) { "Password baru harus memiliki minimal 1 huruf kapital." }
        require(newPassword.any(Char::isDigit)) { "Password baru harus memiliki minimal 1 angka." }
        require(newPassword != currentPassword) { "Password baru tidak boleh sama dengan password lama." }

        user.reauthenticate(EmailAuthProvider.getCredential(email, currentPassword)).await()
        user.updatePassword(newPassword).await()
        sessionPassword = newPassword
    }

    /**
     * Mengganti email. Firebase mengirim link verifikasi ke email BARU; email baru baru berlaku
     * setelah link tersebut dibuka. Wajib memasukkan password saat ini (re-autentikasi).
     */
    suspend fun requestEmailChange(currentPassword: String, newEmail: String) {
        require(enabled) { "Firebase belum dikonfigurasi." }
        val user = auth.currentUser ?: error("Login terlebih dahulu.")
        val oldEmail = user.email.orEmpty()
        val normalized = newEmail.trim().lowercase()
        require(currentPassword.isNotEmpty()) { "Password saat ini wajib diisi." }
        require(normalized.contains("@") && normalized.contains(".")) { "Masukkan alamat email yang valid." }
        require(normalized != oldEmail.lowercase()) { "Email baru sama dengan email saat ini." }

        user.reauthenticate(EmailAuthProvider.getCredential(oldEmail, currentPassword)).await()
        user.verifyBeforeUpdateEmail(normalized).await()
    }

    /** Memuat ulang data akun dari server (mis. setelah email baru diverifikasi). */
    suspend fun reloadUser() {
        auth.currentUser?.reload()?.await()
        auth.currentUser?.let { syncAccountEmail(it) }
    }

    private fun profileRequest(name: String): UserProfileChangeRequest =
        UserProfileChangeRequest.Builder().setDisplayName(name).build()

    private fun validateName(raw: String): String {
        val clean = raw.trim().replace(Regex("\\s+"), " ")
        require(clean.length >= 2) { "Nama minimal 2 karakter." }
        require(clean.length <= 40) { "Nama maksimal 40 karakter." }
        return clean
    }

    /** Menyamakan field email di Firestore dengan email Auth setelah pergantian email. */
    private suspend fun syncAccountEmail(user: FirebaseUser) {
        val email = user.email?.lowercase().orEmpty()
        if (email.isBlank()) return
        runCatching {
            firestore.collection("accounts").document(user.uid).set(
                mapOf(
                    "email" to email,
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
        }
    }

    class EmailVerificationRequiredException(val address: String) : Exception(
        "Email belum terverifikasi. Silakan verifikasi email terlebih dahulu."
    )
}
