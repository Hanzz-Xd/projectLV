package com.baklava.projectlv.ui.auth

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import com.baklava.projectlv.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import com.baklava.projectlv.ui.components.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import com.baklava.projectlv.ui.components.IconButton
import com.baklava.projectlv.ui.components.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import com.baklava.projectlv.ui.components.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.R
import com.baklava.projectlv.data.security.FirebaseUserAuthManager
import com.baklava.projectlv.ui.components.staggeredEntrance
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.BrightMagenta
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(authManager: FirebaseUserAuthManager) {
    var registerMode by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var confirmVisible by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var verificationPending by remember { mutableStateOf(authManager.currentUser?.isEmailVerified == false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(authManager.currentUser?.uid) {
        verificationPending = authManager.currentUser?.isEmailVerified == false
    }

    fun submit() {
        if (loading) return
        error = null
        info = null
        val normalized = email.trim()
        val cleanName = name.trim().replace(Regex("\\s+"), " ")
        if (registerMode && cleanName.length < 2) {
            error = "Nama minimal 2 karakter."
            return
        }
        if (!normalized.contains("@")) {
            error = "Masukkan alamat email yang valid."
            return
        }
        if (password.isBlank()) {
            error = "Password wajib diisi."
            return
        }
        if (registerMode) {
            if (password.length < 8 || !password.any(Char::isUpperCase) || !password.any(Char::isDigit)) {
                error = "Password minimal 8 karakter, 1 huruf kapital, dan 1 angka."
                return
            }
            if (password != confirmPassword) {
                error = "Konfirmasi password tidak cocok."
                return
            }
        }

        loading = true
        scope.launch {
            try {
                if (registerMode) {
                    authManager.register(normalized, password, cleanName)
                    verificationPending = true
                    info = "Akun dibuat. Buka email verifikasi, lalu kembali ke sini dan masuk."
                } else {
                    authManager.signIn(normalized, password)
                }
            } catch (t: FirebaseUserAuthManager.EmailVerificationRequiredException) {
                verificationPending = true
                error = t.message
            } catch (t: Throwable) {
                error = friendlyAuthError(t)
            } finally {
                loading = false
            }
        }
    }

    fun resendVerification() {
        if (loading) return
        loading = true
        error = null
        info = null
        scope.launch {
            try {
                authManager.resendVerification()
                info = "Email verifikasi berhasil dikirim ulang. Periksa Inbox/Spam."
            } catch (t: Throwable) {
                error = friendlyAuthError(t)
            } finally {
                loading = false
            }
        }
    }

    fun checkVerification() {
        if (loading) return
        loading = true
        error = null
        info = null
        scope.launch {
            try {
                val verified = authManager.refreshVerificationState()
                if (verified) {
                    verificationPending = false
                    info = "Email sudah terverifikasi. Silakan masuk kembali."
                    authManager.signOut()
                } else {
                    verificationPending = true
                    info = "Belum terverifikasi. Selesaikan verifikasi melalui email terlebih dahulu."
                }
            } catch (t: Throwable) {
                error = friendlyAuthError(t)
            } finally {
                loading = false
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 460.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .imePadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AuthLogoHeader(
                verificationPending = verificationPending,
                modifier = Modifier.staggeredEntrance(index = 0, offsetY = 30.dp, durationMs = 700, startScale = 0.85f)
            )

            Spacer(Modifier.height(18.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(22.dp)),
                colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CyberSurfaceVariant, RoundedCornerShape(12.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        AuthModeButton("Masuk", !registerMode) {
                            registerMode = false
                            error = null
                            info = null
                        }
                        AuthModeButton("Daftar", registerMode) {
                            registerMode = true
                            error = null
                            info = null
                        }
                    }

                    AnimatedVisibility(
                        visible = verificationPending && authManager.currentUser != null,
                        enter = fadeIn(tween(300)) + expandVertically(tween(300)),
                        exit = fadeOut(tween(200)) + shrinkVertically(tween(200))
                    ) {
                        Box(Modifier.padding(top = 12.dp)) {
                            VerificationCard(
                                email = authManager.currentUser?.email.orEmpty().ifBlank { email },
                                loading = loading,
                                onResend = ::resendVerification,
                                onCheck = ::checkVerification
                            )
                        }
                    }

                    AnimatedVisibility(
                        visible = registerMode,
                        enter = fadeIn(tween(300)) + expandVertically(tween(300)),
                        exit = fadeOut(tween(200)) + shrinkVertically(tween(200))
                    ) {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it.take(40); error = null },
                            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                            label = { Text("Nama") },
                            leadingIcon = { Icon(Icons.Default.Person, null, tint = MutedGrey) },
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                            singleLine = true,
                            enabled = !loading
                        )
                    }

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it.take(320); error = null },
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                        label = { Text("Email") },
                        leadingIcon = { Icon(Icons.Default.Email, null, tint = MutedGrey) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true,
                        enabled = !loading
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it.take(128); error = null },
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                        label = { Text("Password") },
                        leadingIcon = { Icon(Icons.Default.Lock, null, tint = MutedGrey) },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    if (passwordVisible) "Sembunyikan password" else "Tampilkan password",
                                    tint = MutedGrey
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        enabled = !loading
                    )

                    AnimatedVisibility(
                        visible = registerMode,
                        enter = fadeIn(tween(300)) + expandVertically(tween(300)),
                        exit = fadeOut(tween(200)) + shrinkVertically(tween(200))
                    ) {
                        Column(
                            modifier = Modifier.padding(top = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            PasswordRuleHint(password)
                            OutlinedTextField(
                                value = confirmPassword,
                                onValueChange = { confirmPassword = it.take(128); error = null },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Konfirmasi password") },
                                trailingIcon = {
                                    IconButton(onClick = { confirmVisible = !confirmVisible }) {
                                        Icon(
                                            if (confirmVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            null,
                                            tint = MutedGrey
                                        )
                                    }
                                },
                                visualTransformation = if (confirmVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                singleLine = true,
                                enabled = !loading
                            )
                        }
                    }

                    StatusMessage(error = error, info = info)

                    Button(
                        onClick = ::submit,
                        modifier = Modifier.fillMaxWidth().padding(top = 14.dp).height(48.dp),
                        enabled = !loading,
                        colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (loading) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = CyberBlack)
                        } else {
                            AnimatedContent(
                                targetState = registerMode,
                                transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
                                label = "submit_label"
                            ) { isRegister ->
                                Text(if (isRegister) "BUAT AKUN" else "MASUK", fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }

                    AnimatedVisibility(
                        visible = !registerMode,
                        enter = fadeIn(tween(300)) + expandVertically(tween(300)),
                        exit = fadeOut(tween(200)) + shrinkVertically(tween(200))
                    ) {
                        TextButton(
                            onClick = {
                                if (email.isBlank()) {
                                    error = "Masukkan email terlebih dahulu."
                                    return@TextButton
                                }
                                loading = true
                                error = null
                                info = null
                                scope.launch {
                                    try {
                                        authManager.sendPasswordResetEmail(email)
                                        info = "Email reset password sudah dikirim."
                                    } catch (t: Throwable) {
                                        error = friendlyAuthError(t)
                                    } finally {
                                        loading = false
                                    }
                                }
                            },
                            enabled = !loading,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Lupa password?", color = BrightCyan, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Header login: foto splash_logo + nama aplikasi, dengan cincin cahaya berdenyut halus.
 */
@Composable
private fun AuthLogoHeader(verificationPending: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "auth_logo")
    val glow by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "auth_logo_glow"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .size(132.dp)
                    .graphicsLayer {
                        alpha = 0.55f * glow
                        scaleX = 0.88f + 0.12f * glow
                        scaleY = 0.88f + 0.12f * glow
                    }
                    .background(
                        Brush.radialGradient(listOf(BrightCyan.copy(alpha = 0.35f), Color.Transparent)),
                        CircleShape
                    )
            )
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .border(
                        2.dp,
                        Brush.linearGradient(
                            listOf(
                                BrightCyan.copy(alpha = 0.5f + 0.5f * glow),
                                BrightMagenta.copy(alpha = 0.5f + 0.5f * glow)
                            )
                        ),
                        RoundedCornerShape(26.dp)
                    )
            ) {
                Image(
                    painter = painterResource(id = R.drawable.splash_logo),
                    contentDescription = "Project Leviathan",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        Text(
            "PROJECT-LEVIATHAN",
            color = Color.White,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 22.sp,
            letterSpacing = 1.5.sp,
            textAlign = TextAlign.Center
        )

        Spacer(Modifier.height(2.dp))

        AnimatedContent(
            targetState = verificationPending,
            transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(200)) },
            label = "auth_subtitle"
        ) { pending ->
            Text(
                if (pending) "Verifikasi email diperlukan" else "Masuk atau buat akun untuk melanjutkan",
                color = if (pending) BrightCyan else MutedGrey,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun RowScope.AuthModeButton(label: String, selected: Boolean, onClick: () -> Unit) {
    val background by animateColorAsState(
        targetValue = if (selected) BrightCyan.copy(alpha = 0.14f) else Color.Transparent,
        animationSpec = tween(280),
        label = "tab_bg"
    )
    val foreground by animateColorAsState(
        targetValue = if (selected) BrightCyan else MutedGrey,
        animationSpec = tween(280),
        label = "tab_fg"
    )
    TextButton(
        onClick = onClick,
        modifier = Modifier.weight(1f).background(background, RoundedCornerShape(9.dp)),
        shape = RoundedCornerShape(9.dp)
    ) {
        Text(label, color = foreground, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun VerificationCard(email: String, loading: Boolean, onResend: () -> Unit, onCheck: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = BrightCyan.copy(alpha = 0.07f)),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.border(1.dp, BrightCyan.copy(alpha = 0.22f), RoundedCornerShape(14.dp))
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.MarkEmailRead, null, tint = BrightCyan, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(7.dp))
                Column(Modifier.weight(1f)) {
                    Text("Verifikasi email", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(email.ifBlank { "Email akun" }, color = MutedGrey, fontSize = 10.sp)
                }
            }
            Text(
                "Buka link verifikasi di email, kemudian tekan Cek Verifikasi. Inbox Spam/Junk juga perlu diperiksa.",
                color = MutedGrey,
                fontSize = 10.sp,
                lineHeight = 14.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onResend, enabled = !loading, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Refresh, null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Kirim lagi", fontSize = 11.sp)
                }
                Button(
                    onClick = onCheck,
                    enabled = !loading,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
                ) {
                    Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Cek", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun PasswordRuleHint(password: String) {
    val lengthOk = password.length >= 8
    val upperOk = password.any(Char::isUpperCase)
    val digitOk = password.any(Char::isDigit)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        RulePill("8+", lengthOk)
        RulePill("A-Z", upperOk)
        RulePill("0-9", digitOk)
    }
}

@Composable
private fun RulePill(label: String, ok: Boolean) {
    val color by animateColorAsState(
        targetValue = if (ok) BrightGreen else MutedGrey,
        animationSpec = tween(250),
        label = "rule_pill"
    )
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(label, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

private data class AuthMessage(val text: String, val isError: Boolean)

@Composable
private fun StatusMessage(error: String?, info: String?) {
    val message = error?.let { AuthMessage(it, true) } ?: info?.let { AuthMessage(it, false) }
    AnimatedContent(
        targetState = message,
        transitionSpec = {
            (fadeIn(tween(260)) + expandVertically(tween(260))) togetherWith
                (fadeOut(tween(160)) + shrinkVertically(tween(160)))
        },
        label = "auth_status"
    ) { msg ->
        if (msg != null) {
            val tint = if (msg.isError) BrightRed else BrightGreen
            Row(
                Modifier
                    .padding(top = 12.dp)
                    .fillMaxWidth()
                    .background(tint.copy(alpha = 0.08f), RoundedCornerShape(10.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    if (msg.isError) Icons.Default.Security else Icons.Default.CheckCircle,
                    null,
                    tint = tint,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(Modifier.width(7.dp))
                Text(msg.text, color = tint, fontSize = 10.sp, lineHeight = 14.sp)
            }
        } else {
            Spacer(Modifier.height(0.dp))
        }
    }
}

private fun friendlyAuthError(t: Throwable): String {
    val raw = t.message.orEmpty()
    return when {
        raw.contains("password is invalid", true) || raw.contains("INVALID_LOGIN_CREDENTIALS", true) -> "Email atau password salah."
        raw.contains("email address is already in use", true) -> "Email tersebut sudah terdaftar."
        raw.contains("badly formatted", true) -> "Format email tidak valid."
        raw.contains("network", true) -> "Tidak dapat terhubung ke Firebase. Periksa koneksi internet."
        raw.contains("too many requests", true) -> "Terlalu banyak percobaan. Coba lagi beberapa saat."
        raw.isBlank() -> "Autentikasi gagal."
        else -> raw
    }
}
