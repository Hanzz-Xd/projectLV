package com.baklava.projectlv.ui.maintenance

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.ui.components.Button
import com.baklava.projectlv.ui.components.OutlinedButton
import com.baklava.projectlv.ui.security.ADMIN_TELEGRAM_URL
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberDarkNavy

private const val DEFAULT_MESSAGE =
    "Aplikasi sedang dalam maintenance. Silakan coba lagi beberapa saat lagi."

/**
 * Layar maintenance global layar penuh. Memakai bahasa visual yang sama dengan
 * [com.baklava.projectlv.ui.security.DeviceBlockedScreen] (latar CyberBlack, kartu
 * CyberDarkNavy ber-border merah, tombol Hubungi Admin + OK).
 */
@Composable
fun MaintenanceScreen(
    message: String,
    onOk: () -> Unit = {}
) {
    val context = LocalContext.current
    // ":)" adalah nilai default saat field message belum diisi di Firebase.
    val displayMessage = message.trim().takeIf { it.isNotBlank() && it != ":)" } ?: DEFAULT_MESSAGE

    Box(
        modifier = Modifier.fillMaxSize().background(CyberBlack).padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                .background(CyberDarkNavy).border(2.dp, BrightRed, RoundedCornerShape(18.dp))
                .padding(30.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Build, contentDescription = "Maintenance", tint = BrightRed)
                Spacer(Modifier.height(18.dp))
                Text("MAINTENANCE", color = BrightRed, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
                Spacer(Modifier.height(12.dp))
                Text(
                    displayMessage,
                    color = Color.White,
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center
                )

                Spacer(Modifier.height(26.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            try {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ADMIN_TELEGRAM_URL)))
                            } catch (_: ActivityNotFoundException) {
                                // Tidak ada aplikasi yang bisa membuka link; abaikan.
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Hubungi Admin")
                    }

                    Button(
                        onClick = onOk,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BrightRed,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("OK")
                    }
                }
            }
        }
    }
}
