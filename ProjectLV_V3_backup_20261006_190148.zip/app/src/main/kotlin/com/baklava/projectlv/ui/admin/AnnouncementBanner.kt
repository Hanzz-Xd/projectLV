package com.baklava.projectlv.ui.admin

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import com.baklava.projectlv.ui.components.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.data.admin.AnnouncementContext
import com.baklava.projectlv.data.admin.AnnouncementSeenStore
import com.baklava.projectlv.data.admin.AnnouncementRecord
import com.baklava.projectlv.ui.theme.BrightAmber
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.delay

/**
 * Realtime stacked notification overlay.
 *
 * Renders every currently-active announcement as its own dismissible card,
 * stacked top to bottom, each animating in/out independently as Firestore
 * pushes updates. INFORMATION and UPDATE notices auto-hide after a short
 * delay; WARNING and HARD_WARNING stay until the admin disables them or the
 * user dismisses them. Dismissed ids are remembered for the process lifetime
 * so a notice the user already closed does not reappear on every
 * recomposition/snapshot tick.
 */
@Composable
fun AnnouncementBanner(
    announcements: List<AnnouncementRecord>,
    seenStore: AnnouncementSeenStore,
    uid: String,
    forcedMessage: String? = null,
    onDismiss: (String) -> Unit = {}
) {
    val forced = forcedMessage?.takeIf { it.isNotBlank() }?.let {
        AnnouncementRecord(
            id = "__forced__",
            context = AnnouncementContext.HARD_WARNING,
            title = "SYSTEM NOTICE",
            body = it,
            enabled = true
        )
    }

    // Hanya satu pengumuman global aktif yang ditampilkan. Pengumuman dianggap
    // sudah pernah tampil setelah masuk ke composable, sehingga keluar-masuk
    // Streaming atau activity recreation tidak membuat pesan lama muncul lagi.
    val nextAnnouncement = announcements
        .sortedByDescending { it.updatedAt ?: it.createdAt ?: 0L }
        .firstOrNull { !seenStore.isSeen(uid, it) }

    val item = forced ?: nextAnnouncement ?: return

    LaunchedEffect(uid, item.id, item.updatedAt, item.createdAt) {
        if (item.id != "__forced__") {
            seenStore.markSeen(uid, item)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(top = 6.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        NotificationCard(
            item = item,
            onDismiss = {
                if (item.id != "__forced__") {
                    seenStore.markSeen(uid, item)
                    onDismiss(item.id)
                }
            }
        )
    }
}

@Composable
private fun NotificationCard(item: AnnouncementRecord, onDismiss: () -> Unit) {
    var visible by remember(item.id) { mutableStateOf(false) }

    LaunchedEffect(item.id) {
        visible = true
        // Non-urgent notices self-clear so the overlay never permanently
        // occupies screen space; warnings persist until acted on.
        val autoHideAfter = when (item.context) {
            AnnouncementContext.INFORMATION -> 6000L
            AnnouncementContext.UPDATE -> 8000L
            AnnouncementContext.WARNING, AnnouncementContext.HARD_WARNING -> null
        }
        if (autoHideAfter != null) {
            delay(autoHideAfter)
            visible = false
            delay(220L)
            onDismiss()
        }
    }

    val accent = contextAccent(item.context)
    val icon = contextIcon(item.context)

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(200)) + slideInVertically(tween(220)) { -it / 2 },
        exit = fadeOut(tween(180)) + shrinkVertically(tween(200)) + slideOutVertically(tween(200)) { -it / 3 }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer { shadowElevation = 18f; shape = RoundedCornerShape(14.dp); clip = false }
                .background(CyberDarkNavy.copy(alpha = 0.98f), RoundedCornerShape(14.dp))
                .border(1.dp, accent.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                .padding(start = 14.dp, end = 6.dp, top = 12.dp, bottom = 12.dp)
        ) {
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .background(accent.copy(alpha = 0.14f), RoundedCornerShape(9.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(17.dp))
                }
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(item.context.label.uppercase(), color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text(item.title.ifBlank { "SYSTEM NOTICE" }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(item.body, color = Color(0xFFE5E7EB), fontSize = 12.sp, lineHeight = 16.sp)
                }
                IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup notifikasi", tint = MutedGrey, modifier = Modifier.size(15.dp))
                }
            }
        }
    }
}

private fun contextAccent(context: AnnouncementContext): Color = when (context) {
    AnnouncementContext.INFORMATION -> BrightCyan
    AnnouncementContext.WARNING -> BrightAmber
    AnnouncementContext.HARD_WARNING -> BrightRed
    AnnouncementContext.UPDATE -> BrightGreen
}

private fun contextIcon(context: AnnouncementContext) = when (context) {
    AnnouncementContext.INFORMATION -> Icons.Default.Info
    AnnouncementContext.WARNING -> Icons.Default.Warning
    AnnouncementContext.HARD_WARNING -> Icons.Default.Error
    AnnouncementContext.UPDATE -> Icons.Default.SystemUpdate
}
