package com.baklava.projectlv.ui.modules.alightfinder

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.data.models.AlightMotionFinderResult
import com.baklava.projectlv.data.remote.AlightMotionFinderClient
import com.baklava.projectlv.ui.components.AppWindowSize
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AlightMotionFinderScreen(
    windowSize: AppWindowSize,
    onShowSnackbar: (String) -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val client = remember { AlightMotionFinderClient() }
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<AlightMotionFinderResult?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun copyLink(link: String) {
        clipboard.setText(AnnotatedString(link))
        onShowSnackbar("Link disalin ke clipboard.")
    }

    fun launchLink(link: String) {
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
        }.onFailure {
            onShowSnackbar("Tidak ada aplikasi yang dapat membuka link ini.")
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(CyberBlack),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            horizontal = if (windowSize.isCompact) 12.dp else 24.dp,
            vertical = 16.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = Color.White)
                }
                Column(modifier = Modifier.padding(start = 4.dp)) {
                    Text("ALIGHT MOTION FINDER", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Cari link preset dari posting TikTok", color = MutedGrey, fontSize = 12.sp)
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                border = BorderStroke(1.dp, CyberCardBorder),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        label = { Text("Link TikTok") },
                        placeholder = { Text("https://www.tiktok.com/@.../video/...") }
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val target = input.trim()
                            if (target.isBlank()) {
                                onShowSnackbar("Masukkan link TikTok terlebih dahulu.")
                                return@Button
                            }
                            if (!target.startsWith("http://") && !target.startsWith("https://")) {
                                onShowSnackbar("Link harus diawali http:// atau https://")
                                return@Button
                            }
                            loading = true
                            error = null
                            result = null
                            scope.launch {
                                runCatching { withContext(Dispatchers.IO) { client.find(target) } }
                                    .onSuccess { result = it }
                                    .onFailure { error = it.message ?: "Finder gagal memproses link." }
                                loading = false
                            }
                        },
                        enabled = !loading,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (loading) {
                            CircularProgressIndicator(modifier = Modifier.height(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Search, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("CARI PRESET")
                        }
                    }
                }
            }
        }

        error?.let { message ->
            item {
                Text(
                    text = message,
                    color = Color(0xFFFF6B6B),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        }

        result?.let { data ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                    border = BorderStroke(1.dp, CyberCardBorder),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(data.message, color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text("${data.links.size} link preset ditemukan", color = MutedGrey, fontSize = 12.sp)
                    }
                }
            }

            items(data.links) { link ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                    border = BorderStroke(1.dp, CyberCardBorder),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(link, color = Color.White, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { copyLink(link) }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("SALIN")
                            }
                            Button(onClick = { launchLink(link) }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.OpenInNew, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("BUKA")
                            }
                        }
                    }
                }
            }
        }
    }
}
