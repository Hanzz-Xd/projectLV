package com.baklava.projectlv.ui.modules.pyobfuscator

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import com.baklava.projectlv.ui.components.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Difference
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Terminal
import com.baklava.projectlv.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import com.baklava.projectlv.ui.components.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import com.baklava.projectlv.ui.components.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.data.remote.PyObfuscateClient
import com.baklava.projectlv.data.repository.LeviathanRepository
import com.baklava.projectlv.ui.components.AppWindowSize
import com.baklava.projectlv.ui.components.ModuleHeaderCard
import com.baklava.projectlv.ui.theme.BrightAmber
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.BrightGreenContainer
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.BrightRedContainer
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.launch

private enum class ResultView { HASIL, DIFF }

@Composable
fun PyObfuscatorScreen(
    repository: LeviathanRepository,
    windowSize: AppWindowSize,
    onShowSnackbar: (String) -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    val viewModel = remember { PyObfuscatorViewModel() }
    val uiState by viewModel.state.collectAsState()

    var sourceCode by remember { mutableStateOf("") }
    var options by remember { mutableStateOf(PyObfuscateClient.Options()) }
    var resultView by remember { mutableStateOf(ResultView.DIFF) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
    ) {
        // ------------------------------------------------------------
        // HEADER
        // ------------------------------------------------------------
        ModuleHeaderCard(
            icon = Icons.Default.Terminal,
            title = "PY OBFUSCATOR",
            subtitle = "Khusus source Python · Rename, encrypt, flatten & bandingkan hasilnya",
            modifier = Modifier.padding(16.dp)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            when (val state = uiState) {

                is PyObfuscatorViewModel.UiState.Success -> {
                    ResultSection(
                        state = state,
                        resultView = resultView,
                        onResultViewChange = { resultView = it },
                        onCopy = {
                            clipboard.setText(AnnotatedString(state.code))
                            onShowSnackbar("Hasil obfuscate disalin ke clipboard.")
                        },
                        onSave = {
                            scope.launch {
                                try {
                                    val fileName = "obfuscated_${System.currentTimeMillis()}.py"
                                    val uri = repository.workspaceManager.saveToDownloads(
                                        fileName,
                                        "text/x-python",
                                        state.code.toByteArray()
                                    )
                                    if (uri != null) {
                                        onShowSnackbar("Tersimpan sebagai $fileName di folder Download/Leviathan.")
                                    } else {
                                        onShowSnackbar("Gagal menyimpan file.")
                                    }
                                } catch (e: Exception) {
                                    onShowSnackbar("Gagal menyimpan file: ${e.message}")
                                }
                            }
                        },
                        onObfuscateAgain = { viewModel.reset() }
                    )
                }

                is PyObfuscatorViewModel.UiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxWidth().heightIn(min = 240.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = BrightCyan)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Memproses obfuscation...", color = MutedGrey, fontSize = 12.sp)
                        }
                    }
                }

                is PyObfuscatorViewModel.UiState.Error -> {
                    InputSection(
                        sourceCode = sourceCode,
                        onSourceCodeChange = { sourceCode = it },
                        options = options,
                        onOptionsChange = { options = it },
                        errorMessage = state.message,
                        onPaste = {
                            clipboard.getText()?.text?.let { pasted ->
                                sourceCode = pasted
                            }
                        },
                        onClear = { sourceCode = "" },
                        onObfuscate = { viewModel.obfuscate(sourceCode, options) }
                    )
                }

                PyObfuscatorViewModel.UiState.Idle -> {
                    InputSection(
                        sourceCode = sourceCode,
                        onSourceCodeChange = { sourceCode = it },
                        options = options,
                        onOptionsChange = { options = it },
                        errorMessage = null,
                        onPaste = {
                            clipboard.getText()?.text?.let { pasted ->
                                sourceCode = pasted
                            }
                        },
                        onClear = { sourceCode = "" },
                        onObfuscate = { viewModel.obfuscate(sourceCode, options) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

// =====================================================================
// INPUT SECTION
// =====================================================================

@Composable
private fun InputSection(
    sourceCode: String,
    onSourceCodeChange: (String) -> Unit,
    options: PyObfuscateClient.Options,
    onOptionsChange: (PyObfuscateClient.Options) -> Unit,
    errorMessage: String?,
    onPaste: () -> Unit,
    onClear: () -> Unit,
    onObfuscate: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BrightCyan.copy(alpha = 0.06f), RoundedCornerShape(8.dp))
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Lock, contentDescription = null, tint = BrightCyan, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "Fitur ini hanya menerima source Python (.py). Kode bahasa lain akan otomatis ditolak.",
                color = BrightCyan,
                fontSize = 11.sp
            )
        }

        OutlinedTextField(
            value = sourceCode,
            onValueChange = onSourceCodeChange,
            label = { Text("Kode Python Asli") },
            placeholder = { Text("Tempel atau ketik kode Python di sini...") },
            isError = errorMessage != null,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 220.dp, max = 340.dp)
                .testTag("input_python_source"),
            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrightCyan,
                unfocusedBorderColor = CyberCardBorder,
                errorBorderColor = BrightRed,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedContainerColor = CyberDarkNavy,
                unfocusedContainerColor = CyberDarkNavy
            ),
            shape = RoundedCornerShape(8.dp)
        )

        if (errorMessage != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BrightRedContainer, RoundedCornerShape(8.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = BrightRed, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(errorMessage, color = BrightRed, fontSize = 12.sp)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = onPaste,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = BrightCyan)
            ) {
                Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Tempel")
            }
            OutlinedButton(
                onClick = onClear,
                enabled = sourceCode.isNotBlank(),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MutedGrey)
            ) {
                Icon(Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Bersihkan")
            }
        }

        ObfuscationOptionsCard(options = options, onOptionsChange = onOptionsChange)

        Button(
            onClick = onObfuscate,
            enabled = sourceCode.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("btn_obfuscate"),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
        ) {
            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Obfuscate Sekarang", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
        }
    }
}

@Composable
private fun ObfuscationOptionsCard(
    options: PyObfuscateClient.Options,
    onOptionsChange: (PyObfuscateClient.Options) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, CyberCardBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                "OPSI OBFUSCATION",
                style = MaterialTheme.typography.labelMedium.copy(color = MutedGrey, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            OptionToggleRow("Rename identifier", "Acak nama variabel & fungsi", options.rename) { onOptionsChange(options.copy(rename = it)) }
            OptionToggleRow("Encrypt string", "Enkripsi literal string", options.encrypt) { onOptionsChange(options.copy(encrypt = it)) }
            OptionToggleRow("Flatten control-flow", "Ratakan struktur alur kontrol", options.flatten) { onOptionsChange(options.copy(flatten = it)) }
            OptionToggleRow("Obfuscate builtins", "Samarkan pemanggilan built-in", options.builtins) { onOptionsChange(options.copy(builtins = it)) }
            OptionToggleRow("Obfuscate imports", "Samarkan nama import module", options.imports) { onOptionsChange(options.copy(imports = it)) }
            OptionToggleRow("Obfuscate attrs", "Samarkan akses atribut/property", options.attrs) { onOptionsChange(options.copy(attrs = it)) }
            OptionToggleRow("Junk code", "Sisipkan kode pengecoh", options.junk) { onOptionsChange(options.copy(junk = it)) }
        }
    }
}

@Composable
private fun OptionToggleRow(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Text(subtitle, color = MutedGrey, fontSize = 10.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = BrightCyan, checkedThumbColor = CyberBlack)
        )
    }
}

// =====================================================================
// RESULT SECTION (Hasil / Preview Diff)
// =====================================================================

@Composable
private fun ResultSection(
    state: PyObfuscatorViewModel.UiState.Success,
    resultView: ResultView,
    onResultViewChange: (ResultView) -> Unit,
    onCopy: () -> Unit,
    onSave: () -> Unit,
    onObfuscateAgain: () -> Unit
) {
    val diff = remember(state.originalCode, state.code) {
        LineDiffer.diffLines(state.originalCode, state.code)
    }
    val stats = remember(diff) { LineDiffer.stats(diff) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BrightGreenContainer, RoundedCornerShape(8.dp))
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BrightGreen, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Obfuscation berhasil.", color = BrightGreen, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }

        if (state.metrics != null) {
            MetricsRow(state.metrics)
        }

        // ------------------------------------------------------------
        // TOGGLE: Hasil vs Preview Diff
        // ------------------------------------------------------------
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CyberSurfaceVariant)
                .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp))
                .padding(3.dp)
        ) {
            ResultToggleTab(
                label = "Hasil",
                icon = Icons.Default.Terminal,
                selected = resultView == ResultView.HASIL,
                modifier = Modifier.weight(1f)
            ) { onResultViewChange(ResultView.HASIL) }
            ResultToggleTab(
                label = "Preview Diff",
                icon = Icons.Default.Difference,
                selected = resultView == ResultView.DIFF,
                modifier = Modifier.weight(1f)
            ) { onResultViewChange(ResultView.DIFF) }
        }

        when (resultView) {
            ResultView.HASIL -> HasilView(code = state.code)
            ResultView.DIFF -> DiffPreviewView(diff = diff, stats = stats)
        }

        if (state.diagnostics.isNotEmpty()) {
            DiagnosticsCard(state.diagnostics)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onCopy,
                modifier = Modifier.weight(1f).height(46.dp).testTag("btn_copy_result"),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrightCyan, contentColor = CyberBlack)
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Salin", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
            }
            Button(
                onClick = onSave,
                modifier = Modifier.weight(1f).height(46.dp).testTag("btn_save_result"),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrightGreen, contentColor = CyberBlack)
            ) {
                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Simpan .py", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
            }
        }

        OutlinedButton(
            onClick = onObfuscateAgain,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MutedGrey)
        ) {
            Text("Obfuscate Kode Lain")
        }
    }
}

@Composable
private fun ResultToggleTab(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) BrightCyan.copy(alpha = 0.14f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = if (selected) BrightCyan else MutedGrey, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            label,
            color = if (selected) BrightCyan else MutedGrey,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun HasilView(code: String) {
    OutlinedTextField(
        value = code,
        onValueChange = {},
        readOnly = true,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 260.dp, max = 420.dp)
            .testTag("output_obfuscated_code"),
        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = BrightCyan,
            unfocusedBorderColor = CyberCardBorder,
            focusedTextColor = Color(0xFFE5E7EB),
            unfocusedTextColor = Color(0xFFE5E7EB),
            focusedContainerColor = CyberDarkNavy,
            unfocusedContainerColor = CyberDarkNavy
        ),
        shape = RoundedCornerShape(8.dp)
    )
}

@Composable
private fun DiffPreviewView(diff: List<LineDiffer.DiffLine>, stats: LineDiffer.DiffStats) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DiffStatChip("+${stats.added}", BrightGreen)
            DiffStatChip("-${stats.removed}", BrightRed)
            DiffStatChip("${stats.unchanged} sama", MutedGrey)
        }

        Card(
            modifier = Modifier.fillMaxWidth().border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp)),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(10.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 260.dp, max = 480.dp)
                    .padding(vertical = 8.dp)
                    .testTag("diff_preview_list")
            ) {
                items(diff) { line -> DiffLineRow(line) }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.CompareArrows, contentDescription = null, tint = MutedGrey, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                "Hijau = baris ditambahkan/hasil obfuscate · Merah = baris asli yang diganti · Abu = tidak berubah",
                color = MutedGrey,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun DiffStatChip(label: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.14f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DiffLineRow(line: LineDiffer.DiffLine) {
    val (bg, marker, textColor) = when (line.type) {
        LineDiffer.LineType.ADDED -> Triple(BrightGreenContainer, "+", Color(0xFFBBF7D0))
        LineDiffer.LineType.REMOVED -> Triple(BrightRedContainer, "-", Color(0xFFFECACA))
        LineDiffer.LineType.SAME -> Triple(Color.Transparent, " ", Color(0xFF9CA3AF))
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(bg)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp, vertical = 2.dp)
    ) {
        Text(
            text = marker,
            color = textColor,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            modifier = Modifier.width(14.dp)
        )
        Text(
            text = line.text.ifEmpty { " " },
            color = textColor,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun MetricsRow(metrics: PyObfuscateClient.Metrics) {
    val metricItems = listOfNotNull(
        metrics.inputBytes?.let { "Input" to "$it B" },
        metrics.outputBytes?.let { "Output" to "$it B" },
        metrics.astNodes?.let { "AST Nodes" to "$it" },
        metrics.stringsEncoded?.let { "String Enc." to "$it" }
    )
    if (metricItems.isEmpty()) return

    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(metricItems) { (label, value) ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
            ) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Text(label, color = MutedGrey, fontSize = 9.sp)
                    Text(value, color = BrightCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun DiagnosticsCard(diagnostics: List<PyObfuscateClient.Diagnostic>) {
    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, BrightAmber.copy(alpha = 0.4f), RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("CATATAN SERVER", color = BrightAmber, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            diagnostics.forEach { diag ->
                Text(
                    "• ${diag.severity?.uppercase().orEmpty()} ${diag.code.orEmpty()}: ${diag.message.orEmpty()}".trim(),
                    color = Color(0xFFE5E7EB),
                    fontSize = 11.sp
                )
            }
        }
    }
}
