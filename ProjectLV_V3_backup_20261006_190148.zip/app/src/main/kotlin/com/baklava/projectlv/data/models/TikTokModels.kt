package com.baklava.projectlv.data.models

data class TikTokMediaInfo(
    val author: String? = null,
    val caption: String? = null,
    val duration: String? = null,
    val likeCount: String? = null,
    val commentCount: String? = null,
    val shareCount: String? = null,
    val playCount: String? = null,
    val videoUrl: String? = null,
    /** Direct HD stream used by the in-app preview/player (from the HD web resolver). */
    val videoHdUrl: String? = null,
    /** Download endpoint for the best stream selected by the HD web resolver. */
    val videoHdDownloadUrl: String? = null,
    /** True when the resolver returned a real hdplay stream; false means it fell back to play. */
    val hasNativeHd: Boolean = false,
    val mp3Url: String? = null,
    val itemId: String? = null,
    val coverUrl: String? = null
)

data class DownloadFormatOption(
    val id: String,
    val label: String,
    val url: String,
    val extension: String
)

/** Satu opsi kualitas video/audio dari hasil ekstraksi YouTube. */
data class YoutubeFormatOption(
    val quality: Int,
    val label: String,
    val url: String,
    val isAudioOnly: Boolean
)

data class YoutubeMediaInfo(
    val title: String? = null,
    /** Original YouTube URL used to refresh short-lived download endpoints. */
    val sourceUrl: String? = null,
    val duration: String? = null,
    val thumbnailUrl: String? = null,
    val formats: List<YoutubeFormatOption> = emptyList()
) {
    /** URL kualitas tertinggi (HD) di antara format video (non-audio), dipakai sebagai preview player. */
    val previewVideoUrl: String?
        get() = formats.filter { !it.isAudioOnly }.maxByOrNull { it.quality }?.url
}

data class DriveMediaInfo(
    val name: String? = null,
    val downloadUrl: String? = null,
    val sourceLink: String? = null
)
