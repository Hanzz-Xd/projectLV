package com.baklava.projectlv.ui.modules.pterodactyl

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baklava.projectlv.data.pterodactyl.PterodactylPanelResult
import com.baklava.projectlv.data.pterodactyl.PterodactylWhatsAppApi
import com.baklava.projectlv.ui.components.AppWindowSize
import com.baklava.projectlv.ui.components.Button
import com.baklava.projectlv.ui.components.Card
import com.baklava.projectlv.ui.components.ModuleHeaderCard
import com.baklava.projectlv.ui.theme.BrightGreen
import com.baklava.projectlv.ui.theme.BrightRed
import com.baklava.projectlv.ui.theme.BrightCyan
import com.baklava.projectlv.ui.theme.CyberBlack
import com.baklava.projectlv.ui.theme.CyberCardBorder
import com.baklava.projectlv.ui.theme.CyberDarkNavy
import com.baklava.projectlv.ui.theme.CyberSurfaceVariant
import com.baklava.projectlv.ui.theme.MutedGrey
import kotlinx.coroutines.launch

@Composable
fun PterodactylWhatsAppScreen(
    windowSize: AppWindowSize,
    onShowSnackbar: (String) -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val api = remember { PterodactylWhatsAppApi() }

    var username by remember { mutableStateOf("") }
    var serverName by remember { mutableStateOf("") }
    var ram by remember { mutableStateOf("100000") }
    var disk by remember { mutableStateOf("100000") }
    var isCreating by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<PterodactylPanelResult?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    fun copy(value: String, label: String) {
        clipboard.setText(AnnotatedString(value))
        onShowSnackbar("$label berhasil disalin.")
    }

    fun openUrl(url: String) {
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addCategory(Intent.CATEGORY_BROWSABLE)
                }
            )
        }.onFailure {
            onShowSnackbar("Tidak ada browser yang dapat membuka link.")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack)
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ModuleHeaderCard(
            icon = Icons.Default.Cloud,
            title = "cPANEL PTERODACTYL",
            subtitle = "Create Pterodactyl Panel Free"
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = null,
                        tint = BrightGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "cPANEL PTERODACTYL",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    )
                }

                Text(
                    text = "Buat cPanel Pterodactyl gratis untuk keperluan bot WhatsApp, ini di buat secara gratis jadi gunakan dengan bijak (dilarang memperjualbelikan cPanel ini)",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MutedGrey,
                        lineHeight = 17.sp
                    )
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(CyberSurfaceVariant)
                        .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "RESOURCE FREE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = BrightCyan,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "RAM 1–100000 MB  •  DISK 1–100000 MB",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = username,
                    onValueChange = {
                        username = it.take(32)
                        error = null
                    },
                    label = { Text("Username") },
                    placeholder = { Text("contoh: Hanz") },
                    singleLine = true,
                    enabled = !isCreating,
                    modifier = Modifier.fillMaxWidth().testTag("input_pterodactyl_username"),
                    colors = fieldColors(),
                    shape = RoundedCornerShape(8.dp)
                )

                OutlinedTextField(
                    value = serverName,
                    onValueChange = {
                        serverName = it.take(48)
                        error = null
                    },
                    label = { Text("Nama Server") },
                    placeholder = { Text("WhatsApp Bot") },
                    singleLine = true,
                    enabled = !isCreating,
                    modifier = Modifier.fillMaxWidth().testTag("input_pterodactyl_server_name"),
                    colors = fieldColors(),
                    shape = RoundedCornerShape(8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = ram,
                        onValueChange = {
                            ram = it.filter(Char::isDigit).take(6).let { value ->
                                value.toIntOrNull()?.coerceAtMost(100000)?.toString() ?: value
                            }
                            error = null
                        },
                        label = { Text("RAM (MB)") },
                        placeholder = { Text("100000") },
                        singleLine = true,
                        enabled = !isCreating,
                        modifier = Modifier.weight(1f).testTag("input_pterodactyl_ram"),
                        colors = fieldColors(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = disk,
                        onValueChange = {
                            disk = it.filter(Char::isDigit).take(6).let { value ->
                                value.toIntOrNull()?.coerceAtMost(100000)?.toString() ?: value
                            }
                            error = null
                        },
                        label = { Text("Disk (MB)") },
                        placeholder = { Text("100000") },
                        singleLine = true,
                        enabled = !isCreating,
                        modifier = Modifier.weight(1f).testTag("input_pterodactyl_disk"),
                        colors = fieldColors(),
                        shape = RoundedCornerShape(8.dp)
                    )
                }

                Text(
                    text = "Maks Ram & Disk 1–100000 MB",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MutedGrey,
                        lineHeight = 15.sp
                    )
                )

                Button(
                    onClick = {
                        val cleanUsername = username.trim()
                        val cleanServerName = serverName.trim()
                        val ramMb = ram.toIntOrNull()
                        val diskMb = disk.toIntOrNull()

                        when {
                            cleanUsername.length < 3 -> {
                                error = "Username minimal 3 karakter."
                                return@Button
                            }
                            !cleanUsername.matches(Regex("^[A-Za-z0-9._-]+$")) -> {
                                error = "Username hanya boleh berisi huruf, angka, titik, garis bawah, dan tanda minus."
                                return@Button
                            }
                            cleanServerName.length < 3 -> {
                                error = "Nama server minimal 3 karakter."
                                return@Button
                            }
                            ramMb == null || ramMb !in 1..100000 -> {
                                error = "RAM harus antara 1 sampai 100000 MB."
                                return@Button
                            }
                            diskMb == null || diskMb !in 1..100000 -> {
                                error = "Disk harus antara 1 sampai 100000 MB."
                                return@Button
                            }
                        }

                        scope.launch {
                            isCreating = true
                            result = null
                            error = null

                            api.createPanel(
                                username = cleanUsername,
                                serverName = cleanServerName,
                                ram = ramMb!!,
                                disk = diskMb!!
                            ).onSuccess {
                                result = it
                                onShowSnackbar("cPanel Pterodactyl berhasil dibuat.")
                            }.onFailure {
                                error = it.message ?: "Gagal membuat panel."
                                onShowSnackbar("Gagal membuat cPanel Pterodactyl.")
                            }

                            isCreating = false
                        }
                    },
                    enabled = !isCreating,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("btn_create_pterodactyl_whatsapp"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BrightGreen,
                        contentColor = CyberBlack
                    )
                ) {
                    if (isCreating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = CyberBlack,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Cloud,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(7.dp))
                        Text(
                            text = "CREATE PANEL GRATIS",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                error?.let {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(BrightRed.copy(alpha = 0.10f))
                            .border(
                                1.dp,
                                BrightRed.copy(alpha = 0.35f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(10.dp)
                    ) {
                        Text(
                            text = it,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = BrightRed,
                                lineHeight = 17.sp
                            )
                        )
                    }
                }
            }
        }

        result?.let { panel ->
            PanelResultCard(
                panel = panel,
                onCopy = ::copy,
                onOpen = ::openUrl
            )
        }

        Text(
            text = "Gunakan cPanel Petrodytl untuk keperluan instalasi bot WhatsApp",
            style = MaterialTheme.typography.labelSmall.copy(
                color = MutedGrey,
                lineHeight = 15.sp
            ),
            modifier = Modifier.padding(horizontal = 2.dp)
        )
    }
}

@Composable
private fun PanelResultCard(
    panel: PterodactylPanelResult,
    onCopy: (String, String) -> Unit,
    onOpen: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberDarkNavy),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCardBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = BrightGreen,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "PANEL BERHASIL DIBUAT",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = BrightGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                )
            }

            PanelValueRow("Panel", panel.panelUrl, onCopy)
            PanelValueRow("Login", panel.loginUrl, onCopy)
            PanelValueRow("Email", panel.email, onCopy)
            PanelValueRow("Username", panel.username, onCopy)
            PanelValueRow("Password", panel.password, onCopy)
            PanelValueRow("Server", panel.serverName, onCopy)
            panel.serverIdentifier?.let { PanelValueRow("Identifier", it, onCopy) }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { onOpen(panel.loginUrl) },
                    modifier = Modifier.weight(1f).testTag("btn_open_pterodactyl_login"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BrightCyan,
                        contentColor = CyberBlack
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text("BUKA PANEL", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { onCopy(panel.password, "Password") },
                    modifier = Modifier.weight(1f).testTag("btn_copy_pterodactyl_password"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberSurfaceVariant,
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text("SALIN PASSWORD", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PanelValueRow(
    label: String,
    value: String,
    onCopy: (String, String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = MutedGrey,
                fontWeight = FontWeight.Bold
            )
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(7.dp))
                .background(CyberBlack)
                .border(1.dp, CyberCardBorder, RoundedCornerShape(7.dp))
                .padding(start = 9.dp, top = 7.dp, bottom = 7.dp, end = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color.White,
                    fontWeight = if (label == "Password") FontWeight.Bold else FontWeight.Normal,
                    fontSize = 12.sp
                ),
                modifier = Modifier.weight(1f)
            )
            androidx.compose.material3.IconButton(
                onClick = { onCopy(value, label) },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Salin $label",
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = BrightGreen,
    unfocusedBorderColor = CyberCardBorder,
    focusedLabelColor = BrightGreen,
    unfocusedLabelColor = MutedGrey,
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    disabledTextColor = MutedGrey,
    focusedContainerColor = CyberBlack,
    unfocusedContainerColor = CyberBlack
)
